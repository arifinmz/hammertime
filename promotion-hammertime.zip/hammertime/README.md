# Hammertime
Load testing and performance analysis tools from Team Dexter that supports only python2.

This project contains of 3 main folders:
- tests (list of all test will be put inside here, it will call some of tasks from the `Modules` folder)
    - pages (test by page)
        - home.py
        - pdp.py
        - ...
    - modules (test by modules)
        - mojito.py
        - ace.py
        - ...
- modules (contain all function to call the API inside their own repositories)
    - mojito.py
    - ace.py
    - hoth.py
    - ...
- libs (contains all the library or third party used for running the test)
    - tkpdhmac.py

### Installation
#### Installation For Linux and MacOS
1. Clone this repo: `git clone https://github.com/tokopedia/dexter`
2. Open terminal and go to `hammertime` directory
3. Skip step 4 to 6 if you have run the command on step 4
4. Run `chmod +x setup.sh && sh setup.sh && source ~/.bashrc` to add the **hammertime** into pythonpath
5. Skip step 6 if you are not using virtual environment
6. Step 4 will turn off your virtual environment, you need to activate your virtual environment again
7. Install dependencies for this project by run `python setup.py install`
8. Done!

#### Installation For Windows
This steps are intended for Windows 10 users. 
First, you need to install Linux Bash Shell on Windows.
It allows you to run Linux applications directly on Windows. It’s intended for developers who want to run Linux command-line utilities on Windows. 
These applications get access to the Windows file system, but you can’t use Bash commands to automate normal Windows programs, or launch Bash commands from the standard Windows command-line. They get access to the same Windows file system, but that’s it. Not every command-line application will work, either, as this feature is still in beta.

1. Ensure you’ve installed the Windows 10 Anniversary Update. This only works on 64-bit builds of Windows 10. If you use 32-bit version, it’s must be switch to 64-bit version (https://www.howtogeek.com/228042/how-to-switch-from-32-bit-windows-10-to-64-bit-windows-10/).
2. Once you’re sure using the correct version of Windows 10, open Settings app and go to “Update & Security” > “For developers”. Activate the “Developer mode” to enable developer mode.
3. Open Control Panel, click “Programs”, and click “Turn Windows Features On or Off” under Programs and Features. Enable the “Windows Subsystem for Linux (Beta)” option in the list and click “OK”.You’ll be prompted to reboot your computer. Click “Restart now” to reboot your computer and Windows 10 will install the new feature.
4. After done restarting, click the Start button or press the Windows key, type “bash” on the search bar and press “Enter”.
5. The action will open a window and you’ll be prompted to accept the terms of service. The command will then download the “Bash on Ubuntu on Windows” application from the Windows Store. You’ll be asked to create a user account and password for use in the Bash environment. And voila! The bash is ready to be used.

Next, install the hammertime project.
1. Clone this repo: `git clone https://github.com/tokopedia/dexter`
2. After the cloning is done, open Bash on Ubuntu on Windows. Click the Start button or press the Windows key, type “ubuntu” on the search bar and press “Enter”.
3. Check whether python have been installed or not by running `python --version`. If there is message “bash: python: command not found”, you need to install Python. Run `sudo apt-get update` then `sudo apt install python-minimal` to install it.
4. Run `sudo apt install pip` to install pip (it is package management system used to install and manage software packages written in Python).
5. Run `cd /mnt` so that you can access Windows directory through the bash
6. Go to hammertime directory.
7. Run `chmod +x setup.sh && sh setup.sh && source ~/.bashrc` to add hammertime into pythonpath.
8. Install dependencies for this project by running `python setup.py install --user`.
If you want to make changes inside hammertime project, run `pip uninstall hammertime`.

### File Naming
File naming is using snakecase. Write the filename using lower case and every word is separated with underscore. For Example `product_page.py`

### Function Naming
Write the function name with lower case. Define everything in endpoint including the version and the method, but not the parameters. Every slash `/` is changed with underscore `_`. If there are parameters like id in the endpoint, change it with `P` in uppercase. Put the version if the endpoint has version number. For version with point `.`, change it with underscore.
For example: endpoint `/v1.4/users/5480842/wishlist` will be translated to `def users_P_wishlist_v1_4`

### Function's Parameter
For value which is required for endpoint's path or required for generating HMAC, the value must be thrown to a function as required parameter (not being put inside args or kwargs). Example of the values are user id, shop id, os type, and device id.

### Endpoint Naming
The endpoint name will be shown on locust web UI so it is needed to uniform the naming style.
1. Start name it from the domain (eq. https://www.tokopedia.com)
2. For the query on the endpoint, write it all except for dynamic datas (eq. token, timestamp)

### Run Test at Elastic Beanstalk from AWS Console
1. Login to your elastic beanstalk AWS console at https://us-east-2.console.aws.amazon.com/elasticbeanstalk/ .
2. Please note that this instruction is using latest UI Design for elastic beanstalk.
3. Create new application with name `hammertime` if it doesn't exist yet.
4. Create new environment under the hammertime application.
5. Choose `Web Server Environment` tier since our hammertime has website to be accessed.
6. Environment information section
    1. Name your environment and domain.
7. Base configuration section
    1. Choose `Java` as your platform.
    2. For application code, choose `Upload your code` if you haven't upload you application source code. Upload .zip of your hammertime and give the version labels's name. Or you can choose `Existing version` if you have uploaded your Application source code.
8. Click `Configure more options` button.
9. Software configuration
    1. Click on `Modify` link at `Software` configuration section.
    2. Go to `Environment properties` section.
    3. Add `TEST_FILE` property and fill the value with the desired test file(s) path like `tests/pages/android/home.py` or `tests/pages/desktop/`.
    4. Add `OPTION` property to add more options for your test. ex : `--ramp` for auto adjustment of simulated users.
    5. Add `COOKIE` property to pass your cookie for the test.
    6. Click on `Save` button.
10. Instances configuration
    1. Click on `Modify` link at `Instances` configuration section
    2. Choose instance type base on your need.
    3. Click on `Save` button.
11. Capacity configuration
    1. Click on `Modify` link at `Capacity` configuration section.
    2. Choose `Load Balanced` for Environment type.
    3. Adjust your locust instance at `Instance` section. We suggest you to have minimum of 2 instance since the one will be the master, and the others will be the slave. Put same value for `Min` and `Max`.
    4. Click on `Save` button.
12. Security configuration
    1. Click on `Modify` link at `Security` configuration section.
    2. Change your IAM instance profile to `aws-elasticbeanstalk-locust-role`.
    3. If you want to ssh to instance(s), choose your EC2 key pair. This step is optional.
    4. Click on `Save` button.
13. Network configuration
    1. Click on `Modify` link at `Network` configuration section.
    2. Go to `Load balancer settings` section.
    3. On load balacer subnets' table, choose `Public-Subnet-A`and `Public-Subnet-B`.
    4. Go to `Instance settings` section.
    5. On instance subnets' table, choose `Private-Subnet-A` and `Private-Subnet-B`.
    6. On instance security group's table, choose `Internal` group.
    7. Click on `Save` button
14. Finally! Click on `Create environment` button. Wait until all the instance already up, then you can open the domain to start your test.
