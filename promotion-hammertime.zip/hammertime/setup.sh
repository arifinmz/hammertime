location=`pwd`
export_path="export PYTHONPATH=\"\$PYTHONPATH:$location\""
`echo $export_path >> $HOME/.bashrc`
echo "IMPORTED! $export_path"
