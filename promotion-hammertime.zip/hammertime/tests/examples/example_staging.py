from locust import HttpLocust, TaskSet, task
from modules import ace, accounts, ws_v4
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper(bearer_host=accounts.host_staging, login_host=ws_v4.host_staging)

class SearchProductStaging(TaskSet):

    def on_start(self):
        self.config = self.configuration["staging"] 
        self.account = ah.get_account(self)

    @task(1)
    def task1(self):
        search_product_keyword = random.choice(self.config['search']['search_product_keywords'])
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = self.account['user_id']
        platform = 'android'
        headers = {
            'Authorization': ah.get_token(user_id)
        }

        res = ace.search_product_v2_4(self, ace.host_staging, headers=headers, query='device='+platform+'&start=0&shop_id=&rows=12&source=search_product&hashtag=false&-id=&terms=true&image_size=200&fq=&q='+search_product_keyword+'&highlight=&hc=&id=&ob=23&image_square=true&sc=&negative=&user_id='+user_id+'&breadcrumb=true', name=ace.host_staging+'/search/v2.4/product?source=search_product', timeout=timeout, cb_threshold=cb_threshold)
        
class WebsiteUser(HttpLocust):
    host = ""
    task_set = SearchProductStaging
    min_wait = 1500
    max_wait = 2500
