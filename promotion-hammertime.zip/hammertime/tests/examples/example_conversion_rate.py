import random
from locust import HttpLocust, TaskSet, task
from modules import tokopedia, ace
from libs import user_conversion
from tests.pages.android.no_session.product_detail_production import ProductDetailProduction

#instantiate user conversion module
uc = user_conversion.UserConversion()

class TopPicksProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.productDetailProduction = ProductDetailProduction(self)
        self.productDetailProduction.config = self.config       

        #set maximum conversion rate threshold
        global uc
        uc.max_threshold = 0.2

    @task(1)
    def task1(self):
        top_picks = self.config["top_picks"]['data'][random.randint(0,len(self.config["top_picks"]['data'])-1)]

        #access toppicks page as internal test
        res = tokopedia.page(self, tokopedia.host_production, top_picks["link"], name=tokopedia.host_production+"/toppicks")

        #Access PDP with conversion rate
        @uc.attempt(self.runners.user_count)
        def product_detail():
            self.productDetailProduction.task1()
        product_detail()

class WebsiteUser(HttpLocust):
    host = ""
    task_set = TopPicksProduction
    min_wait = 1500
    max_wait = 2500
