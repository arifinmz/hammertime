import random
from locust import HttpLocust, TaskSet, task
from modules import tokopedia, ace
from libs import user_conversion
from tests.pages.android.no_session.product_detail_production import ProductDetailProduction

class TopPicksProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]

        # instantiate the imported test class
        self.productDetailProduction = ProductDetailProduction(self)
        # pass test configuration into imported test's configuration
        self.productDetailProduction.config = self.config       

    @task(1)
    def task1(self):
        top_picks = self.config["top_picks"]['data'][random.randint(0,len(self.config["top_picks"]['data'])-1)]

        #access toppicks page as internal test
        res = tokopedia.page(self, tokopedia.host_production, top_picks["link"], name=tokopedia.host_production+"/toppicks")
        
        # we call a test from another test file
        self.productDetailProduction.task1()

class WebsiteUser(HttpLocust):
    host = ""
    task_set = TopPicksProduction
    min_wait = 1500
    max_wait = 2500
