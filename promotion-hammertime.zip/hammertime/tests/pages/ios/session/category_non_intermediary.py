from locust import HttpLocust, TaskSet, task
from modules import hades, topads, mojito, ace
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class CategoryNonIntermediary(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_APP, os_type='2')

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        device_id = self.config['device_id']
        category_id = random.choice(self.config['category_mapping'].keys())
        department_name = self.config['category_mapping'][category_id]
        platform = 'ios'
        os_type='2'
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        product_ids = str(random.sample(self.config['dexter']['massive_products'], 15))

        headers = {
           'Authorization' : ah.get_token(user_id)
        }

        #Ace
        res = ace.search_product_v2_5(self, ace.host_production, headers=headers, query='breadcrumb=true&department_name={0}&device={1}&device_id={2}&ob=23&os_type={3}&q=&rows=1&sc={4}&source=directory&start=0&type=search_product&user_id={5}'.format(department_name, platform, device_id, os_type, category_id, user_id), timeout=timeout, cb_threshold=cb_threshold, hide_query=True)
                
        #Mojito
        res = mojito.users_P_wishlist_check_P_v1(self, mojito.host_production, user_id, product_ids, name=mojito.host_production+"/v1/users/{user_id}/wishlist/check/{product_ids}", headers=headers, query='device_id={0}&os_type={1}&user_id={2}'.format(device_id, os_type, user_id), timeout=timeout, cb_threshold=cb_threshold)

        #Hades
        res = hades.categories_P_detail_v1(self, hades.host_production, category_id, headers=headers, name=hades.host_production+"/v1/categories/{category_id}/detail", query='device_id={0}&os_type={1}&user_id={2}'.format(device_id, os_type, user_id), timeout=timeout, cb_threshold=cb_threshold)
       
        #Topads
        res = topads.promo_display_ads_v1_2(self, topads.host_production, headers=headers, query='dep_id={0}&device={1}&device_id={2}&ep=headline&item=1&os_type={3}&page=1&src=intermediary&template_id=3%2C4&user_id={4}'.format(category_id, platform, device_id, os_type, user_id), name=topads.host_production+'/promo/v1.1/display/ads?ep=headline', timeout=timeout, cb_threshold=cb_threshold)
        res = topads.promo_display_ads_v1_2(self, topads.host_production, headers=headers, query='dep_id={0}&device={1}&device_id={2}&ep=product&item=2%2C1&os_type={3}&page=0&src=intermediary&user_id={4}'.format(category_id, platform, device_id, os_type, user_id), name=topads.host_production+'/promo/v1.1/display/ads?ep=product', timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ace.host_production
    task_set = CategoryNonIntermediary
    min_wait = 1500
    max_wait = 2500


