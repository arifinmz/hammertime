from locust import HttpLocust, TaskSet, task
from modules import hades, topads, mojito, ace
import random

class CategoryIntermediary(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"] 

    @task(1)
    def task1(self):
        user_id = '0'
        device_id = self.config['device_id']
        category_id = random.choice(self.config['category']['category_id']['all_intermediary'])
        list_category_no_child = self.config['category']['category_id']['category_no_child']              
        platform = 'ios'
        os_type = '2'
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']

        #Ace
        res = ace.search_product_v2_5(self, ace.host_production, query='breadcrumb=true&department_name=&device={0}&device_id={1}&ob=23&os_type={2}&q=&rows=1&sc={3}&source=directory&start=0&type=search_product'.format(platform, device_id, os_type, category_id), timeout=timeout, cb_threshold=cb_threshold, hide_query=True)
        
        if category_id not in list_category_no_child:
            res = ace.hoth_hotlist_category_v1(self, ace.host_production, query='categories={0}&device_id={1}&os_type={2}&perPage=7'.format(category_id, device_id, os_type), timeout=timeout, cb_threshold=cb_threshold, hide_query=True)

        #Mojito
        res = mojito.os_api_brands_category_P_P_v1(self, mojito.host_production, platform, category_id, name=mojito.host_production+"/os/api/v1/brands/category/{platform}/{category_id}", timeout=timeout, cb_threshold=cb_threshold)

        #Hades
        res = hades.categories_P_detail_v1(self, hades.host_production, category_id, name=hades.host_production+"/v1/categories/{category_id}/detail", query='device_id={0}&os_type={1}'.format(device_id, os_type), timeout=timeout, cb_threshold=cb_threshold)

        #Topads
        res = topads.promo_display_ads_v1_2(self, topads.host_production, query='dep_id={0}&device={1}&device_id={2}&ep=headline&item=1&os_type={3}&page=1&src=intermediary&template_id=3%2C4'.format(category_id, platform, device_id, os_type), name=topads.host_production+'/promo/v1.2/display/ads?ep=headline', timeout=timeout, cb_threshold=cb_threshold)
        res = topads.promo_display_ads_v1_2(self, topads.host_production, query='dep_id={0}&device={1}&device_id={2}&ep=product&item=2%2C1&os_type={3}&page=0&src=intermediary'.format(category_id, platform, device_id, os_type), name=topads.host_production+'/promo/v1.2/display/ads?ep=product', timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ace.host_production
    task_set = CategoryIntermediary
    min_wait = 1500
    max_wait = 2500


