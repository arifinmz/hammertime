from locust import HttpLocust, TaskSet, task
from tests.helper.account_helper import AccountHelper
from tests.pages.android.session.home_production import HomeProduction as HomeAndroid
from tests.pages.desktop.session.home_production import HomeProduction as HomeDesktop
from tests.pages.mobile_web.session.home_production import HomeProduction as HomeLite
import random

ah = AccountHelper()

class HomeProductionAll(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_BOTH)
        self.account_lite = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_LITE)

        self.home_android = HomeAndroid(self)
        self.home_desktop = HomeDesktop(self)
        self.home_lite = HomeLite(self)

        self.home_android.config = self.config
        self.home_desktop.config = self.config
        self.home_lite.config = self.config

        self.home_android.account = self.account
        self.home_desktop.account = self.account
        self.home_lite.account = self.account_lite

    @task(50)
    def android(self):
        self.home_android.task1()

    @task(20)
    def desktop(self):
        self.home_desktop.task1()

    @task(10)
    def lite(self):
        self.home_lite.task1()

class WebsiteUser(HttpLocust):
    host = ""
    task_set = HomeProductionAll
    min_wait = 1500
    max_wait = 2500
