from locust import HttpLocust, TaskSet, task
from tests.pages.android.no_session.search_product_production import SearchProductProduction as SearchAndroid
from tests.pages.desktop.no_session.search_product_production import SearchProductProduction as SearchDesktop
import random

class SearchDesktopAndroid(TaskSet):

    def on_start(self):
      self.config = self.configuration["production"]

      self.search_android = SearchAndroid(self)
      self.search_desktop = SearchDesktop(self)

      self.search_android.config = self.config
      self.search_desktop.config = self.config

    @task(4)
    def android(self):
      self.search_android.task1()

    @task(1)
    def desktop(self):
      self.search_desktop.task1()

class WebsiteUser(HttpLocust):
    host = ""
    task_set = SearchDesktopAndroid
    min_wait = 1500
    max_wait = 2500
