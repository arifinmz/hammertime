from locust import HttpLocust, TaskSet, task
from tests.helper.account_helper import AccountHelper
from tests.pages.android.session.product_detail_production import ProductDetailProduction as PDPAndroid
from tests.pages.desktop.session.product_detail_production import ProductDetailProduction as PDPDesktop
from tests.pages.mobile_web.session.product_detail_production import ProductDetailProduction as PDPLite
import random

ah = AccountHelper()

class PDPProductionAll(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account_android = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_APP)
        self.account_desktop = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_BROWSER)
        self.account_lite = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_LITE)

        self.pdp_android = PDPAndroid(self)
        self.pdp_desktop = PDPDesktop(self)
        self.pdp_lite = PDPLite(self)

        self.pdp_android.config = self.config
        self.pdp_desktop.config = self.config
        self.pdp_lite.config = self.config

        self.pdp_android.account = self.account_android
        self.pdp_desktop.account = self.account_desktop
        self.pdp_lite.account = self.account_lite

    @task(30)
    def android(self):
        self.pdp_android.task1()

    @task(10)
    def desktop(self):
        self.pdp_desktop.task1()

    @task(10)
    def lite(self):
        self.pdp_lite.task1()

class WebsiteUser(HttpLocust):
    host = ""
    task_set = PDPProductionAll
    min_wait = 1500
    max_wait = 2500
