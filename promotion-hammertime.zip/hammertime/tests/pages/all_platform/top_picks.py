from locust import HttpLocust, TaskSet, task
from modules import tokopedia, ace, hades, inbox
import random

class TopPicks(TaskSet):
    def on_start(self):
        self.config         = self.configuration["production"]
        self.timeout_page   = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        self.timeout        = (self.config['timeout'][0],self.config['timeout'][1])
        self.cb_threshold   = self.config["cb_threshold"]

    @task(15)
    def android_app(self):
        top_picks = self.config["top_picks"]["search_keys"][random.randint(0, len(self.config["top_picks"]['search_keys'])-1)]

        res = ace.hoth_discovery_api_page_P(self, ace.host_production, top_picks["key"], name=ace.host_production+"/hoth/discovery/api/page/{search_key}", timeout=self.timeout, cb_threshold=self.cb_threshold)

    @task(5)
    def desktop(self):
        top_picks = self.config["top_picks"]["search_keys"][random.randint(0, len(self.config["top_picks"]['search_keys'])-1)]

        res = tokopedia.page(self, tokopedia.host_production, "/discovery/"+top_picks["key"], name=tokopedia.host_production+"/discovery/{search_key}", timeout=self.timeout_page, cb_threshold=self.cb_threshold)
    
        if "category_key" in top_picks:
            res = hades.categories_P_v1(self, hades.host_production, top_picks["category_key"], query="filter=type==tree", name=hades.host_production+"/v1/categories/{category_key}", timeout=self.timeout, cb_threshold=self.cb_threshold)
            
        if "query_search_v3" in top_picks:
            query = top_picks["query_search_v3"][random.randint(0, len(top_picks["query_search_v3"])-1)]
            res = ace.search_product_v3(self, ace.host_production, query=query, name=ace.host_production+"/search/product/v3", timeout=self.timeout, cb_threhold=self.cb_threshold)

        if "shop_ids" in top_picks:
            shop_id = top_picks["shop_ids"][random.randint(0, len(top_picks["shop_ids"])-1)]
            res = inbox.reputation_badge_shop_P_v1(self, inbox.host_production, shop_id, name=inbox.host_production+"/reputation/v1/badge/shop/{shop_id}", timeout=self.timeout, cb_threshold=self.cb_threshold)

    @task(1)
    def lite(self):
        top_picks = self.config["top_picks"]["search_keys"][random.randint(0, len(self.config["top_picks"]['search_keys'])-1)]

        res = tokopedia.page(self, tokopedia.host_production_m, "/discovery/"+top_picks["key"], name=tokopedia.host_production_m+"/discovery/{search_key}", timeout=self.timeout_page, cb_threshold=self.cb_threshold)

        if "query_search_v3" in top_picks:
            query = top_picks["query_search_v3"][random.randint(0, len(top_picks["query_search_v3"])-1)]
            res = ace.search_product_v3(self, ace.host_production, query=query, name=ace.host_production+"/search/product/v3", timeout=self.timeout, cb_threhold=self.cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = TopPicks
    min_wait = 1500
    max_wait = 2500