from locust import HttpLocust, TaskSet, task
from modules import tokopedia, hades
import random


class CategoryProduction(TaskSet):

    def on_start(self):
        if not hasattr(CategoryProduction, 'config_loaded') :
                CategoryProduction.test_config = self.configuration["production"]
                CategoryProduction.config_loaded = True

    @task(1)
    def task1(self):
        category_id = random.choice(CategoryProduction.test_config['category']['category_id']['all_intermediary'])         
        timeout = (CategoryProduction.test_config['timeout'][0],CategoryProduction.test_config['timeout'][1])
        cb_threshold = CategoryProduction.test_config['cb_threshold']
        
        headers = {
            'X-Device':'desktop'
        }


        #Get All Categories
        res = hades.categoriesFilter_v1(self, hades.host_production, query="filter=type%3D%3Dtree", timeout=timeout, cb_threshold=cb_threshold)

        #Get All Categories by ID
        res = hades.categories_v0_P(self, hades.host_production, category_id, name=hades.host_production+"/v0/categories/{category_id}", timeout=timeout, cb_threshold=cb_threshold)

        #Get All Category Detail by ID
        res = hades.categories_P_detail_v1(self, hades.host_production, category_id, name=hades.host_production+"/v1/categories/{category_id}/detail", timeout=timeout, cb_threshold=cb_threshold)
        res = hades.categories_P_detail_v2(self, hades.host_production, category_id, name=hades.host_production+"/v2/categories/{category_id}/detail", timeout=timeout, cb_threshold=cb_threshold)
        res = hades.categories_P_detail_v3(self, hades.host_production, category_id, name=hades.host_production+"/v3/categories/{category_id}/detail", headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        
        #Get Category layout by ID
        res = hades.categoriesLayout_v1_P(self, hades.host_production, category_id, name=hades.host_production+"/v1/category_layout/{category_id}", timeout=timeout, cb_threshold=cb_threshold)

        #Get Categories Version
        res = hades.categoriesVersion2_v1(self, hades.host_production, timeout=timeout, cb_threshold=cb_threshold)

        # #Get Categories with Features by ID
        res = hades.categoriesFeatures_v2_P(self, hades.host_production, category_id, name=hades.host_production+"/v2/categories/{category_id}/features", timeout=timeout, cb_threshold=cb_threshold)

        #Get Categories Image Sample by ID
        res = hades.categoriesImageSample_v1_P(self, hades.host_production, category_id, name=hades.host_production+"/v1/categories/{category_id}/image_sample", timeout=timeout, cb_threshold=cb_threshold)

        # #Get Categories Description by ID
        res = hades.categoriesDescription_v2_P(self, hades.host_production, category_id, name=hades.host_production+"/v2/categories/{category_id}/description", timeout=timeout, cb_threshold=cb_threshold)

        #Get Categories Curated by ID
        res = hades.categoryCuratedGet_v1_P(self, hades.host_production, category_id, name=hades.host_production+"/v1/category_curated/get/{category_id}", timeout=timeout, cb_threshold=cb_threshold)

        #Get Categories Breadcrumb
        res = hades.categoriesBreadcrumb_v1_P(self, hades.host_production, category_id, name=hades.host_production+"/v1/categories/{category_id}?filter=type==list%3Blevel==breadcrumb", timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = CategoryProduction
    min_wait = 1500
    max_wait = 2500

