from locust import HttpLocust, TaskSet, task
from modules import tokopedia
import random


class HotlistProduction(TaskSet):

   def on_start(self):
       
       self.config = self.configuration["production"]

   @task(1)
   def task1(self):
       timeout = (self.config['timeout'][0],self.config['timeout'][1])
       cb_threshold = self.config['cb_threshold']
       hot_name = random.choice(self.config['hotlist_alias'])

    
       res = tokopedia.hot_P(self, tokopedia.host_production, hot_name, name=tokopedia.host_production+"/hot/{hot_name}", timeout=timeout, cb_threshold=cb_threshold)
       res = tokopedia.hot_P(self, tokopedia.host_production_m, hot_name, name=tokopedia.host_production_m+"/hot/{hot_name}", timeout=timeout, cb_threshold=cb_threshold)
       res = tokopedia.hot(self, tokopedia.host_production, timeout=timeout, cb_threshold=cb_threshold)
       res = tokopedia.hot(self, tokopedia.host_production_m, timeout=timeout,cb_threshold=cb_threshold)


       
     
class WebsiteUser(HttpLocust):
   host = ""
   task_set = HotlistProduction
   min_wait = 1500
   max_wait = 2500