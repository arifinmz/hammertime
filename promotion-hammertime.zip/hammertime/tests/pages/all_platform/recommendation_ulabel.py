from locust import HttpLocust, TaskSet, task
from modules import tokopedia, ace
from random import randint




class RecommendationProduction(TaskSet):

   def on_start(self):
       
       self.config = self.configuration["production"]


   @task(1)
   def task1(self):
       timeout = (self.config['timeout'][0],self.config['timeout'][1])
       cb_threshold = self.config['cb_threshold']
       user_id = str(randint(15000000,25000000))
    
       res = ace.r3_ulabel_v1(self, ace.host_production, user_id, name=ace.host_production+"/r3/v1/ulabel?user_id={user_id}&label=category1,category2,category3,location,user_gender,cluster,price_level&xsource=engine&xdevice=loadtest", timeout=timeout, cb_threshold=cb_threshold)
       
class WebsiteUser(HttpLocust):
   host = ""
   task_set = RecommendationProduction
   min_wait = 1500
   max_wait = 2500