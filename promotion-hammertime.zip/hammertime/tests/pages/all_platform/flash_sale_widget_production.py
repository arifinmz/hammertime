from locust import HttpLocust, TaskSet, task
from modules import tokopedia, mojito, graphql

class FlashSaleWidget(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"]

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']

        headers = {
            'x-device':'desktop-0.0'
        }
        res = mojito.api_channel_v1(self, mojito.host_production, headers=headers,timeout=timeout, cb_threshold=cb_threshold)
        
    @task(1)
    def task2(self):
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']

        res = graphql.graphql_flashSaleWidget(self, graphql.host_graphql, method='POST', timeout=timeout_graphql, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = FlashSaleWidget
    min_wait = 1500
    max_wait = 2500