from locust import HttpLocust, TaskSet, task
from modules import ace
import random




class DiscoveryPageProduction(TaskSet):

   def on_start(self):
       if not hasattr(DiscoveryPageProduction, 'config_loaded') :
                DiscoveryPageProduction.test_config = self.configuration["production"]
                DiscoveryPageProduction.config_loaded = True


   @task(1)
   def task1(self):
       timeout = (DiscoveryPageProduction.test_config['timeout'][0],DiscoveryPageProduction.test_config['timeout'][1])
       cb_threshold = DiscoveryPageProduction.test_config['cb_threshold']
       product = DiscoveryPageProduction.test_config['products'][random.randint(0,(len(DiscoveryPageProduction.test_config['products']) - 1))]
       product_id = product['id'] 
       dictionary = DiscoveryPageProduction.test_config["top_picks"]["identifier_mapping"][random.randint(0, len(DiscoveryPageProduction.test_config["top_picks"]['identifier_mapping'])-1)]
       identifier = dictionary.keys()[0]
       component_id = dictionary[identifier]
       

      
       # Hoth Get API Page
       res = ace.hoth_discovery_api_page_P(self, ace.host_production, identifier, name=ace.host_production+"/hoth/discovery/api/page/{identifier}", timeout=timeout, cb_threshold=cb_threshold)

       # Hoth Get API Component
       res = ace.hoth_discovery_api_component_P(self, ace.host_production, identifier, component_id,  name=ace.host_production+"/hoth/discovery/api/component/{identifier}/{component_id}", timeout=timeout, cb_threshold=cb_threshold)

       # Hoth API Page Desktop
       res = ace.hoth_page_P(self, ace.host_production, identifier, name=ace.host_production+"/hoth/page/{identifier}", timeout=timeout, cb_threshold=cb_threshold)

       # Hoth API Page Mobile
       res = ace.hoth_page_mobile_P(self, ace.host_production, identifier, name=ace.host_production+"/hoth/mobile_page/{identifier}", timeout=timeout, cb_threshold=cb_threshold)

       # Hoth API Render Component Desktop
       res = ace.hoth_discovery_render_component_desktop_P(self, ace.host_production, identifier, component_id, name=ace.host_production+"/hoth/discovery/render/component/desktop/{identifier}/{component_id}", timeout=timeout, cb_threshold=cb_threshold)

       # Hoth API Render Component Mobile
       res = ace.hoth_discovery_render_component_mobile_P(self, ace.host_production, identifier, component_id, name=ace.host_production+"/hoth/discovery/render/component/mobile/{identifier}/{component_id}", timeout=timeout, cb_threshold=cb_threshold)
       


      

class WebsiteUser(HttpLocust):
   host = ""
   task_set = DiscoveryPageProduction
   min_wait = 1500
   max_wait = 2500