from locust import HttpLocust, TaskSet, task
from modules import tokopedia, graphql
import random

class OsProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]

    @task(1)
    def task1(self):
        shop = random.choice(self.config['merchant']['os'])
        shop_id = shop['id']   
        shop_domain = shop['shop_domain']

        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']

        #shop page
        res = tokopedia.page(self, tokopedia.host_production_m, "/"+shop_domain, name=tokopedia.host_production_m+"/{shop_domain}", timeout=timeout_page, cb_threshold=cb_threshold)

        #graphql
        res = graphql.graphql_shopFollowers(self, graphql.host_graphql, json={"operationName":"shopFollowers","variables":{"shopID":shop_id,"page":1,"perPage":10}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_shopSummaryQuery(self, graphql.host_graphql, json={"operationName":"ShopSummaryQuery","variables":{"toShopId":shop_id}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_ssiOfficialStoreQuery(self, graphql.host_graphql, json={"operationName":"SSIOfficialStoreQuery","variables":{"domain":shop_domain}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_updateProductList(self, graphql.host_graphql, json={"operationName":"updateProductList","variables":{"userID":None,"shopID":shop_id,"filter":{"ob":1},"page":1,"perPage":10,"etalase":"all","query":"","useace":True,"isOfficial":True}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_shopCheckFavorite(self, graphql.host_graphql, json={"operationName":"shopCheckFavorite","variables":{"userID":0,"shopID":shop_id}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_isAuthenticatedQuery(self, graphql.host_graphql, json={"operationName":"isAuthenticatedQuery","variables":{"key":shop_domain}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_shopTopChatQuery(self, graphql.host_graphql, json={"operationName":"ShopTopChatQuery","variables":{"toShopId":shop_id}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_shopFeaturedProduct(self, graphql.host_graphql, json={"operationName":"shopFeaturedProduct","variables":{"shopID":shop_id}}, timeout=timeout_graphql, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = tokopedia.host_production_m
    task_set = OsProduction
    min_wait = 3000
    max_wait = 5000