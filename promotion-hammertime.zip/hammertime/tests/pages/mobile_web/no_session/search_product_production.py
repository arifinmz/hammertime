from locust import HttpLocust, TaskSet, task
from modules import tokopedia, topads, accounts, graphql
from libs import randex

class SearchProductProduction(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]

    # User accessing home page without login first
    @task(1)
    def task1(self):
        keyword = randex.generate_word(2,20)
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']
        platform = 'mobile'

        res = tokopedia.page(self, tokopedia.host_production_m, '/search', query='q='+keyword+'&st=product', hide_query=True, timeout=timeout_page, cb_threshold=cb_threshold)
        res = tokopedia.ajax_prosecure_pl(self, tokopedia.host_production_m, query='action=shop_list', timeout=timeout, cb_threshold=cb_threshold)

        res = topads.promo_display_ads_v1_1(self, topads.host_production, query='q={0}&user_id=0&ep=product&item=4&src=search&device={1}'.format(keyword, platform), name=topads.host_production+"/promo/v1.1/display/ads?src=search&ep=product", timeout=timeout, cb_threshold=cb_threshold)
        viewport = 'H_tF6sJRHAUOHpnd6sJEH_tho_Hh6Aj7op1p6MusrprXPcY0QRCBgcBxbMNBPmY2Q3r5yfVsqc15HsnFb9ohP3VagZYFrMYjP3o7b_J5Hsnh6m47bp15HsedopHaHAn5HsedopHaHACw6AHdgsHfysjWgszioZ77HAnNb_jOHs1Wg_uxHc1NgAUFgMVi9pKFHV4hHsnFbM2FgptEHAtFbsnp6_HdHs2B812kgJxGgBBXZSgjH7NDZ325q1OAZ9o-Q1dFyfFN8B29zSBgHMP2_fB-P7B2PfBxHByOgAUN8u2c692gHsBN3Bo-ojBke3BHe72OysUOqB2_Z_g-qBBN33Ouo1OJqp-HuVBE_uPVPJNJQcW6q_n7_BzsoJh9192oz77a_1zu8u2kyRxg81BpZ37N83V9gICiQABRyf7Nqfz9_sCyHMh0Z325q1OAZ9o-Q_BNyuPjrc-D692xzpBR3A-Dq7BkQfBoe7BpZ3NcHu2yZsuyHO-t3sooq1Y2Z3BHe72E3_UN8u2363BsQ_jpyp-uq1Y2Z9PHqjVE_7zSHJO1_9PouJVR_32zH1NJ_92-q9P2yp-6PMoWuMgsHBgtyfO6Q7BkQfBoepzR_9208jYJZ9x68j7F_S2S8jNkZ9x6e7tN'
        res = topads.promo_views_P_v1(self, topads.host_production, viewport, query='is_search=1&number_ads_req=2&src=search&alg=stm&t={0}&n_candidate_ads=2&post_alg=cpc_shop_unq&keywords={1}&number_of_ads=2&page=1&ob=23&uid=0&ab_test=N&render=false'.format(platform, keyword), name=topads.host_production+"/promo/v1/views/{viewport}/v1", timeout=timeout, cb_threshold=cb_threshold)

        res = accounts.marketplace_pixel(self, accounts.host_production, timeout=timeout, cb_threshold=cb_threshold)

        res = graphql.graphql_isAuthenticatedQuery(self, graphql.host_graphql, json={"operationName":"isAuthenticatedQuery", "variables":{"key": "/search"}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_headerQuery(self, graphql.host_graphql, json={"variables":{"loggedIn":False},"operationName":"HeaderQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)
        res = graphql.graphql_quickFilter(self, graphql.host_graphql, json={"operationName":"quick_filter", "variables":{"query":keyword}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_searchFilterQuery(self, graphql.host_graphql, json={"operationName":"SearchFilterQuery", "variables":{"query":keyword, "source":"product", "extraParams":""}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_srcProdQueries(self, graphql.host_graphql, json={"operationName":"SrcProdQueries","variables":{"userID":0,"query":keyword,"source":"search","additional_params":"","ob":23,"per_page":10,"userSearchID":"","filter":{"sc":"","variants":"","brand":"","fcity":"","shipping":"","condition":"","rt":"","pmin":"","pmax":""}}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_showCatalogQuery(self, graphql.host_graphql, json={"operationName":"ShowCatalogQuery","variables":{"query":keyword,"per_page":10,"ob":23,"pmin":"","pmax":"","sc":""}}, timeout=timeout_graphql, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = SearchProductProduction
    min_wait = 3000
    max_wait = 5000
