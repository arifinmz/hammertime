from locust import HttpLocust, TaskSet, task
from modules import graphql, tokopedia
import random

class CategoryNonIntermediary(TaskSet):

    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.config = self.configuration["production"]
    
    @task(1)
    def task1(self):
        user_id = -1
        category_id = random.choice(self.config['category']['category_id']['all_intermediary'])
        category_id_lite = random.choice(self.config['category_id_lite'].keys())
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']

        #accessing category level from intermediary
        res = graphql.graphql_categoryDetail(self, graphql.host_graphql, json={"variables":{"id":category_id_lite, "device":"mobile", "user_id":user_id}, "operationName":"CategoryDetail"}, cb_threshold=cb_threshold, timeout = timeout_graphql)
        res = graphql.graphql_categoryFilterQuery(self, graphql.host_graphql, json={"variables":{"category_id":category_id, "filter_source":"directory"}, "operationName":"CategoryFilterQuery"}, cb_threshold=cb_threshold, timeout = timeout_graphql)
        res = graphql.graphql_categoryProductsQuery(self, graphql.host_graphql, json={"variables":{"category_id":category_id, "user_id":user_id, "user_search_id":0, "product_page":1, "catalog_page":1, "per_page": 12, "tracker":{}, "filter":{"ob":None}}}, cb_threshold=cb_threshold, timeout = timeout_graphql)
        res = graphql.graphql_categoryBreadcrumb(self, graphql.host_graphql, json={"operationName":"Query","variables":{"catID":category_id}}, cb_threshold=cb_threshold, timeout=timeout_graphql)
        

class WebsiteUser(HttpLocust):
    host     = tokopedia.host_production_m
    task_set = CategoryNonIntermediary
    min_wait = 1500
    max_wait = 2500
