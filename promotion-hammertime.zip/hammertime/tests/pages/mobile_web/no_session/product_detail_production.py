from locust import HttpLocust, TaskSet, task
from modules import tokopedia, inbox, accounts, js, graphql, tome
import random


class ProductDetailProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]

    @task(1)
    def task1(self):
        self.product_id      = str(random.choice(self.config["dexter"]["massive_products"]))
        headers         = {
          'origin':"https://m.tokopedia.com"
        }
        access_status = True

        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']

        res = tome.product_P_v2(self, tome.host_production, self.product_id, query='p_id='+self.product_id, name=tome.host_production+"/v2/product/{product_id}", catch_response=True)
        try:
          json_res = res.json()
          shop_domain = json_res['data']['product_shop']['shop_domain']
          shop_id = json_res['data']['product_shop']['shop_id']
          product_alias = json_res['data']['product_alias']
          product_domain = "/%s/%s" % (shop_domain, product_alias)
        except Exception as er:
          access_status = False

        if access_status :
            res = tokopedia.page(self, tokopedia.host_production_m, product_domain, name=tokopedia.host_production_m+"{shop_domain}/{product_domain}", timeout=timeout_page, cb_threshold=cb_threshold)

            # IsAuthenticatedQuery
            isAuthenticatedQueryVariables = {
                "key": product_domain
            }
            res = graphql.graphql_isAuthenticatedQuery(self, graphql.host_graphql, json={"variables":isAuthenticatedQueryVariables,"operationName":"isAuthenticatedQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)

            # ProductStockQuery
            productStockQueryVariables = {
                "productID": self.product_id,
                "lang": "id"
            }
            res = graphql.graphql_productStockQuery(self, graphql.host_graphql, json={"variables":productStockQueryVariables,"operationName":"ProductStockQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)

            # ProductTokenQuery
            res = graphql.graphql_productTokenQuery(self, graphql.host_graphql, json={"variables":{},"operationName":"ProductTokenQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)

            # ProductWishlistQuery
            productWishlistQueryVariables = {
                "productID": self.product_id
            }

            res = graphql.graphql_ProductWishlistQuery(self, graphql.host_graphql, json={"variables":productWishlistQueryVariables, "operationName":"ProductWishlistQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

            # PromoWidgetQuery
            promoWidgetQueryVariables = {
                "userID": 0,
                "deviceType": "mobile",
                "targetType": "guest",
                "placeholder": "pdp_widget",
                "lang": "id",
                "shopType": "merchant"
            }
            res = graphql.graphql_promoWidgetQuery(self, graphql.host_graphql, json={"variables":promoWidgetQueryVariables,"operationName":"PromoWidgetQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

            # ProductVideoQuery
            productVideoQueryVariables = {
                "productID": self.product_id
            }
            res = graphql.graphql_productVideoQuery(self, graphql.host_graphql, json={"variables":productVideoQueryVariables,"operationName":"ProductVideoQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

            # ProductReviewQuery
            productReviewQueryVariables = {
                "productID": self.product_id,
                "ssr": False
            }

            res = graphql.graphql_productReviewQuery(self, graphql.host_graphql, json={"variables":productReviewQueryVariables, "operationName":"ProductReviewQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

            # PDPTalkQuery
            PDPTalkQueryVariables = {
                "productId": self.product_id,
                "page": 1,
                "perPage": 1,
                "source": "sneak_peak"
            }
            res = graphql.graphql_PDPTalkQuery(self, graphql.host_graphql, json={"variables":PDPTalkQueryVariables,"operationName":"PDPTalkQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

            # ProductOtherQuery
            productOtherQueryVariables = {
                "productID": self.product_id,
                "rows": 10,
                "shopID": shop_id,
                "start": 0
            }

            res = graphql.graphql_ProductOtherQuery(self, graphql.host_graphql, json={"variables":productOtherQueryVariables,"operationName":"ProductOtherQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

class WebsiteUser(HttpLocust):
    host     = ""
    task_set = ProductDetailProduction
    min_wait = 3000
    max_wait = 5000
