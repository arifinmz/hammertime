from locust import HttpLocust, TaskSet, task
from modules import tokopedia, pulsa, pulsa_api, topads, accounts, ace

class SearchShopProduction(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]

    # User accessing home page without login first
    @task(1)
    def task1(self):
        search_keyword = 'kacamata'
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        cb_threshold = self.config['cb_threshold']

        # search page
        res = tokopedia.page(self, tokopedia.host_production_m, '/search', query='q='+search_keyword+'&st=shop', hide_query=True, timeout=timeout_page, cb_threshold=cb_threshold)
        # recharge
        res = pulsa_api.category_list_v1_1(self, pulsa_api.host_production, query='device_id=9', timeout=timeout, cb_threshold=cb_threshold)
        # accounts
        res = accounts.marketplace_pixel(self, accounts.host_production, timeout=timeout, cb_threshold=cb_threshold)
        # ace
        res = ace.search_shop_v1(self, ace.host_production, query='callback=searchMobile&q='+search_keyword+'&device=mobile&breadcrumb=true&full_domain=m.tokopedia.com&scheme=https&source=search&start=0&rows=10', timeout=timeout, cb_threshold=cb_threshold)
        res = ace.search_catalog_v1(self, ace.host_production, query='callback=searchMobileCatalog&q='+search_keyword+'&source=universe&st=shop', timeout=timeout, cb_threshold=cb_threshold)
        res = ace.dynamicAttributes_v1_1(self, ace.host_production, query='callback=dynamic_attributes&q='+search_keyword+'&st=shop&device=desktop&source=search_shop', timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = SearchShopProduction
    min_wait = 3000
    max_wait = 5000
