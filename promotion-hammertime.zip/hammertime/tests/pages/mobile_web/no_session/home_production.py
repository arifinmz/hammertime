from locust import HttpLocust, TaskSet, task
from modules import graphql, accounts, tokopedia


class HomeProduction (TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]

    # User accessing home page with session from cookie
    @task(1)
    def task1(self):
        user_id = '0'
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold    = self.config['cb_threshold']

        # home
        home_domain = '/'
        res = tokopedia.page(self, tokopedia.host_production_m, home_domain, cb_threshold=cb_threshold, timeout=timeout_page)

        # graphql
        res = graphql.graphql_headerQuery(self, graphql.host_graphql, json={"variables":{"loggedIn":False},"operationName":"HeaderQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)
        res = graphql.graphql_rechargeCategoryDetail(self, graphql.host_graphql, json={"variables":{"category_id":1},"operationName":"rechargeCategoryDetail"}, cb_threshold=cb_threshold, timeout=timeout_graphql)
        res = graphql.graphql_footerQuery(self, graphql.host_graphql, json={"variables":{"loggedIn":False},"operationName":"FooterQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)
        res = graphql.graphql_updateCartCounterMutation(self, graphql.host_graphql, json={"variables":{},"operationName":"updateCartCounterMutation"}, cb_threshold=cb_threshold, timeout=timeout_graphql)
        res = graphql.graphql_digitalQuery(self, graphql.host_graphql, json={"operationName":"DigitalQuery","variables":{"isLoggedIn":False}}, timeout=timeout_graphql, cb_threshold=cb_threshold)

        # accounts
        res = accounts.marketplace_pixel(self, accounts.host_production, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host     = ""
    task_set = HomeProduction
    min_wait = 1500
    max_wait = 2500
