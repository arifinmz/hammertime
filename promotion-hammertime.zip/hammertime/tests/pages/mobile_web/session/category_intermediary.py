from locust import HttpLocust, TaskSet, task
from modules import graphql, tokopedia, topads, hades
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class CategoryIntermediary(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config["dexter"]["massive_accounts"], login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id = self.account["user_id"]
        category_id = random.choice(self.config['category']['category_id']['all_intermediary'])
        platform = "mobile"
        timeout_page  = (self.config['timeout_page'][0], self.config['timeout_page'][1])
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        timeout_graphql = (self.config['timeout_graphql'][0], self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']
        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }
        test_failed = False

        res_category = hades.categories_P_v1(self, hades.host_production, category_id, headers=headers, query="filter=type==tree", name=hades.host_production+"/v1/categories/{category_id}?filter=type==tree")
        try :
            category_json = res_category.json()
            category_identifier = category_json["data"]["categories"][0]["identifier"]
        except Exception as e :
            test_failed = True

        if not test_failed : 
            res = tokopedia.page(self, tokopedia.host_production_m, '/p/'+category_identifier, name=tokopedia.host_production_m+"/p/{category_identifier}", headers=headers, timeout=timeout_page, cb_threshold=cb_threshold)
        
        # topads
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query='ep=product&item=2&src=intermediary&device={0}&page=1&user_id={1}&dep_id={2}&search_nf=0'.format(platform, user_id, category_id), name=topads.host_production+"/promo/v1.1/display/ads?ep=product&src=intermediary", timeout=timeout, cb_threshold=cb_threshold)

        # graphql
        res = graphql.graphql_updateCartCounterMutation(self, graphql.host_graphql, headers=headers, json={"operationName":"updateCartCounterMutation","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_intermediaryLifestyle(self, graphql.host_graphql, headers=headers, json={"operationName":"IntermediaryLifestyle","variables":{"id":category_id,"user_id":-1,"filter":{"ob":None},"product_page":1,"per_page":4,"page_name":"category","xdevice":platform,"xsource":"lite","tracker":{}}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_categoryBreadcrumb(self, graphql.host_graphql, headers=headers, json={"operationName":"Query","variables":{"catID":category_id}}, timeout=timeout_graphql, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host        = tokopedia.host_production_m
    task_set    = CategoryIntermediary
    min_wait    = 1500
    max_wait    = 2500 