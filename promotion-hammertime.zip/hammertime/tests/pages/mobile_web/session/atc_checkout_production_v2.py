from locust import HttpLocust, TaskSet, task
from modules import tokopedia, gw, cartapp, scrooge, orderapp, graphql
from tests.helper.account_helper import AccountHelper
import datetime
import random
import sys
import time

ah = AccountHelper()

class ATCCheckoutMWeb(TaskSet):

    def on_start(self):
        if not hasattr(ATCCheckoutMWeb, 'config_loaded') :
            ATCCheckoutMWeb.test_config = self.configuration['production']
            ATCCheckoutMWeb.large_users = self.team_configuration(ATCCheckoutMWeb.test_config['dexter']['20k_accounts'])
            ATCCheckoutMWeb.config_loaded = True
        self.account = ah.get_account(self, accounts=ATCCheckoutMWeb.large_users, login_type=ah.LOGIN_TYPE_BROWSER)
        self.user_id = self.account['user_id']
        self.device_id = ATCCheckoutMWeb.test_config['device_id']
        self.timeout = (ATCCheckoutMWeb.test_config['stitch']['timeout_ATC'][0], ATCCheckoutMWeb.test_config['stitch']['timeout_ATC'][1])
        self.cb_threshold = ATCCheckoutMWeb.test_config['cb_threshold']
        self.cookie = ah.get_sid_cookie(self.user_id)
        self.headers = {
            'Tkpd-UserId': self.user_id,
            'content-type': 'application/x-www-form-urlencoded',
            'cookie': self.cookie
        }

    @task(20)
    def task1(self):
        test_failed = False
        product = random.choice(ATCCheckoutMWeb.test_config['products'])
        product_id = product['id']
        shop_id = product['shop_id']

        bodies_reset_cart = {
            'status': '1',
            'lang': 'id'
        }
        cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, self.user_id, self.device_id, 
            bodies=bodies_reset_cart, headers=self.headers, 
            cb_threshold=self.cb_threshold, timeout=self.timeout)

        add_cart_variables = {
            "productID": product_id,
            "shopID": shop_id,
            "quantity": 1,
            "notes": None,
            "lang": "id"
        }
        res = graphql.graphql_addToCartMutation(self, graphql.host_graphql, headers=self.headers, json={"variables":add_cart_variables,"operationName":"addToCartMutation"}, cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)
        if res.status_code == 200 :
            try :
                data = res.json()['data']['add_to_cart']
                if data['data']['success'] == 1 :
                    res.success()
                    test_failed = False
                else :
                    res.failure(data['data']['message'])
                    test_failed = True
                    print(res.content)
            except Exception as e :
                test_failed = True
                res.failure(e)
                print(res.content)
        else :
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)
                print(res.content)
        
        if test_failed :
            return

        cartListQueryVariables = {
            "lang": "id",
            "isReset": True
        }
        res = graphql.graphql_cartListQuery(self, graphql.host_graphql, headers=self.headers, 
            json={"variables":cartListQueryVariables,"operationName":"CartListQuery"}, 
            cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)
        cart_id = None
        if res.status_code == 200:
            try:
                if '"cart_id"' in res.content:
                    res.success()
                    cart_id = res.json()['data']['cart_list']['data']['cart_list'][0]['cart_id']
                    test_failed = False
                else:
                    res.failure(res.content)
                    test_failed = True
            except Exception as e:
                res.failure(res.content)
                test_failed = True
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                res.failure(e)
                test_failed = True

        #do not continue if previous step failed
        if test_failed:
            return

        updateCartVariables = {
            "carts": [
                {
                "cart_id": cart_id,
                "quantity": 1,
                "notes": ""
                }
            ],
            "lang": "id"
        }
        res = graphql.graphql_updateCart(self, graphql.host_graphql, headers=self.headers, 
            json={"variables":updateCartVariables,"operationName":"updateCart"}, 
            cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)
        if res.status_code == 200:
            try:
                if '"OK"' in res.content:
                    res.success()
                    test_failed = False
                else:
                    res.failure(res.content)
                    test_failed = True
            except Exception as e:
                res.failure(res.content)
                test_failed = True
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                res.failure(e)
                test_failed = True

        #do not continue if previous step failed
        if test_failed:
            return

        #list address
        listAddressVariables = {}
        res = graphql.graphql_listAddress(self, graphql.host_graphql, headers=self.headers, 
            json={"variables":listAddressVariables,"operationName":"listAddress"}, 
            cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)
        if res.status_code == 200:
            try:
                if '"addr_id"' in res.content:
                    res.success()
                    test_failed = False
                else:
                    res.failure(res.content)
                    test_failed = True
            except Exception as e:
                res.failure(res.content)
                test_failed = True
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                res.failure(e)
                test_failed = True

        #do not continue if previous step failed
        if test_failed:
            return

        #shipment form
        getShipmentFormVariables = {
            "lang":"en"
        }
        res = graphql.graphql_getShipmentForm(self, graphql.host_graphql, headers=self.headers, 
        json={"variables":getShipmentFormVariables,"operationName":"GetShipmentForm"}, 
        cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)
        get_courier_variables = None
        destination = None
        shipment = None
        if res.status_code == 200:
            try:
                if '"ship_id"' in res.content:
                    res.success()
                    shipment = res.json()['data']['get_shipment_form']
                    kero_token = shipment['kero_token']
                    kero_ut = shipment['kero_unix_time']
                    destination = {
                        "district_id": str(shipment['group_address'][0]['user_address']["district_id"]),
                        "postal_code": shipment['group_address'][0]['user_address']['postal_code'],
                        "lat": random.uniform(-6.149573, -6.247871),
                        "lng": random.uniform(106.751159, 106.900907)
                    }
                    origin = {
                        "district_id": str(shipment['group_address'][0]['group_shop'][0]['shop']["district_id"]),
                        "postal_code": shipment['group_address'][0]['group_shop'][0]['shop']['postal_code'],
                        "lat": shipment['group_address'][0]['group_shop'][0]['shop']["latitude"],
                        "lng": shipment['group_address'][0]['group_shop'][0]['shop']["longitude"]
                    }
                    couriers = list()
                    for courier in shipment['group_address'][0]['group_shop'][0]['shop_shipments']:
                        ship_prods = list()
                        ship_prods_id = list()
                        for ship_prod in courier['ship_prods']:
                            ship_prods.append(ship_prod['ship_group_name'])
                            ship_prods_id.append(ship_prod['ship_prod_id'])
                        couriers.append(
                            {
                                "courier_id":courier['ship_id'],
                                "courier_name":courier['ship_code'],
                                "shipping_products":ship_prods,
                                "shipping_products_id":ship_prods_id
                            }
                        )
                    get_courier_variables = {
                        "couriers":couriers,
                        "origin":origin,
                        "destination":destination,
                        "weight":str(random.randint(10,10000))+"g",
                        "token":kero_token,
                        "ut":kero_ut,
                        "insurance":random.randint(0,1),
                        "productInsurance":random.randint(0,1),
                        "orderValue":shipment['group_address'][0]['group_shop'][0]['products'][0]['product_price'] * \
                                    shipment['group_address'][0]['group_shop'][0]['products'][0]['product_quantity'],
                        "catId":[  
                            random.randint(1,50)
                        ],
                        "lang":"en"
                    }
                    test_failed = False
                else:
                    res.failure(res.content)
                    test_failed = True
            except Exception as e:
                res.failure(res.content)
                test_failed = True
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                res.failure(e)
                test_failed = True

        #do not continue if previous step failed
        if test_failed:
            return

        res = graphql.graphql_getCourier(self, graphql.host_graphql, headers=self.headers, 
            json={"variables":get_courier_variables,"operationName":"GetCourier"}, 
        cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)
        if res.status_code == 200:
            try:
                if '"shipper_id"' in res.content:
                    test_failed = False
                    res.success()
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        #do not continue if previous step failed
        if test_failed:
            return

        get_district_boundary_variables = {
            "districtId":destination['district_id']
        }
        res = graphql.graphql_getDistrictBoundary(self, graphql.host_graphql, headers=self.headers, 
            json={"variables":get_district_boundary_variables,"operationName":"GetDistrictBoundary"}, 
            cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)
        if res.status_code == 200:
            try:
                if '"boundary"' in res.content:
                    res.success()
                    test_failed = False
                else:
                    res.failure(res.content)
                    test_failed = True
            except Exception as e:
                res.failure(res.content)
                test_failed = True
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                res.failure(e)
                test_failed = True

        #do not continue if previous step failed
        if test_failed:
            return

        currenttime = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        checkout_variables = {
            "carts": '{\
                "bot_data":{\
                    "m":true,\
                    "k":false,\
                    "s":true,\
                    "duration":'+str(random.randint(10,10000))+',\
                    "timestamp":"'+currenttime+'"\
                    },\
                "promo_code":"",\
                "is_donation":0,\
                "data":[\
                    {\
                        "address_id":'+str(shipment['group_address'][0]['user_address']['address_id'])+',\
                        "shop_products":[ \
                            {\
                                "shop_id":'+str(shop_id)+',\
                                "is_preorder":0,\
                                "finsurance":0,\
                                "shipping_info":{\
                                    "shipping_id":'+str(shipment['group_address'][0]['group_shop'][0]['shop_shipments'][0]['ship_id'])+',\
                                    "sp_id":'+str(shipment['group_address'][0]['group_shop'][0]['shop_shipments'][0]['ship_prods'][0]['ship_prod_id'])+'},\
                                "is_dropship":0,\
                                "dropship_data":{"name":"","telp_no":""},\
                                "product_data":[{"product_id":'+str(product_id)+'}],\
                                "fcancel_partial":0\
                            }\
                        ]\
                    }\
                ]}',
            "promo_suggested":False,
            "lang":"id"
            }
        res = graphql.graphql_checkout(self, graphql.host_graphql, headers=self.headers, 
            json={"variables":checkout_variables,"operationName":"checkout"}, 
            cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)
        bodies_v2Payment = None
        if res.status_code == 200:
            try:
                if 'transaction_id' in res.content:
                    res.success()
                    test_failed = False
                    respon = res.json()
                    transaction_id = respon['data']['checkout_cart']['data']['parameter']['transaction_id']
                    transaction_date = respon['data']['checkout_cart']['data']['parameter']['transaction_date']
                    user_defined_value = respon['data']['checkout_cart']['data']['parameter']['user_defined_value']
                    product_list = respon['data']['checkout_cart']['data']['product_list']
                    ids = orderapp.itemsList(product_list, 'id')
                    prices = orderapp.itemsList(product_list, 'price')
                    quantities = orderapp.itemsList(product_list, 'quantity')
                    names = orderapp.itemsList(product_list, 'name')
                    payment_metadata = respon['data']['checkout_cart']['data']['parameter']['payment_metadata']
                    merchant_code = respon['data']['checkout_cart']['data']['parameter']['merchant_code']
                    nid = respon['data']['checkout_cart']['data']['parameter']['nid']
                    pid = respon['data']['checkout_cart']['data']['parameter']['pid']
                    profile_code = respon['data']['checkout_cart']['data']['parameter']['profile_code']
                    gateway_code = respon['data']['checkout_cart']['data']['parameter']['gateway_code']
                    amount = respon['data']['checkout_cart']['data']['parameter']['amount']
                    customer_email = respon['data']['checkout_cart']['data']['parameter']['customer_email']
                    signature = respon['data']['checkout_cart']['data']['parameter']['signature']
                    customer_name = respon['data']['checkout_cart']['data']['parameter']['customer_name']
                    msisdn = respon['data']['checkout_cart']['data']['parameter']['customer_msisdn']
                    currency = respon['data']['checkout_cart']['data']['parameter']['currency']

                    bodies_v2Payment = {
                        'customer_id': self.user_id,
                        'customer_email': customer_email,
                        'customer_name': customer_name,
                        'transaction_id': transaction_id,
                        'transaction_date': transaction_date,
                        'amount': amount,
                        'gateway_code': gateway_code,
                        'currency': currency,
                        'signature': signature,
                        'items[id]': ids,
                        'items[price]': prices,
                        'items[quantity]': quantities,
                        'items[name]': names,
                        'nid': nid,
                        'pid': pid,
                        'user_defined_value': user_defined_value,
                        'merchant_code': merchant_code,
                        'profile_code': profile_code,
                        'language': 'id-ID',
                        'payment_metadata': payment_metadata,
                        'customer_msisdn': msisdn,
                        'device_info': '[object+Object]'
                    }
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        #do not continue if previous step failed
        if test_failed:
            return

        #payment
        headers_v2Payment = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        res = scrooge.payment_v2(self, scrooge.host_production, bodies=bodies_v2Payment,
                                    headers=headers_v2Payment, timeout=self.timeout,
                                    cb_threshold=self.cb_threshold, catch_response=True)
        if res != "" and res.status_code == 200:
                try:
                    if 'Payment Failed' in res.content or len(str(res.content)) < 1:
                        res.failure("Payment Failed or empty html returned")
                        test_failed = True
                    else:
                        res.success()
                except Exception as e:
                    test_failed = True
                    res.failure(res.content)
        else:
                try:
                    res.raise_for_status()
                except Exception as e:
                    test_failed = True
                    res.failure(e)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = ATCCheckoutMWeb
    min_wait = 1500
    max_wait = 2500