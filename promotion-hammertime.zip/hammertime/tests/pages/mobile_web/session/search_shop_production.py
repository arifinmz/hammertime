from locust import HttpLocust, TaskSet, task
from modules import tokopedia, pulsa, pulsa_api, topads, accounts, ace
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class SearchShopProduction(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.users, login_type=ah.LOGIN_TYPE_LITE)

    # User accessing home page without login first
    @task(1)
    def task1(self):
        search_keyword = 'kacamata'
        hotlist_id = '2607'
        user_id     = self.account['user_id']
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        cb_threshold = self.config['cb_threshold']

        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }

        # search page
        res = tokopedia.page(self, tokopedia.host_production_m, '/search', headers=headers, query='q='+search_keyword+'&st=shop', hide_query=True, timeout=timeout_page, cb_threshold=cb_threshold)
        # tokopedia
        res = tokopedia.ajaxNavDeposit_pl(self, tokopedia.host_production_m, headers=headers, query='callback=get_deposit_handler&action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajaxNavNotification_pl(self, tokopedia.host_production_m, headers=headers, query='callback=get_notification_handler&action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        # recharge
        res = pulsa_api.category_list_v1_1(self, pulsa_api.host_production, headers=headers, query='device_id=9', timeout=timeout, cb_threshold=cb_threshold)
        # topads
        res = topads.promo_display_shops_v1(self, topads.host_production, headers=headers, query='src=search&item=4&user_id='+user_id+'&device=mobile&q='+search_keyword, timeout=timeout, cb_threshold=cb_threshold)
        # accounts
        res = accounts.marketplace_pixel(self, accounts.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        res = accounts.api_wallet_balance(self, accounts.host_production, headers={'origin':accounts.host_production, 'cookie':ah.get_sid_cookie(user_id)}, timeout=timeout, cb_threshold=cb_threshold)
        # ace
        res = ace.search_catalog_v1(self, ace.host_production, headers=headers, query='callback=searchMobileCatalog&q='+search_keyword+'&st=shop', timeout=timeout, cb_threshold=cb_threshold)
        res = ace.dynamicAttributes_v1_1(self, ace.host_production, headers=headers, query='callback=dynamic_attributes&q='+search_keyword+'&st=shop&device=desktop&source=search_shop', timeout=timeout, cb_threshold=cb_threshold)
        res = ace.search_shop_v1(self, ace.host_production, headers=headers, query='callback=searchMobile&q='+search_keyword+'&device=mobile&breadcrumb=true&full_domain=m.tokopedia.com&scheme=https&source=search&start=0&rows=10', timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = SearchShopProduction
    min_wait = 3000
    max_wait = 5000
