from locust import HttpLocust, TaskSet, task
from modules import graphql, topads, accounts, tokopedia, pulsa_api, tome
from tests.helper.account_helper import AccountHelper
import random, json

ah = AccountHelper()

class HomeProduction(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]

        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_LITE)

        headers = {
            'cookie':ah.get_sid_cookie(self.account["user_id"])
        }
        res = tome.webService_fav_shop_list_v1(self, tome.host_production,  headers=headers, query="user_id="+self.account["user_id"], hide_query=True)
        responseJSON = res.json()
        count = 0
        for shop in responseJSON["data"]:
            if shop["shop_id"] == "1009431":
                count = count + 1
        if count < 1:
            headers = {
                "cookie":ah.get_sid_cookie(self.account["user_id"]),
                "origin":"https://www.tokopedia.com",
                "content-type":"application/x-www-form-urlencoded; charset=UTF-8"
            }
            bodies = {
                "s_id":1009431
            }
            res = tome.addFavorite(self, tome.host_production, headers=headers, bodies=bodies)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        phone = self.account['phone']
        device_id = self.config['device_id']
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']

        headers = {
            'cookie': ah.get_sid_cookie(user_id),
            'Authorization': ah.get_token(user_id)
        }

        #feed
        feed_domain = '/feed'
        res = tokopedia.page(self, tokopedia.host_production_m, feed_domain, headers=headers,  cb_threshold=cb_threshold, timeout=timeout_page)
        headerQueryVariables = {
            "loggedIn": True
        }
        res = graphql.graphql_headerQuery(self, graphql.host_graphql, headers=headers, json={"variables":headerQueryVariables, "operationName":"HeaderQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

        rechargeFavoriteNumberVariables = {
            "category_id": 1
        }
        res = graphql.graphql_rechargeFavoriteNumber(self, graphql.host_graphql, headers=headers, json={"variables":rechargeFavoriteNumberVariables, "operationName":"rechargeFavoriteNumber"}, cb_threshold=cb_threshold, timeout=timeout_graphql)
        
        footerQueryVariables = {
            "loggedIn": True
        }
        res = graphql.graphql_footerQuery(self, graphql.host_graphql, headers=headers, json={"variables":footerQueryVariables, "operationName":"FooterQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

        updateCartCounterMutationVariables = {}
        res = graphql.graphql_updateCartCounterMutation(self, graphql.host_graphql, headers=headers, json={"variables":updateCartCounterMutationVariables,"operationName":"updateCartCounterMutation"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

        #graphql_recentViewQuery
        recentViewQueryVariables =  { 
            "userID": int(user_id) 
        }
        res = graphql.graphql_recentViewQuery(self, graphql.host_graphql, headers=headers, json={"variables":recentViewQueryVariables,"operationName":"RecentViewQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

        #graphql_feed
        FeedQuery={
            "userID": int(user_id),
            "limit":3,
            "page":1,
            "pageName":"",
            "source":"feed"
        }
        res = graphql.graphql_feedQuery(self, graphql.host_graphql, headers=headers, json={"variables":FeedQuery,"operationName":"FeedQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

        #topads
        query = "pub_id=12"
        res = topads.promo_info_user_v1(self, topads.host_production, user_id, device_id, headers=headers, query=query, name=topads.host_production+"/promo/v1/info/user?"+query, cb_threshold=cb_threshold, timeout=timeout)
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query="ep=product&item=4&src=fav_product&device=mobile&page=1&user_id="+user_id+"&search_nf=0&dep_id=24%2C36%2C502", cb_threshold=cb_threshold, timeout=timeout, hide_query=True)

        # accounts
        res = accounts.marketplace_pixel(self, accounts.host_production, headers=headers,  cb_threshold=cb_threshold, timeout=timeout)

class WebsiteUser(HttpLocust):
    host     = ""
    task_set = HomeProduction
    min_wait = 1500
    max_wait = 2500