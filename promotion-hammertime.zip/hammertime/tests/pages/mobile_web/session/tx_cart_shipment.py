from locust import HttpLocust, TaskSet, task
from modules import tokopedia, graphql
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class TxCartShipment(TaskSet):
    
    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.config = self.configuration["production"]
        self.cart_id = random.choice(self.config["cart_id"])
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']
        test_failed = False

        # # graphql
        home_domain = '/cart/shipment'
        res = tokopedia.page(self, tokopedia.host_production_m, home_domain,  cb_threshold=cb_threshold, timeout=timeout_page)
        updateCartVariables = {
            "carts": [
                {
                "cart_id": self.cart_id,
                "quantity": random.randint(1,800),
                "notes": ""
                }
            ],
            "lang": "en"
        }
        res = graphql.graphql_updateCart(self, graphql.host_graphql, headers=headers, json={"variables":updateCartVariables,"operationName":"updateCart"}, cb_threshold=cb_threshold, timeout=timeout_graphql)
        listAddressVariables = {}
        res_address = graphql.graphql_listAddress(self, graphql.host_graphql, headers=headers, json={"variables":listAddressVariables,"operationName":"listAddress"}, cb_threshold=cb_threshold, timeout=timeout_graphql) 
        updateCartCounterMutationVariables = {}
        res = graphql.graphql_updateCartCounterMutation(self, graphql.host_graphql, headers=headers, json={"variables":updateCartCounterMutationVariables,"operationName":"updateCartCounterMutation"}, cb_threshold=cb_threshold, timeout=timeout_graphql)
        getShipmentFormVariables = {
            "lang":"en"
        }
        res = graphql.graphql_getShipmentForm(self, graphql.host_graphql, headers=headers, json={"variables":getShipmentFormVariables,"operationName":"GetShipmentForm"}, cb_threshold=cb_threshold, timeout=timeout_graphql, catch_response=True)
        try :
            shipment_data = res.json()
            if shipment_data['data']['get_shipment_form']['error_code'] > 0 :
                test_failed = True
            else :
                shipment = res.json()['data']['get_shipment_form']
                kero_token = shipment['kero_token']
                kero_ut = shipment['kero_unix_time']
                destination = {
                    "district_id": str(shipment['group_address'][0]['user_address']["district_id"]),
                    "postal_code": shipment['group_address'][0]['user_address']['postal_code'],
                    "lat": shipment['group_address'][0]['user_address']["latitude"],
                    "lng": shipment['group_address'][0]['user_address']["longitude"]
                }
                origin = {
                    "district_id": str(shipment['group_address'][0]['group_shop'][0]['shop']["district_id"]),
                    "postal_code": shipment['group_address'][0]['group_shop'][0]['shop']['postal_code'],
                    "lat": shipment['group_address'][0]['group_shop'][0]['shop']["latitude"],
                    "lng": shipment['group_address'][0]['group_shop'][0]['shop']["longitude"]
                }
                couriers = list()
                for courier in shipment['group_address'][0]['group_shop'][0]['shop_shipments']:
                    ship_prods = list()
                    ship_prods_id = list()
                    for ship_prod in courier['ship_prods']:
                        ship_prods.append(ship_prod['ship_group_name'])
                        ship_prods_id.append(ship_prod['ship_prod_id'])
                    couriers.append(
                        {
                            "courier_id":courier['ship_id'],
                            "courier_name":courier['ship_code'],
                            "shipping_products":ship_prods,
                            "shipping_products_id":ship_prods_id
                        }
                    )
                res.success()
        except Exception as e:
            print('error GetShipmentForm',e.message)
            res.failure(res.content)
            test_failed = True

        if not test_failed :
            get_courier_variables = {
                "couriers":couriers,
                "origin":origin,
                "destination":destination,
                "weight":str(random.randint(10,10000))+"g",
                "token":kero_token,
                "ut":kero_ut,
                "insurance":random.randint(0,1),
                "productInsurance":random.randint(0,1),
                "orderValue":str(random.randint(10000,10000000)),
                "catId":[  
                    random.randint(1,50)
                ],
                "lang":"en"
            }
            res = graphql.graphql_getCourier(self, graphql.host_graphql, headers=headers, json={"variables":get_courier_variables,"operationName":"GetCourier"}, cb_threshold=cb_threshold, timeout=timeout_graphql)
            get_district_boundary_variables = {
                "districtId":destination['district_id']
            }
            res = graphql.graphql_getDistrictBoundary(self, graphql.host_graphql, headers=headers, json={"variables":get_district_boundary_variables,"operationName":"GetDistrictBoundary"}, cb_threshold=cb_threshold, timeout=timeout_graphql)
class WebsiteUser(HttpLocust):
    host = tokopedia.host_production
    task_set = TxCartShipment
    min_wait = 1000
    max_wait = 1500
