from locust import HttpLocust, TaskSet, task
from modules import tokopedia, graphql
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class Tokopoints(TaskSet):
    def on_start(self):
        if not hasattr(Tokopoints, 'config_loaded') :
            Tokopoints.test_config = self.configuration['production']
            Tokopoints.large_users = self.team_configuration(Tokopoints.test_config['dexter']['20k_accounts'])
            Tokopoints.config_loaded = True
        self.account = ah.get_account(self, accounts=Tokopoints.large_users, login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        timeout_graphql= (Tokopoints.test_config['timeout_graphql'][0], Tokopoints.test_config['timeout_graphql'][1])
        timeout_page = (Tokopoints.test_config['timeout_page'][0], Tokopoints.test_config['timeout_page'][1])
        cb_threshold = Tokopoints.test_config['cb_threshold']
        headers = {
            'cookie': ah.get_sid_cookie(user_id)
        }

        res = tokopedia.page(self, tokopedia.host_production_m, '/tokopoints', headers=headers, timeout=timeout_page, cb_threshold=cb_threshold)

        res = graphql.graphql_hachikoMainQuery(self, graphql.host_graphql, headers={'cookie': ah.get_sid_cookie(user_id), 'origin':'https://m.tokopedia.com'}, json={"operationName":"HachikoMainQuery","variables":{"page":1,"page_size":15}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_isAuthenticatedQuery(self, graphql.host_graphql, headers=headers, json={"operationName": "isAuthenticatedQuery", "variables": {"key": "/tokopoints"}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_HomeTabsGoQuery(self, graphql.host_graphql, headers=headers, json={"operationName": "HomeTabsGoQuery", "variables":{"page": 1, "limit": 5, "sortID": 1, "categoryID": 7, "pointRange": 0}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_UserPointsQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"UserPointsQuery","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_QuestTickerQuery(self, graphql.host_graphql, headers=headers, json={}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_TokopointsMainGolangQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"TokopointsMainGolangQuery","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        # res = graphql.graphql_FloatingEggQuery(self, graphql.host_graphql, headers=headers, json={"operationName": "FloatingEggQuery", "variables": {}}, timeout=timeout_graphql, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = tokopedia.host_production
    task_set = Tokopoints
    min_wait = 1500
    max_wait = 2500
