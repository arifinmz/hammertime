from locust import HttpLocust, TaskSet, task
from modules import tokopedia, inbox, accounts, js, graphql, tome
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class ProductCreateTalkProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config["dexter"]["massive_accounts"], login_type=ah.LOGIN_TYPE_LITE)


    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        product = random.choice(self.config['products'])
        product_id = product['id']
        shop_id = product['shop_id']
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        test_failed = False
        headers         = {
          'cookie':ah.get_sid_cookie(user_id),
          'origin':"https://m.tokopedia.com"
        }
        res = inbox.token_generate_v1(self, inbox.host_production, headers=headers, cb_threshold=cb_threshold, timeout=timeout)
        try :
            json_token = res.json()
            csrf_token = json_token["data"]["nekot"]
        except Exception as e:
            test_failed = True

        if not test_failed:
            bodies = {
                'shop_id':shop_id,
                'product_id':product_id,
                'message':'this is a message',
                'csrf_token':csrf_token,
                'offline':1
            }
            res = inbox.talk_create_v1(self, inbox.host_production, headers=headers, bodies=bodies, cb_threshold=cb_threshold, timeout=timeout, catch_response=True)
            if res.status_code == 201 or res.status_code == 200:
                try:
                    response = res.json()
                    if response["data"]["talk"]["status"] == 1 :
                        res.success()
                    else:
                        res.failure(res.content)
                except Exception:
                    res.failure(res.content)
            else :
                try :
                    res.raise_for_status()
                except Exception as e:
                    res.failure(e)


class WebsiteUser(HttpLocust):
    host     = ""
    task_set = ProductCreateTalkProduction
    min_wait = 1000
    max_wait = 1500
