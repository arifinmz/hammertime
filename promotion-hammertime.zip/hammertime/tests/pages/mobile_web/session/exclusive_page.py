from locust import HttpLocust, TaskSet, task
from modules import accounts, tokopedia
from tests.helper.account_helper import AccountHelper
import random, json

ah = AccountHelper()

class ExclusivePage(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config["dexter"]["massive_accounts"], login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        cb_threshold = self.config['cb_threshold']


        headers = {
            'cookie': ah.get_sid_cookie(user_id)
        }

        # home
        home_domain = '/discovery/'
        #random page
        exclusive_page = self.config["discovery"]["exclusive_page_list"][random.randint(0, 
            len(self.config["discovery"]["exclusive_page_list"])-1)]
        res = tokopedia.page(self, tokopedia.host_production_m, home_domain+exclusive_page, 
            name=tokopedia.host_production_m+home_domain+"{exclusive-page}",
            headers=headers, cb_threshold=cb_threshold, timeout=timeout_page)
        
        #balance
        res = accounts.api_wallet_balance(self, accounts.host_production, headers={'origin':accounts.host_production, 'cookie':ah.get_sid_cookie(user_id)}, timeout=timeout, cb_threshold=cb_threshold)

        #others
        headers = {
            'cookie': ah.get_sid_cookie(user_id)
        }
        res = tokopedia.ajaxNavDeposit_pl(self, tokopedia.host_production_m, headers=headers, query='callback=get_deposit_handler&action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajaxNavNotification_pl(self, tokopedia.host_production_m, headers=headers, query='callback=get_notification_handler&action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)


class WebsiteUser(HttpLocust):
    host     = ""
    task_set = ExclusivePage
    min_wait = 1500
    max_wait = 2500