from locust import HttpLocust, TaskSet, task
from modules import graphql,  tokopedia
from tests.helper.account_helper import AccountHelper
import random, json

ah = AccountHelper()

class ResolutionInbox(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config["dexter"]["massive_accounts"], login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']


        headers = {
            'cookie': ah.get_sid_cookie(user_id)
        }

        # home
        home_domain = '/resolution/inbox/buyer'
        res = tokopedia.page(self, tokopedia.host_production_m, home_domain, headers=headers,  cb_threshold=cb_threshold, timeout=timeout_page)

        # graphql
        updateCartCounterMutationVariables = {}
        res = graphql.graphql_updateCartCounterMutation(self, graphql.host_graphql, headers=headers, json={"variables":updateCartCounterMutationVariables,"operationName":"updateCartCounterMutation"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

        resolutionInboxVariables = {"user_type":"buyer","limit":10,"startID":None,"sortBy":None,"asc":None,"filter":[],"startTime":None,"endTime":None}
        res = graphql.graphql_resolutionInboxBuyerQuery(self, graphql.host_graphql, headers=headers, json={"variables":resolutionInboxVariables,"operationName":"ResolutionInboxBuyerQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)



class WebsiteUser(HttpLocust):
    host     = ""
    task_set = ResolutionInbox
    min_wait = 1500
    max_wait = 2500