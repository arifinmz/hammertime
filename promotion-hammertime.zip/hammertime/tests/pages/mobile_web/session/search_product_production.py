from locust import HttpLocust, TaskSet, task
from modules import tokopedia, pulsa, pulsa_api, topads, accounts, ace, graphql
from tests.helper.account_helper import AccountHelper
from libs import randex
import random

ah = AccountHelper()

class SearchProductProduction(TaskSet):
    
    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        keyword = randex.generate_word(2,20)
        user_id     = self.account['user_id']
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']
        platform = 'mobile'

        headers = {
            'cookie': ah.get_sid_cookie(user_id)
        }

        # search page
        res = tokopedia.page(self, tokopedia.host_production_m, '/search', headers=headers, query='q='+keyword+'&st=product', hide_query=True, timeout=timeout_page, cb_threshold=cb_threshold)

        # topads
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query='user_id={0}&ep=product&item=4&src=search&device={1}&q={2}'.format(user_id, platform, keyword), timeout=timeout, name=topads.host_production+"/promo/v1.1/display/ads?src=search&ep=product", cb_threshold=cb_threshold)
        viewport = "H_tF6sJO6_yO6Aj76sJEH_tho_Hh6AU7HAUd6MusrprXPcY0QRCBgcBxbMNBPmY2Q3r5yfVsqc15HsnFb9ohP3VagZYFrMYjP3o7b_J5Hsnh6m4abpJpbpn5HVYs63zjosCjyZ7RHpVMb_zjo3yWy_eNoZ7Oy_nNgsn7ypVjoAzw6A1d9pya6ZNkrcrE6snEHmdFHpKFHsrEg9BGqMzUZMggQj2fgAo6QJBkQfBoe7BpZ3O6HcoD692qu7gN3_-Sq1Y2Z9P-q9P2y_-3o3ea69BqzsBE3_UN8u2_Z_g-qjV2_JoGP3Uao32q17jfZ32so1NJgcxouJ-D_VzsH1Nk39z6zcoE3uHFoV2Je_uHucWE_3OGqJY9Z_uoucod_3B-r7BW69BxufzFyMFNPfoW63Wju7dF3A-Dq7BkQfBoe7BpZ37N83V9gICiQABEy1rNPOKaQcW-qMY2_1o-r7BXzsVq3JtO3AoZqVtp_3Bvq1B2_JoG8Bja69BqusB2yf7NHfHau3Bvq1BR_c2C8jYJe9B68jBd_uzgHJNEz_C68jjOZ3BRq3Ha_SgsQugMyp-3qcoW_MY-qMY2_1H7P7OEgRPoqMoN_uzVHjNJyRx6zcoN_OoG6e"
        res = topads.promo_views_P_v1(self, topads.host_production, viewport, headers=headers, name=topads.host_production+"/promo/v1/views/{viewport}", query="is_search=1&n_candidate_ads=3&src=search&alg=stm&ob=23&page=1&ab_test=N&number_ads_req=2&post_alg=cpc_shop_unq&number_of_ads=2&keywords={0}0&t={1}&uid={2}&render=false".format(keyword, platform, user_id), timeout=timeout, cb_threshold=cb_threshold)

        # accounts
        res = accounts.marketplace_pixel(self, accounts.host_production, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)

        # graphql
        res = graphql.graphql_searchFilterQuery(self, graphql.host_graphql, headers=headers, json={"variables":{"query":keyword, "source":"product"},"operationName":"SearchFilterQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        variables = {
            "userID": user_id,
            "query": keyword,
            "source": "search",
            "additional_params": "",
            "ob": 23,
            "per_page": 10,
            "userSearchID": "e79ceadfd4ba557416e6feda410bee3e",
            "filter": {
                "sc": "",
                "variants": "",
                "brand": "",
                "fcity": "",
                "shipping": "",
                "condition": "",
                "rt": "",
                "pmin": "",
                "pmax": ""
            }
        }
        res = graphql.graphql_srcProdQueries(self, graphql.host_graphql, headers=headers, json={"variables":variables,"operationName":"SrcProdQueries"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_searchModalQuery(self, graphql.host_graphql, headers=headers, json={"variables":{"q":keyword, "userId":user_id, "uniqueId":"8e4572f54dc5538765ea37ff30ab3c37"}, "operationName":"SearchModalQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_headerQuery(self, graphql.host_graphql, headers=headers, json={"variables":{"loggedIn":True}, "operationName":"HeaderQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_quickFilter(self, graphql.host_graphql, headers=headers, json={"variables":{"query":keyword}, "operationName":"quick_filter"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_isAuthenticatedQuery(self, graphql.host_graphql, headers=headers, json={"operationName": "isAuthenticatedQuery", "variables": {"key": "/search"}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_showCatalogQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"ShowCatalogQuery","variables":{"query":keyword,"per_page":10,"ob":23,"pmin":"","pmax":"","sc":""}}, timeout=timeout_graphql, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = SearchProductProduction
    min_wait = 3000
    max_wait = 5000
