from locust import HttpLocust, TaskSet, task
from modules import tokopedia, gw, cartapp, scrooge, orderapp, graphql
from tests.helper.account_helper import AccountHelper
import datetime
import random
import sys
import time

ah = AccountHelper()

class CartPayV2(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_LITE)
        self.user_id = self.account['user_id']
        self.device_id = self.config["device_id"]
        self.timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        self.timeout_page    = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        self.timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        self.cb_threshold    = self.config['cb_threshold']
        self.cookie = ah.get_sid_cookie(self.user_id)

    @task(1)
    def task1(self):

        bodies_reset_cart = {
            'status': '1',
            'lang': 'id'
        }
        headers_reset_cart = {
            'Tkpd-UserId': self.user_id,
            'content-type': 'application/x-www-form-urlencoded',
            'cookie': self.cookie
        }
        cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, self.user_id, self.device_id, 
            bodies=bodies_reset_cart, headers=headers_reset_cart, 
            cb_threshold=self.cb_threshold, timeout=self.timeout)

        #click buy
        product = random.choice(self.config['products'])
        product_id = product['id']
        shop_id = product['shop_id']
        headers = {
            'cookie':ah.get_sid_cookie(self.user_id)
        }
        addToCartMutationVariables = {
            "productID": product_id,
            "shopID": shop_id,
            "quantity": 1,
            "notes": None,
            "lang": "id"
        }
        res = graphql.graphql_addToCartMutation(self, graphql.host_graphql, headers=headers, 
            json={"variables":addToCartMutationVariables,"operationName":"addToCartMutation"}, 
            cb_threshold=self.cb_threshold, timeout=self.timeout_graphql, catch_response=True)

        if res.status_code == 200:
            try:
                if '"success":1' in res.content:
                    test_failed = False
                    res.success()
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        #do not continue if previous step failed
        if test_failed:
            return
        
        productRecentViewTriggerVariables = {
            "productID": product_id
        }
        res = graphql.graphql_productRecentViewTrigger(self, graphql.host_graphql, 
            headers=headers, json={"variables":productRecentViewTriggerVariables,"operationName":"ProductRecentViewTrigger"}, 
            cb_threshold=self.cb_threshold, timeout=self.timeout_graphql)

        res = graphql.graphql_isAuthenticatedQuery(self, graphql.host_graphql, 
            json={"operationName":"isAuthenticatedQuery","variables":{"key":"/cart"}}, 
            headers=headers, timeout=self.timeout_graphql, cb_threshold=self.cb_threshold)

        #query cart
        cartListQueryVariables = {
            "lang": "id",
            "isReset": True
        }
        res = graphql.graphql_cartListQuery(self, graphql.host_graphql, headers=headers, 
            json={"variables":cartListQueryVariables,"operationName":"CartListQuery"}, 
            cb_threshold=self.cb_threshold, timeout=self.timeout_graphql, catch_response=True)
        respon = dict()
        if res.status_code == 200:
            try:
                if '"cart_id"' in res.content:
                    test_failed = False
                    respon = res.json()
                    res.success()
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        #do not continue if previous step failed
        if test_failed:
            return

        updateCartVariables = {
            "carts": [
                {
                "cart_id": respon['data']['cart_list']['data']['cart_list'][0]['cart_id'],
                "quantity": 1,
                "notes": ""
                }
            ],
            "lang": "id"
        }
        res = graphql.graphql_updateCart(self, graphql.host_graphql, headers=headers, 
            json={"variables":updateCartVariables,"operationName":"updateCart"}, 
            cb_threshold=self.cb_threshold, timeout=self.timeout_graphql, catch_response=True)

        if res.status_code == 200:
            try:
                if '"OK"' in res.content:
                    test_failed = False
                    res.success()
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        #do not continue if previous step failed
        if test_failed:
            return


        #list address
        listAddressVariables = {}
        res = graphql.graphql_listAddress(self, graphql.host_graphql, headers=headers, 
            json={"variables":listAddressVariables,"operationName":"listAddress"}, 
            cb_threshold=self.cb_threshold, timeout=self.timeout_graphql, catch_response=True)
        if res.status_code == 200:
            try:
                if '"addr_id"' in res.content:
                    test_failed = False
                    res.success()
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        #do not continue if previous step failed
        if test_failed:
            return


        #shipment form
        getShipmentFormVariables = {
            "lang":"en"
        }
        res = graphql.graphql_getShipmentForm(self, graphql.host_graphql, headers=headers, 
        json={"variables":getShipmentFormVariables,"operationName":"GetShipmentForm"}, 
        cb_threshold=self.cb_threshold, timeout=self.timeout_graphql, catch_response=True)
        if res.status_code == 200:
            try:
                if '"ship_id"' in res.content:
                    test_failed = False
                    respon = res.json()
                    res.success()
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        #do not continue if previous step failed
        if test_failed:
            return

        shipment = respon['data']['get_shipment_form']
        kero_token = shipment['kero_token']
        kero_ut = shipment['kero_unix_time']
        destination = {
            "district_id": str(shipment['group_address'][0]['user_address']["district_id"]),
            "postal_code": shipment['group_address'][0]['user_address']['postal_code'],
            "lat": random.uniform(-6.149573, -6.247871),
            "lng": random.uniform(106.751159, 106.900907)
        }
        origin = {
            "district_id": str(shipment['group_address'][0]['group_shop'][0]['shop']["district_id"]),
            "postal_code": shipment['group_address'][0]['group_shop'][0]['shop']['postal_code'],
            "lat": shipment['group_address'][0]['group_shop'][0]['shop']["latitude"],
            "lng": shipment['group_address'][0]['group_shop'][0]['shop']["longitude"]
        }
        couriers = list()
        for courier in shipment['group_address'][0]['group_shop'][0]['shop_shipments']:
            ship_prods = list()
            ship_prods_id = list()
            for ship_prod in courier['ship_prods']:
                ship_prods.append(ship_prod['ship_group_name'])
                ship_prods_id.append(ship_prod['ship_prod_id'])
            couriers.append(
                {
                    "courier_id":courier['ship_id'],
                    "courier_name":courier['ship_code'],
                    "shipping_products":ship_prods,
                    "shipping_products_id":ship_prods_id
                }
            )
        get_courier_variables = {
            "couriers":couriers,
            "origin":origin,
            "destination":destination,
            "weight":str(random.randint(10,10000))+"g",
            "token":kero_token,
            "ut":kero_ut,
            "insurance":random.randint(0,1),
            "productInsurance":random.randint(0,1),
            "orderValue":shipment['group_address'][0]['group_shop'][0]['products'][0]['product_price'] * \
                         shipment['group_address'][0]['group_shop'][0]['products'][0]['product_quantity'],
            "catId":[  
                random.randint(1,50)
            ],
            "lang":"en"
        }

        res = graphql.graphql_getCourier(self, graphql.host_graphql, headers=headers, 
            json={"variables":get_courier_variables,"operationName":"GetCourier"}, 
        cb_threshold=self.cb_threshold, timeout=self.timeout_graphql, catch_response=True)
        if res.status_code == 200:
            try:
                if '"shipper_id"' in res.content:
                    test_failed = False
                    res.success()
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        #do not continue if previous step failed
        if test_failed:
            return


        get_district_boundary_variables = {
            "districtId":destination['district_id']
        }
        res = graphql.graphql_getDistrictBoundary(self, graphql.host_graphql, headers=headers, 
            json={"variables":get_district_boundary_variables,"operationName":"GetDistrictBoundary"}, 
            cb_threshold=self.cb_threshold, timeout=self.timeout_graphql, catch_response=True)
        if res.status_code == 200:
            try:
                if '"boundary"' in res.content:
                    test_failed = False
                    res.success()
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        #do not continue if previous step failed
        if test_failed:
            return

        currenttime = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        checkout_variables = {
            "carts": '{\
                "bot_data":{\
                    "m":true,\
                    "k":false,\
                    "s":true,\
                    "duration":'+str(random.randint(10,10000))+',\
                    "timestamp":"'+currenttime+'"\
                    },\
                "promo_code":"",\
                "is_donation":0,\
                "data":[\
                    {\
                        "address_id":'+str(shipment['group_address'][0]['user_address']['address_id'])+',\
                        "shop_products":[ \
                            {\
                                "shop_id":'+str(shop_id)+',\
                                "is_preorder":0,\
                                "finsurance":0,\
                                "shipping_info":{\
                                    "shipping_id":'+str(shipment['group_address'][0]['group_shop'][0]['shop_shipments'][0]['ship_id'])+',\
                                    "sp_id":'+str(shipment['group_address'][0]['group_shop'][0]['shop_shipments'][0]['ship_prods'][0]['ship_prod_id'])+'},\
                                "is_dropship":0,\
                                "dropship_data":{"name":"","telp_no":""},\
                                "product_data":[{"product_id":'+str(product_id)+'}],\
                                "fcancel_partial":0\
                            }\
                        ]\
                    }\
                ]}',
            "promo_suggested":False,
            "lang":"id"
            }
        res = graphql.graphql_checkout(self, graphql.host_graphql, headers=headers, 
            json={"variables":checkout_variables,"operationName":"checkout"}, 
            cb_threshold=self.cb_threshold, timeout=self.timeout_graphql, catch_response=True)
        if res.status_code == 200:
            try:
                if 'transaction_id' in res.content:
                    test_failed = False
                    respon = res.json()
                    res.success()
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        #do not continue if previous step failed
        if test_failed:
            return

        #payment
        transaction_id = respon['data']['checkout_cart']['data']['parameter']['transaction_id']
        transaction_date = respon['data']['checkout_cart']['data']['parameter']['transaction_date']
        user_defined_value = respon['data']['checkout_cart']['data']['parameter']['user_defined_value']
        product_list = respon['data']['checkout_cart']['data']['product_list']
        ids = orderapp.itemsList(product_list, 'id')
        prices = orderapp.itemsList(product_list, 'price')
        quantities = orderapp.itemsList(product_list, 'quantity')
        names = orderapp.itemsList(product_list, 'name')
        payment_metadata = respon['data']['checkout_cart']['data']['parameter']['payment_metadata']
        merchant_code = respon['data']['checkout_cart']['data']['parameter']['merchant_code']
        nid = respon['data']['checkout_cart']['data']['parameter']['nid']
        pid = respon['data']['checkout_cart']['data']['parameter']['pid']
        profile_code = respon['data']['checkout_cart']['data']['parameter']['profile_code']
        gateway_code = respon['data']['checkout_cart']['data']['parameter']['gateway_code']
        amount = respon['data']['checkout_cart']['data']['parameter']['amount']
        customer_email = respon['data']['checkout_cart']['data']['parameter']['customer_email']
        signature = respon['data']['checkout_cart']['data']['parameter']['signature']
        customer_name = respon['data']['checkout_cart']['data']['parameter']['customer_name']
        msisdn = respon['data']['checkout_cart']['data']['parameter']['customer_msisdn']
        currency = respon['data']['checkout_cart']['data']['parameter']['currency']

        bodies_v2Payment = {
            'customer_id': self.user_id,
            'customer_email': customer_email,
            'customer_name': customer_name,
            'transaction_id': transaction_id,
            'transaction_date': transaction_date,
            'amount': amount,
            'gateway_code': gateway_code,
            'currency': currency,
            'signature': signature,
            'items[id]': ids,
            'items[price]': prices,
            'items[quantity]': quantities,
            'items[name]': names,
            'nid': nid,
            'pid': pid,
            'user_defined_value': user_defined_value,
            'merchant_code': merchant_code,
            'profile_code': profile_code,
            'language': 'id-ID',
            'payment_metadata': payment_metadata,
            'customer_msisdn': msisdn,
            'device_info': '[object+Object]'
        }

        headers_v2Payment = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        res = scrooge.payment_v2(self, scrooge.host_production, bodies=bodies_v2Payment,
                                    headers=headers_v2Payment, timeout=self.timeout_page,
                                    cb_threshold=self.cb_threshold, catch_response=True)

        if res != "" and res.status_code == 200:
                try:
                    if 'Payment Failed' in res.content or len(str(res.content)) < 1:
                        test_failed = True
                        res.failure("Payment Failed or empty html returned")
                    else:
                        res.success()
                except Exception as e:
                    test_failed = True
                    res.failure(res.content)
        else:
                try:
                    res.raise_for_status()
                except Exception as e:
                    test_failed = True
                    res.failure(e)


class WebsiteUser(HttpLocust):
    host = ""
    task_set = CartPayV2
    min_wait = 1500
    max_wait = 2500
