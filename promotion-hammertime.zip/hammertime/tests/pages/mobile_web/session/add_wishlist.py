from locust import HttpLocust, TaskSet, task
from modules import graphql
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class AddWishlist(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BOTH)

    @task(1)
    def task1(self):
        user_id = self.account["user_id"]
        product_ids = random.choice(self.config['dexter']['massive_products'])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold    = self.config['cb_threshold']
        
        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }
        addWishlistVariable = {
            "userID": user_id,
            "productID": product_ids
        }
        res = graphql.graphql_addWishlist(self, graphql.host_graphql, headers=headers, json={"variables":addWishlistVariable,"operationName":"addWishlist"}, cb_threshold=cb_threshold, timeout=timeout_graphql, catch_response=True)
        
        is_success = False
        try:
            resJSON = res.json()
            is_success = resJSON['data']['wishlist_add']['success']
            res.success()
        except Exception, e:
            res.failure(e)
        if is_success is True:
            removeWishlistVariable = {
                "userID": user_id,
                "productID": product_ids
            }
            resRemove = graphql.graphql_removeWishlist(self, graphql.host_graphql, headers=headers, json={"variables":removeWishlistVariable,"operationName":"removeWishlist"}, cb_threshold=cb_threshold, timeout=timeout_graphql)
        


class WebsiteUser(HttpLocust):
    host = ""
    task_set = AddWishlist
    min_wait = 1500
    max_wait = 2500
