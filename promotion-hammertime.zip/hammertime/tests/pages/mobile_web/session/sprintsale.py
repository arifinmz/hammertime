from locust import HttpLocust, TaskSet, task
from modules import accounts, tokopedia, ace
from tests.helper.account_helper import AccountHelper
import random, json

ah = AccountHelper()

class SprintSale(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config["dexter"]["massive_accounts"], login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout      = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        campaign = self.config["sprint_sale_campaign"]


        headers = {
            'cookie': ah.get_sid_cookie(user_id)
        }

        # home
        home_domain = '/discovery/flash-sale'
        res = tokopedia.page(self, tokopedia.host_production_m, home_domain, headers=headers,  cb_threshold=cb_threshold, timeout=timeout_page)
        
        # ace
        # campaign id for flash-sale is always fixed 62532 (confirmed by stephanus tedy)
        # paging is random, at least one page, max 4 pages sequentially
        pageList = ['2', '3', '4', '5'] 
        for index in range (0, random.randint(0, len(pageList)) ):
            res = ace.hoth_discovery_render_component_flashsale_P(self, ace.host_production, "mobile", campaign,
                query='rpc_Page='+pageList[index]+'&rpc_ResultPerPage=20', cb_threshold=cb_threshold, timeout=timeout,
                name=ace.host_production+'/hoth/discovery/render/component/mobile/flash-sale')


class WebsiteUser(HttpLocust):
    host     = ""
    task_set = SprintSale
    min_wait = 1500
    max_wait = 2500