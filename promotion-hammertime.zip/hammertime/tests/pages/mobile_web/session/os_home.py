from locust import HttpLocust, TaskSet, task
from modules import graphql, mojito, tome, tokopedia
from tests.helper.account_helper import AccountHelper
import random, json

ah = AccountHelper()

class OSHome(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config["dexter"]["massive_accounts"], login_type=ah.LOGIN_TYPE_BOTH)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']

        headers = {
            'cookie': ah.get_sid_cookie(user_id),
            'Authorization': ah.get_token(user_id)
        }

        domain = '/official-store'
        res = tokopedia.page(self, tokopedia.host_production_m, domain, headers=headers,  cb_threshold=cb_threshold, timeout=timeout_page)

        updateCartCounterMutationVariables = {}
        res = graphql.graphql_updateCartCounterMutation(self, graphql.host_graphql, headers=headers, json={"variables":updateCartCounterMutationVariables,"operationName":"updateCartCounterMutation"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

        officialStoreProductsVariables = {
            "device": "mobile",
            "offset": 0,
            "categories": [
                0
            ]
        }
        res = graphql.graphql_officialStoreProducts(self, graphql.host_graphql, headers=headers, json={"variables":officialStoreProductsVariables,"operationName":"OfficialStoreProducts"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

class WebsiteUser(HttpLocust):
    host     = ""
    task_set = OSHome
    min_wait = 1500
    max_wait = 2500