from locust import HttpLocust, TaskSet, task
from modules import tokopedia, graphql
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class OsProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        shop = random.choice(self.config['merchant']['os'])
        shop_id = shop['id']   
        shop_domain = shop['shop_domain']
        user_id = self.account['user_id']

        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        headers     = {
            'cookie': ah.get_sid_cookie(user_id)
        }
        cb_threshold = self.config['cb_threshold']

        #shop page
        res = tokopedia.page(self, tokopedia.host_production_m, "/"+shop_domain, name=tokopedia.host_production_m+"/{shop_domain}", headers=headers, timeout=timeout_page, cb_threshold=cb_threshold)

        #graphql
        res = graphql.graphql_shopFollowers(self, graphql.host_graphql, json={"operationName":"shopFollowers","variables":{"shopID":shop_id,"page":1,"perPage":10}}, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_shopSummaryQuery(self, graphql.host_graphql, json={"operationName":"ShopSummaryQuery","variables":{"toShopId":shop_id}}, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_ssiOfficialStoreQuery(self, graphql.host_graphql, json={"operationName":"SSIOfficialStoreQuery","variables":{"domain":shop_domain}}, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_updateProductList(self, graphql.host_graphql, json={"operationName":"updateProductList","variables":{"userID":user_id,"shopID":shop_id,"filter":{"ob":1},"page":1,"perPage":10,"etalase":"all","query":"","useace":True,"isOfficial":True}}, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_shopCheckFavorite(self, graphql.host_graphql, json={"operationName":"shopCheckFavorite","variables":{"userID":user_id,"shopID":shop_id}}, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_isAuthenticatedQuery(self, graphql.host_graphql, json={"operationName":"isAuthenticatedQuery","variables":{"key":shop_domain}}, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_shopTopChatQuery(self, graphql.host_graphql, json={"operationName":"ShopTopChatQuery","variables":{"toShopId":shop_id}}, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_shopFeaturedProduct(self, graphql.host_graphql, json={"operationName":"shopFeaturedProduct","variables":{"shopID":shop_id}}, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = tokopedia.host_production_m
    task_set = OsProduction
    min_wait = 3000
    max_wait = 5000