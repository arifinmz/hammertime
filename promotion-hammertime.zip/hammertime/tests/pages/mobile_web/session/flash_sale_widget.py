from locust import HttpLocust, TaskSet, task
from tests.helper.account_helper import AccountHelper
from modules import tokopedia, mojito, graphql

ah = AccountHelper()

class FlashSaleWidget(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task2(self):
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']

        res = graphql.graphql_flashSaleWidgetMweb(self, graphql.host_graphql, method='POST', timeout=timeout_graphql, cb_threshold=cb_threshold)
        print(res.content)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = FlashSaleWidget
    min_wait = 1500
    max_wait = 2500