from locust import HttpLocust, TaskSet, task
from modules import tokopedia, graphql
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class TokopointsCatalogs(TaskSet):
    def on_start(self):
        if not hasattr(TokopointsCatalogs, 'config_loaded') :
            TokopointsCatalogs.test_config = self.configuration['production']
            TokopointsCatalogs.large_users = self.team_configuration(TokopointsCatalogs.test_config['dexter']['20k_accounts'])
            TokopointsCatalogs.config_loaded = True
        self.account = ah.get_account(self, accounts=TokopointsCatalogs.large_users, login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        timeout_graphql= (TokopointsCatalogs.test_config['timeout_graphql'][0], TokopointsCatalogs.test_config['timeout_graphql'][1])
        timeout_page = (TokopointsCatalogs.test_config['timeout_page'][0], TokopointsCatalogs.test_config['timeout_page'][1])
        cb_threshold = TokopointsCatalogs.test_config['cb_threshold']
        headers = {
            'cookie': ah.get_sid_cookie(user_id)
        }

        res = tokopedia.page(self, tokopedia.host_production_m, '/tokopoints/tukar-point', headers=headers, timeout=timeout_page, cb_threshold=cb_threshold)
        
        res = graphql.graphql_hachikoMainQuery(self, graphql.host_graphql, headers={'cookie': ah.get_sid_cookie(user_id), 'origin':'https://m.tokopedia.com'}, json={"operationName":"HachikoMainQuery","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_isAuthenticatedQuery(self, graphql.host_graphql, headers=headers, json={"operationName": "isAuthenticatedQuery", "variables": {"key": "/tokopoints"}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_CatalogListGoQuery(self, graphql.host_graphql, headers=headers, json={"operationName": "CatalogListGoQuery", "variables":{"page": 1, "limit": 100, "sortID": 1, "categoryID": 0, "pointRange": 0}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_UserPointsQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"UserPointsQuery","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_tokopointsCarouselQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"TokopointsCarouselQuery","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_TokopointsMainGolangQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"TokopointsMainGolangQuery","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        # res = graphql.graphql_FloatingEggQuery(self, graphql.host_graphql, headers=headers, json={"operationName": "FloatingEggQuery", "variables": {}}, timeout=timeout_graphql, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = tokopedia.host_production
    task_set = TokopointsCatalogs
    min_wait = 600
    max_wait = 800
