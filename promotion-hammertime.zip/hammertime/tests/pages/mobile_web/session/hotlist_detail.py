from locust import HttpLocust, TaskSet, task
from modules import tokopedia, graphql, topads
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class HotlistDetail(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id         = self.account['user_id']
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page    = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold    = self.config['cb_threshold']
        headers         = {
            'cookie':ah.get_sid_cookie(user_id)
        }
        platform        = 'mobile'
        hotlist         = random.choice(self.config['hotlist'])
        hotlist_id      = hotlist['filter_attribute']['hot_id']

        domain = '/hot/'+hotlist['alias_key']
        res = tokopedia.page(self, tokopedia.host_production_m, domain, headers=headers, name=tokopedia.host_production_m+'/hot/{alias_key}', timeout=timeout_page, cb_threshold=cb_threshold)

        # graphql
        filter_attribute = '&'.join(['%s=%s' % (key, value) for (key, value) in hotlist['filter_attribute'].items()])
        search_json = {
            'operationName': 'SearchFilterQuery',
            'variables': {
                "query": hotlist['filter_attribute']['q'],
                "source": hotlist['filter_attribute']['source'],
                "extraParams": filter_attribute
            }
        }
        res = graphql.graphql_searchFilterQuery(self, graphql.host_graphql, headers=headers, json=search_json, timeout=timeout, cb_threshold=cb_threshold)
        res = graphql.graphql_updateCartCounterMutation(self, graphql.host_graphql, headers=headers, json={"operationName":"updateCartCounterMutation","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)

        hotlist_json = {
            'operationName': 'HotlistDetailProductQuery',
            'variables': {
                'filterAttribute': filter_attribute,
                'rows': 20,
                'start': 0
            }
        }
        res = graphql.graphql_HotlistDetailProductQuery(self, graphql.host_graphql, headers=headers, json=hotlist_json, timeout=timeout_graphql, cb_threshold=cb_threshold)

        # topads
        topads_query = 'ep=product&item=2&src=hotlist&device={0}&page=1&user_id={1}&search_nf=0&h={2}&q=&dep_id=&pmin={3}&pmax={4}&official=&rating=&floc=&variants=&fcity=&wholesale=&shipping=&preorder=&condition=&freereturns=&cashback=&brand='.format(platform, user_id, hotlist_id, hotlist['filter_attribute']['pmin'], hotlist['filter_attribute']['pmax'])
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query=topads_query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = HotlistDetail
    min_wait = 1500
    max_wait = 2500