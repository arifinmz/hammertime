from locust import HttpLocust, TaskSet, task
from modules import tokopedia, accounts, topads, graphql
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class Wishlist(TaskSet):
    def on_start(self):
        self.config = self.configuration['production']
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id         = self.account['user_id']
        phone           = self.account['phone']
        platform        = 'mobile'
        device_id       = self.config['device_id']
        timeout         = (self.config['timeout'][0], self.config['timeout'][1])
        timeout_page    = (self.config['timeout_page'][0], self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0], self.config['timeout_graphql'][1])
        cb_threshold    = self.config['cb_threshold']
        
        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }

        res = tokopedia.page(self, tokopedia.host_production_m, '/wishlist', headers=headers, timeout=timeout_page, cb_threshold=cb_threshold)

        # accounts
        res = accounts.marketplace_pixel(self, accounts.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        # graphql
        res = graphql.graphql_headerQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"HeaderQuery","variables":{"loggedIn":True}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_pendingCashback(self, graphql.host_graphql, headers=headers, json={"operationName":"PendingCashback","variables":{"userID":int(user_id),"msisdn":phone}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_rechargeCategoryDetail(self, graphql.host_graphql, headers=headers, json={"operationName":"rechargeCategoryDetail","variables":{"category_id":1}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_rechargeFavoriteNumber(self, graphql.host_graphql, headers=headers, json={"operationName":"rechargeFavoriteNumber","variables":{"category_id":1}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_footerQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"FooterQuery","variables":{"loggedIn":True}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_updateCartCounterMutation(self, graphql.host_graphql, headers=headers, json={"operationName":"updateCartCounterMutation","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_feedInspirationQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"FeedInspirationQuery","variables":{"userID":int(user_id),"insLimit":3,"insCursor":"","insPage":1,"source":"home"}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_saldoQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"SaldoQuery", "variables":{"userID": user_id}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_wishlistQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"WishlistQuery","variables":{"userID":user_id,"query":"","page":1,"count":20}}, timeout=timeout_graphql, cb_threshold=cb_threshold)

        # topads
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query="ep=product&src=wishlist&device={0}&user_id={1}&page=1&dep_id=36".format(platform, user_id), name=topads.host_production+"/promo/v1.1/display/ads?ep=product&src=wishlist", timeout=timeout, cb_threshold=cb_threshold)
        res = topads.promo_info_user_v1(self, topads.host_production, user_id, device_id, headers=headers, query="pub_id=12", name=topads.host_production+"/promo/v1/info/user?pub_id=12", timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = tokopedia.host_production
    task_set = Wishlist
    min_wait = 1500
    max_wait = 2500