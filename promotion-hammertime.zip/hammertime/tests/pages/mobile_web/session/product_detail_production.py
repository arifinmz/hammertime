from locust import HttpLocust, TaskSet, task
from modules import tokopedia, inbox, accounts, js, graphql, tome
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class ProductDetailProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_LITE)


    @task(1)
    def task1(self):
        user_id         = self.account['user_id']
        product_id      = str(random.choice(self.config['dexter']['massive_products']))
        headers         = {
          'cookie':ah.get_sid_cookie(user_id),
          'origin':"https://m.tokopedia.com"
        }
        access_status = True

        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']

        res = tome.product_P_v2_1(self, tome.host_production, product_id, query='p_id='+product_id, name=tome.host_production+"/v2/product/{product_id}", catch_response=True)
        try:
            json_res = res.json()
            shop_domain = json_res['data']['product_shop']['shop_domain']
            shop_id = json_res['data']['product_shop']['shop_id']
            product_alias = json_res['data']['product_alias']
            product_path = "/%s/%s" % (shop_domain, product_alias)
        except Exception as er:
            access_status = False

        if access_status :
            res_page = tokopedia.page(self, tokopedia.host_production_m, product_path, name=tokopedia.host_production_m+"/{shop_domain}/{product_domain}", headers=headers, timeout=timeout_page, cb_threshold=cb_threshold)

            # IsAuthenticatedQuery
            isAuthenticatedQueryVariables = {
                "key": product_path
            }
            res = graphql.graphql_isAuthenticatedQuery(self, graphql.host_graphql, json={"variables":isAuthenticatedQueryVariables,"operationName":"isAuthenticatedQuery"}, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)
            
            productStockQueryVariables = {
                "productID": product_id,
                "lang": "id"
            }
            res = graphql.graphql_productStockQuery(self, graphql.host_graphql, json={"variables":productStockQueryVariables,"operationName":"ProductStockQuery"}, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)
            
            res = graphql.graphql_ProductTopChatQuery(self, graphql.host_graphql, json={"operationName":"ProductTopchatQuery","variables":{"toShopId":int(shop_id)}}, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)
            
            res = graphql.graphql_SessionQuery(self, graphql.host_graphql, json={"operationName":"SessionQuery","variables":{"source":user_id}}, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)
            
            res = graphql.graphql_productTokenQuery(self, graphql.host_graphql, json={"variables":{"loggedIn":True},"operationName":"ProductTokenQuery"}, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)
            
            productWishlistQueryVariables = {
                "productID": product_id
            }
            res = graphql.graphql_ProductWishlistQuery(self, graphql.host_graphql, json={"variables":productWishlistQueryVariables, "operationName":"ProductWishlistQuery"}, cb_threshold=cb_threshold, headers=headers, timeout=timeout_graphql)
                        
            promoWidgetQueryVariables = {
                "userID": int(user_id),
                "deviceType": "mobile",
                "targetType": "login_user",
                "placeholder": "pdp_widget",
                "lang": "id",
                "shopType": "merchant"
            }
            res = graphql.graphql_promoWidgetQuery(self, graphql.host_graphql, json={"variables":promoWidgetQueryVariables,"operationName":"PromoWidgetQuery"}, cb_threshold=cb_threshold, headers=headers, timeout=timeout_graphql)
            
            productVideoQueryVariables = {
                "productID": product_id
            }
            res = graphql.graphql_productVideoQuery(self, graphql.host_graphql, json={"variables":productVideoQueryVariables,"operationName":"ProductVideoQuery"}, cb_threshold=cb_threshold, headers=headers, timeout=timeout_graphql)
            
            productReviewQueryVariables = {
                "productID": product_id,
                "ssr": False
            }
            res = graphql.graphql_productReviewQuery(self, graphql.host_graphql, json={"variables":productReviewQueryVariables, "operationName":"ProductReviewQuery"}, cb_threshold=cb_threshold, headers=headers, timeout=timeout_graphql)
            
            PDPTalkQueryVariables = {
                "productId": product_id,
                "page": 1,
                "perPage": 1,
                "source": "sneak_peak"
            }
            res = graphql.graphql_PDPTalkQuery(self, graphql.host_graphql, json={"variables":PDPTalkQueryVariables,"operationName":"PDPTalkQuery"}, cb_threshold=cb_threshold, headers=headers, timeout=timeout_graphql)
            
            productOtherQueryVariables = {
                "productID": product_id,
                "rows": 10,
                "shopID": shop_id,
                "start": 0
            }
            res = graphql.graphql_ProductOtherQuery(self, graphql.host_graphql, json={"variables":productOtherQueryVariables,"operationName":"ProductOtherQuery"}, cb_threshold=cb_threshold, headers=headers, timeout=timeout_graphql)
        
class WebsiteUser(HttpLocust):
    host     = ""
    task_set = ProductDetailProduction
    min_wait = 3000
    max_wait = 5000
