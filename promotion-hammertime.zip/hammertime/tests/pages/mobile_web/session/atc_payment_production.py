import random
from locust import HttpLocust, TaskSet, task
from modules import cartapp, scrooge, orderapp
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()


class Checkout(TaskSet):

    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        if not hasattr(Checkout, 'config_loaded'):
            Checkout.test_config = self.configuration['production']
            Checkout.stitch_accounts = self.team_configuration(Checkout.test_config['stitch']['massive_accounts'])
            Checkout.config_loaded = True
        self.account = ah.get_account(self, accounts=Checkout.stitch_accounts,
                                      login_type=ah.LOGIN_TYPE_LITE)

    # User accessing home page with session from cookie
    @task(1)
    def task1(self):

        timeout = (Checkout.test_config['timeout'][0], Checkout.test_config['timeout'][1])
        cb_threshold = Checkout.test_config["cb_threshold"]
        test_failed = False
        device_id = Checkout.test_config['device_id']
        os_type = Checkout.test_config['os_type']
        password = self.account['password']
        product = random.choice(Checkout.test_config['products'])
        product_id = product['id']
        shop_id = product['shop_id']
        user_id = self.account["user_id"]
        cookie = orderapp.find_between(ah.get_sid_cookie(user_id), '_SID_Tokopedia', ';')
        # attribute for reset cart
        bodies_reset = {
            'status': '1',
            'lang': 'id'
        }
        headers_reset = {
            'Tkpd-UserId': user_id,
            'content-type': 'application/x-www-form-urlencoded',
            'cookie': cookie,
            'X-Device': 'loadtest-stitch'
        }

        # atc
        headers = {
            'cookie': cookie,
            'Authorization': ah.get_token(self.account['user_id']),
            'Tkpd-UserId': user_id,
            'X-Device': 'loadtest-stitch'
        }
        body_atc = {
            'params': '{"product_id":' + product_id + ', "quantity": 1, "shop_id":' + shop_id + ', "notes": ""}'
        }

        res = cartapp.add_product_cart_v1(self, cartapp.host_production, headers=headers, bodies=body_atc,
                                          cb_threshold=cb_threshold, timeout=timeout, catch_response=True)

        if res.status_code == 200:
            try:
                if '"success":1' in res.content:
                    test_failed = False
                    res.success()
                else:
                    if 'Maaf, Permohonan Anda tidak dapat diproses saat ini. Mohon dicoba kembali.' in res.content:
                        res.failure('Maaf, Permohonan Anda tidak dapat diproses saat ini. Mohon dicoba kembali.')
                    else:
                        res.failure("attribute success is not 1")
                    test_failed = True
            except Exception as e:
                test_failed = True
                res.failure(e)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        if not test_failed:
            try:
                respon = res.json()
                cart_id = respon['data']['data']['cart_id']
                # update cart
                carts_param = '[{"cart_id": ' + str(cart_id) + ', "quantity":1, "notes": "update ya"}]'
                body_updateCart = {
                    "carts": carts_param
                }
                res = cartapp.update_cart(self, cartapp.host_production, headers=headers, bodies=body_updateCart,
                                          cb_threshold=cb_threshold, timeout=timeout, catch_response=True)

                if res.status_code == 200:
                    try:
                        if '"status":true' and '"status":"OK"' in res.content:
                            test_failed = False
                            res.success()
                        else:
                            test_failed = True
                            res.failure('status is not true/ok')
                    except Exception as e:
                        test_failed = True
                        res.failure(e)
                else:
                    try:
                        res.raise_for_status()
                    except Exception as e:
                        test_failed = True
                        res.failure(e)
            except Exception:
                test_failed = True

            if not test_failed:
                # shipment address form
                headers_shipmentAddressForm = {
                    'cookie': cookie,
                    'Tkpd-UserId': user_id,
                    'X-Device': 'loadtest-stitch'
                }
                res = cartapp.shipment_address_form(self, cartapp.host_production, headers=headers_shipmentAddressForm,
                                                    cb_threshold=cb_threshold, timeout=timeout, catch_response=True)

                if res.status_code == 200:
                    try:
                        if 'address_id' in res.content:
                            test_failed = False
                            res.success()
                        else:
                            test_failed = True
                            res.failure('address_id is not exist')
                    except Exception as e:
                        test_failed = True
                        res.failure(e)
                else:
                    try:
                        res.raise_for_status()
                    except Exception as e:
                        test_failed = True
                        res.failure(e)

                if not test_failed:
                    try:
                        respon = res.json()
                        address_id = respon['data']['group_address'][0]['user_address']['address_id']
                        shop_id = respon['data']['group_address'][0]['group_shop'][0]['shop']['shop_id']
                        shipping_id = respon['data']['group_address'][0]['group_shop'][0]['shop_shipments'][0][
                            'ship_id']  # jne
                        sp_id = \
                        respon['data']['group_address'][0]['group_shop'][0]['shop_shipments'][0]['ship_prods'][0][
                            'ship_prod_id']  # reguler
                        product_id = respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_id']
                        notes = respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_notes']
                        quantity = respon['data']['group_address'][0]['group_shop'][0]['products'][0][
                            'product_quantity']

                        # check promo code
                        promo_code = "MZAFREONGKIR"
                        headers_checkPromoCode = {
                            "Tkpd-UserId": user_id,
                            "cookie": cookie,
                            'X-Device': 'loadtest-stitch'
                        }

                        body_checkPromoCode = {
                            "promo_code": promo_code
                        }
                        res = cartapp.check_promo_code(self, cartapp.host_production, headers=headers_checkPromoCode,
                                                       bodies=body_checkPromoCode, cb_threshold=cb_threshold,
                                                       timeout=timeout, catch_response=True)

                        if res.status_code == 200:
                            try:
                                if '"status":"OK"' in res.content:
                                    test_failed = False
                                    res.success()
                                else:
                                    test_failed = True
                                    res.failure('status is not ok')
                            except Exception as e:
                                test_failed = True
                                res.failure(e)
                        else:
                            try:
                                res.raise_for_status()
                            except Exception as e:
                                test_failed = True
                                res.failure(e)
                    except Exception:
                        test_failed = True

                    if not test_failed:

                        # check promo code final
                        carts_param = cartapp.check_promo_code_final_params(promo_code, address_id, shop_id,
                                                                            shipping_id, sp_id, product_id, notes,
                                                                            quantity)
                        headers_checkPromoCodeFinal = {
                            "Tkpd-UserId": user_id,
                            "cookie": cookie,
                            'X-Device': 'loadtest-stitch'
                        }
                        body_checkPromoCodeFinal = {
                            "carts": carts_param
                        }
                        res = cartapp.check_promo_code_final(self, cartapp.host_production,
                                                             headers=headers_checkPromoCodeFinal,
                                                             bodies=body_checkPromoCodeFinal, cb_threshold=cb_threshold,
                                                             timeout=timeout, catch_response=True)

                        if res.status_code == 200:
                            try:
                                if '"status":"OK"' in res.content:
                                    test_failed = False
                                    res.success()
                                else:
                                    test_failed = True
                                    res.failure('status is not ok')
                            except Exception as e:
                                test_failed = True
                                res.failure(e)
                        else:
                            try:
                                res.raise_for_status()
                            except Exception as e:
                                test_failed = True
                                res.failure(e)

                        if not test_failed:
                            # checkout
                            headers_checkout = {
                                "Tkpd-UserId": user_id,
                                "cookie": cookie,
                                'X-Device': 'loadtest-stitch'
                            }
                            body_checkout = {
                                "carts": carts_param
                            }
                            res = cartapp.checkout(self, cartapp.host_production, headers=headers_checkout,
                                                   bodies=body_checkout, cb_threshold=cb_threshold, timeout=timeout,
                                                   catch_response=True)
                            if not res == "":
                                if res.status_code == 200:
                                    try:
                                        if 'transaction_id' in res.content:
                                            test_failed = False
                                            res.success()
                                        else:
                                            if 'Tidak ada keranjang belanja yang bisa diproses.' in \
                                                    res.json()['message_error'][0]:
                                                res.success()
                                            else:
                                                cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                                                                   bodies=bodies_reset, headers=headers_reset,
                                                                   cb_threshold=cb_threshold, timeout=timeout)
                                                res.failure('transaction id is not exist')

                                            test_failed = True

                                    except Exception as e:
                                        test_failed = True
                                        res.failure(e)
                                else:
                                    try:
                                        res.raise_for_status()
                                    except Exception as e:
                                        test_failed = True
                                        cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                                                           bodies=bodies_reset, headers=headers_reset,
                                                           cb_threshold=cb_threshold, timeout=timeout)
                                        res.failure(e)
                            else:
                                test_failed = True
                                cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                                                   bodies=bodies_reset,
                                                   headers=headers_reset, cb_threshold=cb_threshold,
                                                   timeout=timeout)

                            if not test_failed:
                                try:
                                    respon = res.json()
                                    transaction_id = respon['data']['data']['parameter']['transaction_id']
                                    transaction_date = respon['data']['data']['parameter']['transaction_date']
                                    user_defined_value = respon['data']['data']['parameter']['user_defined_value']
                                    product_list = respon['data']['data']['product_list']
                                    ids = orderapp.itemsList(product_list, 'id')
                                    prices = orderapp.itemsList(product_list, 'price')
                                    quantities = orderapp.itemsList(product_list, 'quantity')
                                    names = orderapp.itemsList(product_list, 'name')
                                    payment_metadata = respon['data']['data']['parameter']['payment_metadata']
                                    merchant_code = respon['data']['data']['parameter']['merchant_code']
                                    nid = respon['data']['data']['parameter']['nid']
                                    pid = respon['data']['data']['parameter']['pid']
                                    profile_code = 'TKPD_VOUCHER'
                                    gateway_code = respon['data']['data']['parameter']['gateway_code']
                                    amount = respon['data']['data']['parameter']['amount']
                                    customer_email = respon['data']['data']['parameter']['customer_email']
                                    signature = respon['data']['data']['parameter']['signature']
                                    customer_name = respon['data']['data']['parameter']['customer_name']
                                    msisdn = respon['data']['data']['parameter']['customer_msisdn']
                                    currency = respon['data']['data']['parameter']['currency']

                                    # payment
                                    bodies_v2Payment = {
                                        'customer_id': user_id,
                                        'customer_email': customer_email,
                                        'customer_name': customer_name,
                                        'transaction_id': transaction_id,
                                        'transaction_date': transaction_date,
                                        'amount': amount,
                                        'gateway_code': gateway_code,
                                        'currency': currency,
                                        'signature': signature,
                                        'items[id]': ids,
                                        'items[price]': prices,
                                        'items[quantity]': quantities,
                                        'items[name]': names,
                                        'nid': nid,
                                        'pid': pid,
                                        'user_defined_value': user_defined_value,
                                        'merchant_code': merchant_code,
                                        'profile_code': profile_code,
                                        'language': 'id-ID',
                                        'payment_metadata': payment_metadata,
                                        'customer_msisdn': msisdn,

                                    }

                                    headers_v2Payment = {
                                        'Content-Type': 'application/x-www-form-urlencoded'
                                    }

                                    res = scrooge.payment_v2(self, scrooge.host_production, bodies=bodies_v2Payment,
                                                             headers=headers_v2Payment, timeout=timeout,
                                                             cb_threshold=cb_threshold, catch_response=True)

                                    if not res == "":
                                        if res.status_code == 200:
                                            try:
                                                if 'Payment Failed' in res.content or len(str(res.content)) < 1:
                                                    test_failed = True
                                                    cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id,
                                                                       device_id,
                                                                       bodies=bodies_reset,
                                                                       headers=headers_reset, cb_threshold=cb_threshold,
                                                                       timeout=timeout)
                                                    res.failure("Payment Failed or empty html returned")
                                                else:
                                                    res.success()
                                            except Exception as e:
                                                res.failure('v2/payment is not ok')
                                                test_failed = True
                                                cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                                                                   bodies=bodies_reset,
                                                                   headers=headers_reset, cb_threshold=cb_threshold,
                                                                   timeout=timeout)
                                        else:
                                            try:
                                                res.raise_for_status()
                                            except Exception as e:
                                                res.failure(e)
                                                test_failed = True
                                                cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                                                                   bodies=bodies_reset,
                                                                   headers=headers_reset, cb_threshold=cb_threshold,
                                                                   timeout=timeout)
                                    else:
                                        test_failed = True
                                        cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                                                           bodies=bodies_reset,
                                                           headers=headers_reset, cb_threshold=cb_threshold,
                                                           timeout=timeout)
                                except Exception:
                                    test_failed = True

                                if not test_failed and res.content:

                                    # confirm
                                    attribute = [
                                        'payment_amount',
                                        'toppoints_amount',
                                        'merchant_code',
                                        'transaction_id',
                                        'profile_code',
                                        'signature',
                                        'merchant_id',
                                        'is_use_tokocash',
                                        'is_use_saldo',
                                        'voucher_code'
                                    ]

                                    bodies = scrooge.get_values_from_selector(self, res.content, 'name', attribute)

                                    payment_amount = bodies[0]
                                    toppoints_amount = bodies[1]
                                    merchant_code = bodies[2]
                                    transaction_id = bodies[3]
                                    profile_code = bodies[4]
                                    signature = bodies[5]
                                    merchant_id = bodies[6]
                                    is_use_tokocash = bodies[7]
                                    is_use_saldo = bodies[8]
                                    voucher_code = bodies[9]

                                    bodies_v2Confirm = {
                                        "gateway_code": "TOKOPEDIAWALLET",
                                        "toppoints_amount": toppoints_amount,
                                        "payment_amount": payment_amount,
                                        "merchant_code": merchant_code,
                                        "transaction_id": transaction_id,
                                        "profile_code": profile_code,
                                        "gateways": "",
                                        "voucher_code": voucher_code,
                                        "signature": signature,
                                        "merchant_id": merchant_id,
                                        "is_use_tokocash": is_use_tokocash,
                                        "is_use_saldo": is_use_saldo,
                                        "passwordTokopedia": password
                                    }
                                    res = scrooge.payment_confirm_P_v2(self, scrooge.host_production,
                                                                       bodies=bodies_v2Confirm, timeout=timeout,
                                                                       cb_threshold=cb_threshold, catch_response=True)

                                    if not res == "":
                                        if res.status_code == 200:
                                            try:
                                                manual_json = res.json()
                                                error_status = manual_json["errors"]
                                                if error_status == None:
                                                    res.success()
                                                else:
                                                    test_failed = True
                                                    cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id,
                                                                       device_id, bodies=bodies_reset,
                                                                       headers=headers_reset, cb_threshold=cb_threshold,
                                                                       timeout=timeout)
                                                    res.failure('errors exist')
                                            except Exception as e:
                                                res.failure(e)
                                                test_failed = True
                                                cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                                                                   bodies=bodies_reset,
                                                                   headers=headers_reset, cb_threshold=cb_threshold,
                                                                   timeout=timeout)
                                        else:
                                            try:
                                                res.raise_for_status()
                                            except Exception as e:
                                                res.failure(e)
                                                test_failed = True
                                                cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                                                                   bodies=bodies_reset,
                                                                   headers=headers_reset, cb_threshold=cb_threshold,
                                                                   timeout=timeout)
                                    else:
                                        test_failed = True
                                        cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                                                           bodies=bodies_reset,
                                                           headers=headers_reset, cb_threshold=cb_threshold,
                                                           timeout=timeout)

                                    if not test_failed:
                                        if error_status is None:
                                            try:
                                                # thanks
                                                respon = res.json()
                                                gateway_code = respon['data']['form']['gateway_code'][0]
                                                merchant_code = respon['data']['form']['merchant_code'][0]
                                                transaction_id = respon['data']['form']['transaction_id'][0]
                                                profile_code = respon['data']['form']['profile_code'][0]
                                                signature = respon['data']['form']['signature'][0]

                                                bodies_v2Thanks = {
                                                    "gateway_code": gateway_code,
                                                    "merchant_code": merchant_code,
                                                    "transaction_id": transaction_id,
                                                    "profile_code": profile_code,
                                                    "signature": signature
                                                }

                                                res = scrooge.payment_thanks_P_v2(self, scrooge.host_production,
                                                                                  gateway_code,
                                                                                  bodies=bodies_v2Thanks,
                                                                                  timeout=timeout,
                                                                                  cb_threshold=cb_threshold)
                                            except Exception:
                                                test_failed = True


class WebsiteUser(HttpLocust):
    host = cartapp.host_production
    task_set = Checkout
    min_wait = 1500
    max_wait = 2500