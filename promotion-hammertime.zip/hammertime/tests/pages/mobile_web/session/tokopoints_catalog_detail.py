from locust import HttpLocust, TaskSet, task
from modules import tokopedia, graphql
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()
slug = 'DATAH'

class TokopointsDetailCatalog(TaskSet):
    def on_start(self):
        if not hasattr(TokopointsDetailCatalog, 'config_loaded') :
            TokopointsDetailCatalog.test_config = self.configuration['production']
            TokopointsDetailCatalog.large_users = self.team_configuration(TokopointsDetailCatalog.test_config['dexter']['20k_accounts'])
            TokopointsDetailCatalog.config_loaded = True
        self.account = ah.get_account(self, accounts=TokopointsDetailCatalog.large_users, login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        timeout_graphql= (TokopointsDetailCatalog.test_config['timeout_graphql'][0], TokopointsDetailCatalog.test_config['timeout_graphql'][1])
        timeout_page = (TokopointsDetailCatalog.test_config['timeout_page'][0], TokopointsDetailCatalog.test_config['timeout_page'][1])
        cb_threshold = TokopointsDetailCatalog.test_config['cb_threshold']
        headers = {
            'cookie': ah.get_sid_cookie(user_id)
        }

        res = tokopedia.page(self, tokopedia.host_production_m, '/tokopoints/detail/%s' % (slug) , headers=headers, timeout=timeout_page, cb_threshold=cb_threshold)

        res = graphql.graphql_hachikoMainQuery(self, graphql.host_graphql, headers={'cookie': ah.get_sid_cookie(user_id), 'origin':'https://m.tokopedia.com'}, json={"operationName":"HachikoMainQuery","variables":{"page":1,"page_size":15}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_isAuthenticatedQuery(self, graphql.host_graphql, headers=headers, json={"operationName": "isAuthenticatedQuery", "variables": {"key": "/tokopoints"}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_hachikoCatalogDetailQuery(self, graphql.host_graphql, headers=headers, json={"operationName": "hachikoCatalogDetailQuery", "variables":{"slug": slug}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_UserPointsQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"UserPointsQuery","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_TokopointsMainGolangQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"TokopointsMainGolangQuery","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = tokopedia.host_production
    task_set = TokopointsDetailCatalog
    min_wait = 1500
    max_wait = 2500
