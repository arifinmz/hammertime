from locust import HttpLocust, TaskSet, task
from modules import graphql, topads, accounts, tokopedia
from tests.helper.account_helper import AccountHelper
import random, json

ah = AccountHelper()

class HomeProduction(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        phone = self.account['phone']
        device_id = self.config['device_id']
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']
        headers = {
            'cookie': ah.get_sid_cookie(user_id),
        }

        # home
        home_domain = '/'
        res = tokopedia.page(self, tokopedia.host_production_m, home_domain, headers=headers, cb_threshold=cb_threshold, timeout=timeout_page)
        
        # graphql
        res = graphql.graphql_headerQuery(self, graphql.host_graphql, headers=headers, json={"variables":{"loggedIn": True}, "operationName":"HeaderQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)
        res = graphql.graphql_rechargeCategoryDetail(self, graphql.host_graphql, headers=headers, json={"operationName":"rechargeCategoryDetail","variables":{"category_id":1}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        
        pendingCashbackVariables = {
            "userID": int(user_id),
            "msisdn": phone
        }
        res = graphql.graphql_pendingCashback(self, graphql.host_graphql, headers=headers, json={"variables":pendingCashbackVariables,"operationName":"PendingCashback"}, cb_threshold=cb_threshold, timeout=timeout_graphql)
        res = graphql.graphql_isAuthenticatedQuery(self, graphql.host_graphql, json={"operationName":"isAuthenticatedQuery","variables":{"key":"/"}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_digitalQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"DigitalQuery","variables":{"isLoggedIn":True}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_OpenShopPopUp(self, graphql.host_graphql, headers=headers, json={"operationName":"OpenShopPopUp","variables":{"userID":int(user_id)}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        
        footerQueryVariables = {
            "loggedIn": True
        }
        res = graphql.graphql_footerQuery(self, graphql.host_graphql, headers=headers, json={"variables":footerQueryVariables, "operationName":"FooterQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)
        
        feedInspirationQueryVariables = {
            "userID": int(user_id),
            "insLimit": 3,
            "insCursor": "",
            "insPage": 1,
            "source": "home"
        }
        res = graphql.graphql_feedInspirationQuery(self, graphql.host_graphql, headers=headers, json={"variables":feedInspirationQueryVariables, "operationName":"FeedInspirationQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)
        res = graphql.graphql_TokopointsQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"TokopointsQuery","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_tokopointsNotificationQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"TokopointsNotificationQuery","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        # res = graphql.graphql_FloatingEggQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"FloatingEggQuery","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_Carousel(self, graphql.host_graphql, headers=headers, json={"operationName":"Carousel","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_SessionQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"SessionQuery","variables":{"source":str(user_id)}}, timeout=timeout_graphql, cb_threshold=cb_threshold)

        #topads
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query="ep=product&item=4&src=home&device=mobile&page=1&user_id="+user_id+"&search_nf=0&dep_id=0", name=topads.host_production+"/promo/v1.1/display/ads?src=home&ep=product", cb_threshold=cb_threshold, timeout=timeout)
        
        viewport = 'H_tF6sJ76_eRo_jF6sJEHptho_Hh6AJhoAnR6MusrprXPcY0QRCBgcBxbMNBPmY2Q3r5yfVsqc15HsnFb9ohP3VagZYFrMYjP3o7b_J5Hsnh6m47bpJNbpJhoAydo_jhbpJhoAydo_jh9pjfH_zMHsBjb_HNypyWoA-B6m7NHpnab_1OgceFyszMgc1hgV4hHsnF9pJaHAnXqSCS6stF6snXHAnRHsUO6MuNZM2jZJ2M33NGPMep_Mh-qMY2_1H78jOk1_z6uJud_1z0o1OJypu6ucr7_Bo-r7BW_sCsQABE3BPc8ujagfBvq1BR_c2z81YJu_oouVVN_7zuH7O119BvzVB2_JoGrB2yQAoiH7203Ao6qMUpZMh-qMY2_1o-r7BWo9giQ1NDZ325q1Y1_926qMzk3uP-PV29Z_-61pnF_92CHJh1Qc2qqMW7_OP3q7OJqRP6qMWE_92jq1B2PfBiH72F3s-DPuKpeSBiHBUh3_oZgMV913Bvq1BRZ3BRq3UpZSCqHMhO3Ao6QfUpeMgxuOV2_fB-P7B2PfBs3VgDyfNDgMzIzMNs81jfZ3B-r7BX_M2iH72D3A-G83UpgI2q17jfZ32CP1OJe_ooqjjF_7zSoJYJu9xoqjVR_M2g81N_Z9o-QjNkysoGQVKp_Mhg3J2ky1o-ojBke9uozJJp_Bz0HJNJ1_oouJOE_92gP7NJypo-QsnY'
        res = topads.promo_views_P_v1(self, topads.host_production, viewport, query='uid=' + user_id + '&post_alg=def&number_ads_req=4&t=mobile&src=home&ab_test=exp_cluster_recom_v2&n_candidate_ads=4&alg=fsclick&number_of_ads=3&page=1&render=false', name=topads.host_production+'/promo/v1/views/{viewport}', timeout=timeout, cb_threshold=cb_threshold)
        
        # accounts
        res = accounts.marketplace_pixel(self, accounts.host_production, headers=headers, cb_threshold=cb_threshold, timeout=timeout)
        res = graphql.graphql_rechargeFavoriteNumber(self, graphql.host_graphql, headers=headers, json={"operationName":"rechargeFavoriteNumber","variables":{"category_id":1}}, timeout=timeout, cb_threshold=cb_threshold)
        res = graphql.graphql_dynamicChannel(self, graphql.host_graphql, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        res = graphql.graphql_dynamicHomeQuery(self, graphql.host_graphql, headers=headers, cb_threshold=cb_threshold, timeout=timeout)
        res = graphql.graphql_ticker(self, graphql.host_graphql, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host     = ""
    task_set = HomeProduction
    min_wait = 1500
    max_wait = 2500