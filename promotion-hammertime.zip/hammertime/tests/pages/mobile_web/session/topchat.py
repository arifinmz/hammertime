from locust import HttpLocust, TaskSet, task
from modules import graphql,  tokopedia
from tests.helper.account_helper import AccountHelper
import random, json

ah = AccountHelper()

class TopChat(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['topchat']['accounts'], login_type=ah.LOGIN_TYPE_LITE)
        
    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']


        headers = {
            'cookie': ah.get_sid_cookie(user_id),
            'origin': 'https://m.tokopedia.com'
        }

        # home
        home_domain = '/chat'
        res = tokopedia.page(self, tokopedia.host_production_m, home_domain, headers=headers,  cb_threshold=cb_threshold, timeout=timeout_page)
        # topchat
        res = graphql.graphql_chatListQuery(self, graphql.host_graphql, headers=headers,  method='POST', json={"operationName":"ChatListQuery","variables":{"page":1,"perPage":10,"order":"desc","platform":"mobile","tab":"inbox","filter":"all"}}, cb_threshold=cb_threshold, timeout=timeout_graphql)
class WebsiteUser(HttpLocust):
    host     = ""
    task_set = TopChat
    min_wait = 1500
    max_wait = 2500