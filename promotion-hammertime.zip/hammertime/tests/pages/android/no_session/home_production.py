from locust import HttpLocust, TaskSet, task
from modules import tokopedia, pulsa_api, graphql
import random

class HomeProduction(TaskSet):
    # User opening android app without login first

    def on_start(self):
        self.config = self.configuration["production"]

    @task(1)
    def task1(self):
        user_id = "0"
        device_id   = self.config["device_id"]
        os_type     = self.config["os_type"]
        timeout     = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config["cb_threshold"]

        res = graphql.graphql_dynamicHome(self, graphql.host_graphql, method='POST',  cb_threshold=cb_threshold, timeout=timeout_graphql)

        res = pulsa_api.status_v1_4(self, pulsa_api.host_production, timeout=timeout, cb_threshold=cb_threshold)
        res = pulsa_api.category_list_v1_4(self, pulsa_api.host_production, timeout=timeout, cb_threshold=cb_threshold)
        try:
            category_json = res.json()
            category_list = category_json["data"]
            random_category = random.choice(category_list)

            query = "os_type="+os_type+"&device_id="+device_id
            res = pulsa_api.category_P_v1_4(self, pulsa_api.host_production, random_category["id"], query=query, name = pulsa_api.host_production+"/v1.4/category/{cat_id}", timeout=timeout, cb_threshold=cb_threshold, hide_query=True)
        except Exception as e:
            print e
            pass


class WebsiteUser(HttpLocust):
    host = ""
    task_set = HomeProduction
    min_wait = 1500
    max_wait = 2500
