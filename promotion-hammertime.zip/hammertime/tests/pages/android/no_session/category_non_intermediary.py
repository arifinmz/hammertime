from locust import HttpLocust, TaskSet, task
from modules import hades, topads, ace
import random

class CategoryNonIntermediary(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"] 

    @task(1)
    def task1(self):
        user_id = '0'
        device_id = self.config['device_id']
        category_id = random.choice(self.config['category_mapping'].keys())
        platform = 'android'
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']

        #Ace
        res = ace.search_product_v3(self, ace.host_production, query='device={0}&start=0&rows=12&source=directory&ob=23&rf=false&image_size=200&q=&image_square=true&sc={1}'.format(platform, category_id), timeout=timeout, cb_threshold=cb_threshold, hide_query=True)
        res = ace.dynamic_attributes_v2(self, ace.host_production, query='device={0}&source=directory&device_id={1}&sc={2}&user_id='.format(platform, device_id, category_id), timeout=timeout, cb_threshold=cb_threshold, hide_query=True)

        #Hades
        res = hades.categories_P_detail_v1(self, hades.host_production, category_id, query='total_curated=6', timeout=timeout, cb_threshold=cb_threshold, name=hades.host_production+"/{category_id}/"+platform)
       
        #Topads
        res = topads.promo_display_ads_v1_1(self, topads.host_production, query='device={0}&dep_id={1}&ep=product&src=directory&page=1&item=2&user_id='.format(platform, category_id), name=topads.host_production+'/promo/v1.1/display/ads?ep=product', timeout=timeout, cb_threshold=cb_threshold)
        res = topads.promo_display_ads_v1_2(self, topads.host_production, query='template_id=3%2C4&device={0}&ep=cpm&dep_id={1}&page=1&item=1'.format(platform, category_id), name=topads.host_production+'/promo/v1.1/display/ads?ep=cpm', timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ace.host_production
    task_set = CategoryNonIntermediary
    min_wait = 1500
    max_wait = 2500


