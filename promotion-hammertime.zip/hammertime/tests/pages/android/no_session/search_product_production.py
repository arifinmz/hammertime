from locust import HttpLocust, TaskSet, task
from modules import ace, mojito, topads
from libs import randex
import random

class SearchProductProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration['production']

    @task(1)
    def task1(self):
        keyword = randex.generate_word(2,20)
        
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        platform = 'android'
        device_id = self.config['device_id']

        res = ace.search_product_v3(self, ace.host_production, query="device={0}&start=0&rows=12&source=search&ob=23&rf=false&image_size=200&q={1}&image_square=true".format(platform, keyword), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        res = ace.guide_v1(self, ace.host_production, query="q="+keyword, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        res = ace.dynamic_attributes_v4(self, ace.host_production, name=ace.host_production+'/v4/dynamic_attributes?source=search_product', timeout=timeout, cb_threshold=cb_threshold, query='device={0}&source=search_product&q={1}&os_type=1&user_id='.format(platform, keyword))
        res = ace.dynamic_attributes_v2(self, ace.host_production, name=ace.host_production+"/v2/dynamic_attributes?source=quick_filter", query="device={0}&source=quick_filter&q={1}&os_type=1&sc=0&user_id=".format(platform, keyword), timeout=timeout, cb_threshold=cb_threshold)

        res = mojito.os_api_search_banner_P(self, mojito.host_production, platform, query="keywords="+keyword, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        res = topads.promo_display_ads_v1_1(self, topads.host_production, name=topads.host_production+'/promo/v1.1/display/ads?src=search&ep=product', query='q={0}&device={1}&ep=product&src=search&page=1&item=2&user_id='.format(keyword, platform), timeout=timeout, cb_threshold=cb_threshold)
        res = topads.promo_display_ads_v1_3(self, topads.host_production, name=topads.host_production+'/promo/v1.3/display/ads?src=search&ep=cpm', query='template_id=3%2C4&device={0}&src=search&q={1}&ep=cpm&item=1&page=1&user_id='.format(platform, keyword), timeout=timeout, cb_threshold=cb_threshold)
        viewport = 'H_tF6sJRHAU7H_JF6sJEHstho_Hh6Ajfop1F6MusrprXPcY0QRCBgcBxbMNBPmY2Q3r5yfVsqc15H_nFb9ohP3VagZYFrMYjP3o7b_J5Hsnh6m4hbpJfbpU76ArpHsnFbpU76ArpHsnF9pnhHMoiyMUhb_eNH3JWoAyFyiOxgsoMb_PMHfJFyMHOypzsHO4aHAed9pnXqSCS6stF6snXHAHNHAUN6MuNZM2jZJ2M33NGPMep_Mh-qMY2_1o-r7BW_sCsQABE3BPc8ujagfBvq1BN_c2ooJOJqpVoqj77_1z0H1Ok__zo17BpZ3O7QcuygIgsQu-Myp-6PMoWu3Bvq1BRZ3BRq3-W69ugHBu2_fBGquBEZ9xquJg0_uHhQ1Y9_MxHuVJa3BzoPJY9ZMxg8_n7_32C8BB1QcO6z72D3MOgq1hAZSgsQ3hXyurOgMoUZSgqZVgkgJyNrV2AZ_g-qjV2_JoGPMoWQcNxupuMyp-tPMoc69Cqe7jfZ32Cq1hAZSxjuOgNguyNHVB9gI2-qMY2Z3BRq3Ha_SgsQugM33NGPMep_Mh-qMY2_1H7P7OEgRxoqjJh_S2C81NJ19Po8j7p_7o-r7BX_M2iH72D3Ao6QVByZM2xe7jfZ32CP1OJ__uozJj7_Oz08jNkgpuo8j1a_Ozgq3gzv_7?sid=fZSAkP1Srdg%3AAPA91bFxSM1y7YIIhorhKVRvlMx8Hu51JNWFrWoX6y3sVOsq1f0xLIkjXEvo4BeJxzJBMa5cZSw71IQ0oT2fG_oWrcu2U8SPNeiJ3HPHkwAt1x9DbQm7s9CrReMdrNwWHHVwO6QEJs0dNgdZ-hmV_0B1pVW8A7ekZQ'
        res = topads.promo_views_P_v1(self, topads.host_production, viewport, name=topads.host_production+'/promo/v1/views/{viewport}', query='page=1&n_candidate_ads=2&number_of_ads=2&src=search&is_search=1&keywords={0}&t={1}&uid=0&alg=stm&post_alg=cpc_shop_unq&ab_test=N&number_ads_req=2'.format(keyword, platform), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = SearchProductProduction
    min_wait = 1500
    max_wait = 2500
