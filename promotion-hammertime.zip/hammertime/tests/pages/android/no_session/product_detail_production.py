from locust import HttpLocust, TaskSet, task
from modules import tokopedia, ace, mojito, gold_merchant, inbox, ws_v4, galadriel
import random

class ProductDetailProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration['production']

    @task(1)
    def task1(self):
        product = self.config['products'][random.randint(0,(len(self.config['products']) - 1))]
        product_id = product['id'] 
        shop_id = product['shop_id']
        talk_id = product['talk_id']
        user_id = ""
        device_id = self.config['device_id']
        os_type = self.config['os_type']
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']

        # ace
        res = ace.search_product_v1(self, ace.host_production, query="-id="+product_id+"&shop_id="+shop_id, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        # gold_merchant
        res = gold_merchant.product_video_v1(self, gold_merchant.host_production, product_id, method='GET', name=gold_merchant.host_production+"/v1/product/video/{product_id}", timeout=timeout, cb_threshold=cb_threshold)
        
        # inbox
        query = "product_id="+product_id+"&device_id=" + device_id +"&per_page=1&source=sneak_peak&os_type="+os_type+"&shop_domain="+shop_id+"&page=1&user_id="+user_id
        res = inbox.talk_read_v2(self, inbox.host_production, device_id, user_id, query=query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        
        if talk_id :
            query = "shop_id="+shop_id+"&device_id=" + device_id +"&os_type="+os_type+"&talk_id="+talk_id+"&page=1&per_page=1&source=sneak_peak&user_id="+user_id
            res = inbox.talk_comment_v2(self, inbox.host_production, device_id, user_id, query=query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        # tokopedia
        res = tokopedia.reputationapp_review_api_mosthelpful_v1(self, tokopedia.host_production, query='product_id='+product_id, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        # ws_v4
        query = 'product_id='+product_id+'&device_id='+device_id+'&product_key=&os_type=1&shop_domain=&user_id='
        res = ws_v4.product_getDetail_v4(self, ws_v4.host_production, product_id, user_id, device_id, query=query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = ProductDetailProduction
    min_wait = 1500
    max_wait = 2500
