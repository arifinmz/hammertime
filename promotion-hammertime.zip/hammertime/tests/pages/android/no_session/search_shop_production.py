from locust import HttpLocust, TaskSet, task
from modules import ace
import random

class SearchShopProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration['production']

    @task(1)
    def task1(self):
        search_shop_keyword = random.choice(self.config["search"]["search_shop_keywords"])
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']

        res = ace.search_shop_v1(self, ace.host_production, query='device=android&q='+search_shop_keyword+'&start=0&rows=12&fshop=&floc=', hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        res = ace.dynamic_attributes_v2(self, ace.host_production, query='device=android&source=search_shop&q='+search_shop_keyword+'&user_id=', hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = SearchShopProduction
    min_wait = 1500
    max_wait = 2500
