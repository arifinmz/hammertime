from locust import HttpLocust, TaskSet, task
from modules import ws_v4, gold_merchant, ace, mojito, reputationapp, inbox, tome
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class OsProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        shop = random.choice(self.config['merchant']['os'])
        shop_id = str(shop['id'])   
        shop_domain = shop['shop_domain']
        user_id = self.account['user_id']

        device_id   = self.config['device_id']
        timeout     = (self.config['timeout'][0],self.config['timeout'][1])
        headers = {
            'Authorization' : ah.get_token(user_id)
        }
        cb_threshold = self.config['cb_threshold']
        platform = "android"

        #ws_v4
        getshopinfo_body = {
            "shop_domain": "",
            "shop_id": shop_id,
            "show_all": "1",
            "user_id": user_id
        }
        res = ws_v4.ssi_shopStatic_P_apps_top(self, ws_v4.host_production, shop_domain, user_id, device_id, headers=headers, name=ws_v4.host_production+"/ssi/shop-static/{shop_domain}/_apps/top",timeout=timeout, cb_threshold=cb_threshold)
        # res = reputationapp.reputationapp_statistic_api_shop_P_speed_v1(self, ws_v4.host_production, shop_id, user_id, device_id, headers=headers, name=ws_v4.host_production+"/reputationapp/statistic/api/v1/shop/{shop_id}/speed", timeout=timeout, cb_threshold=cb_threshold)
        res_review = reputationapp.reputationapp_review_api_shop_v1(self, ws_v4.host_production, headers=headers, query="shop_id={0}&per_page=12&shop_domain=&page=1&user_id={1}".format(shop_id,user_id) , hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        try:
            review_data = res_review.json()
            review_data = review_data['data']['list']
            if len(review_data) > 1:
                review_ids = []
                for review in review_data:
                    review_ids.append(str(review['review_id']))
                
                rid = '~'.join(review_ids)
                # res = reputationapp.reputationapp_review_api_likedislike_v1(self, ws_v4.host_production, user_id, device_id, headers=headers, query="user_id=&review_ids={0}".format(rid), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        except Exception as e:
            print(e)

        #gold merchant
        # res = gold_merchant.mobile_featuredProduct_P_v1(self, gold_merchant.host_production, shop_id, user_id, device_id, headers=headers, query="json=1", name=gold_merchant.host_production+"/v1/mobile/featured_product/{shop_id}", timeout=timeout, cb_threshold=cb_threshold)

        #ace
        res_get_shop_product = ace.webService_shop_getShopProduct_v1(self, ace.host_production, user_id, device_id, headers=headers, query="wholesale=1&keyword=&etalase_id=etalase&user_id={0}&per_page=12&shop_domain=&order_by=&shop_id={1}".format(user_id, shop_id), hide_query=True, timeout=timeout, cb_threshold=cb_threshold, catch_response=True)
        print(res_get_shop_product.content)
        try:
            product_data = res_get_shop_product.json()
            product_data = product_data['data']['list']
            if len(product_data) > 1:
                product_ids = []
                for product in product_data:
                    product_ids.append(str(product['product_id']))

                # mojito
                pid = ','.join(product_ids)
                res = mojito.os_campaign_product_info_v1(self, mojito.host_production, headers=headers, query="pid={0}".format(pid), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
                res = mojito.users_P_wishlist_check_P_v1(self, mojito.host_production, user_id, pid, headers=headers, name=mojito.host_production+"/v1/users/{user_id}/wishlist/check/{product_ids}", timeout=timeout, cb_threshold=cb_threshold)
        except Exception as e:
            print(e)

        #tome
        res = tome.webService_shop_getShopInfo_v1(self, tome.host_production, headers=headers, query="shop_id={0}&user_id=&".format(shop_id), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        #inbox
        res = inbox.talk_read_v2(self, inbox.host_production, device_id, user_id, headers=headers, query="shop_id={0}&shop_domain=&type=s&page=1&user_id={1}".format(shop_id,user_id), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ws_v4.host_production
    task_set = OsProduction
    min_wait = 1500
    max_wait = 2500