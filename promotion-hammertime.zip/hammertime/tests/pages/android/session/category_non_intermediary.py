from locust import HttpLocust, TaskSet, task
from modules import hades, topads, mojito, ace
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class CateogryNonIntermediary(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        device_id = self.config['device_id']
        category_id = random.choice(self.config['category_mapping'].keys())             
        platform = 'android'
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        product_ids = str(random.sample(self.config['dexter']['massive_products'], 15))

        headers = {
            'Authorization' : ah.get_token(user_id)
        }

        #Ace
        res = ace.search_product_v3(self, ace.host_production, headers=headers, query='device={0}&start=0&rows=12&source=directory&ob=23&rf=false&image_size=200&q=&image_square=true&sc={1}&user_id={2}'.format(platform, category_id, user_id), timeout=timeout, cb_threshold=cb_threshold, hide_query=True)
        res = ace.dynamic_attributes_v2(self, ace.host_production, headers=headers,query='device={0}&source=directory&device_id={1}&sc={2}&user_id={3}'.format(platform, device_id, category_id, user_id), timeout=timeout, cb_threshold=cb_threshold, hide_query=True)

        #Hades
        res = hades.categories_P_detail_v1(self, hades.host_production, category_id ,headers=headers, query='total_curated=6', timeout=timeout, cb_threshold=cb_threshold, name=hades.host_production+"/{category_id}/"+platform)
       
        #mojito
        res = mojito.users_P_wishlist_check_P_v1(self, mojito.host_production, user_id, product_ids, headers=headers, timeout=timeout, cb_threshold=cb_threshold, name=mojito.host_production+"/v1/users/{user_id}/wishlist/check/{product_ids}")

        #Topads
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query='device={0}&ep=product&dep_id={1}&src=directory&page=1&item=2&user_id={2}'.format(platform, category_id, user_id),  name=topads.host_production+'/promo/v1.1/display/ads?ep=product', timeout=timeout, cb_threshold=cb_threshold)
        res = topads.promo_display_ads_v1_2(self, topads.host_production, headers=headers, query='template_id=3%2C4&device={0}&dep_id={1}&src=directory&ep=cpm&page=1&item=1&user_id={2}'.format(platform, category_id, user_id), name=topads.host_production+'/promo/v1.1/display/ads?ep=cpm', timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ace.host_production
    task_set = CateogryNonIntermediary
    min_wait = 1500
    max_wait = 2500


