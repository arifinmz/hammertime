from locust import HttpLocust, TaskSet, task
from modules import ace, tome, accounts, ws_v4
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class SearchShopProduction(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"] 
        self.users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.users, login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        search_shop_keyword = random.choice(self.config['search']['search_shop_keywords'])

        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']

        user_id = self.account['user_id']
        platform = 'android'
        device_id = self.config['device_id']
        os_type = self.config['os_type']
        shop_id = '1677427,1665080,429924,1651592,2624255,1538900,890143,2601460,645824,1369613,799701,1649848'
        headers = {
            'Authorization': ah.get_token(user_id)
        }

        res = ace.search_shop_v1(self, ace.host_production, headers=headers, query='device=android&q='+search_shop_keyword+'&start=0&rows=12&fshop=&floc=', hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        res = ace.dynamic_attributes_v2(self, ace.host_production, headers=headers, query='device=android&source=search_shop&q='+search_shop_keyword+'&user_id='+user_id, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        query = 'user_id='+user_id+'&shop_id='+shop_id
        res = tome.user_isfollowing_v1(self, tome.host_production, device_id, user_id, headers=headers, query=query, name=tome.host_production+'/v1/user/isfollowing?'+query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = SearchShopProduction
    min_wait = 1500
    max_wait = 2500
