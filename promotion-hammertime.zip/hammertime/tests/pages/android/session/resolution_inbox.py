from locust import HttpLocust, TaskSet, task
from modules import api
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class ResolutionInbox(TaskSet):
    
    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_APP, accounts=self.config["dexter"]["massive_accounts"])

    @task(1)
    def task1(self):
        headers = {
            'Authorization': ah.get_token(self.account['user_id'])
        }
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]


        # graphql
        res = api.resolution_inbox_buyer_v2(self, api.host_production, headers=headers, 
            name=api.host_production+"/resolution/v2/inbox/buyer", timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = ResolutionInbox
    min_wait = 1500
    max_wait = 2500
