from locust import HttpLocust, TaskSet, task
from modules import accounts, ws_v4
import random


class LoginProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        self.user=random.choice(self.config['dexter']['massive_accounts'])
        os_type = self.config['os_type']
        device_id = self.config['device_id']
        
        bodies = {
            'username':self.user['email'],
            'password':self.user['password'],
            'client_id':1001,
            'grant_type':'password'
        }
        headers = {
            'authorization':'Basic MTAwMTo3YzcxNDFjMTk3Zjg5Nzg3MWViM2I1YWY3MWU1YWVjNzAwMzYzMzU1YTc5OThhNGUxMmMzNjAwYzdkMzE='
        }
        res_token = accounts.token(self, accounts.host_production, bodies=bodies, timeout=timeout, cb_threshold=cb_threshold)

        headers = None
        try:
          bearer = res_token.json()
          if "access_token" in bearer :
              headers = {
                'Authorization': bearer['token_type']+' '+bearer['access_token']
              }
        except Exception, e:
          pass
          
        if headers is not None :
          bodies = {
              'user_id':self.user['user_id'],
              'device_id':device_id,
              'os_type':os_type
          }
          res = ws_v4.session_makeLogin_pl_v4(self, ws_v4.host_production, headers=headers, bodies=bodies, timeout=timeout, cb_threshold=cb_threshold, catch_response=True)
          message = None
          if res.status_code == 200:
            try:
                response = res.json()
                if response["data"]["is_login"] == "true" :
                    res.success()
                else:
                    message = res.content
            except Exception, e:
                message = res.content
          else :
            try :
                res.raise_for_status()
            except Exception, e:
                message = e
          if message is not None : 
            res.failure(message)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = LoginProduction
    min_wait = 1500
    max_wait = 2500
