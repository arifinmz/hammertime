from locust import HttpLocust, TaskSet, task
from modules import mojito, ws_v4, accounts, chat, graphql
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class SprintSaleOS(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_BOTH)

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']
        promoslug = random.choice(self.config['spike']['promoslug'])

        user_id = self.account['user_id']
        platform = 'android'
        device_id = self.config['device_id']
        os_type = self.config['os_type']
       
        headers = {
            'Authorization': ah.get_token(user_id),
            'cookie':ah.get_sid_cookie(user_id)
        }
        res = graphql.graphql_userAttribute(self, graphql.host_graphql, headers=headers, json={"variables":{"userID":int(user_id)}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        query = "os_type=%s&device_id=%s&user_id=%s" % (os_type,device_id, user_id)
        res = chat.tc_notifUnreads_v1(self, chat.host_production, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, timeout=timeout, cb_threshold=cb_threshold, query=query, hide_query=True)
        
        response = accounts.info(self, accounts.host_production, query='os_type=%s&device_id=%s&user_id=%s' %(os_type, device_id, user_id), timeout=timeout, headers=headers, cb_threshold=cb_threshold,hide_query=True)

        res = mojito.os_api_ospromo_topcontent_P_v1(self, mojito.host_production, promoslug, name=mojito.host_production+"/os_api_ospromo_topcontent_P_v1", timeout=timeout, cb_threshold=cb_threshold, query='device=mobile', hide_query=True)
        res = mojito.os_api_ospromo_categories_v1(self, mojito.host_production, name=mojito.host_production+"/os/api/v1/ospromo/categories/", timeout=timeout, cb_threshold=cb_threshold, query='promo='+promoslug+'&device=mobile&limit=5&offset=0', hide_query=True)
        
class WebsiteUser(HttpLocust):
    host = ""
    task_set = SprintSaleOS
    min_wait = 1500
    max_wait = 2500
