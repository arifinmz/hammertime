from locust import HttpLocust, TaskSet, task
from modules import graphql, gw, tokopedia
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class KOLInspirationProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_APP, accounts=self.config["dexter"]["massive_accounts"])

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = self.account['user_id']
        
        headers_consumergql = {
            'Accounts-Authorization': ah.get_token(self.account['user_id'])
        }
        res = graphql.graphql_consumerDrawerData(self, graphql.host_graphql, headers=headers_consumergql, json={"variables":{"userID":int(user_id)}}, cb_threshold=cb_threshold, timeout=timeout_graphql, catch_response=True)
        self.checking_errors(res)
        res = graphql.graphql_updateCartCounterMutation(self, graphql.host_graphql, json={"operationName":"updateCartCounterMutation","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold, catch_response=True)
        self.checking_errors(res)
        res = graphql.graphql_getDiscoveryKolData(self, graphql.host_graphql, json ={"operationName":"GetDiscoveryKolData","variables":{"idcategory":0,"limit":18,"cursor":"MTU2NzExNTgsMCwxLDA=","search":""}}, timeout=timeout_graphql, cb_threshold=cb_threshold, catch_response=True)
        self.checking_errors(res)
        res = tokopedia.content_explore(self, tokopedia.host_production_m, cb_threshold=cb_threshold, timeout=timeout)

    def checking_errors(self, res):
        if res.status_code == 200:
            try:
                response = res.json()
                if response.get('errors'):
                    res.failure(res.content)
                else:
                    res.success()
            except Exception:
                res.failure(res.content)
        else :
            try :
                res.raise_for_status()
            except Exception as e:
                res.failure(e)
        

class WebsiteUser(HttpLocust):
    host = ""
    task_set = KOLInspirationProduction
    min_wait = 1500
    max_wait = 2500
