from locust import HttpLocust, TaskSet, task
from modules import tokopedia, ace, ws_v4, accounts
from libs import bearer_token
from libs import user_conversion
from tests.pages.android.no_session.product_detail_production import ProductDetailProduction
from tests.helper.account_helper import AccountHelper
import random

uc = user_conversion.UserConversion()
ah = AccountHelper()

class TopPicksProduction(TaskSet):

    def on_start(self):
        
        global uc
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_APP)
        self.productDetailProduction = ProductDetailProduction(self)
        self.productDetailProduction.config = self.config
        uc.max_threshold = self.config["top_picks"]['convertion_rate']

    @task(1)
    def task1(self):
        top_picks = self.config["top_picks"]['data'][random.randint(0,len(self.config["top_picks"]['data'])-1)]
        device_id = self.config['device_id']
        os_type = self.config['os_type']
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        user_id = self.account['user_id']
        cb_threshold = self.config["cb_threshold"]
        #access toppicks page
        res = tokopedia.page(self, tokopedia.host_production, top_picks["link"], name=tokopedia.host_production+"/toppicks", timeout=timeout_page, cb_threshold=cb_threshold)
        #validate product from content team
        query = "source=toppicks&device=desktop&rows=413&id="+",".join(top_picks["not_validated_product_ids"])
        res = ace.search_product_v3(self, ace.host_production, query=query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        #show list of validated product
        query = "source=toppicks&device=desktop&rows=413&id="+",".join(top_picks["validated_product_ids"])
        res = ace.search_product_v3(self, ace.host_production, query=query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        @uc.attempt(self.runners.user_count)
        def product_detail():
            self.productDetailProduction.task1()
        product_detail()

class WebsiteUser(HttpLocust):
    host = ""
    task_set = TopPicksProduction
    min_wait = 1500
    max_wait = 2500
