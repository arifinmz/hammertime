from locust import HttpLocust, TaskSet, task
from modules import tokopedia, ace, mojito, gold_merchant, inbox, ws_v4, galadriel, tome, topads
from tests.helper.account_helper import AccountHelper
import random, json

ah = AccountHelper()

class ProductDetailProduction(TaskSet):
    def on_start(self):
        if not hasattr(ProductDetailProduction, 'config_loaded') :
            ProductDetailProduction.test_config = self.configuration['production']
            ProductDetailProduction.large_users = self.team_configuration(ProductDetailProduction.test_config['dexter']['20k_accounts'])
            ProductDetailProduction.config_loaded = True
        self.account = ah.get_account(self, accounts=ProductDetailProduction.large_users, login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        product_id = random.choice(ProductDetailProduction.test_config['dexter']['massive_products'])
        user_id = self.account["user_id"]
        device_id = ProductDetailProduction.test_config['device_id']
        os_type = ProductDetailProduction.test_config['os_type']
        timeout = (2,2)
        cb_threshold = ProductDetailProduction.test_config['cb_threshold']
        test_failed = False

        headers = {
            'Authorization' : ah.get_token(user_id),
            'Accounts-Authorization' : ah.get_token(user_id),
            'X-Device':'android'
        }

        # ws_v4
        query = 'device=android&product_id={0}&device_id={1}&product_key=&os_type={2}&shop_domain=&user_id={3}'.format(product_id, device_id, os_type, user_id)
        res_detail = ws_v4.product_getDetail_v4(self, ws_v4.host_production, product_id, user_id, device_id, query=query, hide_query=True, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        try :
            detail_json = res_detail.json()            
            shop_id = detail_json["data"]["shop_info"]["shop_id"]
            has_variant = detail_json["data"]["info"]["has_variant"]
            product_name = detail_json["data"]["info"]["product_name"]
            shop_id = detail_json["data"]["shop_info"]["shop_id"]
            catalog_id = detail_json["data"]["info"]["catalog_id"]
        except Exception as e:
            test_failed = True

        if not test_failed:
            # topads
            query = 'ep=product&item=5&src=pdp&device=android&'
            xparam = {
                'product_id':product_id,
                'product_name':product_name,
                'shop_id':shop_id,
                'catalog_id':catalog_id
            }
            res = topads.promo_display_ads_v1_1(self, topads.host_production, query=query + "user_id=" + user_id + "&xparam=" + str(xparam)  , name=topads.host_production+"/promo/v1.1/display/ads?src=pdp", cb_threshold=cb_threshold, timeout=timeout)

            # tokopedia
            mosthelpful_query = 'product_id={0}&shop_id={1}&device_id={2}&source=sneak_peak&per_page=1&os_type={3}&user_id={4}'.format(product_id, shop_id, device_id, os_type, user_id)
            res = tokopedia.reputationapp_review_api_mosthelpful_v1(self, tokopedia.host_production, query=mosthelpful_query, hide_query=True, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
            # galadriel
            res = galadriel.promoSuggestion_widget_v1(self, galadriel.host_production, query="shop_type=merchant&placeholder=pdp_widget&target_type=login_user&device_type=android&lang=id&user_id="+user_id, hide_query=True, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
            
            # gold_merchant
            res = gold_merchant.product_video_v1(self, gold_merchant.host_production, product_id, name=gold_merchant.host_production+"/v1/product/video/{product_id}", headers=headers, timeout=timeout, cb_threshold=cb_threshold)
            
            res = mojito.users_P_wishlist_check_P_v1(self, mojito.host_production, user_id, product_id, headers=headers, name=mojito.host_production+'/v1/users/{user_id}/wishlist/check/{product_ids}', timeout=timeout, cb_threshold=cb_threshold)
            
            # tome
            # if not has_variant :
            res = tome.product_P_stock_v2(self, tome.host_production, product_id, cb_threshold=cb_threshold, headers={'authorization':ah.get_token(user_id), 'x-device':'android'}, timeout=timeout, name=tome.host_production+"/v2/product/{product_id}/stock")
            # else :
            res = tome.product_P_variant_v2(self, tome.host_production, product_id, cb_threshold=cb_threshold, headers={'authorization':ah.get_token(user_id), 'x-device':'android'}, timeout=timeout, name=tome.host_production+"/v2/product/{product_id}/variant")
                
            # ace
            res = ace.search_product_v1(self, ace.host_production, query="-id="+product_id+"&shop_id="+shop_id, hide_query=True, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
            
            # inbox
            query = "product_id={0}&device_id={1}&source=sneak_peak&per_page=1&os_type={2}&shop_domain={3}&page=1&user_id={4}".format(product_id, device_id, os_type, shop_id, user_id)
            res = inbox.talk_read_v2(self, inbox.host_production, device_id, user_id, query=query, hide_query=True, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
            try :
                read_json = res.json()
                talk_index = len(read_json["data"]["list"]) - 1
                talk_id = str(read_json["data"]["list"][talk_index]["talk_id"])
            except Exception as e :
                test_failed = True
            
            if not test_failed and talk_id :
                query = "shop_id={0}&device_id={1}&source=sneak_peak&per_page=1&os_type={2}&talk_id={3}&page=1&user_id={4}".format(shop_id, device_id, os_type, talk_id, user_id)
                res = inbox.talk_comment_v2(self, inbox.host_production, device_id, user_id, query=query, hide_query=True, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = ProductDetailProduction
    min_wait = 600
    max_wait = 800
