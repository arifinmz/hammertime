from locust import HttpLocust, TaskSet, task
from modules import graphql, chat
from libs import tkpdhmac
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class TopChat(TaskSet):
    
    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['topchat']['accounts'], login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        device_id = self.config['device_id']
        headers = {
            'Tkpd-UserId':user_id,
            'X-Device':'android-2.21.1'
        }
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config["cb_threshold"]


        # graphql
        headers_userAttribute = {
            'Accounts-Authorization': ah.get_token(self.account['user_id'])
        }
        res = graphql.graphql_consumerDrawerData(self, graphql.host_graphql, headers=headers_userAttribute, json={"variables":{"userID":int(user_id)}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        
        # top chat
        res = chat.tc_list_message_v1(self, chat.host_production, user_id, device_id, headers=headers, 
            name=chat.host_production+"/tc/v1/list_message", 
            query="tab=inbox&filter=all&page=1&per_page=10&platform=android",
            cb_threshold=cb_threshold, timeout=timeout)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = TopChat
    min_wait = 1500
    max_wait = 2500
