from locust import HttpLocust, TaskSet, task
from modules import chat
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class GroupChatChannels(TaskSet):
    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_APP)

    @task
    def task1(self):
        token = ah.get_token(self.account['user_id'])
        headers = {
            'Authorization' : token
        }
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        res = chat.gcn_api_channels_v1(self, chat.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = GroupChatChannels
    min_wait = 3000
    max_wait = 5000
