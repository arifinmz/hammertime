from locust import HttpLocust, TaskSet, task
from modules import ace, mojito, ws_v4, accounts, chat, graphql
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class HotlistTabProduction(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_APP, accounts=self.config["dexter"]["massive_accounts"])

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = self.account['user_id']
        device_id = self.config['device_id']
        os_type = self.config['os_type']
       
        headers = {
            'Authorization': ah.get_token(user_id),
            'cookie':ah.get_sid_cookie(user_id)
        }
        query = "device_id="+device_id+"&per_page=15&query=&os_type="+os_type+"&page=1&user_id="+user_id
        res = ws_v4.hotlist_getHotlist_pl_v4(self, ws_v4.host_production, user_id, device_id, query=query, headers=headers, cb_threshold=cb_threshold, timeout=timeout, hide_query=True)
        
class WebsiteUser(HttpLocust):
    host = ""
    task_set = HotlistTabProduction
    min_wait = 1500
    max_wait = 2500
