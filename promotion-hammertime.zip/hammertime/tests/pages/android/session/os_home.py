from locust import HttpLocust, TaskSet, task
from modules import graphql, mojito, tome
from tests.helper.account_helper import AccountHelper
import random, json

ah = AccountHelper()

class OSHome(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config["dexter"]["massive_accounts"], login_type=ah.LOGIN_TYPE_BOTH)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']

        headers = {
            'X-Device':'android-2.20',
            'cookie': ah.get_sid_cookie(user_id),
            'Authorization': ah.get_token(user_id)
        }

        contentDataVariables = {
            "offset": 0,
            "categoryId": 0,
            "categories": [0],
            "fetchingMore": False,
            "skipFlashsale": False
        }
        res = graphql.graphql_contentData(self, graphql.host_graphql, headers=headers, json={"variables":contentDataVariables,"operationName":"ContentData"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

        categoryDataVariables = {
            "lang": "id",
            "device": "android"
        }
        res = graphql.graphql_categoryData(self, graphql.host_graphql, headers=headers, json={"variables":categoryDataVariables,"operationName":"CategoryData"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

class WebsiteUser(HttpLocust):
    host     = ""
    task_set = OSHome
    min_wait = 1500
    max_wait = 2500