from locust import HttpLocust, TaskSet, task
from modules import tokopedia, ace
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()


class SprintSale(TaskSet):

    def on_start(self):
        if not hasattr(SprintSale, 'config_loaded') :
            SprintSale.test_config = self.configuration['production']
            SprintSale.large_users = self.team_configuration(SprintSale.test_config['dexter']['20k_accounts'])
            SprintSale.config_loaded = True
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_APP, accounts=SprintSale.large_users)

    @task(1)
    def task1(self):
        headers = {
            'Authorization': ah.get_token(self.account['user_id'])
        }
        timeout = (SprintSale.test_config['timeout'][0], SprintSale.test_config['timeout'][1])
        cb_threshold = SprintSale.test_config["cb_threshold"]
        campaign = SprintSale.test_config["sprint_sale_campaign"]

        # ace
        res = ace.hoth_discovery_api_page_P(self, ace.host_production, "sprint-sale-test-2",
                                             headers=headers, cb_threshold=cb_threshold, timeout=timeout)
        # campaign id for flash-sale is always fixed 62532 (confirmed by stephanus tedy)
        # paging is random, at least one page, max 4 pages sequentially
        pageList = ['2', '3', '4'] 
        for index in range (0, random.randint(0, len(pageList)) ):
            res = ace.hoth_discovery_api_component_sprintSaleTest2_P(self, ace.host_production, campaign,
                query='rpc_Page='+pageList[index]+'&rpc_ResultPerPage=20&rpc_GroupID=0', cb_threshold=cb_threshold, timeout=timeout,
                name=ace.host_production+'/hoth/discovery/api/component/sprint-sale-test-2/'+campaign)



class WebsiteUser(HttpLocust):
    host = ""
    task_set = SprintSale
    min_wait = 600
    max_wait = 800
