import random
from locust import HttpLocust, TaskSet, task
from modules import tokopedia, ace, graphql, tome, ws_v4
from tests.helper.account_helper import AccountHelper
from tests.pages.android.session.sprintsale import SprintSale
from tests.modules.logistic_api.kero_gql_production import KeroGqlRates
from tests.pages.android.session.atc_checkout_production_new import ATCCheckout as CheckoutCartApp
from tests.pages.android.session.atc_checkout_production_old import ATCCheckout as CheckoutOrderApp

ah = AccountHelper()

NCFRatio = 1

class FlashSale(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        # self.large_users = [{
        #             "phone": "6289999999999",
        #             "password": "4d9142dd",
        #             "user_id": "36139902",
        #             "email": "loadtest+94@tokopedia.com",
        #             "address_list": [
        #                 {
        #                     "province": 13,
        #                     "city": 175,
        #                     "address_id": "52525777",
        #                     "district": 2265,
        #                     "addr_name": "alamat teman",
        #                     "phone": 2175920440,
        #                     "postal_code": 12310,
        #                     "receiver_name": "LIA",
        #                     "address_street": "jl. alteri pondok indah ZEQFBNVCLZ4Y8ZMI4BSSK42KWWKGDV"
        #                 }
        #             ]
        #         }]
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_APP)

        self.SprintSale = SprintSale(self)
        self.SprintSale.config = self.config
        self.SprintSale.account = self.account

        self.ATCCartApp = CheckoutCartApp(self)
        self.ATCCartApp.config = self.config
        self.ATCCartApp.account = self.account

        # self.ATCOrderApp = CheckoutOrderApp(self)
        # self.ATCOrderApp.config = self.config
        # self.ATCOrderApp.account = self.account
        # self.ATCOrderApp.kero = KeroGqlRates(self)
        # self.ATCOrderApp.kero.config = self.config

        self.timeout = (self.config['timeout'][0],self.config['timeout'][1])
        self.timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        self.cb_threshold = self.config["cb_threshold"]
        self.device_id = self.config["device_id"]
        self.os_type = self.config["os_type"]
        self.user_id = self.account["user_id"]

    # @task(2)
    # def task1(self):
    #     #hit flash sale page with OCF
    #     self.home()
    #     self.SprintSale.task1()
    #     self.pdp()
    #     self.ATCOrderApp.task1()

    @task(1)
    def task2(self):
        #hit flash sale page with NCF
        self.home()
        self.SprintSale.task1()
        self.pdp()
        self.ATCCartApp.task1()

    def home(self):
        
        headers = {
            'Authorization': ah.get_token(self.account['user_id']),
            'cookie':ah.get_sid_cookie(self.user_id)
        }
        # graphql
        res = graphql.graphql_dynamicHome(self, graphql.host_graphql, headers=headers,  json={"variables":{"cursor": "","limit": 3,"page": 1,"userID":self.user_id}}, timeout=self.timeout_graphql, cb_threshold=self.cb_threshold)
        headers_userAttribute = {
            'Accounts-Authorization': headers["Authorization"],
            'cookie' : headers["cookie"]
        }
        res = graphql.graphql_homeFeedQuery(self, graphql.host_graphql, headers=headers_userAttribute,  json={"variables":{"cursor": "","limit": 4,"userID":int(self.user_id)}}, timeout=self.timeout_graphql, cb_threshold=self.cb_threshold)

    def pdp(self):        
        self.product_id = random.choice(self.config['dexter']['massive_products'])
        test_failed = False

        # ws_v4
        query = 'product_id='+self.product_id+'&device_id='+self.device_id+'&product_key=&os_type=1&shop_domain=&user_id='
        self.res_detail = ws_v4.product_getDetail_v4(self, ws_v4.host_production, self.product_id, self.user_id, self.device_id, query=query, hide_query=True, timeout=self.timeout, cb_threshold=self.cb_threshold)
        
        try :
            detail_json = self.res_detail.json()            
            has_variant = detail_json["data"]["info"]["has_variant"]
        except Exception as e:
            test_failed = True

        tomeHeader = {'x-device': 'android'}

        if not test_failed :
            # tome
            if not has_variant :
                res = tome.product_P_stock_v2(self, tome.host_production, self.product_id, headers=tomeHeader, cb_threshold=self.cb_threshold, timeout=self.timeout, name=tome.host_production+"/v2/product/{product_id}/stock")
            else :
                res = tome.product_P_variant_v2(self, tome.host_production, self.product_id, headers=tomeHeader, cb_threshold=self.cb_threshold, timeout=self.timeout, name=tome.host_production+"/v2/product/{product_id}/variant")


class WebsiteUser(HttpLocust):
    host = ""
    task_set = FlashSale
    min_wait = 1500
    max_wait = 2500
