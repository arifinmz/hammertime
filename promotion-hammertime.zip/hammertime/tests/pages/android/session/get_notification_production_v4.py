import random
from locust import HttpLocust, TaskSet, task
from modules import cartapp
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class GetNotif(TaskSet):

    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        if not hasattr(GetNotif, 'config_loaded') :
            GetNotif.test_config = self.configuration["production"]
            GetNotif.config_loaded = True
        self.account = ah.get_account(self, accounts=GetNotif.test_config["dexter"]["massive_accounts"],
                                      login_type=ah.LOGIN_TYPE_APP)

    # User accessing home page with session from cookie
    @task(1)
    def task1(self):

        timeout = (GetNotif.test_config['timeout'][0], GetNotif.test_config['timeout'][1])
        cb_threshold = GetNotif.test_config["cb_threshold"]
        user_id = self.account["user_id"]

        res = cartapp.get_notification_v4(self, cartapp.host_production, cb_threshold=cb_threshold, timeout=timeout, 
                                            query='bypass=true_true&user_id='+ user_id, catch_response=True, name=cartapp.host_production+'/v4/notification/get_notification.pl?bypass=true_true&user_id={user_id}')

        if not res == "":
            if res.status_code == 200:
                if '"status":"OK"' in res.content:
                    res.success()
                else:
                    res.failure("Status is not OK")
            else:
                try:
                    res.raise_for_status()
                except Exception as e:
                    res.failure(e)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = GetNotif
    min_wait = 1500
    max_wait = 2500