from locust import HttpLocust, TaskSet, task
from modules import chat
from tests.helper.account_helper import AccountHelper
from tests.pages.android.session.group_chat_channels_production import GroupChatChannels
import random

ah = AccountHelper()

class GroupChatViewChannel(TaskSet):
    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_APP)

        self.groupChatChannels = GroupChatChannels(self)
        self.groupChatChannels.config = self.config
        self.groupChatChannels.account = self.account

    @task
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        self.groupChatChannels.task1()
        token = ah.get_token(self.account['user_id'])
        headers = {
            'Authorization' : token
        }
        index_channel_id = random.randint(0,len(self.config['chat_channel'])-1)
        channel_id = self.config['chat_channel'][index_channel_id]['id']
        res = chat.gcn_api_channel_P_v1(self, chat.host_production, channel_id, name=chat.host_production+"/gcn/api/v1/channel/{channel_id}", headers=headers, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = GroupChatViewChannel
    min_wait = 3000
    max_wait = 5000
