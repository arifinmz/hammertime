from locust import HttpLocust, TaskSet, task
from modules import graphql, mojito, tome
from tests.helper.account_helper import AccountHelper
import random, json

ah = AccountHelper()

class FeedAndroidPage(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config["dexter"]["massive_accounts"], login_type=ah.LOGIN_TYPE_BOTH)

        headers = {
            'cookie':ah.get_sid_cookie(self.account["user_id"])
        }
        res = tome.webService_fav_shop_list_v1(self, tome.host_production,  headers=headers, query="user_id="+self.account["user_id"], name=tome.host_production+"/v1/web-service/fav_shop/list")
        
        responseJSON = res.json()
        count = 0
        for shop in responseJSON["data"]:
            if shop["shop_id"] == "1137776":
                count = count + 1
        if count < 1:
            headers = {
                "cookie":ah.get_sid_cookie(self.account["user_id"]),
                "origin":"https://www.tokopedia.com",
                "content-type":"application/x-www-form-urlencoded; charset=UTF-8"
            }
            bodies = {
                "s_id":1137776
            }
            res = tome.addFavorite(self, tome.host_production, headers=headers, bodies=bodies)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        phone = self.account['phone']
        device_id = self.config['device_id']
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']

        headers = {
            'X-Device':'android-2.20',
            'Tkpd-SessionId':self.config['spike']['device_id_a'],
            'Tkpd-UserId':user_id
        }

        res = mojito.users_P_recentview_products_v1(self, mojito.host_production, user_id, device_id, name=mojito.host_production+"/users/{user_id}/recentview/products/v1")

        #graphql_feed
        FeedQuery={
            "userID": int(user_id),
            "limit":3,
            "cursor":"",
            "source":"feeds"
        }
        res = graphql.graphql_feedQuery(self, graphql.host_graphql, method="POST", headers=headers, json={"variables":FeedQuery,"operationName":"FeedQuery"}, cb_threshold=cb_threshold, timeout=timeout_graphql)

class WebsiteUser(HttpLocust):
    host     = ""
    task_set = FeedAndroidPage
    min_wait = 1500
    max_wait = 2500