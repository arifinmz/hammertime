from locust import HttpLocust, TaskSet, task
from modules import ace, mojito, ws_v4, accounts, chat, graphql
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class HotlistProduction(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_BOTH)

    @task(1)
    def task1(self):
        hotlist = random.choice(self.config['spike']['hotlist'])
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']

        user_id = self.account['user_id']
        platform = 'android'
        device_id = self.config['device_id']
        os_type = self.config['os_type']
        product_id = '130711942,261038564,231198750,63882198,232044176,203008668,9873490,14892971,4903119,9751782,8847003,204407751'
        shop_id = '1859858,2983935,2975520'
       
        headers = {
            'Authorization': ah.get_token(user_id),
            'cookie':ah.get_sid_cookie(user_id)
        }
        res = graphql.graphql_userAttribute(self, graphql.host_graphql, headers=headers, json={"variables":{"userID":int(user_id)}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        
        query = "os_type=%s&device_id=%s&user_id=%s&type=1" % (os_type,device_id, user_id)
        res = chat.tc_notifUnreads_v1(self, chat.host_production, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, timeout=timeout, cb_threshold=cb_threshold, query=query, hide_query=True)
        
        response = accounts.info(self, accounts.host_production, query='os_type=%s&device_id=%s&user_id=%s' %(os_type, device_id, user_id), timeout=timeout, headers=headers, cb_threshold=cb_threshold,hide_query=True)

        res = ace.search_product_v3(self, ace.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold, query='device='+platform+'&hot_id='+hotlist['hot_id']+'&shop_id=&rows=12&pmin=&source=hot_product&pmax=&image_size=200&q='+hotlist['keyword']+'&default_sc=35,983&fshop=0&hc=6656&ob=23&unique_id='+user_id+'&image_square=true&negative=&user_id='+user_id, name=ace.host_production+'/search/product/v3', hide_query=True)
        res = ace.dynamic_attributes_v2(self, ace.host_production, name=ace.host_production+'/v2/dynamic_attributes', headers=headers, timeout=timeout, cb_threshold=cb_threshold, query='device='+platform+'&start=0&hot_id='+hotlist['hot_id']+'&shop_id=&rows=12&pmin=&source=hot_product&pmax=&q='+hotlist['keyword']+'&os_type='+os_type+'&default_sc=35,983&fshop=0&device_id='+device_id+'&hc=6656&ob=23&unique_id='+user_id+'&sc=35,983&negative=&user_id='+user_id, hide_query=True)

        res = mojito.users_P_wishlist_check_P_v1(self, mojito.host_production, user_id, product_id, headers=headers, name=mojito.host_production+"/v1/users/wishlist/check/", timeout=timeout, cb_threshold=cb_threshold)
        
class WebsiteUser(HttpLocust):
    host = ""
    task_set = HotlistProduction
    min_wait = 1500
    max_wait = 2500
