import random, json, time
from locust import HttpLocust, TaskSet, task
from modules import cartapp, scrooge, orderapp, gw
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()


class ATCCheckout(TaskSet):

    def on_start(self):
        if not hasattr(ATCCheckout, 'config_loaded') :
            ATCCheckout.test_config = self.configuration['production']
            ATCCheckout.large_users = self.team_configuration(ATCCheckout.test_config['dexter']['20k_accounts'])
            ATCCheckout.config_loaded = True
        self.account = ah.get_account(self, accounts=ATCCheckout.large_users,
                                      login_type=ah.LOGIN_TYPE_APP)

    # User accessing home page with session from cookie
    @task(1)
    def task1(self):
        timeout = (ATCCheckout.test_config['timeout'][0], ATCCheckout.test_config['timeout'][1])
        timeout_page = (ATCCheckout.test_config['timeout_page'][0], ATCCheckout.test_config['timeout_page'][1])
        cb_threshold = ATCCheckout.test_config["cb_threshold"]
        timeout_ATC = (ATCCheckout.test_config["stitch"]["timeout_ATC"][0], ATCCheckout.test_config["stitch"]["timeout_ATC"][1])
        test_failed = False
        user_id = self.account["user_id"]
        device_id = ATCCheckout.test_config['device_id']
        product = random.choice(ATCCheckout.test_config["flash_sale_products"])
        product_id = str(product['ID'])
        shop_id = str(product['shop']['shopID'])

        user_id = str(user_id)
        # attribute for reset cart
        bodies_reset = {
            'status': '1',
            'lang': 'id'
        }
        headers_reset = {
            'Tkpd-UserId': user_id,
            'content-type': 'application/x-www-form-urlencoded'
        }

        # atc
        headers = {
            "Tkpd-UserId": user_id,
            "X-Device": "android",
            "tkpd-sessionid": device_id,
            "accounts-authorization":ah.get_token(user_id)
        }
        body_atc = {
            'params': '{"product_id":' + product_id + ', "quantity": 1, "shop_id":' + shop_id + ', "notes": ""}'
        }
        res = cartapp.add_product_cart_v2(self, cartapp.host_production, headers=headers, bodies=body_atc,
                                          cb_threshold=cb_threshold, timeout=timeout_ATC, catch_response=True)
        
        cart_id = None
        if res.status_code == 200:
            try:
                if '"success":1' in res.content:
                    test_failed = False
                    res.success()
                    res_json = res.json()
                    cart_id = res_json['data']['data']['cart_id']
                else:
                    if 'Maaf, Permohonan Anda tidak dapat diproses saat ini. Mohon dicoba kembali.' in res.content:
                        res.failure('Maaf, Permohonan Anda tidak dapat diproses saat ini. Mohon dicoba kembali.')
                    else:
                        res.failure("attribute success is not 1")
                    test_failed = True
            except Exception as e:
                # print("disini : ", cart)
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)
        time.sleep(0.5)

        if not test_failed:
            res = cartapp.cart_list_v2(self, cartapp.host_production, headers=headers, cb_threshold=cb_threshold, timeout=timeout_ATC, catch_response=True)

            if res.status_code == 200:
                try:
                    res_json = res.json()
                    if res_json['header']['error_code'] == '200':
                        test_failed = False
                        res.success()
                    else:
                        res.failure(res_json['header']['reason'])
                        test_failed = True
                except Exception as e:
                    test_failed = True
                    res.failure("can't parse response as json")
            else:
                try:
                    res.raise_for_status()
                except Exception as e:
                    test_failed = True
                    res.failure(e)

            if not test_failed:
                # update cart
                carts_param = json.dumps([{"cart_id": cart_id, "quantity":1, "notes": ""}])
                body_updateCart = {
                    "carts": carts_param
                }
                res = cartapp.update_cart_v2(self, cartapp.host_production, headers=headers, bodies=body_updateCart,
                                            cb_threshold=cb_threshold, timeout=timeout_ATC, catch_response=True)

                if res.status_code == 200:
                    if '"status":true' and '"error_code":"200"' in res.content:
                        test_failed = False
                        res.success()
                    else:
                        print("cart_id : ", cart_id)
                        print("headers : ", headers)
                        print("body : ", body_updateCart)
                        test_failed = True
                        res.failure(res.content)
                else:
                    try:
                        print("cart_id : ", cart_id)
                        print("headers : ", headers)
                        print("body : ", body_updateCart)
                        res.raise_for_status()
                    except Exception as e:
                        print("cart_id : ", cart_id)
                        print("headers : ", headers)
                        print("body : ", body_updateCart)
                        test_failed = True
                        res.failure(e)

                if not test_failed:
                    # shipment address form
                    headers_shipmentAddressForm = {
                        "Tkpd-UserId": user_id,
                        "X-Device": "android",
                        "tkpd-sessionid": device_id,
                        "accounts-authorization":ah.get_token(user_id)
                    }
                    res = cartapp.shipment_address_form_v2(self, cartapp.host_production, headers=headers_shipmentAddressForm,
                                                        cb_threshold=cb_threshold, timeout=timeout_ATC, catch_response=True)

                    if res.status_code == 200:
                        try:
                            if 'address_id' in res.content:
                                res.success()
                            else:
                                res.failure(res.content)
                        except Exception as e:
                            res.failure(res.content)
                    else:
                        try:
                            res.raise_for_status()
                        except Exception as e:
                            res.failure(e)

                    try:
                        respon = res.json()
                        address_id = respon['data']['group_address'][0]['user_address']['address_id']
                        shop_id = respon['data']['group_address'][0]['group_shop'][0]['shop']['shop_id']
                        shipping_id = respon['data']['group_address'][0]['group_shop'][0]['shop_shipments'][0][
                            'ship_id']  # jne
                        sp_id = \
                        respon['data']['group_address'][0]['group_shop'][0]['shop_shipments'][0]['ship_prods'][0][
                            'ship_prod_id']  # reguler
                        product_id = respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_id']
                        notes = respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_notes']
                        quantity = respon['data']['group_address'][0]['group_shop'][0]['products'][0][
                            'product_quantity']

                        # sp_id       = respon['data']['group_address'][0]['group_shop'][0]['shop_shipments'][0]['ship_prods'][0]['ship_prod_id']
                        cat_id      = str(respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_cat_id'])
                        #Random latitude & longitude jakarta area
                        origin_latitude = str(random.uniform(-6.149573, -6.247871))
                        origin_longtitude = str(random.uniform(106.751159, 106.900907))
                        destination = str(respon['data']['group_address'][0]['user_address']['district_id']) + "|"+ \
                                    respon['data']['group_address'][0]['user_address']['postal_code'] + "|"+ \
                                    origin_latitude + "," + origin_longtitude
                        order_value = respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_price'] * \
                                    respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_quantity']              
                        weight      = respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_weight'] * \
                                    respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_quantity'] / 1000.0              
                        origin      = str(respon['data']['group_address'][0]['group_shop'][0]['shop']['district_id']) + "|"+ \
                                    respon['data']['group_address'][0]['group_shop'][0]['shop']['postal_code'] + "|"+ \
                                    respon['data']['group_address'][0]['group_shop'][0]['shop']['latitude'] + "," + \
                                    respon['data']['group_address'][0]['group_shop'][0]['shop']['longitude'] 
                        product_insurance = str(respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_finsurance'])
                        token       = respon['data']['kero_token']
                        ut          = str(respon['data']['kero_unix_time'])
                    except Exception:
                        test_failed = True

                    if not test_failed:
                        #kero rates
                        query = 'cat_id='+cat_id+'&'+ \
                                'destination='+destination+'&'+ \
                                'from=client&insurance=1&lang=id&names=jne,tiki,wahana,pos,first,gojek,sicepat,ninja,grab,jnt,rex&' + \
                                'order_value='+str(order_value)+'&'+ \
                                'origin='+origin+'&'+ \
                                'product_insurance='+product_insurance+'&'+ \
                                'service=regular,nextday,economy,sameday,cargo&' + \
                                'token='+token+'&'+ \
                                'ut='+ut+'&'+ \
                                'weight='+str(weight)
                        res = gw.rates_v2(self, gw.host_production, device_id, user_id, timeout=timeout, cb_threshold=cb_threshold, 
                            headers=headers, query=query, hide_query=True,  catch_response=True)


                        if res.status_code == 200:
                            try:
                                if 'shipper_name' in res.content:
                                    res.success()
                                else:
                                    res.failure(res.content)
                            except Exception as e:
                                res.failure(res.content)
                        else:
                            try:
                                res.raise_for_status()
                            except Exception as e:
                                res.failure(e)

                        carts_param = cartapp.check_promo_code_final_params("", address_id, shop_id,
                                                                            shipping_id, sp_id, product_id, notes,
                                                                            quantity)
                        # checkout
                        headers_checkout = {
                            "Tkpd-UserId": user_id,
                            "X-Device": "android",
                            "tkpd-sessionid": device_id,
                            "accounts-authorization":ah.get_token(user_id)
                        }
                        body_checkout = {
                            "carts": carts_param
                        }
                        res = cartapp.checkout_v2(self, cartapp.host_production, headers=headers_checkout,
                                                bodies=body_checkout, cb_threshold=cb_threshold, timeout=timeout_ATC,
                                                catch_response=True)

                        if not res == "":
                            if res.status_code == 200:
                                try:
                                    if 'transaction_id' in res.content:
                                        test_failed = False
                                        res.success()
                                    else:
                                        if 'Tidak ada keranjang belanja yang bisa diproses.' in \
                                                res.json()['message_error'][0]:
                                            res.success()
                                        else:
                                            res.failure(res.content)

                                        test_failed = True

                                except Exception as e:
                                    test_failed = True
                                    res.failure(e)
                            else:
                                try:
                                    res.raise_for_status()
                                except Exception as e:
                                    test_failed = True
                                    res.failure(e)
                        else:
                            test_failed = True

                        if not test_failed:
                            #payment iframe
                            respon = res.json()
                            transaction_id = respon['data']['data']['parameter']['transaction_id']
                            transaction_date = respon['data']['data']['parameter']['transaction_date']
                            user_defined_value = respon['data']['data']['parameter']['user_defined_value']
                            product_list = respon['data']['data']['product_list']
                            ids = orderapp.itemsList(product_list, 'id')
                            prices = orderapp.itemsList(product_list, 'price')
                            quantities = orderapp.itemsList(product_list, 'quantity')
                            names = orderapp.itemsList(product_list, 'name')
                            payment_metadata = respon['data']['data']['parameter']['payment_metadata']
                            merchant_code = respon['data']['data']['parameter']['merchant_code']
                            nid = respon['data']['data']['parameter']['nid']
                            pid = respon['data']['data']['parameter']['pid']
                            profile_code = respon['data']['data']['parameter']['profile_code']
                            gateway_code = respon['data']['data']['parameter']['gateway_code']
                            amount = respon['data']['data']['parameter']['amount']
                            customer_email = respon['data']['data']['parameter']['customer_email']
                            signature = respon['data']['data']['parameter']['signature']
                            customer_name = respon['data']['data']['parameter']['customer_name']
                            msisdn = respon['data']['data']['parameter']['customer_msisdn']
                            currency = respon['data']['data']['parameter']['currency']

                            # payment
                            bodies_v2Payment = {
                                'customer_id': user_id,
                                'customer_email': customer_email,
                                'customer_name': customer_name,
                                'transaction_id': transaction_id,
                                'transaction_date': transaction_date,
                                'amount': amount,
                                'gateway_code': gateway_code,
                                'currency': currency,
                                'signature': signature,
                                'items[id]': ids,
                                'items[price]': prices,
                                'items[quantity]': quantities,
                                'items[name]': names,
                                'nid': nid,
                                'pid': pid,
                                'user_defined_value': user_defined_value,
                                'merchant_code': merchant_code,
                                'profile_code': profile_code,
                                'language': 'id-ID',
                                'payment_metadata': payment_metadata,
                                'customer_msisdn': msisdn,
                                'device_info': '[object+Object]'
                            }

                            headers_v2Payment = {
                                'Content-Type': 'application/x-www-form-urlencoded'
                            }
                            res = scrooge.payment_v2(self, scrooge.host_production, bodies=bodies_v2Payment,
                                                        headers=headers_v2Payment, timeout=timeout_page,
                                                        cb_threshold=cb_threshold, catch_response=True)

                            if res != "" and res.status_code == 200:
                                    try:
                                        if 'Payment Failed' in res.content or len(str(res.content)) < 1:
                                            test_failed = True
                                            res.failure("Payment Failed or empty html returned")
                                        else:
                                            res.success()
                                    except Exception as e:
                                        test_failed = True
                                        res.failure(res.content)
                            else:
                                    try:
                                        res.raise_for_status()
                                    except Exception as e:
                                        test_failed = True
                                        res.failure(e)

        res = cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                            bodies=bodies_reset,
                            headers=headers_reset, cb_threshold=cb_threshold,
                            timeout=timeout_ATC)


class WebsiteUser(HttpLocust):
    host = cartapp.host_production
    task_set = ATCCheckout
    min_wait = 600
    max_wait = 800