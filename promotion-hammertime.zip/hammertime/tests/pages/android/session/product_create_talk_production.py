from locust import HttpLocust, TaskSet, task
from modules import tokopedia, ace, mojito, gold_merchant, inbox, ws_v4, galadriel, tome
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class ProductCreateTalkProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration['production']
        self.account = ah.get_account(self, accounts=self.config["dexter"]["massive_accounts"], login_type=ah.LOGIN_TYPE_APP)


    @task(1)
    def task1(self):
        product = random.choice(self.config['products'])
        product_id = product['id']
        user_id = self.account["user_id"]
        device_id = self.config['device_id']
        os_type = self.config['os_type']
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']

        bodies = {
            'product_id':product_id,
            'text_comment':'this is a comment',
            'user_id':user_id,
            'os_type':os_type,
            'device_id':device_id,
            'offline':1
        }
        res = inbox.talk_create_v2(self, inbox.host_production, user_id, device_id, bodies=bodies, cb_threshold=cb_threshold, timeout=timeout, catch_response=True)
        if res.status_code == 201 or res.status_code == 200:
            try:
                response = res.json()
                if response["data"]["is_success"] == 1 :
                    res.success()
                else:
                    res.failure(res.content)
            except Exception:
                res.failure(res.content)
        else :
            try :
                res.raise_for_status()
            except Exception as e:
                res.failure(e)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = ProductCreateTalkProduction
    min_wait = 1500
    max_wait = 2500
