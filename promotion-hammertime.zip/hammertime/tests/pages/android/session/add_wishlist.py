from locust import HttpLocust, TaskSet, task
from modules import tokopedia, mojito, tome, gw, chat, pulsa, pulsa_api
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class AddWishlist(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BOTH)

    @task(1)
    def task1(self):
        device_id = self.config['device_id']
        user_id = self.account['user_id']
        product_ids = random.choice(self.config['dexter']['massive_products'])
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold    = self.config['cb_threshold']
        
        headers = {
            'cookie':ah.get_sid_cookie(user_id),
            'Accounts-Authorization':ah.get_token(user_id),
            'X-Device':'android'
        }

        res = tokopedia.ajax_wishlist_pl(self, tokopedia.host_production, headers=headers, query='p_id='+product_ids+'&action=event_get_update_wishlist_key&mtd=POST&ref=pdp&type=pdp', cb_threshold=cb_threshold, timeout=timeout, hide_query=True, catch_response=True)
        try:
            resJSON = res.json()
            if 'wishlist_update_key' in resJSON:
                res.success()
            else:
                message = "unexpected JSON response -> " + resJSON
                res.failure(message)
        except Exception, e:
            res.failure(e)
        
        headersMojito = {
            'cookie':ah.get_sid_cookie(user_id),
            'Accounts-Authorization':ah.get_token(user_id),
            'X-Device':'android'
        }
        res = mojito.users_P_wishlist_P_v1_1(self, mojito.host_production, user_id, device_id, product_ids, headers=headersMojito, cb_threshold=cb_threshold, timeout=timeout, name="/users/{user_id}/wishlist/{product_id}/v1.1")

        if res.status_code == 201:
            resDelete = tokopedia.ajax_wishlist_pl(self, tokopedia.host_production, headers=headers, query='p_id='+product_ids+'&action=event_get_update_wishlist_key&mtd=DELETE', cb_threshold=cb_threshold, timeout=timeout, hide_query=True, catch_response=True)
            try:
                resdeleteJSON = resDelete.json()
                if 'wishlist_update_key' in resdeleteJSON:
                    resDelete.success()
                else:
                    message = "unexpected JSON response -> " + resdeleteJSON
                    resDelete.failure(message)
            except Exception, e:
                resDelete.failure(e)

            headersMojitoDelete = {
                'cookie':ah.get_sid_cookie(user_id),
                'Accounts-Authorization':ah.get_token(user_id),
                'X-Device':'android'
            }
            res = mojito.users_P_wishlist_P_v1_1(self, mojito.host_production, user_id, device_id, product_ids, method="DELETE", headers=headersMojitoDelete, cb_threshold=cb_threshold, timeout=timeout, name="/users/{user_id}/wishlist/{product_id}/v1.1")


class WebsiteUser(HttpLocust):
    host = ""
    task_set = AddWishlist
    min_wait = 1500
    max_wait = 2500
