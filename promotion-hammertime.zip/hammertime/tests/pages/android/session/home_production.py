from locust import HttpLocust, TaskSet, task
from modules import tokopedia, graphql, ws_v4, pulsa_api, tokocash, topads, cartapp
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class HomeProduction(TaskSet):
    def on_start(self):
        if not hasattr(HomeProduction, 'config_loaded') :
            HomeProduction.test_config = self.configuration['production']
            HomeProduction.large_users = self.team_configuration(HomeProduction.test_config['dexter']['20k_accounts'])
            HomeProduction.config_loaded = True
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_APP, accounts=HomeProduction.large_users)

    @task(1)
    def task1(self):
        user_id = self.account["user_id"]
        device_id = HomeProduction.test_config["device_id"]
        headers = {
            "Authorization": ah.get_token(user_id),
            "Accounts-Authorization": ah.get_token(user_id),
            "Tkpd-UserId": user_id,
            "X-Device": "android",
            "tkpd-sessionid": device_id,
        }
        timeout = (HomeProduction.test_config['timeout'][0],HomeProduction.test_config['timeout'][1])
        timeout_graphql = (HomeProduction.test_config['timeout_graphql'][0],HomeProduction.test_config['timeout_graphql'][1])
        cb_threshold = HomeProduction.test_config["cb_threshold"]

        # graphql
        res = graphql.graphql_dynamicHome(self, graphql.host_graphql, headers=headers,  json={"variables":{"cursor": "","limit": 3,"page": 1,"userID":user_id}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_consumerDrawerData(self, graphql.host_graphql, headers=headers, json={"variables":{"userID":int(user_id)}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_tokopoints(self, graphql.host_graphql, headers=headers,  json={"variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        # res = graphql.graphql_tokopointsToken(self, graphql.host_graphql, headers=headers, json={}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_RechargeCategoryDetail(self, graphql.host_graphql, headers=headers, json={"variables": {"category_id": 1,"is_seller": 0},"operationName": "RechargeCategoryDetail"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_wallet(self, graphql.host_graphql, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_homeFeedQuery(self, graphql.host_graphql, headers=headers,  json={"variables":{"cursor": "","limit": 4,"userID":int(user_id)}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        
        #topads
        query = 'ep=cpm&item=1&src=home&template_id=6&'
        res = topads.promo_display_ads_v1_1(self, topads.host_production,
                                            query=query + "user_id=" + user_id + "device=android",
                                            name=topads.host_production + "/promo/v1.1/display/ads?ep=cpm&item=1&src=home", timeout=timeout, cb_threshold=cb_threshold)

        #cartapp
        res = cartapp.cart_notif_counter(self, cartapp.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        # pulsa-api
        res = pulsa_api.status_v1_4(self, pulsa_api.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        res = pulsa_api.category_list_v1_4(self, pulsa_api.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        
class WebsiteUser(HttpLocust):
    host = ""
    task_set = HomeProduction
    min_wait = 600
    max_wait = 800
