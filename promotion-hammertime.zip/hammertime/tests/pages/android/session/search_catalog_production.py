from locust import HttpLocust, TaskSet, task
from modules import ws_v4, ace, accounts, topads
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class SearchCatalogProduction(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        user_id         = self.account['user_id']
        device_id       = self.config['device_id']
        os_type         = self.config['os_type']
        search_keyword  = random.choice(self.config["search"]["search_catalog_keywords"])
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold    = self.config["cb_threshold"]

        res = ace.search_catalog_v2_1(self, ace.host_production, query='device=android&start=0&rows=12&pmin=&terms=true&ob=&id=&pmax=&image_size=200&q='+search_keyword+'&image_square=true&sc=&breadcrumb=true', hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        res = topads.promo_display_ads_v1_1(self, topads.host_production, query='device=android&dep_id=&src=search&q='+search_keyword+'&ep=product&page=1&item=2&user_id='+user_id, name=topads.host_production+"/promo/v1.1/display/ads?src=search&ep=product",  timeout=timeout, cb_threshold=cb_threshold)
        res = ace.dynamic_attributes_v2(self, ace.host_production, query='st=product&q='+search_keyword+'&ob=23&source=search&device=desktop&callback=angular.callbacks._0', hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = SearchCatalogProduction
    min_wait = 1500
    max_wait = 2500
