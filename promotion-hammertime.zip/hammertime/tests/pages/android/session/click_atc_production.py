from locust import HttpLocust, TaskSet, task
from modules import tokopedia, ace, ws_v4, accounts, galadriel, gold_merchant, inbox, mojito
from tests.helper.account_helper import AccountHelper
from tests.pages.android.no_session.product_detail_production import ProductDetailProduction
from libs import bearer_token, user_conversion
import random

ah = AccountHelper()
converted_user = 0
uc = user_conversion.UserConversion()

class ClickAtcProduction(TaskSet):
    
    def on_start(self):
        
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_APP)
        self.address = self.account['list_address'][random.randint(0,(len(self.account['list_address']) -1 ))]
        self.product = self.config['products'][random.randint(0,(len(self.config['products']) -1 ))]

        self.productDetailProduction = ProductDetailProduction(self)
        self.productDetailProduction.config = self.config    
        self.productDetailProduction.account = self.account   

        global uc
        uc.max_threshold = 0.2   

    @task(5)
    def task1(self):
        self.productDetailProduction.task1()
        user_id = self.account['user_id']
        device_id = self.config['device_id']
        timeout     = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']

        #Access PDP with conversion rate
        @uc.attempt(self.runners.user_count)
        def add_to_cart():
            atc_bodies = {
                'address_street': self.address["address_street"],
                'product_id': self.product["id"],
                'address_province':self.address["province_id"],
                'insurance':0,
                'os_type':self.config["os_type"],
                'address_postal_code':self.address["postal_code"],
                'shipping_id':1,
                'quantity': 1,
                'address_name':self.address["address_name"],
                'shipping_product':1,
                'receiver_phone':self.address["receiver_phone"],
                'notes': '',
                'receiver_name': self.address["receiver_name"],
                'address_city':self.address["city_id"],
                'address_id': self.address["address_id"],
                'user_id':self.account["user_id"],
                'device_id':self.config["device_id"],
                'address_district':self.address["district_id"]
            }

            res = ws_v4.action_txCart_add_to_cart_v4(self, ws_v4.host_production, user_id, device_id, bodies=atc_bodies, timeout=timeout, catch_response=True, cb_threshold=cb_threshold)
            if res.status_code == 200:
                try:
                    response = res.json()
                    if response["data"]["is_success"] == 1 :
                        res.success()
                    else:
                        res.failure(res.content)
                except Exception, e:
                    res.failure(res.content)
            else :
                try :
                    res.raise_for_status()
                except Exception, e:
                    res.failure(e)
        add_to_cart()

    @task(1)
    def task2(self):
        # remove items(s) from cart
        timeout     = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']

        if hasattr(self, 'product') :
            delete_cart_bodies = {
                'device_id': self.config["device_id"],
                'os_type': self.config["os_type"],
                'shop_id':self.product["shop_id"],
                'shipment_id':1,
                'shipment_package_id':1,
                'address_id':self.address["address_id"],
                'user_id':self.account["user_id"]
            }
            
            res = ws_v4.action_txCart_cancel_cart_pl(self, ws_v4.host_production, self.account["user_id"], self.config["device_id"], bodies=delete_cart_bodies, timeout=timeout, cb_threshold=cb_threshold)


class WebsiteUser(HttpLocust):
    host = ""
    task_set = ClickAtcProduction
    min_wait = 1000
    max_wait = 1500
