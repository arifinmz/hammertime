from locust import HttpLocust, TaskSet, task
from modules import ws_v4, ace, mojito, topads
from tests.helper.account_helper import AccountHelper
import random, json

ah = AccountHelper()

class HotlistDetail(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        device_id       = self.config['device_id']
        user_id         = self.account['user_id']
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold    = self.config['cb_threshold']
        headers         = {
            'cookie':ah.get_token(user_id)
        }
        platform        = 'android'
        hotlist         = random.choice(self.config['hotlist'])
        hotlist_id      = hotlist['filter_attribute']['hot_id']

        # ws_v4
        res = ws_v4.hotlist_getHotlistBanner_pl_v4(self, ws_v4.host_production, user_id, device_id, headers=headers, query='key='+hotlist['alias_key'], hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        # ace
        sub_query = '&'.join(['%s=%s' % (key, value) for (key, value) in hotlist['filter_attribute'].items()])
        search_query = 'device={0}&start=0&shop_id=&rows=12&image_size=200&fshop=0&image_square=True&user_id={1}&{2}&hc={3}'.format(platform, user_id, sub_query, hotlist_id)
        res_search_product = ace.search_product_v3(self, ace.host_production, headers=headers, query=search_query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        
        dynamic_query = 'device={0}&start=0&shop_id=&rows=12&fshop=0&user_id={1}&{2}'.format(platform, user_id, sub_query)
        res = ace.dynamic_attributes_v2(self, ace.host_production, headers=headers, query=dynamic_query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        # mojito
        try:
            product_data = res_search_product.json()
            product_data = product_data['data']['products']
            if product_data:
                product_ids = []
                for product in product_data:
                    product_ids.append(str(product['id']))

                pid = ','.join(product_ids)
                res = mojito.users_P_wishlist_check_P_v1(self, mojito.host_production, user_id, pid, headers=headers, name=mojito.host_production+'/v1/users/{user_id}}/wishlist/check/{product_ids}', timeout=timeout, cb_threshold=cb_threshold)
        
        except Exception as e:
            pass
        
        # topads
        topads_query = 'device={0}&src=hotlist&ep=product&h={1}&page=1&item=2&user_id={2}'.format(platform,  hotlist_id, user_id)
        if 'sc' in hotlist['filter_attribute']:
            topads_query = topads_query + '&dep_id=' + hotlist['filter_attribute']['sc']

        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query=topads_query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        
        viewport = 'H_tp6sJpoArR6_Jh6sJEHstho_UOHsyh6Arp6MusrprXPcY0QRCBgcBxbMNBPmY2Q3r5yfVsqc15HsnFb9ohP3VagZYFrMYjP3o7b_J5Hsnhoi4dbpURbpUaopjOoAH5HsUR6_17HO4FHpefo_oiHm7doAedb_zMy3HW6_H76Z7docHh6ACsofHaopeXqSCS6stF6snXHAHhHAUp6MuNZM2jZJ2M33NGPMep_Mh-qMY2_1o-r7BW_sCsQABE3BPc8ujagfBvq1BRZ3BRq3JausujHsBN3jyN8Bja69Bq17jfZ32Cq1hAZSuiHsuk3Bo-ojBk__uozJ-0_uPgo1h1__Vozco7_jztQ1N_HAz6u72D_VzSP7OI19Pg8BJh_MO6q1O2Z9o-Q_BNyuPjrc-D69PsQ_B0gVP6HVKaQcW-qMY2_1o-r7BW69BxufzFyMFN8MVI69PyHMh0Z325q1OAZ9o-QjNkysoGQVKaZSBiHfzE3Bo-ojBke9uozJOd_1z-81NEgpzvzcWN_920o1O1192-q9P2yp-6PMoWuMgsHBgtyfO6Q7BkQfBoepzR_92V8JOJyRx6qjOd_32SH1NJ__-6q1tN'
        res = topads.promo_views_P_v1(self, topads.host_production, viewport, headers=headers, query='t={0}&src=hotlist&alg=def&post_alg=cpc_shop_unq&number_ads_req=2&n_candidate_ads=61&hotlist_id={1}&page=1&uid={2}&ab_test=N&number_of_ads=2'.format(platform, hotlist_id, user_id), name=topads.host_production+'/promo/v1/views/{viewport}', timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = HotlistDetail
    min_wait = 1500
    max_wait = 2500