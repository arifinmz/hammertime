import random
from locust import HttpLocust, TaskSet, task
from modules import tokopedia, ws_v4, tome
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class AtcProduction(TaskSet):
    
    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self)


    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        device_id = self.config['device_id']
        timeout     = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        self.address = random.choice(self.account['list_address'])
        self.products = random.choice(self.config['products'])
        self.product_id = self.products["id"]

        # action after buyer click buy
        atc_bodies = {
            'address_street': self.address["address_street"],
            'product_id': self.product_id,
            'address_province':self.address["province_id"],
            'insurance':0,
            'os_type':self.config["os_type"],
            'address_postal_code':self.address["postal_code"],
            'shipping_id':1,
            'quantity': 1,
            'address_name':self.address["address_name"],
            'shipping_product':1,
            'receiver_phone':self.address["receiver_phone"],
            'notes': '',
            'receiver_name': self.address["receiver_name"],
            'address_city':self.address["city_id"],
            'address_id': self.address["address_id"],
            'user_id': user_id,
            'device_id': device_id,
            'address_district':self.address["district_id"]
        }
        res = ws_v4.action_txCart_add_to_cart_v4(self, ws_v4.host_production, user_id, device_id, bodies=atc_bodies, timeout=timeout, catch_response=True, cb_threshold=cb_threshold)
        
        if res.status_code == 200:
            try:
                response = res.json()
                if response["data"]["is_success"] == 1 :
                    res.success()
                else:
                    res.failure(res.content)
            except Exception, e:
                res.failure(res.content)
        else :
            try :
                res.raise_for_status()
            except Exception, e:
                res.failure(e)


class WebsiteUser(HttpLocust):
    host = tokopedia.host_production
    task_set = AtcProduction
    min_wait = 1000
    max_wait = 1500
