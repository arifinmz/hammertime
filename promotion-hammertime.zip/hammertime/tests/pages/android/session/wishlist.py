from locust import HttpLocust, TaskSet, task
from modules import mojito
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class Wishlist(TaskSet):
    def on_start(self):
        self.config = self.configuration['production']
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        user_id         = self.account['user_id']
        device_id       = self.config['device_id']
        timeout         = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold    = self.config['cb_threshold']
        
        headers = {
            'Authorization':ah.get_token(user_id)
        }

        # mojito
        res = mojito.users_P_wishlist_products_v1_0_3(self, mojito.host_production, user_id, device_id, headers=headers, query="count=10&page=1", name=mojito.host_production+"/v1.0.3/users/{user_id}/wishlist/products?page=1&count=20&ref=whead", timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = mojito.host_production
    task_set = Wishlist
    min_wait = 1500
    max_wait = 2500