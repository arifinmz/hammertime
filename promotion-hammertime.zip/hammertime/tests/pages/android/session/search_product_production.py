from locust import HttpLocust, TaskSet, task
from modules import ace, mojito, topads, tome
from tests.helper.account_helper import AccountHelper
from libs import randex
import random

ah = AccountHelper()

class SearchProductProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        keyword = randex.generate_word(2,20)
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = self.account['user_id']
        platform = 'android'
        device_id = self.config['device_id']
       
        headers = {
            'Authorization': ah.get_token(user_id)
        }
        res = ace.guide_v1(self, ace.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold, query='q='+keyword, hide_query=True)
        res = ace.dynamic_attributes_v4(self, ace.host_production, name=ace.host_production+'/v2/dynamic_attributes?source=search_product', headers=headers, timeout=timeout, cb_threshold=cb_threshold, query='device={0}&source=search_product&q={1}&sc=&user_id={2}'.format(platform, keyword, user_id))
        res = ace.dynamic_attributes_v2(self, ace.host_production, name=ace.host_production+'/v2/dynamic_attributes?source=quick_filter', headers=headers, timeout=timeout, cb_threshold=cb_threshold, query='device={0}&source=quick_filter&q={1}&os_type=1&sc=0&user_id={2}'.format(platform, keyword, user_id))
        res_product = ace.search_product_v3(self, ace.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold, query='device={0}&start=0&rows=12&source=search&ob=23&rf=false&unique_id=&image_size=200&q={1}&image_square=true&user_id={2}'.format(platform, keyword, user_id), hide_query=True)
        try :
            ace_data = res_product.json()
            products = ace_data['data']['products']
            if len(products) > 1:
                product_ids = []
                for product in products:
                    product_ids.append(str(product['id']))
                
                pid = ','.join(product_ids)

                res = mojito.users_P_wishlist_check_P_v1(self, mojito.host_production, user_id, product_ids, headers=headers, name=mojito.host_production+"/v1/users/{user_id}/wishlist/check/{product_ids}", timeout=timeout, cb_threshold=cb_threshold)
                
        except Exception as e:
            print(e)

        res = mojito.os_api_search_banner_P(self, mojito.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold, platform=platform, query='keywords='+keyword, hide_query=True)

        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold, query='q='+keyword+'&device='+platform+'&ep=product&src=search&page=1&item=2&user_id='+user_id, name=topads.host_production+"/promo/v1.1/display/ads?src=search&ep=product")
        res = topads.promo_display_ads_v1_3(self, topads.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold, query='template_id=3%2C4&device='+platform+'&src=search&q='+keyword+'&ep=cpm&item=1&page=1&user_id='+user_id, name=topads.host_production+"/promo/v1.3/display/ads?src=search&ep=cpm")
        viewport = "H_tEH_rpoAKhopeEHpth6sJOHseFoAnN6_rEg3opoaN7QfW5rcujq3JXQMu7bfBWgaYsy3otgZ4hHAnWrRVOy9-BbRotQRCpb_J5Hsnhoa4pbpJdbpKh6_rRbpKh6_rR9fU7HAnag_jab_BBy_nWoAj7gm7d6c-jb_JNys-jypxj6Ae76ZNFQMrEH_nEHsep6AKFH_tabsjpHAyfoA2B812kgJxGgBBXZSgjH7NDZ325q1OAoIxouJBN_92oHJNJu_V6qBjp_S2So1O2Z9o-Q1dFyfFN8B29zSBgHMP2_fB-P7B2PfBxHByOgAUN8u2c692gHsBN3Bo-ojBke9uvuJOR_Bzz81O1gpu6qMPN_M2V81Y_Z9o-Q_ufyMO6QJBkQfB6Hjjh_32Zq77aZ9z6qMD7_SjFHV2kZMxHu7uR_1zSPJNI__ooz7g2_OzmQJO1QcB-q9P2ysoGrVtaQIuyH7-Nys-ZHujp1MgxuOV2_fB-P7B2PfBiH72F3s-DPuKp_MYiH7-MyuPzq1Y2Z9P-q9P2yp-6PMoWuMggQj2fgAo6QJBkQfBoepeh_1zSH1N1qpovucPd_92gH1OJu_u-q9P2yp-6PMoWuMgsHBgtyfO6Q7BkQfBoq_zR_1zC8JOkz_u68MPN_1zgHJNk1_z-QsnY"
        res = topads.promo_views_P_v1(self, topads.host_production, viewport, query='template_id_used=3&uid='+user_id+'&page=1&number_of_ads=1&cpm_template_req=3%2C4&ab_test=N&n_candidate_ads=3&number_ads_req=1&src=xsource&alg=stm&is_search=1&keywords='+keyword+'&t='+platform, name=topads.host_production+'/promo/v1/views/{viewport}', timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = SearchProductProduction
    min_wait = 1500
    max_wait = 2500
