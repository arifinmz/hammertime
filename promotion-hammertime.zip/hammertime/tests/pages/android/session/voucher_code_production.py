from locust import HttpLocust, TaskSet, task
from libs import bearer_token, tkpdhmac
from modules import ws_v4, accounts
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class VoucherCodeProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        bodies = {
            "user_id":self.account["user_id"],
            "os_type":self.config["os_type"],
            "device_id":self.config["device_id"],
            "voucher_code":self.config["voucher_codes"][0]
        }
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]

        res = ws_v4.txVoucher_checkVoucherCode_pl_v4(self, ws_v4.host_production, self.account["user_id"], self.config["device_id"], headers={"Accounts-Authorization":ah.get_token(self.account['user_id'])}, bodies=bodies, name=ws_v4.host_production+"/v4/tx-voucher/check_voucher_code.pl/"+self.config["voucher_codes"][0], timeout=timeout, cb_threshold=cb_threshold)

    @task(1)
    def task2(self):
        bodies = {
            "user_id":self.account["user_id"],
            "os_type":self.config["os_type"],
            "device_id":self.config["device_id"],
            "voucher_code":self.config["voucher_codes"][1]
        }
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]

        res = ws_v4.txVoucher_checkVoucherCode_pl_v4(self, ws_v4.host_production, self.account["user_id"], self.config["device_id"], headers={"Accounts-Authorization":ah.get_token(self.account['user_id'])}, bodies=bodies, name=ws_v4.host_production+"/v4/tx-voucher/check_voucher_code.pl/"+self.config["voucher_codes"][1], timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = VoucherCodeProduction
    min_wait = 1500
    max_wait = 2500
