from locust import HttpLocust, TaskSet, task
from libs import bearer_token
from modules import tokopedia, accounts, ws_v4, kero, tome
import os, random
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class TxProduction(TaskSet):
    
    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_APP)
        

    # User accessing home page with session from cookie
    @task(1)
    def task1(self):
        user_id = self.account["user_id"]
        device_id = self.config["device_id"]
        os_type = self.config["os_type"]
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        shop_info = self.config["shop_info"]

        # ws_v4
        bodies = {
            'user_id':user_id,
            'device_id':device_id,
            'os_type':os_type
        }
        res = ws_v4.tx_pl_v4(self, ws_v4.host_production, user_id, device_id, cb_threshold=cb_threshold, timeout=timeout, bodies=bodies)
        try:
            tx_json = res.json()
            txlist = tx_json["data"]["list"]
            for tx in txlist:
                cat_id = str(tx["cart_cat_id"])
                weight = str(tx["cart_products"][0]["product_weight"])
                order_value = str(tx["cart_products"][0]["product_price"])
                destination = str(tx["cart_destination"]["address_district_id"])+"|"+str(tx["cart_destination"]["address_postal"])+"|"+tx["cart_destination"]["latitude"]+","+tx["cart_destination"]["longitude"]
                origin = str(tx["cart_destination"]["address_district_id"])+"|"+str(tx["cart_destination"]["address_postal"])+"|"+tx["cart_shop"]["latitude"]+","+tx["cart_shop"]["longitude"]
                query = "destination="+destination+"&insurance=1&os_type="+self.config["os_type"]+"&origin="+origin+"&cat_id="+cat_id+"&from=client&weight="+weight+"&device_id="+device_id+"&product_insurance=0&names="+shop_info["names"]+"&order_value="+order_value+"&type=android&user_id="+user_id
                res = kero.rates_v1(self, kero.host_production, device_id, user_id, timeout=timeout, cb_threshold=cb_threshold, query=query, hide_query=True)
        except Exception as e:
            pass

        
class WebsiteUser(HttpLocust):
    host = ""
    task_set = TxProduction
    min_wait = 1500
    max_wait = 2500
