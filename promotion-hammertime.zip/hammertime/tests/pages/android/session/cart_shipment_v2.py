from locust import HttpLocust, TaskSet, task
from modules import cartapp, orderapp
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class CartShipment(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_BOTH)
        self.user_id = self.account['user_id']
        self.cookie = orderapp.find_between(ah.get_sid_cookie(self.user_id), '_SID_Tokopedia', ';')
        self.device_id = self.config['device_id']
        self.timeout = (self.config['timeout'][0], self.config['timeout'][1])
        self.cb_threshold = self.config['cb_threshold']

    @task(20)
    def task1(self):
        test_failed = False
        
        product = random.choice(self.config['products'])
        product_id = product['id']
        shop_id = product['shop_id']

        headers = {
            'cookie': self.cookie,
            'Authorization': ah.get_token(self.user_id),
            'Tkpd-UserId': self.user_id
        }
        bodies_add_cart = {
            'params': '{"tracker_attribution": "none / other", "tracker_list_name": null, "notes": null, "product_id": ' + product_id + ', "quantity": 1, "shop_id": ' + shop_id + '}'
        }
        res = cartapp.add_product_cart_v2(self, cartapp.host_production, headers=headers, bodies=bodies_add_cart, cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)
        if res.status_code == 200 :
            try :
                data = res.json()
                if data['data']['success'] == 1 :
                    res.success()
                    test_failed = False
                else :
                    res.failure(data['data']['message'])
                    test_failed = True
                    print(res.content)
            except Exception as e :
                test_failed = True
                res.failure(e)
                print(res.content)
        else :
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)
                print(res.content)

        if not test_failed:
            try:
                respon = res.json()
                cart_id = respon['data']['data']['cart_id']
                # update cart
                carts_param = '[{"cart_id": ' + str(cart_id) + ', "quantity":1, "notes": "update ya"}]'
                body_updateCart = {
                    "carts": carts_param
                }
                res = cartapp.update_cart_v2(self, cartapp.host_production, headers=headers, bodies=body_updateCart,
                                        cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)
                if res.status_code == 200:
                    if '"status":true' and '"error_code":"200"' in res.content:
                        test_failed = False
                        res.success()
                    else:
                        test_failed = True
                        res.failure(res.content)
                else:
                    try:
                        res.raise_for_status()
                    except Exception as e:
                        test_failed = True
                        res.failure(e)
            except Exception:
                test_failed = True
            

            if not test_failed:
                # shipment address form
                headers_shipmentAddressForm = {
                    'cookie': self.cookie,
                    'Tkpd-UserId': self.user_id
                }
                res = cartapp.shipment_address_form_v2(self, cartapp.host_production, headers=headers_shipmentAddressForm,
                                                    cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)
                if res.status_code == 200:
                    try:
                        if 'address_id' in res.content:
                            res.success()
                        else:
                            res.failure(res.content)
                    except Exception as e:
                        res.failure(res.content)
                else:
                    try:
                        res.raise_for_status()
                    except Exception as e:
                        res.failure(e)

    @task(1)
    def task2(self):
        bodies_reset_cart = {
            'status': '1',
            'lang': 'id'
        }
        headers_reset_cart = {
            'Tkpd-UserId': self.user_id,
            'content-type': 'application/x-www-form-urlencoded',
            'cookie': self.cookie
        }
        cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, self.user_id, self.device_id, bodies=bodies_reset_cart, headers=headers_reset_cart, cb_threshold=self.cb_threshold, timeout=self.timeout)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = CartShipment
    min_wait = 1500
    max_wait = 2500