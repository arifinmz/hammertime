from locust import HttpLocust, TaskSet, task
from modules import hades, topads, mojito, ace
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class CategoryIntermediary(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        category_id = random.choice(self.config['category']['category_id']['all_intermediary'])
        list_category_no_child = self.config['category']['category_id']['category_no_child']              
        platform = 'android'
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        headers = {
            'Authorization' : ah.get_token(user_id)
        }

        # ace
        if category_id not in list_category_no_child:
            res = ace.hoth_hotlist_category_v1(self, ace.host_production, headers=headers, query='perPage=7&categories={0}'.format(category_id), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        
        # mojito
        res = mojito.os_api_brands_category_P_P_v1(self, mojito.host_production, platform, category_id, headers=headers, timeout=timeout, cb_threshold=cb_threshold, name=mojito.host_production+"/os/api/v1/brands/category/"+platform+"/{category_id}")
   
        # hades
        res = hades.categories_P_detail_v2(self, hades.host_production, category_id, headers=headers, query="total_curated=6", name=hades.host_production+"/v2/categories/{category_id}/detail", timeout=timeout, cb_threshold=cb_threshold)

        # topads
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query='device={0}&dep_id={1}&ep=product&src=intermediary&page=1&item=2&user_id={2}'.format(platform, category_id, user_id), name=topads.host_production+'/promo/v1.1/display/ads?ep=product&src=intermediary', timeout=timeout, cb_threshold=cb_threshold)
        res = topads.promo_display_ads_v1_3(self, topads.host_production, headers=headers, query='template_id=3%2C4&device={0}&ep=cpm&dep_id={1}&src=intermediary&page=1&item=1'.format(platform, category_id), name=topads.host_production+'/promo/v1.1/display/ads?ep=cpm&src=intermediary', timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ace.host_production
    task_set = CategoryIntermediary
    min_wait = 1500
    max_wait = 2500


