from locust import HttpLocust, TaskSet, task
from modules import graphql, gw, tokopedia
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class KOLTopProfilesProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_APP, accounts=self.config["dexter"]["massive_accounts"])

    @task(1)
    def task1(self):
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']
                
        res = graphql.graphql_getWhitelistUserData(self, graphql.host_graphql, json={"operationName":"GetWhitelistUserData","variables":{"limit":10,"cursor":"MCwwLDAsMjA=","search":""}}, cb_threshold=cb_threshold, timeout=timeout_graphql, catch_response=True)
        if res.status_code == 200:
            try:
                response = res.json()
                if response.get('errors') or response['data']['get_whitelist_user']['error']:
                    res.failure(res.content)
                else:
                    res.success()
            except Exception:
                res.failure(res.content)
        else :
            try :
                res.raise_for_status()
            except Exception as e:
                res.failure(e)

        self.koldata = graphql.graphql_getDiscoveryKolData(self, graphql.host_graphql, json ={"operationName":"GetDiscoveryKolData","variables":{"idcategory":0,"limit":18,"cursor":"MTU2NzExNTgsMCwxLDA=","search":""}}, timeout=timeout_graphql, cb_threshold=cb_threshold, catch_response=True)
        res = self.koldata
        if res.status_code == 200:
            try:
                response = res.json()
                if response.get('errors') or response['data']['get_discovery_kol_data']['error']:
                    res.failure(res.content)
                else:
                    res.success()
            except Exception:
                res.failure(res.content)
        else :
            try :
                res.raise_for_status()
            except Exception as e:
                res.failure(e)


class WebsiteUser(HttpLocust):
    host = ""
    task_set = KOLTopProfilesProduction
    min_wait = 1500
    max_wait = 2500
