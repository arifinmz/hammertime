import json, random
from locust import HttpLocust, TaskSet, task
from modules import orderapp, scrooge, ws_v4, accounts, mojito, tome, graphql, cartapp
from tests.helper.account_helper import AccountHelper
from tests.modules.logistic_api.kero_gql_production import KeroGqlRates
from libs import user_conversion

ah = AccountHelper()
uc = user_conversion.UserConversion()


class ATCCheckout(TaskSet):

    def on_start(self):
        if not hasattr(ATCCheckout, 'config_loaded') :
            ATCCheckout.config = self.configuration['production']
            ATCCheckout.config_loaded = True
        self.account = ah.get_account(self, accounts=ATCCheckout.config["dexter"]["massive_accounts"], login_type=ah.LOGIN_TYPE_APP)

        """ on_start is called when a Locust start before any task is scheduled """
        ATCCheckout.kero = KeroGqlRates(self)
        ATCCheckout.kero.config = ATCCheckout.config

    @task(1)
    def task1(self):
        # atc
        device_id = ATCCheckout.config["device_id"]
        user_id = self.account["user_id"]
        product = random.choice(ATCCheckout.config["products"])
        product_id = product['id']
        shop_id = product['shop_id']
        try:
            address = self.account['address_list'][0]
        except Exception as e:
            print(user_id,e)
            return
        address_id = address['address_id']
        receiver_name = address['receiver_name']
        receiver_phone = self.account['phone']
        timeout = (ATCCheckout.config['timeout'][0], ATCCheckout.config['timeout'][1])
        timeout_get_parameter = (ATCCheckout.config['timeout_get_parameter'][0], ATCCheckout.config['timeout_get_parameter'][1])
        timeout_ATC = (ATCCheckout.config["stitch"]["timeout_ATC"][0], ATCCheckout.config["stitch"]["timeout_ATC"][1])
        cb_threshold = ATCCheckout.config["cb_threshold"]
        os_type = ATCCheckout.config["os_type"]
        test_failed = False

        bodies_reset = {
            'status': '1',
            'lang': 'id'
        }
        headers_reset = {
            'Tkpd-UserId': user_id,
            'content-type': 'application/x-www-form-urlencoded'
        }

        res = cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                            bodies=bodies_reset,
                            headers=headers_reset, cb_threshold=cb_threshold,
                            timeout=timeout_ATC)

        get_atc_form_bodies = {
            'product_id': product_id,
            'user_id': user_id,
            'device_id': device_id,
            'os_type': ATCCheckout.config["os_type"]
        }
        self.res_cart = ws_v4.txCart_get_add_to_cart_form_pl_v4(self, ws_v4.host_production, user_id, device_id, bodies=get_atc_form_bodies, timeout=timeout_ATC, catch_response=True, cb_threshold=cb_threshold)
        
        calculate_cart_bodies = {
            'product_id': product_id,
            'weight':'1',
            'shop_id': shop_id,
            'do': "calculate_product",
            'device_id':device_id,
            'postal_code':address["postal_code"],
            'os_type':os_type,
            'district_id':address["district"],
            'qty':1,
            'address_id':address["address_id"],
            'user_id':user_id,
        }
        res = ws_v4.txCart_calculate_cart_pl_v4(self, ws_v4.host_production, user_id, device_id, bodies=calculate_cart_bodies, timeout=timeout_ATC, cb_threshold=cb_threshold)

        ATCCheckout.kero.task1()

        bodies_txCart = {
            'address_id': address_id,
            'notes': '',
            'product_id': product_id,
            'quantity': '1',
            'receiver_name': receiver_name,
            'receiver_phone': receiver_phone,
            'shipping_id': '1',
            'shipping_product': '1',
            'user_id': user_id,
            'device_id': device_id,
            'os_type': os_type
        }
        res = orderapp.action_txCart_add_to_cart_v4(self, orderapp.host_production, user_id, device_id, bodies=bodies_txCart, timeout=timeout_ATC, cb_threshold=cb_threshold, catch_response=True)
        if not res == "":
            if res.status_code == 200:
                try:
                    if '"is_success":1' in res.content:
                        test_failed = False
                        res.success()
                    else:
                        if 'Maaf, Permohonan Anda tidak dapat diproses saat ini. Mohon dicoba kembali.' in res.content:
                            res.failure("Maaf, Permohonan Anda tidak dapat diproses saat ini. Mohon dicoba kembali.")
                        else:
                            print(product_id)
                            # print("headers : ", headers)
                            print("bodies calc : ", calculate_cart_bodies)
                            print("bodies : ", bodies_txCart)
                            res.failure(res.content)
                        test_failed = True
                except Exception as e:
                    res.failure(res.content)
                    print("bodies calc : ", calculate_cart_bodies)
                    print("bodies : ", bodies_txCart)
                    test_failed = True
            else:
                try:
                    res.raise_for_status()
                    print("bodies : ", bodies_txCart)
                except Exception as e:
                    res.failure(e)
                    print("bodies : ", bodies_txCart)
                    test_failed = True
        else:
            test_failed = True

        if not test_failed :
            #get cart details
            bodies_txPl = {
                'device_id': device_id,
                'user_id': user_id,
                'os_type': os_type
            }
            res = orderapp.tx_pl_v4(self, orderapp.host_production, user_id, device_id, bodies=bodies_txPl, timeout=timeout_ATC, cb_threshold=cb_threshold, catch_response=True)

            if not res == "":
                if res.status_code == 200:
                    if '"status":"OK"' in res.content:
                        res.success()
                    else:
                        res.failure("/v4/tx.pl status is not ok")
                else:
                    try:
                        res.raise_for_status()
                    except Exception as e:
                        res.failure(e)

            #toppay get parameter
            bodies_txToppayGetParameter = {
                'user_id': user_id,
                'gateway': '99',
                'device_id': device_id,
                'os_type': os_type,
                'voucher_code': ''
            }
            res = orderapp.action_tx_toppayGetParameter_pl_v4(self, orderapp.host_production, user_id, device_id, bodies=bodies_txToppayGetParameter, timeout=timeout_get_parameter, cb_threshold=cb_threshold, catch_response=True)
            # print("toppay : ", res.content)
            if not res == "" :
                if res.status_code == 200 :
                    try :
                        toppay_res_json = res.json()
                        if 'transaction_id' in res.content:
                            res.success()
                        else :
                            if 'Tidak ada keranjang belanja yang bisa diproses.' in toppay_res_json['message_error'][0]:
                                res.success()
                            else:
                                res.failure(res.content)
                            test_failed = True
                    except Exception as e :
                        res.failure(res.content)
                        test_failed = True
                else :
                    try:
                        res.raise_for_status()
                    except Exception as e:
                        res.failure(e)
                        test_failed = True
            else:
                test_failed = True

            if not test_failed :
                respon = res.json()
                transaction_id = respon['data']['parameter']['transaction_id']
                transaction_date = respon['data']['parameter']['transaction_date']
                user_defined_value = respon['data']['parameter']['user_defined_value']
                nid = respon['data']['parameter']['nid']
                pid = respon['data']['parameter']['pid']
                merchant_code = respon['data']['parameter']['merchant_code']
                profile_code = respon['data']['parameter']['profile_code']
                gateway_code = respon['data']['parameter']['gateway_code']
                amount = respon['data']['parameter']['amount']
                customer_email = respon['data']['parameter']['customer_email']
                signature = respon['data']['parameter']['signature']
                customer_name = respon['data']['parameter']['customer_name']
                msisdn = respon['data']['parameter']['customer_msisdn']
                currency = respon['data']['parameter']['currency']
                query = respon['data']['query_string']
                payment_metadata = query[query.find("payment_metadata") + 17:query.find("&pid")]
                items = respon['data']['parameter']['items']
                ids = orderapp.itemsList(items, 'id')
                prices = orderapp.itemsList(items, 'price')
                quantities = orderapp.itemsList(items, 'quantity')
                names = orderapp.itemsList(items, 'name')

                # payment
                bodies_v2Payment = {
                    'customer_id': user_id,
                    'customer_email': customer_email,
                    'customer_name': customer_name,
                    'transaction_id': transaction_id,
                    'transaction_date': transaction_date,
                    'amount': amount,
                    'gateway_code': gateway_code,
                    'currency': currency,
                    'signature': signature,
                    'items[id]': ids,
                    'items[price]': prices,
                    'items[quantity]': quantities,
                    'items[name]': names,
                    'nid': nid,
                    'pid': pid,
                    'user_defined_value': user_defined_value,
                    'merchant_code': merchant_code,
                    'profile_code': profile_code,
                    'language': 'id-ID',
                    'payment_metadata': payment_metadata,
                    'customer_msisdn': msisdn,

                }

                headers_v2Payment = {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }

                res = scrooge.payment_v2(self, scrooge.host_production, bodies=bodies_v2Payment, headers=headers_v2Payment, timeout=timeout, cb_threshold=cb_threshold, catch_response=True)

                if not res == "":
                    if res.status_code == 200:
                        try:
                            if 'Payment Failed' in res.content or len(str(res.content)) < 1:
                                test_failed = True
                                res.failure("Payment Failed or empty html returned")
                            else :
                                res.success()
                        except Exception as e:
                            res.failure(res.content)
                            test_failed = True
                    else:
                        try:
                            res.raise_for_status()
                        except Exception as e:
                            res.failure(e)
                            test_failed = True
                else :
                    test_failed = True

class WebsiteUser(HttpLocust):
    host = ""
    task_set = ATCCheckout
    min_wait = 600
    max_wait = 800