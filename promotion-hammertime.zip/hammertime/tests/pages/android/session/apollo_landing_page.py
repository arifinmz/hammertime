from locust import HttpLocust, TaskSet, task
from modules import ace
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class ApolloLandingPage(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_APP, accounts=self.config["dexter"]["massive_accounts"])

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]

        #ace
        apollo_landing_key = self.config["apollo_landing_page"]
        headers = {
            'Authorization': ah.get_token(self.account['user_id']),
        }
        res = ace.hoth_discovery_api_page_P(self, ace.host_production, apollo_landing_key,
                                            name=ace.host_production+"/hoth/discovery/api/page/"+apollo_landing_key,
                                            headers=headers, cb_threshold=cb_threshold, timeout=timeout)


class WebsiteUser(HttpLocust):
    host = ""
    task_set = ApolloLandingPage
    min_wait = 1500
    max_wait = 2500
