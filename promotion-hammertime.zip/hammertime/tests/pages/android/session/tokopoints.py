from locust import HttpLocust, TaskSet, task
from modules import graphql
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class Tokopoints(TaskSet):
    def on_start(self):
        self.config = self.configuration['production']
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BOTH)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        timeout_graphql = (self.config['timeout_graphql'][0], self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']
        headers = {
            'Authorization': ah.get_token(user_id)
        }

        res = graphql.graphql_hachikoMainQuery(self, graphql.host_graphql, headers={'cookie': ah.get_sid_cookie(user_id), 'origin':'https://m.tokopedia.com'}, json={"operationName":"HachikoMainQuery","variables":{"page":1,"page_size":15}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_updateCartCounterMutation(self, graphql.host_graphql, headers={'cookie': ah.get_sid_cookie(user_id)}, json={"operationName":"updateCartCounterMutation","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = graphql.host_graphql
    task_set = Tokopoints
    min_wait = 1500
    max_wait = 2500

