import random
import json
from locust import HttpLocust, TaskSet, task
from modules import tokopedia, ace
from libs import user_conversion
from tests.pages.android.session.home_production import HomeProduction
from tests.pages.android.session.product_detail_production import ProductDetailProduction
from tests.pages.android.session.atc_form_production import AtcFormProduction
from tests.pages.android.session.atc_production import AtcProduction
from tests.helper.account_helper import AccountHelper
from libs import user_conversion

ah = AccountHelper()
uc_pdp = user_conversion.UserConversion()
uc_atc = user_conversion.UserConversion()

class HomePDPATC(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]

        self.homeProduction = HomeProduction(self)
        self.homeProduction.config = self.config
        
        self.productDetailProduction = ProductDetailProduction(self)
        self.productDetailProduction.config = self.config
        
        self.atcFormProduction = AtcFormProduction(self)
        self.atcFormProduction.config = self.config

        self.atcProduction = AtcProduction(self)
        self.atcProduction.config = self.config

        global uc_atc, uc_pdp
        uc_pdp.max_threshold = self.config['dexter']['conversion_rate']['pdp']
        uc_atc.max_threshold = self.config['dexter']['conversion_rate']['atc']

        
    @task(1)
    def task1(self):
        account = ah.get_account(self, login_type=ah.LOGIN_TYPE_BOTH)
        test_failed = False

        # users accessing home
        self.homeProduction.account = account
        self.homeProduction.task1()

        try:
            json_info = self.homeProduction.res_info.json()
            if "error" in json_info :
                test_failed = True
        except Exception as e :
            test_failed = True

        if not test_failed : 

            # some travels to pdp after accessing home
            @uc_pdp.attempt(self.runners.user_count)
            def product_detail():
                self.productDetailProduction.account = account
                self.productDetailProduction.task1()
            product_detail()

            # some wanna checkout that products after seeing pdp page 
            detail_json = None
            try :
                detail_json = self.productDetailProduction.res_detail.json()
            except Exception as e :
                test_failed = True
                
            if detail_json["data"] is not None and not test_failed:
                @uc_atc.attempt(uc_pdp.converted_user)
                def atc():
                    self.atcFormProduction.account = account
                    self.atcFormProduction.task1()
                    try:
                        res = self.atcFormProduction.res_cart.json()
                        if not res["error_message"] :
                            self.atcProduction.account = account
                            self.atcProduction.task1()
                    except Exception as e:
                        pass 
                atc()


class WebsiteUser(HttpLocust):
    host = ""
    task_set = HomePDPATC
    min_wait = 1500
    max_wait = 2500