from locust import HttpLocust, TaskSet, task
from modules import graphql, gw, tokopedia
from tests.helper.account_helper import AccountHelper
from tests.pages.android.session.kol_top_profiles_production import KOLTopProfilesProduction
import random

ah = AccountHelper()

class KOLClickTopProfilesProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_BOTH, accounts=self.config["dexter"]["massive_accounts"])

        self.kolTopProfiles = KOLTopProfilesProduction(self)
        self.kolTopProfiles.config = self.config
        self.kolTopProfiles.account = self.account

    @task(1)
    def task1(self):
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = self.account['user_id']
        kol_user_id = None
        test_failed = False

        # opening top profiles page
        self.kolTopProfiles.task1()
        res = self.kolTopProfiles.koldata

        # getting kol user id, to click and follow
        try:
            json_kol = res.json()
            postKol = random.choice(json_kol["data"]["get_discovery_kol_data"]["postKol"])
            kol_user_id =  postKol["userId"]
        except Exception as e:
            test_failed = True
            pass

        if not test_failed:
            res = graphql.graphql_getProfileContent(self, graphql.host_graphql, json={"variables": {"userID": kol_user_id}}, cb_threshold=cb_threshold, timeout=timeout_graphql, catch_response=True)
            if res.status_code == 200:
                try:
                    response = res.json()
                    if response.get('errors') or response['data']['get_user_profile_data']['error']:
                        res.failure(res.content)
                        test_failed = True
                    else:
                        res.success()
                except Exception:
                    res.failure(res.content)
            else :
                try :
                    res.raise_for_status()
                    test_failed = True
                except Exception as e:
                    res.failure(e)
                    test_failed = True


            res = graphql.graphql_getUserKolPost(self, graphql.host_graphql, json={"variables": {"cursor": "","userID": kol_user_id,"limit": 5}}, cb_threshold=cb_threshold, timeout=timeout_graphql, catch_response=True)
            if res.status_code == 200:
                try:
                    response = res.json()
                    if response.get('errors') or response['data']['get_user_kol_post']['error']:
                        res.failure(res.content)
                        test_failed = True
                    else:
                        res.success()
                except Exception:
                    res.failure(res.content)
            else :
                try :
                    res.raise_for_status()
                    test_failed = True
                except Exception as e:
                    res.failure(e)
                    test_failed = True

            # follow and unfollow if not test_failed
            if not test_failed:
                # follow
                headers = {
                    'tkpd-userid':int(user_id),
                    'cookie':ah.get_sid_cookie(user_id)
                }
                res = graphql.graphql_followKol(self, graphql.host_graphql, json={"variables":{"action":1,"userID":kol_user_id}}, headers=headers, cb_threshold=cb_threshold, timeout=timeout_graphql, catch_response=True)
                if res.status_code == 200:
                    try:
                        response = res.json()
                        if response.get('errors') or response['data']['do_follow_kol']['error']:
                            res.failure(res.content)
                            test_failed = True
                        else:
                            res.success()
                    except Exception:
                        res.failure(res.content)
                else :
                    try :
                        res.raise_for_status()
                        test_failed = True
                    except Exception as e:
                        res.failure(e)
                        test_failed = True
                
                # unfollow
                res = graphql.graphql_followKol(self, graphql.host_graphql, json={"variables":{"action":0,"userID":kol_user_id}}, headers=headers, name = "unfollowKol", cb_threshold=cb_threshold, timeout=timeout_graphql, catch_response=True)
                if res.status_code == 200:
                    try:
                        response = res.json()
                        if response.get('errors') or response['data']['do_follow_kol']['error']:
                            res.failure(res.content)
                            test_failed = True
                        else:
                            res.success()
                    except Exception:
                        res.failure(res.content)
                else :
                    try :
                        res.raise_for_status()
                        test_failed = True
                    except Exception as e:
                        res.failure(e)
                        test_failed = True

class WebsiteUser(HttpLocust):
    host = ""
    task_set = KOLClickTopProfilesProduction
    min_wait = 1500
    max_wait = 2500
