import random
from locust import HttpLocust, TaskSet, task
from modules import cartapp, scrooge, orderapp
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()


class Checkout(TaskSet):

    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        if not hasattr(Checkout, 'config_loaded'):
            Checkout.test_config = self.configuration['production']
            Checkout.config_loaded = True
        self.account = ah.get_account(self, accounts=Checkout.test_config['dexter']['massive_accounts'],
                                      login_type=ah.LOGIN_TYPE_LITE)

    # User accessing home page with session from cookie
    @task(1)
    def task1(self):

        timeout = (Checkout.test_config['timeout'][0], Checkout.test_config['timeout'][1])
        cb_threshold = Checkout.test_config["cb_threshold"]
        test_failed = False
        user_id = self.account["user_id"]
        device_id = Checkout.test_config['device_id']
        password = self.account['password']
        product = random.choice(Checkout.test_config['products'])
        product_id = product['id']
        shop_id = product['shop_id']
        cookie = orderapp.find_between(ah.get_sid_cookie(user_id), '_SID_Tokopedia', ';')

        user_id = str(user_id)
        # attribute for reset cart
        bodies_reset = {
            'status': '1',
            'lang': 'id'
        }
        headers_reset = {
            'Tkpd-UserId': user_id,
            'content-type': 'application/x-www-form-urlencoded'
        }

        # atc
        headers = {
            'cookie': cookie,
            'Authorization': ah.get_token(user_id),
            'Tkpd-UserId': user_id,
            'X-Device': 'loadtest-stitch'
        }
        body_atc = {
            'params': '{"product_id":' + product_id + ', "quantity": 1, "shop_id":' + shop_id + ', "notes": ""}'
        }

        res = cartapp.add_product_cart_v2(self, cartapp.host_production, headers=headers, bodies=body_atc,
                                          cb_threshold=cb_threshold, timeout=timeout, catch_response=True)

        if res.status_code == 200:
            try:
                if '"success":1' in res.content:
                    test_failed = False
                    res.success()
                else:
                    if 'Maaf, Permohonan Anda tidak dapat diproses saat ini. Mohon dicoba kembali.' in res.content:
                        res.failure('Maaf, Permohonan Anda tidak dapat diproses saat ini. Mohon dicoba kembali.')
                    else:
                        res.failure("attribute success is not 1")
                    test_failed = True
            except Exception as e:
                test_failed = True
                res.failure(e)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        if not test_failed:
            try:
                respon = res.json()
                cart_id = respon['data']['data']['cart_id']

                # cartlist
                res = cartapp.cart_list_v2(self, cartapp.host_production, headers=headers, cb_threshold=cb_threshold,
                                           timeout=timeout, catch_response=True)
                if res.status_code == 200:
                    try:
                        if '"error_code":"200"' in res.content:
                            res.success()
                        else:
                            res.failure('status is not OK')
                    except Exception as e:
                        res.failure(e)
                else:
                    try:
                        res.raise_for_status()
                    except Exception as e:

                        res.failure(e)

                # update cart
                carts_param = '[{"cart_id": ' + str(cart_id) + ', "quantity":1, "notes": "update ya"}]'
                body_updateCart = {
                    "carts": carts_param
                }
                res = cartapp.update_cart_v2(self, cartapp.host_production, headers=headers, bodies=body_updateCart,
                                             cb_threshold=cb_threshold, timeout=timeout, catch_response=True)

                if res.status_code == 200:
                    try:
                        if '"status":true' and '"error_code":"200"' in res.content:
                            test_failed = False
                            res.success()
                        else:
                            test_failed = True
                            res.failure(e)
                    except Exception as e:
                        test_failed = True
                        res.failure(e)
                else:
                    try:
                        res.raise_for_status()
                    except Exception as e:
                        test_failed = True
                        res.failure(e)
            except Exception:
                test_failed = True

            if not test_failed:
                # shipment address form
                headers_shipmentAddressForm = {
                    'cookie': cookie,
                    'Tkpd-UserId': user_id,
                    'X-Device': 'loadtest-stitch'
                }
                res = cartapp.shipment_address_form_v2(self, cartapp.host_production,
                                                       headers=headers_shipmentAddressForm,
                                                       cb_threshold=cb_threshold, timeout=timeout, catch_response=True)

                if res.status_code == 200:
                    try:
                        if 'address_id' in res.content:
                            test_failed = False
                            res.success()
                        else:
                            test_failed = True
                            res.failure(e)
                    except Exception as e:
                        test_failed = True
                        res.failure(e)
                else:
                    try:
                        res.raise_for_status()
                    except Exception as e:
                        test_failed = True
                        res.failure(e)

                if not test_failed:
                    try:
                        respon = res.json()
                        address_id = respon['data']['group_address'][0]['user_address']['address_id']
                        shop_id = respon['data']['group_address'][0]['group_shop'][0]['shop']['shop_id']
                        shipping_id = respon['data']['group_address'][0]['group_shop'][0]['shop_shipments'][0][
                            'ship_id']  # jne
                        sp_id = \
                            respon['data']['group_address'][0]['group_shop'][0]['shop_shipments'][0]['ship_prods'][0][
                                'ship_prod_id']  # reguler
                        product_id = respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_id']
                        notes = respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_notes']
                        quantity = respon['data']['group_address'][0]['group_shop'][0]['products'][0][
                            'product_quantity']
                        promo_code = "MZAFREONGKIR"
                        carts_param = cartapp.check_promo_code_final_params(promo_code, address_id, shop_id,
                                                                            shipping_id, sp_id, product_id, notes,
                                                                            quantity)
                        # checkout
                        headers_checkout = {
                            "Tkpd-UserId": user_id,
                            "cookie": cookie,
                            'X-Device': 'loadtest-stitch'
                        }
                        body_checkout = {
                            "carts": carts_param
                        }
                        res = cartapp.checkout_v2(self, cartapp.host_production, headers=headers_checkout,
                                                  bodies=body_checkout, cb_threshold=cb_threshold, timeout=timeout,
                                                  catch_response=True)
                        if not res == "":
                            if res.status_code == 200:
                                try:
                                    if 'transaction_id' in res.content:
                                        test_failed = False
                                        res.success()
                                    else:
                                        if 'Tidak ada keranjang belanja yang bisa diproses.' in \
                                                res.json()['message_error'][0]:
                                            res.success()
                                        else:
                                            cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                                                               bodies=bodies_reset, headers=headers_reset,
                                                               cb_threshold=cb_threshold, timeout=timeout)
                                            res.failure(e)

                                        test_failed = True

                                except Exception as e:
                                    test_failed = True
                                    res.failure(e)
                            else:
                                try:
                                    res.raise_for_status()
                                except Exception as e:
                                    test_failed = True
                                    cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                                                       bodies=bodies_reset, headers=headers_reset,
                                                       cb_threshold=cb_threshold, timeout=timeout)
                                    res.failure(e)
                        else:
                            test_failed = True
                            cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                                               bodies=bodies_reset,
                                               headers=headers_reset, cb_threshold=cb_threshold,
                                               timeout=timeout)
                    except Exception:
                        test_failed = True
                        cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                                           bodies=bodies_reset,
                                           headers=headers_reset, cb_threshold=cb_threshold,
                                           timeout=timeout)

                    if not test_failed:
                        res = cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, user_id, device_id,
                                                 bodies=bodies_reset,
                                                 headers=headers_reset, cb_threshold=cb_threshold,
                                                 timeout=timeout)


class WebsiteUser(HttpLocust):
    host = cartapp.host_production
    task_set = Checkout
    min_wait = 1500
    max_wait = 2500