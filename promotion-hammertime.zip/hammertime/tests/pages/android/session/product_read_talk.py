from locust import HttpLocust, TaskSet, task
from modules import inbox, tome
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class ProductReadTalk(TaskSet):
    def on_start(self):
        self.config  = self.configuration['production']
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        user_id     = self.account['user_id']
        device_id   = self.config['device_id']
        product_id  = random.choice(self.config['dexter']['massive_products'])
        cookie      = ah.get_token(user_id)
        headers     = {
            'Authorization': cookie
        }
        cb_threshold = self.config['cb_threshold']
        timeout      = (self.config['timeout'][0], self.config['timeout'][1])
        test_failed = False

        product_detail = tome.webService_product_getSummary_v1(self, tome.host_production, query='product_id={0}'.format(product_id), hide_query=True)
        try:
            product_json = product_detail.json()
            shop_id      = str(product_json['data'][0]['shop_id'])
        except Exception as e:
            test_failed = True

        if not test_failed:
            res = inbox.talk_read_v2(self, inbox.host_production, device_id, user_id, headers=headers, query='product_id={0}&per_page=10&page=1&shop_domain={1}&user_id'.format(product_id, shop_id, user_id), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)


class WebsiteUser(HttpLocust): 
    host        = ""
    task_set    = ProductReadTalk
    min_wait    = 1500
    max_wait    = 2500