from locust import HttpLocust, TaskSet, task
from libs import bearer_token
from modules import pulsa_api, ws_v4, accounts
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class UserBehavior(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['pulsa']['accounts'], login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        user_id = self.account["user_id"]
        device_id = self.config["device_id"]
        os_type = self.config["os_type"]
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']

        # get category list
        res = pulsa_api.category_list_v1_4(self, pulsa_api.host_production, query='device_id=5',name="Android - /v1.4/category/list", timeout=timeout, cb_threshold=cb_threshold)
        
        # get category  pulsa
        res = pulsa_api.category_pulsa_v1_4(self, pulsa_api.host_production, query='device_id=5',name="Android - /v1.4/category/pulsa", timeout=timeout, cb_threshold=cb_threshold)
        
        # get banner
        res = pulsa_api.banner_v1_4(self, pulsa_api.host_production, query='device_id=5', name="Android - /v1.4/banner", timeout=timeout, cb_threshold=cb_threshold)
        
        # get operator list
        res = pulsa_api.operator_list_v1_4(self, pulsa_api.host_production, query='device_id=5', name="Android - /v1.4/operator/list", timeout=timeout, cb_threshold=cb_threshold)

        # get product list
        res = pulsa_api.product_list_v1_4(self, pulsa_api.host_production, query='device_id=5', name="Android - /v1.4/product/list", timeout=timeout, cb_threshold=cb_threshold)

        # favorite list
        query = 'os_type=%s&device_id=%s&user_id=%s' % (os_type, device_id, user_id)
        res = pulsa_api.favorite_list_v1_4(self, pulsa_api.host_production, user_id, query=query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        # status
        res = pulsa_api.status_v1_4(self, pulsa_api.host_production, query='device_id=5', timeout=timeout, cb_threshold=cb_threshold)
    
        
class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 1000
    max_wait = 2000
