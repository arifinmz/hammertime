from locust import HttpLocust, TaskSet, task
from modules import chat
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class GroupChatPolling(TaskSet):
    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_APP)

    @task
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        token = ah.get_token(self.account['user_id'])
        headers = {
            'Authorization' : token
        }
        index_list_channel = random.randint(0,len(self.config['chat_channel'])-1)
        poll_id = self.config['chat_channel'][index_list_channel]['poll_id']
        index_option_id = random.randint(0,len(self.config['chat_channel'][index_list_channel]['options'])-1)
        option_id = self.config['chat_channel'][index_list_channel]['options'][index_option_id]['option_id']
        bodies = {
            'option_id' : option_id
        }
        res = chat.gmf_api_poll_P_vote_v1(self, chat.host_production, poll_id, name=chat.host_production+"/gmf/api/v1/poll/{poll_id}/vote", headers=headers, bodies=bodies, cb_threshold=cb_threshold, timeout=timeout)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = GroupChatPolling
    min_wait = 3000
    max_wait = 5000
