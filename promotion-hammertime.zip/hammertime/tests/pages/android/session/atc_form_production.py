import random
import time
from locust import HttpLocust, TaskSet, task
from modules import tokopedia, ws_v4, kero, accounts, tome
from tests.helper.account_helper import AccountHelper
from libs import tkpdhmac

ah = AccountHelper()

class AtcFormProduction(TaskSet):
    
    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        device_id = self.config['device_id']
        timeout     = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        self.products = random.choice(self.config['products'])
        self.product_id = self.products["id"]
        self.address = random.choice(self.account['list_address'])
        self.shop_info = self.config["shop_info"]
        test_failed = False

        # tome
        res = tome.product_P_v2(self, tome.host_production, self.product_id, query='p_id='+self.product_id, name=tome.host_production+"/v2/product/{product_id}", cb_threshold=cb_threshold, timeout=timeout)
        try :
            product_json = res.json()
            weight = str(product_json["data"]["product_weight"])
            shop_id = str(product_json["data"]["product_shop"]["shop_id"])
            cat_id = str(product_json["data"]["product_category"]["category_id"])
            order_value = str(product_json["data"]["product_price"]["price_value"])
        except Exception as e :
            test_failed = True

        if not test_failed :
            # showing form to buy after pdp
            get_atc_form_bodies = {
                'product_id': self.product_id,
                'user_id': user_id,
                'device_id': device_id,
                'os_type': self.config["os_type"]
            }
            self.res_cart = ws_v4.txCart_get_add_to_cart_form_pl_v4(self, ws_v4.host_production, user_id, device_id, bodies=get_atc_form_bodies, timeout=timeout, catch_response=True, cb_threshold=cb_threshold)
            
            calculate_cart_bodies = {
                'product_id': self.product_id,
                'weight':weight,
                'shop_id': shop_id,
                'do': "calculate_product",
                'device_id':device_id,
                'postal_code':self.address["postal_code"],
                'os_type':self.config["os_type"],
                'district_id':self.address["district_id"],
                'qty':1,
                'address_id':self.address["address_id"],
                'user_id':user_id,
            }
            res = ws_v4.txCart_calculate_cart_pl_v4(self, ws_v4.host_production, user_id, device_id, bodies=calculate_cart_bodies, timeout=timeout, cb_threshold=cb_threshold)
            

            destination = self.address["district_id"]+"|"+self.address["postal_code"]+"|"+self.address["latitude"]+","+self.address["longitude"]
            origin = self.shop_info["district_id"]+"|"+self.shop_info["postal_code"]+"|"+self.shop_info["latitude"]+","+self.shop_info["longitude"]
            query = "destination="+destination+"&insurance=1&os_type="+self.config["os_type"]+"&origin="+origin+"&cat_id="+cat_id+"&from=client&weight="+weight+"&device_id="+device_id+"&product_insurance=0&names="+self.shop_info["names"]+"&order_value="+order_value+"&type=android&user_id="+user_id
            res = kero.rates_v1(self, kero.host_production, device_id, user_id, timeout=timeout, cb_threshold=cb_threshold, query=query, hide_query=True)

class WebsiteUser(HttpLocust):
    host = tokopedia.host_production
    task_set = AtcFormProduction
    min_wait = 1000
    max_wait = 1500
