from locust import HttpLocust, TaskSet, task
from modules import tokopedia, gw, chat, ace, topads, inbox, mojito
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class HotlistDetail(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        device_id       = self.config['device_id']
        user_id         = self.account['user_id']
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page    = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        cb_threshold    = self.config['cb_threshold']
        headers         = {
            'cookie':ah.get_sid_cookie(user_id)
        }
        platform        = 'desktop'
        hotlist         = random.choice(self.config['hotlist'])
        hotlist_id      = hotlist['filter_attribute']['hot_id']

        domain = '/hot/'+hotlist['alias_key']
        res = tokopedia.page(self, tokopedia.host_production, domain, headers=headers, name=tokopedia.host_production+'/hot/{alias_key}', timeout=timeout_page, cb_threshold=cb_threshold)

        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)

        # gw
        res = gw.sellerinfo_api_notification_v1(self, gw.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        
        # chat
        res = chat.tc_notifUnreads_v1(self, chat.host_production, user_id, device_id, headers={'cookie':ah.get_sid_cookie(user_id), 'origin': 'https://www.tokopedia.com'}, timeout=timeout, cb_threshold=cb_threshold)
        
        # ace
        sub_query = '&'.join(['%s=%s' % (key, value) for (key, value) in hotlist['filter_attribute'].items()])
        res = ace.dynamic_attributes_v2(self, ace.host_production, headers=headers, query='scheme=https&device={0}&{1}&page=1&user_id={2}&st=product'.format(platform, sub_query, user_id), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        res = ace.hoth_hotlist_v1(self, ace.host_production, headers=headers, query='scheme=https&device={0}&perPage=3&page=1&user_id={1}&hot_id={2}'.format(platform, user_id, hotlist_id), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        res = ace.hoth_hotlist_get_v1_1(self, ace.host_production, headers=headers, query='alias_key={0}&user_id={1}'.format(hotlist['alias_key'], user_id), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        
        search_query = 'st=product&full_domain=www.tokopedia.com&scheme=https&device={0}&start=0&rows=60&user_id={1}&{2}&hc={3}'.format(platform, user_id, sub_query, hotlist_id)
        res_search_product = ace.search_product_v3(self, ace.host_production, headers=headers, query=search_query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        try:
            product_data = res_search_product.json()
            product_data = product_data['data']['products']
            if product_data:
                product_ids = []
                for product in product_data:
                    product_ids.append(str(product['id']))

                pid = ','.join(product_ids)
                res = tokopedia.ajax_wishlist_pl(self, tokopedia.host_production, headers=headers, query='action=event_get_check_wishlist_key&p_id={0}'.format(pid), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
                # mojito
                res = mojito.users_P_wishlist_check_P_v2(self, mojito.host_production, user_id, device_id, pid, headers={'Content-Type':'application/json'}, name=mojito.host_production+'/v1/users/{user_id}}/wishlist/check/{product_ids}', timeout=timeout, cb_threshold=cb_threshold)
        except Exception as e:
            pass

        # topads
        topads_query = 'page=1&q={0}&h={1}&ep=product&item=10&src=hotlist&device={2}&user_id={3}'.format(hotlist['filter_attribute']['q'], hotlist_id, platform, user_id)
        if 'sc' in hotlist['filter_attribute']:
            topads_query = topads_query + '&dep_id=' + hotlist['filter_attribute']['sc']

        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query=topads_query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = HotlistDetail
    min_wait = 1500
    max_wait = 2500