from locust import HttpLocust, TaskSet, task
from modules import tokopedia, topads,  gold_merchant, accounts , gw, chat
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class ResolutionInbox(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['resolution']['accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        device_id = self.config['device_id']
        user_id = self.account['user_id']
        home_domain = '/resolution-center.pl?nref=resside'
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page    = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        cb_threshold    = self.config['cb_threshold']
        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }

        #homepage
        res = tokopedia.page(self, tokopedia.host_production, home_domain, headers=headers, cb_threshold=cb_threshold, timeout=timeout_page)

        # tokopedia ajax
        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)

        # wallet
        res = tokopedia.api_wallet_balance(self, tokopedia.host_production, cb_threshold=cb_threshold, headers=headers, timeout=timeout)

        # tokopoints
        res = gw.tokopoints_api_dv3points_drawer_v1(self, gw.host_production, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, cb_threshold=cb_threshold, timeout=timeout)
        res = gw.sellerinfo_api_notification_v1(self, gw.host_production, headers=headers, cb_threshold=cb_threshold, timeout=timeout)

        # chat
        res = chat.tc_notifUnreads_v1(self, chat.host_production, user_id, device_id, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, cb_threshold=cb_threshold, timeout=timeout)

        # accounts
        res = accounts.marketplace_pixel(self, accounts.host_production, headers=headers,  cb_threshold=cb_threshold, timeout=timeout)

        # resolution inbox
        res = tokopedia.resolution_inbox_buyer_v2(self, tokopedia.host_production, headers=headers, cb_threshold=cb_threshold, timeout=timeout)


        if 'shop_id' in self.account :
            shop_id = self.account['shop_id']
            res = tokopedia.microfinance_micro_mt_preapprove_P(self, tokopedia.host_production, shop_id, headers=headers, name=tokopedia.host_production+"/microfinance/micro/mt/preapprove/{shop_id}", cb_threshold=cb_threshold, timeout=timeout) 
            res = tokopedia.reputationapp_reputation_api_shop_P_v1(self, tokopedia.host_production, shop_id, headers=headers, name=tokopedia.host_production+"/reputationapp/reputation/api/v1/shop/{shop_id}", cb_threshold=cb_threshold, timeout=timeout)            
            res = gold_merchant.shopstats_shopscore_sum_P_v1(self, gold_merchant.host_production, device_id, user_id, shop_id, headers=headers, name=gold_merchant.host_production+"/v1/shopstats/shopscore/sum/{shop_id}", cb_threshold=cb_threshold, timeout=timeout)
            query = "shop_id=%s&shop_data=1" % (shop_id)
            res = topads.dashboard_deposit_v1_1(self, topads.host_production, user_id, headers=headers, query=query, name=topads.host_production+"/v1.1/dashboard/deposit?shop_id={shop_id}&shop_data=1", cb_threshold=cb_threshold, timeout=timeout)
            res = topads.dashboard_hmac_v1(self, topads.host_production, headers=headers,  query='device=%27desktop%27&method=GET&url=%2Fv1.1%2Fdashboard%2Fdeposit&content=shop_id%3D'+shop_id+'%26shop_data%3D1', name=topads.host_production+"/v1/dashboard/hmac", cb_threshold=cb_threshold, timeout=timeout)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = ResolutionInbox
    min_wait = 1500
    max_wait = 2500
