from locust import HttpLocust, TaskSet, task
from modules import tokopedia, topads,  gold_merchant, accounts , gw, chat
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class TopChat(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['topchat']['accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        device_id = self.config['device_id']
        user_id = self.account['user_id']
        home_domain = '/inbox-chat-new.pl'
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page    = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        cb_threshold    = self.config['cb_threshold']
        headers = {
            'cookie':ah.get_sid_cookie(user_id),
            'origin': 'https://www.tokopedia.com'
        }

        #homepage
        res = tokopedia.page(self, tokopedia.host_production, home_domain, headers=headers, cb_threshold=cb_threshold, timeout=timeout_page)

        # tokopedia ajax
        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)

        # wallet
        res = tokopedia.api_wallet_balance(self, tokopedia.host_production, cb_threshold=cb_threshold, headers=headers, timeout=timeout)

        # tokopoints
        res = gw.tokopoints_api_dv3points_drawer_v1(self, gw.host_production, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, cb_threshold=cb_threshold, timeout=timeout)
        res = gw.sellerinfo_api_notification_v1(self, gw.host_production, headers=headers, cb_threshold=cb_threshold, timeout=timeout)

        # chat
        res = chat.tc_notifUnreads_v1(self, chat.host_production, user_id, device_id, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, cb_threshold=cb_threshold, timeout=timeout)

        # accounts
        res = accounts.marketplace_pixel(self, accounts.host_production, headers=headers,  cb_threshold=cb_threshold, timeout=timeout)

        # topchat
        res = chat.tc_templates_v1(self, chat.host_production, headers=headers, name=chat.host_production+"/tc/v1/templates", cb_threshold=cb_threshold, timeout=timeout)
        res = chat.tc_list_message_v1(self, chat.host_production, user_id, device_id, headers=headers, 
            name=chat.host_production+"/tc/v1/list_message", 
            query="tab=inbox&filter=all&page=1&per_page=10&platform=desktop",
            cb_threshold=cb_threshold, timeout=timeout)

        # there are supposed to be seller APIs in this page, but we agreed to remove them, since 
        # a) topchat accounts are not configured as seller
        # b) seller APIs have been tested in other places

class WebsiteUser(HttpLocust):
    host = ""
    task_set = TopChat
    min_wait = 1500
    max_wait = 2500
