from locust import HttpLocust, TaskSet, task
from modules import tokopedia, mojito, graphql
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class FlashSaleWidget(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']

        headers = {
            'x-device':'desktop-0.0'
        }
        res = mojito.api_channel_v1(self, mojito.host_production, headers=headers,timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = FlashSaleWidget
    min_wait = 1500
    max_wait = 2500