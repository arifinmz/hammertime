from locust import HttpLocust, TaskSet, task
from modules import tokopedia,  chat
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class ExclusivePage(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        home_domain = '/discovery/'
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page    = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        cb_threshold    = self.config['cb_threshold']
        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }

        #random page
        exclusive_page = self.config["discovery"]["exclusive_page_list"][random.randint(0, 
            len(self.config["discovery"]["exclusive_page_list"])-1)]
        #homepage
        res = tokopedia.page(self, tokopedia.host_production, home_domain+exclusive_page, 
            name=tokopedia.host_production+home_domain+"{exclusive-page}",
            headers=headers, cb_threshold=cb_threshold, timeout=timeout_page)

        # tokopedia ajax
        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)

        # chat
        res = chat.tc_notifUnreads_v1(self, chat.host_production, "", "", headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, cb_threshold=cb_threshold, timeout=timeout)


class WebsiteUser(HttpLocust):
    host = ""
    task_set = ExclusivePage
    min_wait = 1500
    max_wait = 2500
