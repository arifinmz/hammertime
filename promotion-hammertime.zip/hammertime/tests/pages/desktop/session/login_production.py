from locust import HttpLocust, TaskSet, task
from modules import mojito, accounts
import random


class LoginProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']

        self.user=random.choice(self.config['dexter']['massive_accounts'])
        headers = {
            'cookie':""
        }
        query="client_id=1001&p=https%3A%2F%2Fwww.tokopedia.com%2F&redirect_uri=https%3A%2F%2Fwww.tokopedia.com%2Fappauth%2Fcode&response_type=code&state=eyJyZWYiOiJodHRwczovL3d3dy50b2tvcGVkaWEuY29tLyIsInV1aWQiOiI0NDdkYzFjZC0yNmI4LTQ5YjktOTJkYS01ZjZiMDZmNmE3OTEiLCJ0aGVtZSI6ImlmcmFtZSIsInAiOiJodHRwczovL3d3dy50b2tvcGVkaWEuY29tLyJ9&theme=iframe"
        res_auth_get = accounts.authorize(self, accounts.host_production, headers=headers, query=query, timeout=timeout, cb_threshold=cb_threshold)
        query="user_id=0&page[size]=50&filter[device]=desktop&action=data_source_ticker"
        res=mojito.api_tickers_v1(self, mojito.host_production, query=query, timeout=timeout, cb_threshold=cb_threshold)
        
        if 'Set-Cookie' in res_auth_get.headers :
            bodies = {
                    'theme':'default',
                    'email': self.user['email'],
                    'password': self.user['password'],
                    'remember_me':'on'
                    }
            query="client_id=1001&p=https%3A%2F%2Fwww.tokopedia.com&redirect_uri=https%3A%2F%2Fwww.tokopedia.com%2Fappauth%2Fcode&response_type=code&state=eyJyZWYiOiJodHRwczovL3d3dy50b2tvcGVkaWEuY29tIiwidXVpZCI6ImE4YjY1MDQ1LTgwOTEtNGVkZS1iODgzLWYwZTAwNmVlZGZmNCJ9"         
            res = accounts.authorize(self, accounts.host_production, method='POST', bodies=bodies, query=query, catch_response=True, cb_threshold=cb_threshold)
            if self.user['user_id'] in res.content:
                res.success()
            else:
                print(self.user['email'], res.content)
                res.failure("user id not found in the response")            

        

class WebsiteUser(HttpLocust):
    host = ""
    task_set = LoginProduction
    min_wait = 1500
    max_wait = 2500
