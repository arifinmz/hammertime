from locust import HttpLocust, TaskSet, task
from modules import tokopedia, cartapp, scrooge
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()


class MyshopOrderProcess(TaskSet):
    def on_start(self):
        if not hasattr(MyshopOrderProcess, 'config_loaded'):
            MyshopOrderProcess.test_config = self.configuration['production']
            MyshopOrderProcess.config_loaded = True

        self.account = ah.get_account(self, accounts=MyshopOrderProcess.test_config["stitch"]["seller_loadtest"], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):

        user_id = self.account['user_id']
        timeout = (MyshopOrderProcess.test_config['timeout'][0], MyshopOrderProcess.test_config['timeout'][1])
        cb_threshold = MyshopOrderProcess.test_config['cb_threshold']
        cookie = ah.get_sid_cookie(user_id)

        headers = {
            'cookie': cookie
        }

        title, response = tokopedia.title(self, tokopedia.host_production, '/myshop_order_process', headers=headers, timeout=timeout,
                              cb_threshold=cb_threshold, catch_response=True)

        if response.status_code == 200:
            try:
                if 'Konfirmasi Pengiriman' in title:
                    response.success()
                else:
                    response.failure("Akun Belum Login")
            except Exception as e:
                response.failure(e)
        else:
            try:
                response.raise_for_status()
            except Exception as e:
                response.failure(e)


class WebsiteUser(HttpLocust):
    host = ""
    task_set = MyshopOrderProcess
    min_wait = 1500
    max_wait = 2500