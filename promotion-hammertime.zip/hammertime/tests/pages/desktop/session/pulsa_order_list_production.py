from locust import HttpLocust, TaskSet, task
from modules import pulsa, tokopedia
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class UserBehavior(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config["pulsa"]["accounts_order_list"], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        cb_threshold = self.config["cb_threshold"]
        domain = '/order-list/'
        headers = {
          'cookie':ah.get_sid_cookie(self.account['user_id'])
        }
        res = tokopedia.page(self, pulsa.host_production , domain, timeout=timeout_page, headers=headers, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 1000
    max_wait = 2000
