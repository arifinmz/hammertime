from locust import HttpLocust, TaskSet, task
from modules import tokopedia, topads, mojito, ace, chat, gw
from tests.helper.account_helper import AccountHelper
from libs import randex
import random

ah = AccountHelper()

class SearchProductProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        keyword = randex.generate_word(2,20)
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        cb_threshold = self.config['cb_threshold']
        search_domain = '/search?st=product&q={0}'.format(keyword)
        platform = 'desktop'
        device_id = self.config['device_id']

        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }

        res = tokopedia.page(self, tokopedia.host_production, search_domain, headers=headers, name=tokopedia.host_production+"/search", timeout=timeout_page, cb_threshold=cb_threshold)
        
        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        
        res = ace.dynamic_attributes_v2(self, ace.host_production, headers=headers, query='scheme=https&device={0}&page=1&ob=23&st=product&user_id={1}&source=search&q={2}'.format(platform, user_id, keyword), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        res = ace.guide_v1(self, ace.host_production, headers=headers, query='q={0}&user_id={1}&page=1&ob=23&st=product&source=universe'.format(keyword, user_id), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        res_product = ace.search_product_v3(self, ace.host_production, headers=headers, query='scheme=https&device={0}&catalog_rows=5&source=search&ob=23&st=product&user_id={1}&rows=60&q={2}'.format(platform, user_id, keyword), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        try :
            ace_data = res_product.json()
            products = ace_data['data']['products']
            if len(products) > 1:
                product_ids = []
                for product in products:
                    product_ids.append(str(product['id']))
                
                pid = ','.join(product_ids)

                res = mojito.users_P_wishlist_check_P_v2(self, mojito.host_production, user_id, device_id, product_ids, headers=headers, name=mojito.host_production+"/users/{user_id}/wishlist/check/{product_ids}/v2", timeout=timeout, cb_threshold=cb_threshold)
                res = tokopedia.ajax_wishlist_pl(self, tokopedia.host_production, headers=headers, query='p_id={0}&action=event_get_check_wishlist_key'.format(product_ids), name=tokopedia.host_production+'/ajax/wishlist.pl?action=event_get_check_wishlist_key', timeout=timeout, cb_threshold=cb_threshold)
        except Exception as e:
            print(e)

        res = gw.sellerinfo_api_notification_v1(self, gw.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        res = chat.tc_notifUnreads_v1(self, chat.host_production, headers={'cookie': ah.get_sid_cookie(user_id), 'origin': 'https://www.tokopedia.com'}, timeout=timeout, cb_threshold=cb_threshold)

        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, name=topads.host_production+"/promo/v1.1/display/ads?src=search&ep=cpm", query="user_id={0}&ep=cpm&item=1&src=search&device={1}&template_id=2%2C3&page=1&q={2}".format(user_id, platform, keyword), timeout=timeout, cb_threshold=cb_threshold)
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, name=topads.host_production+"/promo/v1.1/display/ads?src=search&ep=product", query="user_id={0}&ep=product&item=10&src=search&device={1}&page=1&q={2}".format(user_id, platform, keyword), timeout=timeout, cb_threshold=cb_threshold)
        viewport = 'H_tp6sJRH_jf6Ard6sJEH_tho_U7HAH7HArF6MusrprXPcY0QRCBgcBxbMNBPmY2Q3r5yfVsqc15HsnFb9ohP3VagZYFrMYjP3o7b_J5Hsnh6m47bpJabpJ7HsnNHAKNbpJ7HsnNHAKN9pJR63-sy_j7b_JF6cUWoAefoa7doABsb_xsHcHfHszig_Bxgu4hHAnF9pJFHAnXqSCS6staHpjpH_rd6snXHA1FoAyO6MuNZM2jZJ2M33NGPMep_Mh-qMY2_1o-r7BW_sCsQABE3BPc8ujagfBvq1Bd_c2CH7N1Z_-vzcPd_S2-P7NJ_9PouJB2_JoGrB2yQAoiH7203Ao6qMUpZMh-qMY2_1H7H1Nkz_CouJ1O_S208jO11_uouco2_JoGP3Uao32q17jfZ32SPO21eMWgQuJh_VzcQu2919z6zJJh3MjFouBWZMBHuOJh3BPGQJOkZMOg8jud_7o-r7BW69BxufzFyMFNPfoW63Wju7dF3A-Dq7BkQfBoe7BpZ37N83V9gICiQABEy1rNPOKaQcW-qMY2_1o-r7BX_M2iH72D3A-G83UpgI2q17jfZ32VP1Ok3_-6qMDa_M2o8jNJ39B6zJj7_uo-r7BX_M2iH72D3Ao6QVByZM2xe7jfZ32VP1Nkz9PouJ17_92-81Y1__u6ucHp_BoG6e'
        res = topads.promo_views_P_v1(self, topads.host_production, viewport, query='src=search&page=1&uid={0}&keywords={1}&number_of_ads=10&number_ads_req=10&t={2}&ab_test=exp_new_score&is_search=1&alg=stm&post_alg=cpc_shop_unq&n_candidate_ads=502&render=false'.format(user_id, keyword, platform), name=topads.host_production+'/promo/v1/views/{viewport}', timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = SearchProductProduction
    min_wait = 1500
    max_wait = 2500
