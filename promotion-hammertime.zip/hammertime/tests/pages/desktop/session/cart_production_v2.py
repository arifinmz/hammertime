from locust import HttpLocust, TaskSet, task
from modules import tokopedia, cartapp
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class Cart(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_BROWSER)
        self.user_id = self.account['user_id']
        self.device_id = self.config['device_id']
        self.timeout = (self.config['timeout'][0], self.config['timeout'][1])
        self.cb_threshold = self.config['cb_threshold']
        self.cookie = ah.get_sid_cookie(self.user_id)

    @task(20)
    def task1(self):
        timeout_page = (self.config['timeout_page'][0], self.config['timeout'][1])
        test_failed = False
        
        product = random.choice(self.config['products'])
        product_id = product['id']
        shop_id = product['shop_id']

        bodies_add_cart = {
            'params': '{"product_id":' + product_id + ', "quantity": 1, "shop_id":' + shop_id + ', "notes": ""}'
        }
        headers_add_cart = {
            'tkpd-userid':self.user_id,
            'cookie':self.cookie,
            'content-type':'application/x-www-form-urlencoded',
            'authority':'www.tokopedia.com'
        }
        res = tokopedia.cart_add_product_cart(self, tokopedia.host_production, headers=headers_add_cart, bodies=bodies_add_cart, timeout=self.timeout, cb_threshold=self.cb_threshold, catch_response=True)

        if res.status_code == 200 :
            try :
                data = res.json()
                if data['data']['success'] == 1 :
                    res.success()
                    test_failed = False
                else :
                    res.failure(data['data']['message'])
                    test_failed = True
                    print(res.content)
            except Exception as e :
                test_failed = True
                res.failure(e)
                print(res.content)
        else :
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)
                print(res.content)

        if not test_failed :
            headers_page = {
                'cookie': self.cookie
            }
            res = tokopedia.page(self, tokopedia.host_production, '/cart', headers=headers_page, timeout=timeout_page, cb_threshold=self.cb_threshold)
            
        
    @task(1)
    def task2(self):
        bodies_reset_cart = {
            'status': '1',
            'lang': 'id'
        }
        headers_reset_cart = {
            'Tkpd-UserId': self.user_id,
            'content-type': 'application/x-www-form-urlencoded',
            'cookie': self.cookie
        }
        cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, self.user_id, self.device_id, bodies=bodies_reset_cart, headers=headers_reset_cart, cb_threshold=self.cb_threshold, timeout=self.timeout)


class WebsiteUser(HttpLocust):
    host = ""
    task_set = Cart
    min_wait = 1500
    max_wait = 2500