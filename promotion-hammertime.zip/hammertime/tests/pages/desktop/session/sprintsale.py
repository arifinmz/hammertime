from locust import HttpLocust, TaskSet, task
from modules import tokopedia, chat, ace
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class SprintSale(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        home_domain = '/discovery/flash-sale'
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page    = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        cb_threshold    = self.config['cb_threshold']
        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }
        campaign = self.config["sprint_sale_campaign"]

        #homepage
        res = tokopedia.page(self, tokopedia.host_production, home_domain, headers=headers, cb_threshold=cb_threshold, timeout=timeout_page)

        # tokopedia ajax
        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)

        # chat
        res = chat.tc_notifUnreads_v1(self, chat.host_production, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, cb_threshold=cb_threshold, timeout=timeout)

        # ace
        # campaign id for flash-sale is always fixed 62532 (confirmed by stephanus tedy)
        # paging is random, at least one page, max 4 pages sequentially
        pageList = ['2', '3', '4', '5'] 
        for index in range (0, random.randint(0, len(pageList)) ):
            res = ace.hoth_discovery_render_component_flashsale_P(self, ace.host_production, "desktop", campaign,
                query='rpc_Page='+pageList[index]+'&rpc_ResultPerPage=20', cb_threshold=cb_threshold, timeout=timeout,
                name=ace.host_production+'/hoth/discovery/render/component/desktop/flash-sale')
            


class WebsiteUser(HttpLocust):
    host = ""
    task_set = SprintSale
    min_wait = 1500
    max_wait = 2500
