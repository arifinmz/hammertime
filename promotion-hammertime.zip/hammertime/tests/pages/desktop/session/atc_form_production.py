from locust import HttpLocust, TaskSet, task
from modules import tokopedia
from tests.helper.account_helper import AccountHelper
import random
import time
from bs4 import BeautifulSoup

ah = AccountHelper()

class UserBehavior(TaskSet):

    def get_value_from_selector(self, htmlcontent, attribute_selector, attribute_name):
      soup = BeautifulSoup(htmlcontent, "html.parser")
      result = soup.find(attrs={attribute_selector: attribute_name})
      return str(result.get('value'))

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        headers     = {
            'cookie': ah.get_sid_cookie(self.account['user_id']),
            'referer':'https://www.tokopedia.com/shunshop/cooling-pad-xcool-f2?nref=cart'
        }
        cb_threshold = self.config['cb_threshold']
        product_id = str(random.choice(self.config['dexter']['massive_products']))
        tx_status = True

        query = "action=show_dialog_add_to_cart&p_id=%s&v=%s" % (product_id,int(round(time.time())))
        res = tokopedia.ajax_tx_cart_pl(self, tokopedia.host_production, name=tokopedia.host_production+"/ajax/tx/cart.pl?action=show_dialog_add_to_cart", headers=headers, query=query, cb_threshold=cb_threshold)
        try :
          address_id = self.get_value_from_selector(res.content, "name", "address")
        except Exception as er:
          tx_status = False
        
        if tx_status :
          bodies = {
            "min_order":1,
            "notes":"",
            "address_name":"",
            "receiver_name":"",
            "receiver_phone":"",
            "postal_code":"",
            "province":"",
            "city":"",
            "district":"",
            "address_street":"",
            "input_address":"",
            "shipping_agency":"",
            "shipping_product":"",
            "insurance":0,
            "address":int(address_id),
            "do":"calculate_shipping",
            "action":"event_dialog_calculate",
            "product_id":int(product_id)
          }
          res = tokopedia.ajax_tx_cart_pl(self, tokopedia.host_production, method="POST", headers=headers, bodies=bodies, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 1500
    max_wait = 2500
