from locust import HttpLocust, TaskSet, task
from modules import tokopedia, tome, gold_merchant, ace, slicer, gw, chat, mojito, accounts, js, graphql
from tests.helper.account_helper import AccountHelper
import random
import datetime

ah = AccountHelper()

class OsProduction(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_BOTH)

    @task(1)
    def task1(self):
        shop = random.choice(self.config['merchant']['os'])
        shop_id = str(shop['id'])   
        shop_domain = shop['shop_domain']
        user_id = self.account['user_id']

        #date calculations
        now = datetime.datetime.now()
        calcmonth = now - datetime.timedelta(days=30)
        pastmonth = str(calcmonth.strftime('%Y%m%d'))

        calc3months = now - datetime.timedelta(days=90)
        past3months = str(calc3months.strftime('%Y%m%d'))

        calc1year  = now - datetime.timedelta(days=365)
        past1year  = str(calc1year.strftime('%Y%m%d'))

        device_id   = self.config['device_id']
        os_type     = self.config['os_type']
        timeout     = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_graphql     = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        headers     = {
            'cookie': ah.get_sid_cookie(self.account['user_id'])
        }
        cb_threshold = self.config['cb_threshold']

        #shop page
        res = tokopedia.page(self, tokopedia.host_production, "/"+shop_domain, name=tokopedia.host_production+"/{shop_domain}", headers=headers, timeout=timeout_page, cb_threshold=cb_threshold)

        # accounts
        res = accounts.marketplace_pixel(self, accounts.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        # js
        res = js.js_shoplogin(self, js.host_production, headers=headers, query='id={0}&callback=show_last_online'.format(shop_id), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        #gw
        res = gw.sellerinfo_api_notification_v1(self, gw.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        #chat
        res = chat.tc_notifUnreads_v1(self, chat.host_production, headers=headers, name=chat.host_production+"/tc/v1/notif_unreads", timeout=timeout, cb_threshold=cb_threshold)

        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_nav_deposit_pl(self,tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        bodies={
            'action': 'get_shop_tx_stats',
            'shop_id': shop_id
        }
        res = tokopedia.ajax_shop_shopCharts_pl(self, tokopedia.host_production, bodies=bodies, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        
        #tome
        res = tome.shop_P_showcase_v2(self, tome.host_production, shop_id, headers=headers, name=tome.host_production+"/v2/shop/{shop_id}/showcase", timeout=timeout, cb_threshold=cb_threshold)
        query = "shop_id="+shop_id
        res = tome.shop_shopNote_v1(self,tome.host_production, query=query, timeout=timeout, cb_threshold=cb_threshold, hide_query=True)

        #ace
        query="shop_id="+shop_id+"&ob=10&rows=80&start=0&full_domain=www.tokopedia.com&scheme=https&device=desktop&source=shop_product" 
        res = ace.search_product_v2_6(self, ace.host_production, query=query, headers=headers, name=ace.host_production+"/search/v2.6/product", timeout=timeout, cb_threshold=cb_threshold)
        try :
            ace_data = res.json()
            products = ace_data['data']
            if len(products) > 1:
                product_ids = []
                for product in products:
                    product_ids.append(str(product['id']))
                
                pid = ','.join(product_ids)

                #mojito 
                res = mojito.users_P_wishlist_check_P_v2(self, mojito.host_production, user_id, device_id, pid, headers=headers, name=mojito.host_production+"/users/{user_id}/wishlist/check/{product_ids}/v2", cb_threshold=cb_threshold)
                # ajax
                query="action=event_get_check_wishlist_key&p_id="+pid
                res = tokopedia.ajax_wishlist_pl(self, tokopedia.host_production, query=query, timeout=timeout, headers=headers, name=tokopedia.host_production+"/ajax/wishlist.pl", cb_threshold=cb_threshold)
        except Exception as e:
            print(e)

        #slicer
        res = slicer.shopSpeed_cube_shopSpeedDaily_aggregate(self, slicer.host_production, device_id, user_id, query="cut=shop_id:"+shop_id+"|finish_date:"+pastmonth+"-",name=slicer.host_production+"/shop-speed/cube/shop_speed_daily/aggregate/{pastmonth}", timeout=timeout, cb_threshold=cb_threshold)
        res = slicer.shopSpeed_cube_shopSpeedDaily_aggregate(self, slicer.host_production, device_id, user_id, query="cut=shop_id:"+shop_id+"|finish_date:"+past3months+"-",name=slicer.host_production+"/shop-speed/cube/shop_speed_daily/aggregate/{past3months}", timeout=timeout, cb_threshold=cb_threshold)
        res = slicer.shopSpeed_cube_shopSpeedDaily_aggregate(self, slicer.host_production, device_id, user_id, query="cut=shop_id:"+shop_id+"|finish_date:"+past1year+"-",name=slicer.host_production+"/shop-speed/cube/shop_speed_daily/aggregate/{past1year}", timeout=timeout, cb_threshold=cb_threshold)

        #graphql
        res = graphql.graphql_notifcenterUnread(self, graphql.host_graphql, headers=headers, timeout=timeout_graphql, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = OsProduction
    min_wait = 3000
    max_wait = 5000
