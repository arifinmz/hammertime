from locust import HttpLocust, TaskSet, task
from modules import tokopedia, hades, gw, chat, topads, mojito
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class CategoryNonIntermediary(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        device_id = self.config["device_id"]
        category_id = random.choice(self.config['category']['category_id']['all_category'])
        platform = 'desktop'
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        product_ids = str(random.sample(self.config['dexter']['massive_products'], 15))

        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }

        #Hades
        res = hades.categories_P_features_v2(self, hades.host_production, category_id, name=hades.host_production+"/v2/categories/{category_id}/features", query='total_curated=5', timeout=timeout, cb_threshold=cb_threshold)
        #Topads Lifestyle
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query='user_id='+user_id+'&ep=product&item=8&src=directory&device='+platform+'&dep_id='+category_id+'&fshop=1', name=topads.host_production+'/promo/v1.1/display/ads?ep=product', timeout=timeout, cb_threshold=cb_threshold)
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query='item=3&user_id='+user_id+'&ep=shop&src=directory&device='+platform+'&dep_id='+category_id, name=topads.host_production+'/promo/v1.1/display/ads?ep=shop', timeout=timeout, cb_threshold=cb_threshold)
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query='user_id='+user_id+'&ep=cpm&item=1&src=directory&device='+platform+'&template_id=2,3&dep_id='+category_id, name=topads.host_production+'/promo/v1.1/display/ads?ep=cpm', timeout=timeout, cb_threshold=cb_threshold)

        #Ajax Notification
        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production,  headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        #Ajax Check Quick Guide
        res = tokopedia.ajax_check_quick_guide_pl(self, tokopedia.host_production, headers=headers, query='type=guide_search_prosecure', timeout=timeout, cb_threshold=cb_threshold)
        #Ajax Nav Deposit
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        #Ajax Prosecure
        res = tokopedia.ajax_prosecure_pl(self, tokopedia.host_production, headers=headers, query='action=shop_list', timeout=timeout, cb_threshold=cb_threshold)
        #Sellerinfo API Notification
        res = gw.sellerinfo_api_notification_v1(self, gw.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        #Chat
        res = chat.tc_notifUnreads_v1(self, chat.host_production, name=chat.host_production+"/tc/v1/notif_unreads", headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        #Ajax Wishlist
        res = tokopedia.ajax_wishlist_pl(self, tokopedia.host_production, headers=headers, query='p_id='+product_ids+'&action=event_get_check_wishlist_key', cb_threshold=cb_threshold, timeout=timeout, hide_query=True)
        #Mojito Wiishlist
        res = mojito.users_P_wishlist_check_P_v2(self, mojito.host_production, user_id, device_id, product_ids, headers=headers, name=mojito.host_production+"/users/{user_id}/wishlist/check/{product_ids}/v2", timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = tokopedia.host_production
    task_set = CategoryNonIntermediary
    min_wait = 1500
    max_wait = 2500


