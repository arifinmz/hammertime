from locust import HttpLocust, TaskSet, task
from modules import tokopedia, topads, pulsa, pulsa_api, gold_merchant, ace, mojito, accounts, tokocash, ace, graphql, gw, chat
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class HotlistTabProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        device_id = self.config['device_id']
        user_id = self.account['user_id']
        hotlist_path = '/hotlist?nref=htab'
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page    = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        cb_threshold    = self.config['cb_threshold']
        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }

        #homepage
        res = tokopedia.page(self, tokopedia.host_production, hotlist_path, headers=headers, cb_threshold=cb_threshold, timeout=timeout_page)
        
        #ace
        res = ace.hoth_hotlist_v1(self, ace.host_production, headers=headers, query="nref=htab&page=1&perPage=15&device=desktop&source=feed&user_id="+user_id, cb_threshold=cb_threshold, timeout=timeout, hide_query=True)

        # tokopedia ajax
        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)

        # mojito
        res = mojito.api_slides_v1(self, mojito.host_production, headers=headers, query='page[size]=25&filter[device]=1&filter[state]=1&filter[expired]=0', cb_threshold=cb_threshold, timeout=timeout)
        res = mojito.api_tickers_v1(self, mojito.host_production, headers=headers, query='user_id=%s&page[size]=50&filter[device]=desktop&action=data_source_ticker' % (user_id), name=mojito.host_production+"/api/v1/tickers", cb_threshold=cb_threshold, timeout=timeout)

        # wallet
        res = tokopedia.api_wallet_balance(self, tokopedia.host_production, cb_threshold=cb_threshold, headers=headers, timeout=timeout)

        # accounts
        res = accounts.marketplace_pixel(self, accounts.host_production, headers=headers,  cb_threshold=cb_threshold, timeout=timeout)

        # tokopoints
        res = gw.tokopoints_api_dv3points_drawer_v1(self, gw.host_production, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, cb_threshold=cb_threshold, timeout=timeout)
        res = gw.sellerinfo_api_notification_v1(self, gw.host_production, headers=headers, cb_threshold=cb_threshold, timeout=timeout)

        # topads
        res = topads.promo_info_user_v1(self, topads.host_production, user_id, device_id, headers=headers, query='pub_id=12',  name=topads.host_production+"/promo/v1/info/user?pub_id=12", cb_threshold=cb_threshold, timeout=timeout)
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query="src=fav_product&ep=&item=6%2C2&device=desktop&page=1&user_id="+user_id+"&ab_test=a&dep_id=1043%2C1372%2C1819",  name=topads.host_production+"/promo/v1.1/display/ads?src=fav_product&ep=shop&user_id={user_id}", cb_threshold=cb_threshold, timeout=timeout)

        # chat
        res = chat.tc_notifUnreads_v1(self, chat.host_production, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, cb_threshold=cb_threshold, timeout=timeout)

        # recharge
        res = pulsa_api.category_list_v1_4(self, pulsa_api.host_production, headers=headers, query='device_id=8', cb_threshold=cb_threshold, timeout=timeout)
        res = pulsa_api.operator_list_v1_4(self, pulsa_api.host_production, headers=headers, cb_threshold=cb_threshold, timeout=timeout)
        res = pulsa_api.product_list_v1_4(self, pulsa_api.host_production, headers=headers, query='device_id=8', cb_threshold=cb_threshold, timeout=timeout)
        res = pulsa_api.favorite_lastOrders(self, pulsa.host_production, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'},  cb_threshold=cb_threshold, timeout=timeout)


        if 'shop_id' in self.account :
            shop_id = self.account['shop_id']
            res = tokopedia.microfinance_micro_mt_preapprove_P(self, tokopedia.host_production, shop_id, headers=headers, name=tokopedia.host_production+"/microfinance/micro/mt/preapprove/{shop_id}", cb_threshold=cb_threshold, timeout=timeout) 
            res = tokopedia.reputationapp_reputation_api_shop_P_v1(self, tokopedia.host_production, shop_id, headers=headers, name=tokopedia.host_production+"/reputationapp/reputation/api/v1/shop/{shop_id}", cb_threshold=cb_threshold, timeout=timeout)            
            res = gold_merchant.shopstats_shopscore_sum_P_v1(self, gold_merchant.host_production, device_id, user_id, shop_id, headers=headers, name=gold_merchant.host_production+"/v1/shopstats/shopscore/sum/{shop_id}", cb_threshold=cb_threshold, timeout=timeout)
            query = "shop_id=%s&shop_data=1" % (shop_id)
            res = topads.dashboard_deposit_v1_1(self, topads.host_production, user_id, headers=headers, query=query, name=topads.host_production+"/v1.1/dashboard/deposit?shop_id={shop_id}&shop_data=1", cb_threshold=cb_threshold, timeout=timeout)
            res = topads.dashboard_hmac_v1(self, topads.host_production, headers=headers,  query='device=%27desktop%27&method=GET&url=%2Fv1.1%2Fdashboard%2Fdeposit&content=shop_id%3D'+shop_id+'%26shop_data%3D1', name=topads.host_production+"/v1/dashboard/hmac", cb_threshold=cb_threshold, timeout=timeout)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = HotlistTabProduction
    min_wait = 1500
    max_wait = 2500
