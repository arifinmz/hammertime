from locust import HttpLocust, TaskSet, task
from modules import tokopedia, cartapp, gw, orderapp, scrooge
from tests.helper.account_helper import AccountHelper
import random, json

ah = AccountHelper()

class ATCCheckoutDesktop(TaskSet):

    def on_start(self):
        if not hasattr(ATCCheckoutDesktop, 'config_loaded') :
            ATCCheckoutDesktop.test_config = self.configuration['production']
            ATCCheckoutDesktop.large_users = self.team_configuration(ATCCheckoutDesktop.test_config['dexter']['20k_accounts'])
            ATCCheckoutDesktop.config_loaded = True
        self.account = ah.get_account(self, accounts=ATCCheckoutDesktop.large_users, login_type=ah.LOGIN_TYPE_BROWSER)
        self.user_id = self.account['user_id']
        self.device_id = ATCCheckoutDesktop.test_config['device_id']
        self.timeout = (ATCCheckoutDesktop.test_config['stitch']['timeout_ATC'][0], ATCCheckoutDesktop.test_config['stitch']['timeout_ATC'][1])
        self.cb_threshold = ATCCheckoutDesktop.test_config['cb_threshold']
        self.cookie = ah.get_sid_cookie(self.user_id)
        self.headers = {
            'tkpd-userid':self.user_id,
            'cookie':self.cookie,
            'content-type':'application/x-www-form-urlencoded',
            'authority':'www.tokopedia.com'
        }

    @task(20)
    def task1(self):
        test_failed = False
        product = random.choice(ATCCheckoutDesktop.test_config['products'])
        product_id = product['id']
        shop_id = product['shop_id']

        bodies_reset_cart = {
            'status': '1',
            'lang': 'id'
        }
        cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, self.user_id, self.device_id, 
            bodies=bodies_reset_cart, headers=self.headers, 
            cb_threshold=self.cb_threshold, timeout=self.timeout)

        bodies_add_cart = {
            'params': '{"product_id":' + product_id + ', "quantity": 1, "shop_id":' + shop_id + ', "notes": ""}'
        }
        res = tokopedia.cart_add_product_cart(self, tokopedia.host_production, headers=self.headers, bodies=bodies_add_cart, timeout=self.timeout, cb_threshold=self.cb_threshold, catch_response=True)
        cart_id = None
        if res is not None and hasattr(res, "status_code") and res.status_code == 200:
            try:
                if '"success":1' in res.content:
                    test_failed = False
                    res.success()
                    res_json = res.json()
                    cart_id = res_json['data']['data']['cart_id']
                else:
                    if 'Maaf, Permohonan Anda tidak dapat diproses saat ini. Mohon dicoba kembali.' in res.content:
                        res.failure('Maaf, Permohonan Anda tidak dapat diproses saat ini. Mohon dicoba kembali.')
                    else:
                        res.failure("attribute success is not 1")
                    test_failed = True
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)
        
        if test_failed :
            return

        res = tokopedia.page(self, tokopedia.host_production, '/cart', headers=self.headers, timeout=self.timeout, cb_threshold=self.cb_threshold)

        # update cart
        carts_param = json.dumps([{"cart_id": cart_id, "quantity":1, "notes": "update ya"}])
        body_updateCart = {
            "carts": carts_param
        }
        res = cartapp.update_cart_v2(self, cartapp.host_production, headers=self.headers, bodies=body_updateCart,
                                    cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)

        if res is not None and hasattr(res, "status_code") and res.status_code == 200:
            if '"status":true' and '"error_code":"200"' in res.content:
                test_failed = False
                res.success()
            else:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        if test_failed:
            return

        res = tokopedia.cart_shipmentAddressForm(self, tokopedia.host_production, headers=self.headers,
                                            cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)
        if res is not None and hasattr(res, "status_code") and res.status_code == 200:
            try:
                if 'address_id' in res.content:
                    respon = res.json()
                    address_id  = respon['data']['group_address'][0]['user_address']['address_id']
                    shipping_id = respon['data']['group_address'][0]['group_shop'][0]['shop_shipments'][0]['ship_id']
                    sp_id       = respon['data']['group_address'][0]['group_shop'][0]['shop_shipments'][0]['ship_prods'][0]['ship_prod_id']
                    cat_id      = str(respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_cat_id'])
                    #Random latitude & longitude jakarta area
                    origin_latitude = str(random.uniform(-6.149573, -6.247871))
                    origin_longtitude = str(random.uniform(106.751159, 106.900907))
                    destination = str(respon['data']['group_address'][0]['user_address']['district_id']) + "|"+ \
                                respon['data']['group_address'][0]['user_address']['postal_code'] + "|"+ \
                                origin_latitude + "," + origin_longtitude
                    order_value = respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_price'] * \
                                respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_quantity']              
                    weight      = respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_weight'] * \
                                respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_quantity'] / 1000.0              
                    origin      = str(respon['data']['group_address'][0]['group_shop'][0]['shop']['district_id']) + "|"+ \
                                respon['data']['group_address'][0]['group_shop'][0]['shop']['postal_code'] + "|"+ \
                                respon['data']['group_address'][0]['group_shop'][0]['shop']['latitude'] + "," + \
                                respon['data']['group_address'][0]['group_shop'][0]['shop']['longitude'] 
                    product_insurance = str(respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_finsurance'])
                    token       = respon['data']['kero_token']
                    ut          = str(respon['data']['kero_unix_time'])
                    res.success()
                    test_failed = False
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                    test_failed = True
                    res.failure(res.content)
        else:
            test_failed = True
            try:
                res.raise_for_status()
            except Exception as e:
                res.failure(e)

        
        if test_failed:
            return

        #kero rates
        query = 'cat_id='+cat_id+'&'+ \
                'destination='+destination+'&'+ \
                'from=client&insurance=1&lang=id&names=jne,tiki,wahana,pos,first,gojek,sicepat,ninja,grab,jnt,rex&' + \
                'order_value='+str(order_value)+'&'+ \
                'origin='+origin+'&'+ \
                'product_insurance='+product_insurance+'&'+ \
                'service=regular,nextday,economy,sameday,cargo&' + \
                'token='+token+'&'+ \
                'ut='+ut+'&'+ \
                'weight='+str(weight)
        res = gw.rates_v2(self, gw.host_production, self.device_id, self.user_id, timeout=self.timeout, cb_threshold=self.cb_threshold, 
            headers=self.headers, query=query, hide_query=True,  catch_response=True)
        if res is not None and hasattr(res, "status_code") and res.status_code == 200:
            try:
                if 'shipper_name' in res.content:
                    test_failed = False
                    res.success()
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        if test_failed:
            return

        # checkout
        headers_checkout = {
            "Tkpd-UserId": self.user_id,
            "cookie": self.cookie,
            "X-Device": "desktop"
            # "X-Device": "default_v3"
        }
        body_checkout = {
            "carts": '{"promo_code":"","is_donation":0,\
                "data":[{"address_id": '+str(address_id)+',\
                    "shop_products":[{"shop_id":'+str(shop_id)+',\
                        "product_data":[{"product_id":'+str(product_id)+'}],\
                        "is_preorder":0,"finsurance":0,"is_dropship":0,\
                        "shipping_info":{"shipping_id":'+str(shipping_id)+',"sp_id":'+str(sp_id)+'},\
                        "dropship_data":{"name":"","telp_no":""}}]}]}',
            "profile": "TKPD_DEFAULT"
        }
        res = tokopedia.cart_checkout(self, tokopedia.host_production, headers=headers_checkout,
            bodies=body_checkout, cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)
        if res is not None and hasattr(res, "status_code") and res.status_code == 200:
                try:
                    if 'transaction_id' in res.content:
                        respon = res.json()
                        transaction_id = respon['data']['data']['parameter']['transaction_id']
                        transaction_date = respon['data']['data']['parameter']['transaction_date']
                        user_defined_value = respon['data']['data']['parameter']['user_defined_value']
                        product_list = respon['data']['data']['product_list']
                        ids = orderapp.itemsList(product_list, 'id')
                        prices = orderapp.itemsList(product_list, 'price')
                        quantities = orderapp.itemsList(product_list, 'quantity')
                        names = orderapp.itemsList(product_list, 'name')
                        payment_metadata = respon['data']['data']['parameter']['payment_metadata']
                        merchant_code = respon['data']['data']['parameter']['merchant_code']
                        nid = respon['data']['data']['parameter']['nid']
                        pid = respon['data']['data']['parameter']['pid']
                        profile_code = respon['data']['data']['parameter']['profile_code']
                        gateway_code = respon['data']['data']['parameter']['gateway_code']
                        amount = respon['data']['data']['parameter']['amount']
                        customer_email = respon['data']['data']['parameter']['customer_email']
                        signature = respon['data']['data']['parameter']['signature']
                        customer_name = respon['data']['data']['parameter']['customer_name']
                        msisdn = respon['data']['data']['parameter']['customer_msisdn']
                        currency = respon['data']['data']['parameter']['currency']
                        test_failed = False
                        res.success()
                    else:
                        test_failed = True
                        res.failure(res.content)
                        print(product_id)
                except Exception as e:
                    test_failed = True
                    res.failure(res.content)
                    print(product_id)
        else:
                try:
                    res.raise_for_status()
                    print(product_id)
                except Exception as e:
                    test_failed = True
                    res.failure(e)
                    print(product_id)
        
        if test_failed:
            return

        # payment
        bodies_v2Payment = {
            'customer_id': self.user_id,
            'customer_email': customer_email,
            'customer_name': customer_name,
            'transaction_id': transaction_id,
            'transaction_date': transaction_date,
            'amount': amount,
            'gateway_code': gateway_code,
            'currency': currency,
            'signature': signature,
            'items[id]': ids,
            'items[price]': prices,
            'items[quantity]': quantities,
            'items[name]': names,
            'nid': nid,
            'pid': pid,
            'user_defined_value': user_defined_value,
            'merchant_code': merchant_code,
            'profile_code': profile_code,
            'language': 'id-ID',
            'payment_metadata': payment_metadata,
            'customer_msisdn': msisdn,
            'device_info': '[object+Object]'
        }

        headers_v2Payment = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        res = scrooge.payment_v2(self, scrooge.host_production, bodies=bodies_v2Payment,
                                    headers=headers_v2Payment, timeout=self.timeout,
                                    cb_threshold=self.cb_threshold, catch_response=True)
        if res is not None and hasattr(res, "status_code") and res.status_code == 200:
                try:
                    if 'Payment Failed' in res.content or len(str(res.content)) < 1:
                        test_failed = True
                        res.failure("Payment Failed or empty html returned")
                    else:
                        res.success()
                except Exception as e:
                    test_failed = True
                    res.failure(res.content)
        else:
                try:
                    res.raise_for_status()
                except Exception as e:
                    test_failed = True
                    res.failure(e)
        

class WebsiteUser(HttpLocust):
    host = ""
    task_set = ATCCheckoutDesktop
    min_wait = 1000
    max_wait = 1500