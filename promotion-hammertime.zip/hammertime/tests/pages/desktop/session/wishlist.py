from locust import HttpLocust, TaskSet, task
from modules import tokopedia, accounts, mojito, reputationapp, gold_merchant, gw, chat, ace, topads, pulsa_api, pulsa
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class Wishlist(TaskSet):
    def on_start(self):
        self.config = self.configuration['production']
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        user_id         = self.account['user_id']
        platform        = 'desktop'
        device_id       = self.config['device_id']
        timeout         = (self.config['timeout'][0], self.config['timeout'][1])
        timeout_page    = (self.config['timeout_page'][0], self.config['timeout_page'][1])
        cb_threshold    = self.config['cb_threshold']
        
        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }

        res = tokopedia.page(self, tokopedia.host_production, '/?tab=wishlist&nref=whead', headers=headers, timeout=timeout_page, cb_threshold=cb_threshold)

        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production, headers=headers, query="action=reload_data&is_interval=1", timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query="action=reload_data&is_interval=1", timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_verification_number_pl(self, tokopedia.host_production, headers=headers, query="is_fluid=1", timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_r3global_pl(self, tokopedia.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        
        res = tokopedia.api_wallet_balance(self, tokopedia.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        # gw
        res = gw.tokopoints_api_dv3points_drawer_v1(self, gw.host_production, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, timeout=timeout, cb_threshold=cb_threshold)
        res = gw.sellerinfo_api_notification_v1(self, gw.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        # accounts
        res = accounts.marketplace_pixel(self, accounts.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        # mojito
        res = mojito.api_tickers_v1(self, mojito.host_production, headers=headers, query="user_id={0}&page[size]=50&filter[device]={1}&action=data_source_ticker".format(user_id, platform), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
        res = mojito.api_slides_v1(self, mojito.host_production, headers=headers, query="page[size]=25&filter[device]=1&filter[state]=1&filter[expired]=0", timeout=timeout, cb_threshold=cb_threshold)
        res = mojito.users_P_wishlist_products_v1_0_3(self, mojito.host_production, user_id, device_id, headers=headers, query="page=1&count=20&ref=whead", name=mojito.host_production+"/v1.0.3/users/{user_id}/wishlist/products?page=1&count=20&ref=whead", timeout=timeout, cb_threshold=cb_threshold)

        # chat
        res = chat.tc_notifUnreads_v1(self, chat.host_production, headers={'cookie': ah.get_sid_cookie(user_id), 'origin': 'https://www.tokopedia.com'}, timeout=timeout, cb_threshold=cb_threshold)

        # ace
        query = "callback=r3Callback&dsource=&device={0}&trend_type=&trend_size=1&recommendation_size=5&category=0&popular_day=1&page=1&title=&ftitle=&callback=r3Callback&pmin=&pmax=&fcity=&user_id={1}&full_domain=www.tokopedia.com&scheme=https&page_name=wishlist_page&xdevice=desktop&xsource=js_widget&reff=&layout=full-wslider".format(platform, user_id)
        res = ace.r3_recommendation_bypage_v1(self, ace.host_production, headers=headers, query=query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        # topads
        res = topads.promo_info_user_v1(self, topads.host_production, user_id, device_id, headers=headers, query="pub_id=12", timeout=timeout, cb_threshold=cb_threshold, hide_query=True)
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query="ep=product&src=wishlist&device={0}&user_id={1}&page=1&dep_id=36".format(platform, user_id), name=topads.host_production+"/promo/v1.1/display/ads?ep=product&src=wishlist", timeout=timeout, cb_threshold=cb_threshold)
        

        # pulsa-api
        query = "device_id=8"
        res = pulsa_api.category_list_v1_4(self, pulsa_api.host_production, headers=headers, query=query, timeout=timeout, cb_threshold=cb_threshold)
        res = pulsa_api.operator_list_v1_4(self, pulsa_api.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        res = pulsa_api.product_list_v1_4(self, pulsa_api.host_production, headers=headers, query=query, timeout=timeout, cb_threshold=cb_threshold)
        
        # pulsa
        res = pulsa.favorite_lastOrders(self, pulsa.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        if 'shop_id' in self.account:
            shop_id = self.account['shop_id']
            #tokopedia
            res = tokopedia.reputationapp_reputation_api_shop_P_v1(self, tokopedia.host_production, shop_id, headers=headers, name=tokopedia.host_production+"/reputationapp/reputation/api/v1/shop/{shop_id}", timeout=timeout, cb_threshold=cb_threshold)
            #topads
            res = topads.dashboard_deposit_v1_1(self, topads.host_production, user_id, headers=headers, query="shop_id={0}&shop_data=1".format(shop_id), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
            # gold-merchant
            res = gold_merchant.shopstats_shopscore_sum_P_v1(self, gold_merchant.host_production, device_id, user_id, shop_id, headers=headers, name=gold_merchant.host_production+"/v1/shopstats/shopscore/sum/{shop_id}", timeout=timeout, cb_threshold=cb_threshold)

            # shop_id must be whitelisted, contact wallet team (@sandra.puspa)
            res = tokopedia.microfinance_micro_mt_preapprove_P(self, tokopedia.host_production, shop_id, headers=headers, name=tokopedia.host_production+"/microfinance/micro/mt/preapprove/{shop_id}", timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = tokopedia.host_production
    task_set = Wishlist
    min_wait = 1500
    max_wait = 2500