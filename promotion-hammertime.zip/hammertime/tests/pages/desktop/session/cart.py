from locust import HttpLocust, TaskSet, task
from modules import tokopedia, mojito, chat
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class CartTXDesktop(TaskSet):

    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        device_id = self.config['device_id']
        user_id = self.account['user_id']
        home_domain = '/tx.pl'
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page    = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold    = self.config['cb_threshold']
        
        wishlist_counter = random.randint(0,8)
        products_array = list()
        for x in range(0,wishlist_counter):
            products_array.append(random.choice(self.config['dexter']['massive_products'])) #should be product on cart
        product_ids = ','.join(map(str, products_array))

        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }

        res = tokopedia.page(self, tokopedia.host_production, home_domain, headers=headers, name=tokopedia.host_production+"/tx.pl", cb_threshold=cb_threshold, timeout=timeout_page)
        res = tokopedia.ajax_check_quick_guide_pl(self, tokopedia.host_production, headers=headers, query='type=guide_checkout', cb_threshold=cb_threshold, timeout=timeout)
        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)
        res = tokopedia.ajax_wishlist_pl(self, tokopedia.host_production, headers=headers, query='p_id='+product_ids+'&action=event_get_check_wishlist_key', hide_query=True, cb_threshold=cb_threshold, timeout=timeout)
        res = tokopedia.ajax_r3global_pl(self, tokopedia.host_production, headers=headers, cb_threshold=cb_threshold, timeout=timeout)
        res = tokopedia.ajax_check_security_popup(self, tokopedia.host_production, headers=headers, cb_threshold=cb_threshold, timeout=timeout)
        res = chat.tc_notifUnreads_v1(self, chat.host_production, headers=headers, name=chat.host_production+"/tc/v1/notif_unreads",  timeout=timeout, cb_threshold=cb_threshold)
        res = mojito.users_P_wishlist_check_P_v1(self, mojito.host_production, user_id, product_ids, headers=headers, name=mojito.host_production+"/v1/users/wishlist/check/", timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = tokopedia.host_production
    task_set = CartTXDesktop
    min_wait = 1500
    max_wait = 2500
