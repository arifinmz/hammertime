from locust import HttpLocust, TaskSet, task
from modules import tokopedia, mojito, tome, gw, chat, pulsa, pulsa_api, ace
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class OSHome(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        device_id = self.config['device_id']
        user_id = self.account['user_id']
        home_domain = '/official-store/'
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page    = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold    = self.config['cb_threshold']
        
        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }

        res = tokopedia.page(self, tokopedia.host_production, home_domain, headers=headers, cb_threshold=cb_threshold, timeout=timeout_page)

        #Ajax Check Quick Guide
        res = tokopedia.ajax_check_quick_guide_pl(self, tokopedia.host_production, headers=headers, query='type=guide_checkout', timeout=timeout, cb_threshold=cb_threshold)

        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production,  headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)

        res = tokopedia.ajax_r3global_pl(self, tokopedia.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold )

        res = tokopedia.ajax_check_security_popup(self, tokopedia.host_production, headers=headers, cb_threshold=cb_threshold, timeout=timeout)

        res = chat.tc_notifUnreads_v1(self, chat.host_production, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, cb_threshold=cb_threshold, timeout=timeout)

        res = ace.search_product_v3(self, ace.host_production, headers=headers, query='device=desktop&source=osmicrosite&rows=10&official=true&sc=0&ob=9&start=0', hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        try :
            sp_res = res.json()
            shop_ids = ""
            for x in sp_res['data']['products']:
                shop_ids = ('%s,%s') % (shop_ids,x['shop']['id'])
            res = tome.webService_shop_getSummary_v1(self, tome.host_production, query="shop_id="+shop_ids, timeout=timeout, cb_threshold=cb_threshold, hide_query=True)
        except Exception as e:
            pass

class WebsiteUser(HttpLocust):
    host = ""
    task_set = OSHome
    min_wait = 1500
    max_wait = 2500
