from locust import HttpLocust, TaskSet, task
from modules import tokopedia, topads, mojito, accounts, ace, tome, chat
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class SearchShopProduction(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.users, login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']        
        shop_id = self.account['shop_id']
        device_id = self.config['device_id']
        keyword = random.choice(self.config['search']['search_shop_keywords'])
        search_domain = '/search?st=shop&q='+keyword
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        cb_threshold = self.config['cb_threshold']

        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }

        res = tokopedia.page(self, tokopedia.host_production, search_domain, headers=headers, hide_query=True, timeout=timeout_page, cb_threshold=cb_threshold)
        res = tokopedia.ajax_check_quick_guide_pl(self, tokopedia.host_production,  headers=headers, query='type=guide_search_prosecure', timeout=timeout, cb_threshold=cb_threshold)
        res = topads.dashboard_hmac_v1(self, topads.host_production,  headers=headers, query='device=%27desktop%27&method=GET&url=%2Fv1.1%2Fdashboard%2Fdeposit&content=shop_id%3D'+shop_id+'%26shop_data%3D1', timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production,  headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production,  headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_prosecure_pl(self, tokopedia.host_production,  headers=headers, query='action=shop_list', timeout=timeout, cb_threshold=cb_threshold)
        query = 'shop_id='+shop_id+'&shop_data=1'
        res = topads.dashboard_deposit_v1_1(self, topads.host_production, user_id, headers=headers, query=query,  name=topads.host_production+"/v1.1/dashboard/deposit?"+query, timeout=timeout, cb_threshold=cb_threshold)
        res = tome.webService_fav_shop_list_v1(self, tome.host_production,  headers=headers, query="user_id="+user_id, timeout=timeout, cb_threshold=cb_threshold)
        res = accounts.marketplace_pixel(self, accounts.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        res = ace.dynamic_attributes_v2(self, ace.host_production, headers={'cookie':ah.get_sid_cookie(user_id)}, query='st=shop&q='+keyword+'&ob=23&source=search&device=desktop&callback=angular.callbacks._0', timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.sellerinfo_api_notification_v1(self, tokopedia.host_production_gw,  timeout=timeout, cb_threshold=cb_threshold)
        res = chat.tc_notifUnreads_v1(self, chat.host_production, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, timeout=timeout, cb_threshold=cb_threshold)
        res = ace.search_shop_v1(self, ace.host_production, query='st=shop&q={0}&source=search_shop&device=desktop&scheme=https&page=1&rows=60&unique_id=e79ceadfd4ba557416e6feda410bee3e&start=0&ob=23&full_domain=www.tokopedia.com&callback=angular.callbacks._1'.format(keyword), timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = SearchShopProduction
    min_wait = 1500
    max_wait = 2500
