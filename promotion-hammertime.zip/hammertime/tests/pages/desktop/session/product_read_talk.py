from locust import HttpLocust, TaskSet, task
from modules import tokopedia, inbox, chat, js, tome, reputationapp, mojito
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class ProductReadTalk(TaskSet):

    def on_start(self):
        self.config  = self.configuration['production']
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER) 

    @task(1)
    def task1(self):
        user_id     = self.account['user_id']
        device_id   = self.config['device_id']
        product_id  = random.choice(self.config['dexter']['massive_products'])
        cookie      = ah.get_sid_cookie(user_id)
        headers     = {
            'cookie': cookie,
            'origin':'https://www.tokopedia.com'
        }
        cb_threshold = self.config['cb_threshold']
        timeout      = (self.config['timeout'][0], self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0], self.config['timeout_page'][1])
        test_failed = False

        product_detail = tome.webService_product_getSummary_v1(self, tome.host_production, query='product_id={0}'.format(product_id), hide_query=True)
        try:
            product_json = product_detail.json()
            product_url  = product_json['data'][0]['product_url']
            shop_id      = str(product_json['data'][0]['shop_id'])
        except Exception as e :
            test_failed = True

        if not test_failed :
            # to get shop domain and product name from complete product url, then add it with talk path (and query if needed)
            domain = product_url.replace('https://www.tokopedia.com','')+'/talk'
            res = tokopedia.page(self, tokopedia.host_production, domain, headers=headers, name=tokopedia.host_production+'/{shop_domain}/{product_name}/talk', timeout=timeout_page, cb_threshold=cb_threshold, catch_response=True)
            if res.status_code < 400 or res.status_code == 404 :
                res.success()
            else:
                try:
                    res.raise_for_status()
                except Exception as e:
                    res.failure(e)

            # inbox
            res = inbox.token_generate_v1(self, inbox.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
            res = inbox.talk_talkcount_P_v1(self, inbox.host_production, product_id, headers=headers, name=inbox.host_production+'/talk/v1/talkcount/{product_id}', timeout=timeout, cb_threshold=cb_threshold)
            res = inbox.talk_response_P_v1(self, inbox.host_production, shop_id, headers=headers, name=inbox.host_production+'/talk/v1/response/{shop_id}', timeout=timeout, cb_threshold=cb_threshold)
            res_read_talk = inbox.talk_read_P_v1(self, inbox.host_production, product_id, headers=headers, query='page=1&sort=&talkId=&type=p&state=&pageId=0', name=inbox.host_production+'/talk/v1/read/{product_id}', timeout=timeout, cb_threshold=cb_threshold, catch_response=True)
            if res_read_talk.status_code == 200:
                try:
                    json_talk   = res_read_talk.json()
                    if json_talk['status'] == 1:
                        res_read_talk.success()
                        if len(json_talk['talks']) > 0:
                            talk_ids = []
                            user_ids = []
                            for talk in json_talk['talks']:
                                talk_ids.append(str(talk['id']))
                                user_ids.append(str(talk['user_id']))
                            joined_talk_id = '~'.join(talk_ids)
                            joined_user_id = '~'.join(user_ids)
                        else:
                            test_failed = True
                    else:
                        raise Exception('talk status != 1')
                except Exception as e:
                    res_read_talk.failure(e)
                    test_failed = True
            else:
                try:
                    res_read_talk.raise_for_status()
                except Exception as e:
                    res_read_talk.failure(e)
                    test_failed = True
            
            if not test_failed:
                res = inbox.talk_comment_v1(self, inbox.host_production, joined_talk_id, headers=headers, query='type=multi', name=inbox.host_production+'/talk/v1/comment/{talk_id}?type=multi', timeout=timeout, cb_threshold=cb_threshold)
                res = reputationapp.reputationapp_reputation_api_user_P_v1(self, tokopedia.host_production, user_id, headers=headers, name=tokopedia.host_production+'/reputationapp/reputation/api/v1/user/{user_id}', timeout=timeout, cb_threshold=cb_threshold)

            # reputationapp
            res = reputationapp.reputationapp_reputation_api_shop_P_v1(self, tokopedia.host_production, shop_id, headers=headers, name=tokopedia.host_production+'/reputationapp/reputation/api/v1/shop/{shop_id}', timeout=timeout, cb_threshold=cb_threshold)
            res = reputationapp.reputationapp_review_api_total_p_P_v1(self, tokopedia.host_production, user_id, device_id, product_id, headers=headers, name=tokopedia.host_production+'/reputationapp/review/api/v1/total/p/{product_id}', timeout=timeout, cb_threshold=cb_threshold)

            # tokopedia
            res = tokopedia.ajax_notification_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
            res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
            res = tokopedia.ajax_wishlist_pl(self, tokopedia.host_production, headers=headers, query='p_id={0}&action=event_get_check_wishlist_key'.format(product_id), name=tokopedia.host_production+'/ajax/wishlist.pl?action=event_get_check_wishlist_key', timeout=timeout, cb_threshold=cb_threshold)

            # chat
            res = chat.tc_notifUnreads_v1(self, chat.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
            res = chat.tc_chat_templates_v1(self, chat.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
            res = chat.tc_response_shop_P_v1(self, chat.host_production, shop_id, headers=headers, name=chat.host_production+'/tc/v1/response/shop/{shop_id}', timeout=timeout, cb_threshold=cb_threshold)

            # js
            res = js.productstats_check(self, js.host_production, headers=headers, query='pid={0}&callback=show_product_stats'.format(product_id), name=js.host_production+'/productstats/check?callback=show_product_stats', timeout=timeout, cb_threshold=cb_threshold)
            res = js.js_shoplogin(self, js.host_production, headers=headers, query='id={0}&callback=show_last_online'.format(shop_id), name=js.host_production+'/js/shoplogin?callback=show_last_online', timeout=timeout, cb_threshold=cb_threshold)

            # tome
            res = tome.product_P_variant_v2(self, tome.host_production, product_id, headers=headers, name=tome.host_production+'/v2/product/{product_id}/variant', timeout=timeout, cb_threshold=cb_threshold)

            # mojito
            res = mojito.users_P_wishlist_check_P_v2(self, mojito.host_production, user_id, device_id, product_id, headers=headers, name=mojito.host_production+'/users/{user_id}/wishlist/check/{product_id}/v2', timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust): 
    host        = ""
    task_set    = ProductReadTalk
    min_wait    = 1500
    max_wait    = 2500