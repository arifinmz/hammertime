from locust import HttpLocust, TaskSet, task
from modules import tokopedia, gw, cartapp, scrooge, orderapp
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class CartPayV2(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_BROWSER)
        self.user_id = self.account['user_id']
        self.device_id = self.config["device_id"]
        self.timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        self.timeout_page    = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        self.cb_threshold    = self.config['cb_threshold']
        self.cookie = ah.get_sid_cookie(self.user_id)

    @task(1)
    def task1(self):
        #click buy
        product = random.choice(self.config['products'])
        product_id = product['id']
        shop_id = product['shop_id']
        
        bodies_reset_cart = {
            'status': '1',
            'lang': 'id'
        }
        headers_reset_cart = {
            'Tkpd-UserId': self.user_id,
            'content-type': 'application/x-www-form-urlencoded',
            'cookie': self.cookie
        }
        cartapp.cart_i_reset_cart_item_v1(self, cartapp.host_production, self.user_id, self.device_id, 
            bodies=bodies_reset_cart, headers=headers_reset_cart, 
            cb_threshold=self.cb_threshold, timeout=self.timeout)

        headers_atc = {
            'cookie': self.cookie,
            'Authorization': ah.get_token(self.user_id),
            'Tkpd-UserId': self.user_id
        }
        
        body_atc = {
            'params': '{"product_id":' + product_id + ', "quantity": 1, "shop_id":' + shop_id + ', "notes": ""}'
        }
        res = tokopedia.cart_add_product_cart(self, tokopedia.host_production, headers=headers_atc, bodies=body_atc,
                                          cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)
        respon = dict()
        if res.status_code == 200:
            try:
                if '"success":1' in res.content:
                    test_failed = False
                    respon = res.json()
                    res.success()
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        #do not continue if previous step failed
        if test_failed:
            return


        headers = {
          'cookie':ah.get_sid_cookie(self.user_id)
        }

        # update cart
        cart_id = respon['data']['data']['cart_id']
        carts_param = '[{"cart_id": ' + str(cart_id) + ', "quantity":1, "notes": "update cart"}]'
        headers_updatecart = {
          'cookie':ah.get_sid_cookie(self.user_id),
            'Tkpd-UserId': self.user_id
        }
        body_updateCart = {
            "carts": carts_param
        }
        res = tokopedia.cart_updateCart(self, tokopedia.host_production, headers=headers_updatecart, bodies=body_updateCart,
            cb_threshold=self.cb_threshold, timeout=self.timeout, catch_response=True)
        if res.status_code == 200:
            try:
                if '"status":true' and '"error_code":"200"' in res.content:
                    test_failed = False
                    res.success()
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        #do not continue if previous step failed
        if test_failed:
            return

        # shipment address form
        headers_shipmentAddressForm = {
            'cookie': self.cookie,
            'Tkpd-UserId': self.user_id
        }
        res = tokopedia.cart_shipmentAddressForm(self, tokopedia.host_production, headers=headers_shipmentAddressForm,
            cb_threshold=self.cb_threshold, timeout=self.timeout_page, catch_response=True)

        if res.status_code == 200:
            try:
                if 'address_id' in res.content:
                    test_failed = False
                    respon = res.json()
                    res.success()
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        #do not continue if previous step failed
        if test_failed:
            return

        address_id  = respon['data']['group_address'][0]['user_address']['address_id']
        shipping_id = respon['data']['group_address'][0]['group_shop'][0]['shop_shipments'][0]['ship_id']
        sp_id       = respon['data']['group_address'][0]['group_shop'][0]['shop_shipments'][0]['ship_prods'][0]['ship_prod_id']
        cat_id      = str(respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_cat_id'])
        #Random latitude & longitude jakarta area
        origin_latitude = str(random.uniform(-6.149573, -6.247871))
        origin_longtitude = str(random.uniform(106.751159, 106.900907))
        destination = str(respon['data']['group_address'][0]['user_address']['district_id']) + "|"+ \
                      respon['data']['group_address'][0]['user_address']['postal_code'] + "|"+ \
                      origin_latitude + "," + origin_longtitude
        order_value = respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_price'] * \
                      respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_quantity']              
        weight      = respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_weight'] * \
                      respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_quantity'] / 1000.0              
        origin      = str(respon['data']['group_address'][0]['group_shop'][0]['shop']['district_id']) + "|"+ \
                      respon['data']['group_address'][0]['group_shop'][0]['shop']['postal_code'] + "|"+ \
                      respon['data']['group_address'][0]['group_shop'][0]['shop']['latitude'] + "," + \
                      respon['data']['group_address'][0]['group_shop'][0]['shop']['longitude'] 
        product_insurance = str(respon['data']['group_address'][0]['group_shop'][0]['products'][0]['product_finsurance'])
        token       = respon['data']['kero_token']
        ut          = str(respon['data']['kero_unix_time'])
        #kero rates
        query = 'cat_id='+cat_id+'&'+ \
                'destination='+destination+'&'+ \
                'from=client&insurance=1&lang=id&names=jne,tiki,wahana,pos,first,gojek,sicepat,ninja,grab,jnt,rex&' + \
                'order_value='+str(order_value)+'&'+ \
                'origin='+origin+'&'+ \
                'product_insurance='+product_insurance+'&'+ \
                'service=regular,nextday,economy,sameday,cargo&' + \
                'token='+token+'&'+ \
                'ut='+ut+'&'+ \
                'weight='+str(weight)
        res = gw.rates_v2(self, gw.host_production, self.device_id, self.user_id, timeout=self.timeout, cb_threshold=self.cb_threshold, 
            headers=headers, query=query, hide_query=True,  catch_response=True)


        if res.status_code == 200:
            try:
                if 'shipper_name' in res.content:
                    test_failed = False
                    res.success()
                else:
                    test_failed = True
                    res.failure(res.content)
            except Exception as e:
                test_failed = True
                res.failure(res.content)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                test_failed = True
                res.failure(e)

        #do not continue if previous step failed
        if test_failed:
            return



        # checkout
        headers_checkout = {
            "Tkpd-UserId": self.user_id,
            "cookie": self.cookie,
            "X-Device": "desktop"
            # "X-Device": "default_v3"
        }
        body_checkout = {
            "carts": '{"promo_code":"","is_donation":0,\
                "data":[{"address_id": '+str(address_id)+',\
                    "shop_products":[{"shop_id":'+str(shop_id)+',\
                        "product_data":[{"product_id":'+str(product_id)+'}],\
                        "is_preorder":0,"finsurance":0,"is_dropship":0,\
                        "shipping_info":{"shipping_id":'+str(shipping_id)+',"sp_id":'+str(sp_id)+'},\
                        "dropship_data":{"name":"","telp_no":""}}]}]}',
            "profile": "TKPD_DEFAULT"
        }
        res = tokopedia.cart_checkout(self, tokopedia.host_production, headers=headers_checkout,
            bodies=body_checkout, cb_threshold=self.cb_threshold, timeout=self.timeout_page, catch_response=True)


        if res != "" and res.status_code == 200:
                try:
                    if 'transaction_id' in res.content:
                        test_failed = False
                        respon = res.json()
                        res.success()
                    else:
                        test_failed = True
                        res.failure(res.content)
                        print(product_id)
                except Exception as e:
                    test_failed = True
                    res.failure(res.content)
                    print(product_id)
        else:
                try:
                    res.raise_for_status()
                    print(product_id)
                except Exception as e:
                    test_failed = True
                    res.failure(e)
                    print(product_id)

        #do not continue if previous step failed
        if test_failed:
            return

        #payment iframe
        transaction_id = respon['data']['data']['parameter']['transaction_id']
        transaction_date = respon['data']['data']['parameter']['transaction_date']
        user_defined_value = respon['data']['data']['parameter']['user_defined_value']
        product_list = respon['data']['data']['product_list']
        ids = orderapp.itemsList(product_list, 'id')
        prices = orderapp.itemsList(product_list, 'price')
        quantities = orderapp.itemsList(product_list, 'quantity')
        names = orderapp.itemsList(product_list, 'name')
        payment_metadata = respon['data']['data']['parameter']['payment_metadata']
        merchant_code = respon['data']['data']['parameter']['merchant_code']
        nid = respon['data']['data']['parameter']['nid']
        pid = respon['data']['data']['parameter']['pid']
        profile_code = respon['data']['data']['parameter']['profile_code']
        gateway_code = respon['data']['data']['parameter']['gateway_code']
        amount = respon['data']['data']['parameter']['amount']
        customer_email = respon['data']['data']['parameter']['customer_email']
        signature = respon['data']['data']['parameter']['signature']
        customer_name = respon['data']['data']['parameter']['customer_name']
        msisdn = respon['data']['data']['parameter']['customer_msisdn']
        currency = respon['data']['data']['parameter']['currency']

        # payment
        bodies_v2Payment = {
            'customer_id': self.user_id,
            'customer_email': customer_email,
            'customer_name': customer_name,
            'transaction_id': transaction_id,
            'transaction_date': transaction_date,
            'amount': amount,
            'gateway_code': gateway_code,
            'currency': currency,
            'signature': signature,
            'items[id]': ids,
            'items[price]': prices,
            'items[quantity]': quantities,
            'items[name]': names,
            'nid': nid,
            'pid': pid,
            'user_defined_value': user_defined_value,
            'merchant_code': merchant_code,
            'profile_code': profile_code,
            'language': 'id-ID',
            'payment_metadata': payment_metadata,
            'customer_msisdn': msisdn,
            'device_info': '[object+Object]'
        }

        headers_v2Payment = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        res = scrooge.payment_v2(self, scrooge.host_production, bodies=bodies_v2Payment,
                                    headers=headers_v2Payment, timeout=self.timeout_page,
                                    cb_threshold=self.cb_threshold, catch_response=True)

        if res != "" and res.status_code == 200:
                try:
                    if 'Payment Failed' in res.content or len(str(res.content)) < 1:
                        test_failed = True
                        res.failure("Payment Failed or empty html returned")
                    else:
                        res.success()
                except Exception as e:
                    test_failed = True
                    res.failure(res.content)
        else:
                try:
                    res.raise_for_status()
                except Exception as e:
                    test_failed = True
                    res.failure(e)

        

class WebsiteUser(HttpLocust):
    host = ""
    task_set = CartPayV2
    min_wait = 1500
    max_wait = 2500
