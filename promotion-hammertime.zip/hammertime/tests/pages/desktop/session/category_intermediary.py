from locust import HttpLocust, TaskSet, task
from modules import tokopedia, hades, gw, chat, topads, mojito, accounts, ace, inbox
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class CategoryIntermediary(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        device_id = self.config["device_id"]
        category_id = random.choice(self.config['category']['category_id']['all_intermediary'])
        list_new_intermediary = self.config['category']['category_id']['new_intermediary']             
        platform = 'desktop'
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0], self.config['timeout_page'][1])
        cb_threshold = self.config['cb_threshold']
        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }
        test_failed = False

        res_category = hades.categories_P_v1(self, hades.host_production, category_id, headers=headers, query="filter=type==tree", name=hades.host_production+"/v1/categories/{category_id}?filter=type==tree")
        try :
            category_json = res_category.json()
            category_identifier = category_json["data"]["categories"][0]["identifier"]
        except Exception as e :
            test_failed = True

        if not test_failed : 
            res = tokopedia.page(self, tokopedia.host_production, '/p/'+category_identifier, name=tokopedia.host_production+"/p/{category_identifier}", headers=headers, timeout=timeout_page, cb_threshold=cb_threshold)

        #  tokopedia ajax
        res = tokopedia.ajax_verification_number_pl(self, tokopedia.host_production, headers=headers, query="is_fluid=0", timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production,  headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_check_quick_guide_pl(self, tokopedia.host_production, headers=headers, query='type=guide_search_prosecure', timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_prosecure_pl(self, tokopedia.host_production, headers=headers, query='action=shop_list', timeout=timeout, cb_threshold=cb_threshold)
        

        # accounts
        res = accounts.marketplace_pixel(self, accounts.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        # ace
        query = "categories={0}&imageSize=277x415%2C300x300%2C574x300&perPage=7&curated=true&callback=angular.callbacks._1".format(category_id)
        res = ace.hoth_hotlist_category_v1(self, ace.host_production, headers=headers, query=query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        query = "sc={0}&source=directory&device={1}&scheme=https&start=0&rows=8&full_domain=www.tokopedia.com".format(category_id, platform)
        res_search = ace.search_product_v3(self, ace.host_production, headers=headers, query=query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold, catch_response=True)

        if res_search.status_code == 200 :
            try :
                search_product_json = res_search.json()
                if len(search_product_json["data"]["products"]) > 0 :
                    product_ids = []
                    for product in search_product_json["data"]["products"]:
                        product_ids.append(str(product["id"]))
                    joined_product_id = "~".join(product_ids)
                    test_failed = False
                else :
                    test_failed = True
                res_search.success()
            except Exception as e :
                res_search.failure(e)
                test_failed = True
        else :
            try:
                res_search.raise_for_status()
            except Exception as e:
                res_search.failure(e)
                test_failed = True

        if not test_failed :
            res = mojito.users_P_wishlist_check_P_v2(self, mojito.host_production, user_id, device_id, joined_product_id, headers=headers, name=mojito.host_production+"/users/{user_id}/wishlist/check/{product_ids}/v2", timeout=timeout, cb_threshold=cb_threshold)
            res = tokopedia.ajax_wishlist_pl(self, tokopedia.host_production, headers=headers, query='p_id='+joined_product_id+'&action=event_get_check_wishlist_key', cb_threshold=cb_threshold, timeout=timeout, hide_query=True)

        # topads
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query='src=intermediary&user_id={0}&ep=cpm&item=5,3&device={1}&dep_id={2}&template_id=2%2C3'.format(user_id, platform, category_id), name=topads.host_production+"/promo/v1.1/display/ads?ep=cpm&src=intermediary", timeout=timeout, cb_threshold=cb_threshold)
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query="user_id={0}&dep_id={1}&item=4%2C3&src=intermediary&device={2}".format(user_id, category_id, platform), name=topads.host_production+"/promo/v1.1/display/ads?src=intermediary", timeout=timeout, cb_threshold=cb_threshold)

        # hades
        res = hades.categories_P_features_v2(self, hades.host_production, category_id, name=hades.host_production+"/v2/categories/{category_id}/features", headers=headers, query='intermediary=true&total_curated=10', timeout=timeout, cb_threshold=cb_threshold)               
       
        # gw
        res = gw.sellerinfo_api_notification_v1(self, gw.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        
        # chat
        res = chat.tc_notifUnreads_v1(self, chat.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)        

        if category_id in list_new_intermediary :
            query = "callback=r3Callback&dsource=&device={0}&trend_type=&trend_size=8&recommendation_size=8&category={1}&popular_day=1&page=1&callback=r3Callback&pmin=&pmax=&fcity=&user_id={2}&full_domain=www.tokopedia.com&scheme=https&page_name=intermediary_flexible&xdevice={3}&xsource=lite&reff=&layout=intermediary-flex".format(platform, category_id, user_id, platform)
            res = ace.r3_recommendation_bypage_v1(self, ace.host_production, headers=headers, query=query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
            
            res = tokopedia.ajax_r3global_pl(self, tokopedia.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)


class WebsiteUser(HttpLocust):
    host = tokopedia.host_production
    task_set = CategoryIntermediary
    min_wait = 1500
    max_wait = 2500


