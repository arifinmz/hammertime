from locust import HttpLocust, TaskSet, task
from modules import tokopedia, accounts, reputationapp, gw, mojito, gold_merchant, chat, topads
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class Tokopoints(TaskSet):
    def on_start(self):
        self.config = self.configuration['production']
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        device_id = self.config['device_id']
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0], self.config['timeout_page'][1])
        cb_threshold = self.config['cb_threshold']
        headers = {
            'cookie': ah.get_sid_cookie(user_id)
        }

        res = tokopedia.page(self, tokopedia.host_production, '/tokopoints', headers=headers, timeout=timeout_page, cb_threshold=cb_threshold)

        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production, headers=headers, query="action=reload_data&is_interval=1", timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query="action=reload_data&is_interval=1", timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.api_wallet_balance(self, tokopedia.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        # accounts
        res = accounts.marketplace_pixel(self, accounts.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        # gw
        res = gw.tokopoints_api_dv3points_main_v1(self, gw.host_production, headers={'cookie': ah.get_sid_cookie(user_id),'origin':'https://www.tokopedia.com'}, timeout=timeout, cb_threshold=cb_threshold)
        res = gw.tokopoints_api_dv3catalog_filter_v1(self, gw.host_production, headers={'cookie': ah.get_sid_cookie(user_id),'origin':'https://www.tokopedia.com'}, timeout=timeout, cb_threshold=cb_threshold)
        res = gw.tokopoints_api_dv3catalog_list_v1(self, gw.host_production, headers={'cookie': ah.get_sid_cookie(user_id),'origin':'https://www.tokopedia.com'}, query="category_id=0&page=1", timeout=timeout, cb_threshold=cb_threshold)
        res = gw.tokopoints_api_dv3points_history_v1(self, gw.host_production, headers={'cookie': ah.get_sid_cookie(user_id),'origin':'https://www.tokopedia.com'}, query="page=1&page_size=10", timeout=timeout, cb_threshold=cb_threshold)
        res = gw.tokopoints_api_dv3coupon_list_v1(self, gw.host_production, headers={'cookie': ah.get_sid_cookie(user_id),'origin':'https://www.tokopedia.com'}, query="include_extra=1&page=1", timeout=timeout, cb_threshold=cb_threshold)
        res = gw.tokopoints_api_dv3points_drawer_v1(self, gw.host_production, headers={'cookie': ah.get_sid_cookie(user_id),'origin':'https://www.tokopedia.com'}, timeout=timeout, cb_threshold=cb_threshold)
        res = gw.sellerinfo_api_notification_v1(self, gw.host_production, headers={'cookie': ah.get_sid_cookie(user_id),'origin':'https://www.tokopedia.com'}, timeout=timeout, cb_threshold=cb_threshold)

        # chat
        res = chat.tc_notifUnreads_v1(self, chat.host_production, user_id, device_id, headers={'cookie': ah.get_sid_cookie(user_id),'origin':'https://www.tokopedia.com'}, timeout=timeout, cb_threshold=cb_threshold)

        # mojito
        res = mojito.api_slides_v1(self, mojito.host_production, headers=headers, query="page[size]=25&filter[device]=512&filter[state]=1&filter[expired]=0", timeout=timeout, cb_threshold=cb_threshold)

        # topads
        res = topads.dashboard_deposit_v1_1(self, topads.host_production, user_id, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        if 'shop_id' in self.account:
            shop_id = self.account['shop_id']
            # reputationapp
            res = reputationapp.reputationapp_reputation_api_shop_P_v1(self, tokopedia.host_production, shop_id, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
            # gold merchant
            res = gold_merchant.shopstats_shopscore_sum_P_v1(self, gold_merchant.host_production, device_id, user_id, shop_id, headers=headers, timeout=timeout, cb_threshold=cb_threshold)
            # shop_id must be whitelisted, contact wallet team (@sandra.puspa)
            res = tokopedia.microfinance_micro_mt_preapprove_P(self, tokopedia.host_production, shop_id, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = tokopedia.host_production
    task_set = Tokopoints
    min_wait = 1500
    max_wait = 2500