from locust import HttpLocust, TaskSet, task
from modules import tokopedia, topads, pulsa, pulsa_api, gold_merchant, ace, mojito, accounts, tokocash, ace, graphql, gw, chat
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class HomeProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        device_id = self.config['device_id']
        user_id = self.account['user_id']
        home_domain = '/'
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page    = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold    = self.config['cb_threshold']
        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }

        #homepage
        res = tokopedia.page(self, tokopedia.host_production, home_domain, headers=headers, cb_threshold=cb_threshold, timeout=timeout_page)

        # wallet
        res = tokopedia.api_wallet_balance(self, tokopedia.host_production, cb_threshold=cb_threshold, headers=headers, timeout=timeout)
        

        # tokopedia ajax
        res = tokopedia.ajax_verification_number_pl(self, tokopedia.host_production, headers=headers, query="is_fluid=0", timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)

        # mojito
        res = mojito.os_api_brands_list_widget_desktop_v3(self, mojito.host_production, query='source=custom_json&total=12&userID={0}'.format(user_id), name = mojito.host_production + "/os/api/v3/brands/list/widget/desktop", cb_threshold=cb_threshold, timeout=timeout)        
        res = mojito.api_home_v1(self, mojito.host_production, headers={'x-device':'desktop-0.0', 'x-user-id':user_id}, timeout=timeout, cb_threshold=cb_threshold)
        
        # tokopoints
        res = gw.tokopoints_api_dv3points_drawer_v1(self, gw.host_production, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, cb_threshold=cb_threshold, timeout=timeout)
        res = gw.sellerinfo_api_notification_v1(self, gw.host_production, headers=headers, cb_threshold=cb_threshold, timeout=timeout)

        # ace
        res = ace.hoth_toppicks_list(self, ace.host_production, headers=headers, query='source=homepage&device=desktop&page=1&perPage=1&items=4&userid=%s' % (user_id), name=ace.host_production+"/hoth/toppicks/list",  cb_threshold=cb_threshold, timeout=timeout)

        # topads
        res = topads.promo_display_ads_v1_1(self, topads.host_production, headers=headers, query="src=fav_product&ep=&item=6%2C2&device=desktop&page=1&user_id="+user_id+"&ab_test=a&dep_id=1043%2C1372%2C1819", name=topads.host_production+"/promo/v1.1/display/ads?src=fav_product", cb_threshold=cb_threshold, timeout=timeout)

        # graphql
        res = graphql.graphql_feedQuery(self, graphql.host_graphql, headers=headers,  method='POST', json={"variables":{"limit":3,"userID":int(user_id),"cursor":"","page":1,"operationName":""}}, cb_threshold=cb_threshold, timeout=timeout_graphql)
        res = graphql.graphql_PromoSliderQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"PromoSliderQuery","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_TokopointsTokenQuery(self, graphql.host_graphql, headers=headers, json={"operationName":"TokopointsTokenQuery","variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)

        # recharge
        res = pulsa_api.category_list_v1_4(self, pulsa_api.host_production, headers=headers, query='device_id=8', cb_threshold=cb_threshold, timeout=timeout)
        res = pulsa_api.operator_list_v1_4(self, pulsa_api.host_production, headers=headers, cb_threshold=cb_threshold, timeout=timeout)
        res = pulsa_api.product_list_v1_4(self, pulsa_api.host_production, headers=headers, query='device_id=8', cb_threshold=cb_threshold, timeout=timeout)

        res = chat.tc_notifUnreads_v1(self, chat.host_production, headers={'cookie':ah.get_sid_cookie(user_id), 'origin': 'https://www.tokopedia.com'}, timeout=timeout, cb_threshold=cb_threshold)

        if 'shop_id' in self.account :
            shop_id = self.account['shop_id']
            res = tokopedia.reputationapp_reputation_api_shop_P_v1(self, tokopedia.host_production, shop_id, headers=headers, name=tokopedia.host_production+"/reputationapp/reputation/api/v1/shop/{shop_id}", cb_threshold=cb_threshold, timeout=timeout)            
            res = gold_merchant.shopStats_shopScoreSum_P_v1(self, gold_merchant.host_production, shop_id, method='GET', name=gold_merchant.host_production+"/v1/shopstats/shopscore/sum/{shop_id}")
            
            query = "shop_id=%s&shop_data=1" % (shop_id)
            res = topads.dashboard_deposit_v1_1(self, topads.host_production, user_id, headers=headers, query=query, name=topads.host_production+"/v1.1/dashboard/deposit?shop_id={shop_id}&shop_data=1", cb_threshold=cb_threshold, timeout=timeout)
            res = topads.dashboard_hmac_v1(self, topads.host_production, headers=headers,  query='device=%27desktop%27&method=GET&url=%2Fv1.1%2Fdashboard%2Fdeposit&content=shop_id%3D'+shop_id+'%26shop_data%3D1', name=topads.host_production+"/v1/dashboard/hmac", cb_threshold=cb_threshold, timeout=timeout)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = HomeProduction
    min_wait = 1500
    max_wait = 2500
