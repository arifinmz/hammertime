from locust import HttpLocust, TaskSet, task
from modules import tokopedia, pulsa, pulsa_api
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class UserBehavior(TaskSet):

    def on_start(self):
        self.config = self.configuration['production']
        self.account = ah.get_account(self, accounts=self.config['pulsa']['accounts_order_list'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        headers     = {
            'cookie': ah.get_sid_cookie(self.account['user_id'])
        }
        cb_threshold = self.config['cb_threshold']
        
        # homepage
        res = tokopedia.page(self, pulsa.host_production, '/', timeout=timeout_page, cb_threshold=cb_threshold)
        res = tokopedia.page(self, pulsa.host_production, '/login/ajax', timeout=timeout, cb_threshold=cb_threshold)
        # operator
        res = pulsa_api.operator_list_v1_4(self, pulsa_api.host_production, timeout=timeout, cb_threshold=cb_threshold)
        # product
        res = pulsa_api.product_list_v1_4(self, pulsa_api.host_production, query='device_id=8', timeout=timeout, cb_threshold=cb_threshold)
        
        # banner
        res = pulsa_api.banner_v1_4(self, pulsa_api.host_production,query='device_id=8', timeout=timeout, cb_threshold=cb_threshold)
        
        # get deposit
        res = pulsa.ajax_orderList(self, pulsa.host_production, query='action=get_deposit', headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        # last order
        res = pulsa.ajax_getlastorder(self, pulsa.host_production,headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        #rcn
        res = tokopedia.page(self, pulsa_api.host_production , '/rcn', headers=headers, timeout=timeout, cb_threshold=cb_threshold)
             

class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 1000
    max_wait = 2000
