from locust import HttpLocust, TaskSet, task
from modules import tokopedia, mojito, tome, gw, chat, pulsa, pulsa_api
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class OSHome(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        device_id = self.config['device_id']
        user_id = self.account['user_id']
        home_domain = '/?tab=official'
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page    = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold    = self.config['cb_threshold']
        
        headers = {
            'cookie':ah.get_sid_cookie(user_id)
        }

        res = tokopedia.page(self, tokopedia.host_production, home_domain, headers=headers, cb_threshold=cb_threshold, timeout=timeout_page)

        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production,  headers=headers, query='action=reload_data&is_interval=1', timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, headers=headers, query='action=reload_data&is_interval=1', cb_threshold=cb_threshold, timeout=timeout)
        
        res = mojito.api_tickers_v1(self, mojito.host_production, headers=headers, query='user_id=%s&page[size]=50&filter[device]=desktop&action=data_source_ticker' % (user_id), name=mojito.host_production+"/api/v1/tickers", cb_threshold=cb_threshold, timeout=timeout)
        res = mojito.api_slides_v1(self, mojito.host_production, headers=headers, query='page[size]=25&filter[device]=1&filter[state]=1&filter[expired]=0', cb_threshold=cb_threshold, timeout=timeout)
        
        for i in range(0, random.randint(3,10)):
            product_ids     = str(random.choice(self.config['dexter']['massive_products']))
            res = mojito.users_P_wishlist_check_P_v1(self, mojito.host_production, user_id, product_ids, headers=headers, timeout=timeout, cb_threshold=cb_threshold, name=mojito.host_production+"/v1/users/{user_id}/wishlist/check/{product_ids}")

        for i in range(0, random.randint(1,5)):
            shop            = random.choice(self.config['merchant']['os'])
            shop_id         = str(shop["id"])
            res = tome.ssi_user_following_v1(self, tome.host_production, headers=headers, query='shop_id=' + shop_id + '&user_id=' + user_id, name=tome.host_production+"/v1/ssi/user/isfollowing", cb_threshold=cb_threshold, timeout=timeout)

        res = tokopedia.ajax_verification_number_pl(self, tokopedia.host_production, headers=headers, query='is_fluid=1', cb_threshold=cb_threshold, timeout=timeout)
        
        res = tokopedia.api_wallet_balance(self, tokopedia.host_production, cb_threshold=cb_threshold, headers=headers, timeout=timeout)
        
        res = gw.tokopoints_api_dv3points_drawer_v1(self, gw.host_production, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, cb_threshold=cb_threshold, timeout=timeout)
        res = gw.sellerinfo_api_notification_v1(self, gw.host_production, headers=headers, cb_threshold=cb_threshold, timeout=timeout)
        
        res = chat.tc_notifUnreads_v1(self, chat.host_production, headers={'cookie':ah.get_sid_cookie(user_id), 'origin':'https://www.tokopedia.com'}, cb_threshold=cb_threshold, timeout=timeout)
        
        res = pulsa_api.category_list_v1_4(self, pulsa_api.host_production, headers=headers, query='device_id=8', cb_threshold=cb_threshold, timeout=timeout)
        res = pulsa_api.operator_list_v1_4(self, pulsa_api.host_production, headers=headers, cb_threshold=cb_threshold, timeout=timeout)
        res = pulsa_api.product_list_v1_4(self, pulsa_api.host_production, headers=headers, query='device_id=8', cb_threshold=cb_threshold, timeout=timeout)
        res = pulsa.ajax_getlastorder(self, pulsa.host_production, headers=headers,  cb_threshold=cb_threshold, timeout=timeout)
        

class WebsiteUser(HttpLocust):
    host = ""
    task_set = OSHome
    min_wait = 1500
    max_wait = 2500
