from locust import HttpLocust, TaskSet, task
from modules import tokopedia, hades, topads
import random


class CategoryNonIntermediary(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"] 

    @task(1)
    def task1(self):
        user_id = '0'
        category_id = random.choice(self.config['category']['category_id']['all_category'])
        platform = 'desktop'
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        product_ids = str(random.sample(self.config['dexter']['massive_products'], 15))

        #Hades
        res = hades.categories_P_features_v2(self, hades.host_production, category_id, name=hades.host_production+"/v2/categories/{category_id}/features", query='total_curated=5', timeout=timeout, cb_threshold=cb_threshold)        
        #Topads
        res = topads.promo_display_ads_v1_1(self, topads.host_production, query='user_id='+user_id+'&ep=product&item=8&src=directory&device='+platform+'&dep_id='+category_id+'&fshop=1', name=topads.host_production+'/promo/v1.1/display/ads?ep=product', timeout=timeout, cb_threshold=cb_threshold)
        res = topads.promo_display_ads_v1_1(self, topads.host_production, query='item=3&user_id='+user_id+'&ep=shop&src=directory&device='+platform+'&dep_id='+category_id, name=topads.host_production+'/promo/v1.1/display/ads?ep=shop', timeout=timeout, cb_threshold=cb_threshold)
        res = topads.promo_display_ads_v1_1(self, topads.host_production, query='user_id='+user_id+'&ep=cpm&item=1&src=directory&device='+platform+'&template_id=2,3&dep_id='+category_id, name=topads.host_production+'/promo/v1.1/display/ads?ep=cpm', timeout=timeout, cb_threshold=cb_threshold)
        
        #Ajax Check Quick Guide
        res = tokopedia.ajax_check_quick_guide_pl(self, tokopedia.host_production, query='type=guide_search_prosecure', timeout=timeout, cb_threshold=cb_threshold)
        #Ajax Prosecure
        res = tokopedia.ajax_prosecure_pl(self, tokopedia.host_production, query='action=shop_list', timeout=timeout, cb_threshold=cb_threshold)
        #Ajax Wishlist
        res = tokopedia.ajax_wishlist_pl(self, tokopedia.host_production, query='p_id='+product_ids+'&action=event_get_check_wishlist_key', cb_threshold=cb_threshold, timeout=timeout, hide_query=True)

class WebsiteUser(HttpLocust):
    host = tokopedia.host_production
    task_set = CategoryNonIntermediary
    min_wait = 1500
    max_wait = 2500


