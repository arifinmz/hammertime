import random
from locust import HttpLocust, TaskSet, task
from modules import tokopedia, topads, ace
from libs import randex

class SearchProductProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]

    @task(1)
    def task1(self):
        keyword = randex.generate_word(2,20)
        search_domain = '/search?st=product&q={0}'.format(keyword)
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        cb_threshold = self.config['cb_threshold']
        platform = 'desktop'

        res = tokopedia.page(self, tokopedia.host_production, search_domain, name=tokopedia.host_production+"/search?st=product", timeout=timeout_page, cb_threshold=cb_threshold)
    
        res = tokopedia.login(self, tokopedia.host_production, query='theme=iframe&p=https%3A%2F%2Fwww.tokopedia.com%2Fsearch%3Fst%3Dproduct%26q%3D{0}'.format(keyword), name=tokopedia.host_production+'/login?theme=iframe', timeout=timeout, cb_threshold=cb_threshold)
        
        res = topads.promo_display_ads_v1_1(self, topads.host_production, name=topads.host_production+"/promo/v1.1/display/ads?src=search&ep=cpm",  query='user_id=0&ep=cpm&item=1&src=search&device={0}&template_id=2%2C3&page=1&q={1}'.format(platform, keyword), timeout=timeout, cb_threshold=cb_threshold)
        res = topads.promo_display_ads_v1_1(self, topads.host_production, name=topads.host_production+"/promo/v1.1/display/ads?src=search&ep=product",  query='user_id=0&ep=product&item=10&src=search&device={0}&page=1&q={1}'.format(platform, keyword), timeout=timeout, cb_threshold=cb_threshold)
        
        res = ace.dynamic_attributes_v2(self, ace.host_production, query='scheme=https&device={0}&page=1&ob=23&st=product&source=search&q={1}'.format(platform, keyword), timeout=timeout, cb_threshold=cb_threshold, hide_query=True)
        res = ace.search_product_v3(self, ace.host_production, query='scheme=https&device={0}&catalog_rows=5&source=search&ob=23&st=product&rows=60&q={1}'.format(platform, keyword), timeout=timeout, cb_threshold=cb_threshold, hide_query=True)
        res = ace.guide_v1(self, ace.host_production, query='page=1&ob=23&st=product&q={0}'.format(keyword), hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = SearchProductProduction
    min_wait = 3000
    max_wait = 5000
