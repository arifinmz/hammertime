from locust import HttpLocust, TaskSet, task
from modules import tokopedia, pulsa, pulsa_api, ace, mojito, accounts


class HomeProduction(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]

    # User accessing home page without login first
    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        home_domain = '/'
        res = tokopedia.page(self, tokopedia.host_production, home_domain, timeout=timeout_page)

        # # accounts
        res = accounts.login_iframe(self, tokopedia.host_production, method='GET', query='theme=iframe&p=https%3A%2F%2Fwww.tokopedia.com%2F&t=1502251636879', timeout=timeout)
        res = accounts.marketplace_pixel(self, accounts.host_production, timeout=timeout)
        
        # recharge
        res = pulsa_api.category_list_v1_4(self, pulsa_api.host_production, query='device_id=8', timeout=timeout)
        res = pulsa_api.operator_list_v1_4(self, pulsa_api.host_production, timeout=timeout)
        res = pulsa_api.product_list_v1_4(self, pulsa_api.host_production, query='device_id=8', timeout=timeout)

        # ace
        res = ace.hoth_hotlist_home_v1(self, ace.host_production)
        res = ace.hoth_toppicks_widget(self, ace.host_production, query='source=home&device=desktop&item=4&count=4', timeout=timeout)

        # mojito
        res = mojito.api_tickers_v1(self, mojito.host_production, query='user_id=0&page[size]=50&filter[device]=desktop&action=data_source_ticker', timeout=timeout)
        res = mojito.api_slides_v1(self, mojito.host_production, query='page[size]=25&filter[device]=1&filter[state]=1&filter[expired]=0', timeout=timeout)
        #res = mojito.os_api_brands_list_widget_P_v2(self, mojito.host_production, 'desktop', timeout=timeout)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = HomeProduction
    min_wait = 1500
    max_wait = 2500