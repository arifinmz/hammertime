from locust import HttpLocust, TaskSet, task
from modules import tokopedia, inbox, tome, js, accounts, chat, gold_merchant, topads
import random

class ProductDetailProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]

    # User accessing product detail page without login first
    @task(1)
    def task1(self):
        user_id         = '0'
        product_id      = str(random.choice(self.config['dexter']['massive_products']))
        headers         = {
          'origin':"https://www.tokopedia.com"
        }
        access_status   = True

        # these 2 below variables is needed for v1/talk/response in desktop to prevent conflict with account ws
        device_id   = self.config['device_id']
        os_type     = self.config['os_type']

        timeout     = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        cb_threshold = self.config['cb_threshold']

        res = tome.product_P_v2(self, tome.host_production, product_id, query='p_id='+product_id, name=tome.host_production+"/v2/product/{product_id}", headers=headers, timeout=timeout, cb_threshold=cb_threshold, catch_response=True)
        if res.status_code < 400 :
          res.success()
          try:
            json_res = res.json()
            shop_id = str(json_res['data']['product_shop']['shop_id'])
            shop_domain = json_res['data']['product_shop']['shop_domain']
            product_alias = json_res['data']['product_alias']
            product_name = json_res['data']['product_name']
            product_domain = "/%s/%s" % (shop_domain, product_alias)
            child_cat_id = str(json_res['data']['product_category']['category_id'])
          except Exception as er:
            access_status = False
        else :
          if res.status_code == 422 :
            res.success()
          else :
            try:
              res.raise_for_status()
            except Exception as e:
              res.failure(e)
          access_status = False
        
        if access_status :
          # pdp page
          res = tokopedia.page(self, tokopedia.host_production, product_domain, name=tokopedia.host_production+"/{shop_domain}/{product_domain}", query='trkid=undefined', cb_threshold=cb_threshold, headers=headers, timeout=timeout_page, catch_response=True)
          if res.status_code < 400 or res.status_code == 404 :
            res.success()
          else :
            try:
              res.raise_for_status()
            except Exception as e:
              res.failure(e)

          #  ajax
          res = tokopedia.ajax_producte4_pl(self, tokopedia.host_production, query='p_id='+product_id+'&action=increase_view', name=tokopedia.host_production+'/ajax/product-e4.pl?action=increase_view', cb_threshold=cb_threshold, headers=headers, timeout=timeout)
          res = tokopedia.ajax_prosecure_pl(self, tokopedia.host_production, query='action=is_prosecure_shop&shop_id='+shop_id, hide_query=True, cb_threshold=cb_threshold, headers=headers, timeout=timeout)
          res = tokopedia.ajax_productPrevNext_pl(self, tokopedia.host_production, query='p_id='+product_id+'&action=prev_next&s_id='+shop_id, hide_query=True, cb_threshold=cb_threshold, headers=headers, timeout=timeout)
          # inbox
          res = inbox.talk_response_P_v1(self, inbox.host_production, shop_id, query='device_id='+device_id+'&os_type='+os_type, name=inbox.host_production+"/talk/v1/response/{shop_id}", cb_threshold=cb_threshold, headers=headers, timeout=timeout)
          res = inbox.talk_talkcount_P_v1(self, inbox.host_production, product_id, name=inbox.host_production+"/talk/v1/talkcount/{product_id}", cb_threshold=cb_threshold, headers=headers, timeout=timeout)
          # chat
          res = chat.tc_response_shop_P_v1(self, chat.host_production, shop_id, name=chat.host_production+"tc/v1/response/shop/{shop_id}", cb_threshold=cb_threshold, headers=headers, timeout=timeout)
          # js
          res = js.js_shoplogin(self, js.host_production, query='id='+shop_id+'&callback=show_last_online', hide_query=True, cb_threshold=cb_threshold, headers=headers, timeout=timeout)
          res = js.productstats_check(self, js.host_production, query='pid='+product_id+'&callback=show_product_stats', hide_query=True, cb_threshold=cb_threshold, headers=headers, timeout=timeout)
          # tome
          res = tome.product_P_variant_v2(self, tome.host_production, product_id, query='p_id='+product_id, name=tome.host_production+"/v2/product/{product_id}/variant", cb_threshold=cb_threshold, headers=headers, timeout=timeout)
          # gold merchant
          res = gold_merchant.product_video_v1(self, gold_merchant.host_production, product_id, name=gold_merchant.host_production+"/v1/product/video/{product_id}", cb_threshold=cb_threshold, headers=headers, timeout=timeout)
          # top ads
          res = topads.promo_display_ads_v1_1(self, topads.host_production, query='ep=product&item=5&src=pdp&device=desktop&user_id='+user_id+'&xparams={"product_id":'+product_id+',"product_name":'+product_name+',"child_cat_id":'+child_cat_id+',"source_shop_id":'+shop_id+'}', hide_query=True, cb_threshold=cb_threshold, headers=headers, timeout=timeout)
          # reputation app
          res = tokopedia.reputationapp_reputation_api_shop_P_v1(self, tokopedia.host_production, shop_id, name=tokopedia.host_production+"/reputationapp/reputation/api/v1/shop/{shop_id}", cb_threshold=cb_threshold, headers=headers, timeout=timeout)
          res = tokopedia.reputationapp_review_api_mosthelpful_v1(self, tokopedia.host_production, query='product_id='+product_id, hide_query=True, cb_threshold=cb_threshold, headers=headers, timeout=timeout)
          res = tokopedia.reputationapp_review_api_total_p_P_v1(self, tokopedia.host_production, product_id, name=tokopedia.host_production+"/reputationapp/review/api/v1/total/p/{product_id}", cb_threshold=cb_threshold, headers=headers, timeout=timeout)
          try:
            json_res = res.json()
            review_count = json_res['data']['review_count']
            if review_count > 0 :
              res = tokopedia.reputationapp_review_api_product_v1(self, tokopedia.host_production, query='product_id='+product_id+'&page=1&per_page=5', hide_query=True, cb_threshold=cb_threshold, headers=headers, timeout=timeout)
              json_res = res.json()
              review_ids = ""
              for x in range(0,len(json_res['data']['list'])):
                review_ids = review_ids +"~"+ str(json_res['data']['list'][x]['review_id'])
              res = tokopedia.reputationapp_review_api_like_dislike_v1(self, tokopedia.host_production, query='review_ids='+review_ids+'&user_id='+user_id, hide_query=True, cb_threshold=cb_threshold, headers=headers, timeout=timeout)
          except Exception as er:
            print er
            pass

class WebsiteUser(HttpLocust):
    host = ""
    task_set = ProductDetailProduction
    min_wait = 3000
    max_wait = 5000
