from locust import HttpLocust, TaskSet, task
from modules import tokopedia, accounts, ace
import random

class SearchShopProduction(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]

    @task(1)
    def task1(self):
        keyword = random.choice(self.config['search']['search_shop_keywords'])
        search_domain = '/search?st=shop&q='+keyword
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])
        cb_threshold = self.config['cb_threshold']

        res = tokopedia.page(self, tokopedia.host_production, search_domain, hide_query=True, timeout=timeout_page, cb_threshold=cb_threshold)
        res = tokopedia.ajax_prosecure_pl(self, tokopedia.host_production, query='action=shop_list', timeout=timeout, cb_threshold=cb_threshold)
        res = tokopedia.ajax_check_quick_guide_pl(self, tokopedia.host_production, query='type=guide_search_prosecure', timeout=timeout, cb_threshold=cb_threshold)
        res = accounts.marketplace_pixel(self, accounts.host_production, timeout=timeout, cb_threshold=cb_threshold)
        res = accounts.login_iframe(self, accounts.host_production, query='theme=iframe&p=https%3A%2F%2Fwww.tokopedia.com%2Fsearch%3Fst%3Dproduct%26q%3D', timeout=timeout, cb_threshold=cb_threshold)
        res = ace.dynamic_attributes_v2(self, ace.host_production, query='st=shop&q='+keyword+'&ob=23&source=search&device=desktop&callback=angular.callbacks._0', timeout=timeout, hide_query=True, cb_threshold=cb_threshold)
        res = ace.search_shop_v1(self, ace.host_production, query='device=desktop&q='+keyword+'&start=0&source=search_shop&scheme=https&page=1&rows=60&start=0&ob=23&full_domain=www.tokopedia.com&callback=angular.callbacks._1', timeout=timeout, hide_query=True, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = SearchShopProduction
    min_wait = 1500
    max_wait = 2500
