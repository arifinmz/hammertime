from locust import HttpLocust, TaskSet, task
from modules import tokopedia

class OfficialStore(TaskSet):
	@task(1)
	def task1(self):
		res = tokopedia.officialstore(self, tokopedia.host_production, name = tokopedia.host_production + "/official-store")

class WebsiteUser(HttpLocust):
	task_set = OfficialStore
	host = ""
	min_wait = 1000
	max_wait =  2500