from locust import HttpLocust, TaskSet, task
from modules import tome
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class SetProductAvailable(TaskSet):

    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config["stitch"]["seller"], login_type=ah.LOGIN_TYPE_APP)

    @task
    def task1(self):
        # set product available
        user_id = self.account['user_id']
        token = ah.get_token(user_id)
        products = self.config['products']
        header = {
            "Content-Type": "application/json",
            "origin": "https://www.tokopedia.com",
            "referer": "https://www.tokopedia.com",
            "Authorization": token
        }
        for product in products:
            product_id = product['id']
            tome_param = '{"product_id": ' + product_id + ', "product_status":1}'  # product status = 1 for active and 3 for warehouse/non active
            bodies = tome_param
            res = tome.product_P_v2_1(self, tome.host_production, product_id, headers=header, bodies=bodies, name=tome.host_production+'v2.1/product/{product_id}')
        print('Iteration complete. All state products have been changed')


class WebsiteUser(HttpLocust):
    host = ""
    task_set = SetProductAvailable
    min_wait = 1500
    max_wait = 2500