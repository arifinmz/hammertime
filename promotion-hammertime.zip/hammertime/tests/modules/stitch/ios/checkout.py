import json
from locust import HttpLocust, TaskSet, task
from modules import orderapp, ace, paymentapp, scrooge
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()


class Checkout(TaskSet):

    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config["stitch"]["accounts"])

    # User accessing home page with session from cookie
    @task(1)
    def task1(self):
        #atc
        device_id = self.config["device_id"]
        print('device_id', device_id)
        user_id = self.account["user_id"]
        print('user_id', user_id)
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        os_type = self.account["os_type_android"]
        token = ah.get_token(self.account['user_id'])
        print('token', token)
        body = {
            'address_id': '35459738',
            'notes': '',
            'product_id': '233532722',
            'quantity': '1',
            'receiver_name': 'Kate',
            'receiver_phone': '0712324',
            'shipping_id': '1',
            'shipping_product': '1',
            'user_id': '24305296',
            'device_id': device_id,
            'os_type': os_type
        }
        res = orderapp.action_txCart_add_to_cart_v4(self, orderapp.host_production, user_id, device_id, bodies=body, timeout=timeout, catch_response=True, cb_threshold=cb_threshold)
        print('atc', res.content)

        print('check voucher code', res.content)

        #get cart details
        body = {
            'method': 'POST',
            'bodies': {
                'device_id': device_id,
                'user_id': user_id,
                'os_type': os_type
            }
        }
        res = orderapp.tx_pl_v4(self, orderapp.host_production, user_id, device_id, bodies=body, timeout=timeout, catch_response=True, cb_threshold=cb_threshold)
        print('get cart details', res.content)

        # check voucher
        voucher_code = 'MZAFREONGKIR'
        body = {
            'device_id': device_id,
            'user_id': user_id,
            'os_type': os_type,
            'voucher_code': voucher_code,
        }
        res = orderapp.txVoucher_checkVoucherCode_pl_v4(self, orderapp.host_production, user_id, device_id, voucher_code,
                                                        bodies=body, timeout=timeout, catch_response=True,
                                                        cb_threshold=cb_threshold)
        print('check voucher code', res.content)

        #toppay get parameter
        body = {
            'user_id': user_id,
            'gateway': '99',
            'device_id': device_id,
            'os_type': os_type,
            'voucher_code': voucher_code
        }
        res = orderapp.action_tx_toppayGetParameter_pl_v4(self, orderapp.host_production, user_id, device_id, voucher_code,
                                                          bodies=body, timeout=timeout, catch_response=True,
                                                          cb_threshold=cb_threshold)
        print('toppay get parameter', res.content)
        respon = res.json()
        transaction_id = respon['data']['parameter']['transaction_id']
        transaction_date = respon['data']['parameter']['transaction_date']
        user_defined_value = respon['data']['parameter']['user_defined_value']
        product_id = respon['data']['parameter']['items'][0]['id']
        product_price = respon['data']['parameter']['items'][0]['price']
        product_quantity = respon['data']['parameter']['items'][0]['quantity']
        product_name = respon['data']['parameter']['items'][0]['name']
        shipment_id = respon['data']['parameter']['items'][1]['id']
        shipment_price = respon['data']['parameter']['items'][1]['price']
        shipment_quantity = respon['data']['parameter']['items'][1]['quantity']
        shipment_name = respon['data']['parameter']['items'][1]['name']
        voucher_id = respon['data']['parameter']['items'][2]['id']
        voucher_price = respon['data']['parameter']['items'][2]['price']
        voucher_quantity = respon['data']['parameter']['items'][2]['quantity']
        voucher_name = respon['data']['parameter']['items'][2]['name']
        nid = respon['data']['parameter']['nid']
        merchant_code = respon['data']['parameter']['merchant_code']
        profile_code = respon['data']['parameter']['profile_code']
        gateway_code = respon['data']['parameter']['gateway_code']
        amount = respon['data']['parameter']['amount']
        customer_email = respon['data']['parameter']['customer_email']
        signature = respon['data']['parameter']['signature']
        customer_name = respon['data']['parameter']['customer_name']
        msisdn = respon['data']['parameter']['customer_msisdn']
        currency = respon['data']['parameter']['currency']
        query = respon['data']['query_string']
        payment_metadata = query[query.find("payment_metadata")+17:query.find("&pid")]

        print('transaction_id', transaction_id)
        print('transaction_date', transaction_date)
        print('user_defined_value', user_defined_value)
        print('product_id', product_id)
        print('product_price', product_price)
        print('product_quantity', product_quantity)
        print('product_name', product_name)
        print('shipment_id', shipment_id)
        print('shipment_price', shipment_price)
        print('shipment_quantity', shipment_quantity)
        print('shipment_name', shipment_name)
        print('voucher_id', voucher_id)
        print('voucher_price', voucher_price)
        print('voucher_quantity', voucher_quantity)
        print('voucher_name', voucher_name)
        print('payment_metadata', payment_metadata)
        print('merchant_code', merchant_code)
        print('profile_code', profile_code)
        print('gateway_code', gateway_code)
        print('amount', amount)
        print('customer_email', customer_email)
        print('signature', signature)
        print('customer_name', customer_name)
        print('msisdn', msisdn)
        print('currency', currency)
        print('nid', nid)

        #payment
        body2 = {
            'customer_id': user_id,
            'customer_email': customer_email,
            'customer_name': customer_name,
            'transaction_id': transaction_id,
            'transaction_date': transaction_date,
            'amount': amount,
            'gateway_code': '',
            'currency': currency,
            'signature': signature,
            'items[id]': [product_id, shipment_id, voucher_id],
            'items[price]': [product_price, shipment_price, voucher_price],
            'items[quantity]': [product_quantity, shipment_quantity, voucher_quantity],
            'items[name]': [product_name, shipment_name, voucher_name],
            'nid': nid,
            'pid': '',
            'user_defined_value': user_defined_value,
            'merchant_code': merchant_code,
            'profile_code': profile_code,
            'language': 'id-ID',
            'payment_metadata':payment_metadata,
            'customer_msisdn': msisdn,

        }

        headers2 = {
            'cookie': self.account['cookie'],
            'Content-Type': 'application/x-www-form-urlencoded'
        }

        res = scrooge.payment_v2(self, scrooge.host_production, bodies=body2, headers=headers2, timeout=timeout, catch_response=True, cb_threshold=cb_threshold)
        print('payment', res.content)

        #confirm
        payment_amount = scrooge.get_value_from_selector(res.content, "name", "payment_amount")
        toppoints_amount = scrooge.get_value_from_selector(res.content, "name", "toppoints_amount")
        merchant_code = scrooge.get_value_from_selector(res.content, "name", "merchant_code")
        transaction_id = scrooge.get_value_from_selector(res.content, "name", "transaction_id")
        profile_code = scrooge.get_value_from_selector(res.content, "name", "profile_code")
        signature = scrooge.get_value_from_selector(res.content, "name", "signature")
        merchant_id = scrooge.get_value_from_selector(res.content, "name", "merchant_id")
        is_use_tokocash = scrooge.get_value_from_selector(res.content, "name", "is_use_tokocash")
        is_use_saldo = scrooge.get_value_from_selector(res.content, "name", "is_use_saldo")
        voucher_code = scrooge.get_value_from_selector(res.content, "name", "voucher_code")

        print('payment_amount', payment_amount)
        print('toppoints_amount', toppoints_amount)
        print('merchant_code', merchant_code)
        print('transaction_id', transaction_id)
        print('profile_code', profile_code)
        print('signature', signature)
        print('merchant_id', merchant_id)
        print('is_use_tokocash', is_use_tokocash)
        print('is_use_saldo', is_use_saldo)
        print('voucher_code', voucher_code)

        password = 'tokopedia2017'


        body = {
            "gateway_code": "TOKOPEDIAWALLET",
            "toppoints_amount": toppoints_amount,
            "payment_amount": payment_amount,
            "merchant_code": merchant_code,
            "transaction_id": transaction_id,
            "profile_code": profile_code,
            "gateways": "",
            "voucher_code": voucher_code,
            "signature": signature,
            "merchant_id": merchant_id,
            "is_use_tokocash": is_use_tokocash,
            "is_use_saldo": is_use_saldo,
            "passwordTokopedia": password
        }
        res = scrooge.payment_confirm_P_v2(self, scrooge.host_production, bodies=body, timeout=timeout, catch_response=True, cb_threshold=cb_threshold)
        print('confirm',res.content)
        respon = res.json()

        #thanks
        gateway_code = respon['data']['form']['gateway_code'][0]
        merchant_code = respon['data']['form']['merchant_code'][0]
        transaction_id = respon['data']['form']['transaction_id'][0]
        profile_code = respon['data']['form']['profile_code'][0]
        signature = respon['data']['form']['signature'][0]

        print('gateway_code', gateway_code)
        print('merchant_code', merchant_code)
        print('transaction_id', transaction_id)
        print('profile_code', profile_code)
        print('signature', signature)

        body = {
            "gateway_code": gateway_code,
            "merchant_code": merchant_code,
            "transaction_id": transaction_id,
            "profile_code": profile_code,
            "signature": signature
        }

        res = scrooge.payment_thanks_P_v2(self, scrooge.host_production, gateway_code, bodies=body, timeout=timeout, catch_response=True, cb_threshold=cb_threshold)
        print('thanks', res.content)




class WebsiteUser(HttpLocust):
    host = "https://tokopedia.com"
    task_set = Checkout
    min_wait = 1500
    max_wait = 2500
