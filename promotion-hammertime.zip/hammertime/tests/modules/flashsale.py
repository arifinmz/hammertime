from locust import HttpLocust, TaskSet, task
from modules import tokopedia, mojito
import random

class Flashsale(TaskSet):

    def on_start(self):
            self.config = self.configuration['production']
            
    @task(1)   
    def task1(self):
        campaign_id = self.config['campaign-endpoint']['campaign_id']
        campaign_id1 = self.config['campaign-endpoint']['campaign_id1']
        product_id = random.choice(self.config['campaign-endpoint']['product_id'])
       
        res = mojito.grpc_campaign_products(self, mojito.host_production, query="campaign_id="+campaign_id+"&source=landing-page", name=mojito.host_production+"/campaign/check/grpc/campaign/products?campagin_id={campaign_id}&source=landing-page")
        res = mojito.grpc_campaign_products(self, mojito.host_production, query="id="+product_id+"&source=brand-store", name=mojito.host_production+"/campaign/check/grpc/campaign/products?id={product_id}&source=brand-store")
        res = mojito.grpc_campaign_products(self, mojito.host_production, query="id="+product_id+"&source=paymentapp", name=mojito.host_production+"/campaign/check/grpc/campaign/products?id={product_id}&source=paymentapp")
        res = mojito.campaign_product_search(self, mojito.host_production, query="source=widget&as=1&ss=1&cid="+campaign_id, name=mojito.host_production+"/campaign/search/product_campaign/v1")
        res = mojito.grpc_campaign_info(self, mojito.host_production, query="campaign_id="+campaign_id1, name=mojito.host_production+"/campaign/check/grpc/campaign")

class WebsiteUser(HttpLocust):
    host    = ""
    task_set = Flashsale
    min_wait = 3000
    max_wait = 3000