from locust import HttpLocust, TaskSet, task
from modules import booking
import random

class BookingQR(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"] 

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        tkp_campaign_id = random.choice(self.config['spike']['qr_campaign'])

        res = booking.trigger_api_campaign_qr_verify_v1(self, booking.host_production, timeout=timeout, cb_threshold=cb_threshold, query='tkp_campaign_id='+tkp_campaign_id, hide_query=True)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = BookingQR
    min_wait = 1500
    max_wait = 2500