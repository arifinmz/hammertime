from locust import HttpLocust, TaskSet, task
from modules import feeds
from tests.helper.account_helper import AccountHelper
from libs import ht
from random import randint
import random

ah = AccountHelper()

class FeedsiOS (TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_APP)

    @task(4)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = str(randint(10,20000000))
        device_id = self.config['spike']['device_id_b']

        headers = {
            'X-Device':'ios-1.113',
            'Tkpd-SessionId':self.config['spike']['device_id_b'],
            'Tkpd-UserId':self.config['spike']['user_id_b']
        }
        cursor = ''
        for x in range(0,5):           
            res = feeds.feeds_P(self, feeds.host_production, user_id, device_id, platform='ios', headers=headers, timeout=timeout, cb_threshold=cb_threshold, query='cursor='+cursor, name=feeds.host_production+"/feeds/feeds/user_id page "+str(x), hide_query=True, catch_response = True)
            try :                    
                if not ht._is_failure_status_code(res):
                    resJSON = res.json()
                    cursor = resJSON['meta']['lastcursor']
                    res.success()
                else:
                    res.failure(res.content)                    
            except Exception:
                res.failure("Fail")

    @task(1)
    def task2(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = (random.choice(self.config['spike']['user_following']))
        device_id = self.config['spike']['device_id_b']

        headers = {
            'X-Device':'ios-1.113',
            'Tkpd-SessionId':self.config['spike']['device_id_b'],
            'Tkpd-UserId':self.config['spike']['user_id_b']
        }
        cursor = ''
        for x in range(0,5):           
            res = feeds.feeds_P(self, feeds.host_production, user_id, device_id, platform='ios', headers=headers, timeout=timeout, cb_threshold=cb_threshold, query='cursor='+cursor, name=feeds.host_production+"/feeds/feeds/user_following page "+str(x), hide_query=True, catch_response = True)
            try :                    
                if not ht._is_failure_status_code(res):
                    resJSON = res.json()
                    cursor = resJSON['meta']['lastcursor']
                    res.success()
                else:
                    res.failure(res.content)                    
            except Exception:
                res.failure("Fail")
                

class WebsiteUser(HttpLocust):
    host = ""
    task_set = FeedsiOS
    min_wait = 1500
    max_wait = 2500