from locust import HttpLocust, TaskSet, task
from modules import feeds
from tests.helper.account_helper import AccountHelper
from random import randint

ah = AccountHelper()

class FeedLiteNoHome(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, accounts=self.config["spike"]["accounts"], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(4)
    def task1(self):
        user_id = str(randint(10,20000000))
       
        headersLite = {
            "cookie":ah.get_sid_cookie(self.account['user_id']),
            "X-Device":"lite",
            "Tkpd-UserId":user_id
        }
       
        counter = 5
        cursor = ''
        for x in range(0,counter):
            try:      
                res = feeds.feeds_P(self, feeds.host_production, str(user_id), "", "desktop", headers=headersLite, query="limit=3&cursor="+cursor, name=feeds.host_production+"/feeds/feeds/random_user page "+str(x), timeout=(1,1))
                if res.status_code == 200 :
                    resJSON = res.json()
                    cursor = resJSON['meta']['lastcursor']
                else:
                    break
            except Exception,e:
                break


    @task(1)
    def task2(self):
        user_id=self.config['spike']['user_following'][randint(0,len(self.config['spike']['user_following'])-1)]
       
        headersLite = {
            "cookie":ah.get_sid_cookie(self.account['user_id']),
            "X-Device":"lite",
            "Tkpd-UserId":user_id
        }
       
        counter = 5
        cursor = ''
        for x in range(0,counter):
            try:
                res = feeds.feeds_P(self, feeds.host_production, str(user_id), "", "lite", headers=headersLite, query="limit=3&cursor="+cursor, name=feeds.host_production+"/feeds/feeds/user_following page "+str(x), timeout=(1,1))
                if res.status_code == 200 :
                    resJSON = res.json()
                    cursor = resJSON['meta']['lastcursor']
                else:
                    break
            except Exception,e:
                break
        

class WebsiteUser(HttpLocust):
    host = ""
    task_set = FeedLiteNoHome
    min_wait = 1000
    max_wait = 1500