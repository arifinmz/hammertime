from locust import HttpLocust, TaskSet, task
from modules import booking

class BookingShake2(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"] 

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        
        res = booking.trigger_api_campaign_av_verify_v1(self, booking.host_production, timeout=timeout, cb_threshold=cb_threshold, query='is_audio=false', hide_query=True)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = BookingShake2
    min_wait = 1500
    max_wait = 2500