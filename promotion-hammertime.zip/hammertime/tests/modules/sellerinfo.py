from locust import HttpLocust, TaskSet, task
from modules import gw
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class Sellerinfo(TaskSet):
    def on_start(self):

        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['merchant']['shop_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)
    
    @task(1)
    def task1(self):

        user_id = self.account['user_id']
        timeout     = (self.config['timeout'][0],self.config['timeout'][1])
        
        headers={
            'cookie': ah.get_sid_cookie(self.account['user_id']),
            'content-type':'application/json'
        }
        cb_threshold = self.config['cb_threshold']

        res = gw.sellerinfo_api_notification_v1(self, gw.host_production, method='GET', headers=headers, timeout=timeout, cb_threshold=cb_threshold)
        res = gw.sellerinfo_api_info_list_v1(self, gw.host_production, method='GET', query="page=1&section_id=0", headers=headers, timeout=timeout, cb_threshold=cb_threshold)



class WebsiteUser(HttpLocust):
    host = ""
    task_set = Sellerinfo
    min_wait = 1000
    max_wait = 1500