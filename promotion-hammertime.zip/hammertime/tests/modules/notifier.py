from locust import HttpLocust, TaskSet, task
from modules import notifier
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class Notifier(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(10)
    def task1(self):
        user_id = self.account['user_id']
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold    = self.config['cb_threshold']

        #randomize notification template
        notification_template = random.choice(self.config['notifier']['template_list'])

        json = {
            "template" : notification_template,
            "params" : {},
            "user_id" : [int(user_id)]
        }
        res = notifier.send_v2(self, notifier.host_production, '/smart', json=json, 
            name=notifier.host_production+'/api/v2/send/smart', cb_threshold=cb_threshold, timeout=timeout)

    #this one is for 10% percentage (less possibility that notification is sent to all bearers)
    @task(1)
    def task2(self):
        user_id = self.account['user_id']
        timeout         = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold    = self.config['cb_threshold']

        #randomize notification template
        notification_template = random.choice(self.config['notifier']['template_list'])

        json = {
            "template" : notification_template,
            "params" : {},
            "user_id" : [int(user_id)]
        }
        res = notifier.send_v2(self, notifier.host_production, '', json=json, 
            name=notifier.host_production+'/api/v2/send', cb_threshold=cb_threshold, timeout=timeout)



class WebsiteUser(HttpLocust):
    host = ""
    task_set = Notifier
    min_wait = 1500
    max_wait = 2500
