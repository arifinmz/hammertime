from locust import HttpLocust, TaskSet, task
from modules import mojito
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class OfficialStore(TaskSet):
    def on_start(self):       
        if not hasattr(OfficialStore,'config_loaded'):
			OfficialStore.test_config = self.configuration['production']
			OfficialStore.config_loaded = True

    @task(1)
    def task1(self):
        timeout = (OfficialStore.test_config['timeout'][0],OfficialStore.test_config ['timeout'][1])
        cb_threshold = OfficialStore.test_config['cb_threshold']
        shop_id_os = random.choice(OfficialStore.test_config['merchant_tribe']['shop_id_os'])
        shop_id_random = str(random.randint(100000,150000))
        shop_id = random.choice([shop_id_os, shop_id_random])
        price = random.randint(100,500000000)
        shipping_id = str(random.randint(100000000000,100006000000))
        quantity = random.choice([1,random.randint(2,100)])
        product_id = random.randint(100000000,100050000)
        
        json_paymentLimitValidation = {
               "data": [
                    {
                        "product_id": product_id,
                        "product_price": price,
                        "quantity": quantity,
                        "shop_id": int(shop_id),
                        "shipping_id": shipping_id
                    }
                        ],
                "total_amount": price
            }
        json_calculation=[
            {
            "data":[
                {
                    "dep_id": 1764,
                    "product_id": 306674906,
                    "product_name": "Test123 - Putih, XXS",
                    "product_price": 10000,
                    "quantity": 1
                }
            ],
            "payment_id":"209411575",
            "refunded_voucher": 0,
            "shop_id": 1707045,
            "order_id":180745398,
            "invoice": "INV/20180717/XVIII/VII/180793557"
            },
            {
            "data":[
                {
                    "dep_id": 558,
                    "product_id": 297863429,
                    "product_name": "jajanan",
                    "product_price": 100,
                    "quantity": 1
                }
            ],
            "payment_id":"210452313",
            "refunded_voucher": 0,
            "shop_id": 1707045,
            "order_id":181576422,
            "invoice": "INV/20180719/XVIII/VII/181624581"
            },
            {
            "data":[
                {
                    "dep_id": 1187,
                    "product_id": 297865549,
                    "product_name": "Siap",
                    "product_price": 10000,
                    "quantity": 1
                }
            ],
            "payment_id":"213870073",
            "refunded_voucher": 0,
            "shop_id": 1707045,
            "order_id":184349621,
            "invoice": "INV/20180727/XVIII/VII/184397780"
            },
            {
            "data":[
                {
                    "dep_id": 1187,
                    "product_id": 297865549,
                    "product_name": "Siap",
                    "product_price": 10000,
                    "quantity": 2
                }
            ],
            "payment_id":"213870073",
            "refunded_voucher": 0,
            "shop_id": 1707045,
            "order_id":184349620,
            "invoice": "INV/20180727/XVIII/VII/184397779"
            },
            {
            "data":[
                {
                    "dep_id": 1764,
                    "product_id": 306674906,
                    "product_name": "Test123 - Putih, XXS",
                    "product_price": 10000,
                    "quantity": 1
                }
            ],
            "payment_id":"212047324",
            "refunded_voucher": 0,
            "shop_id": 1707045,
            "order_id":182864297,
            "invoice": "INV/20180723/XVIII/VII/182912456"
            }
        ]

        json_refund=[
            {
            "data":[
                { 
                    "dep_id": 1764,
                    "product_id": 306674906,
                    "product_name": "Test123 - Putih, XXS",
                    "product_price": 100000,
                    "quantity": 1
                }
            ],
            "payment_id":"210414020",
            "shop_id": 1707045,
            "order_id":181544984,
            "total_amount": 0,
            "refunded_voucher":0
            },
            {
            "data":[
                { 
                    "dep_id": 558,
                    "product_id": 297863429,
                    "product_name": "jajanan",
                    "product_price": 100,
                    "quantity": 1
                }
            ],
            "payment_id":"210402933",
            "shop_id": 1707045,
            "order_id":181535908,
            "total_amount": 0,
            "refunded_voucher":0
            },
            {
            "data":[
                { 
                    "dep_id": 558,
                    "product_id": 297863429,
                    "product_name": "jajanan",
                    "product_price": 100,
                    "quantity": 1
                }
            ],
            "payment_id":"209926236",
            "shop_id": 1707045,
            "order_id":181155314,
            "total_amount": 0,
            "refunded_voucher":0
            },
            {
            "data":[
                { 
                    "dep_id": 558,
                    "product_id": 297863429,
                    "product_name": "jajanan",
                    "product_price": 100,
                    "quantity": 1
                }
            ],
            "payment_id":"209919158",
            "shop_id": 1707045,
            "order_id":181149383,
            "total_amount": 0,
            "refunded_voucher":0 
            },
            {
            "data":[
                { 
                    "dep_id": 558,
                    "product_id": 297863429,
                    "product_name": "jajanan",
                    "product_price": 100,
                    "quantity": 1
                }
            ],
            "payment_id":"209901660",
            "shop_id": 1707045,
            "order_id":181134566,
            "total_amount": 0,
            "refunded_voucher":0
            }
        ]
        
        headers={
            "Authorization": "TKPD Tokopedia:ZTdiYTRmMWEyOTU0MmNhYTRkZGQxMDA5MzIyYTkxNjBjYjBmMmNhOA==",
            "X-Method": "GET",
            "Content-SHA1":	"b6875e10e2856b9ad529ad0e88e244c9e518538c",
            "X-Date": "Wed, 31 May 2017 15:19:11 +0700",
            "X-Path": "/os/api/v1/customlogistics/rates"
        }
        shop_id_os_logistik = random.choice(OfficialStore.test_config ['merchant_tribe']['shop_id_os_logistik'])
        destination_id = str(random.randint(1,5680))
    
        res = mojito.os_api_commission_calculation_v1(self, mojito.host_production,method="POST",json=random.choice(json_calculation), name=mojito.host_production+"/os/api/v1/commission/calculation",timeout=timeout, cb_threshold=cb_threshold)
        res = mojito.os_api_commission_refund_v1(self, mojito.host_production, method="POST", json=random.choice(json_refund), name=mojito.host_production+"/os/api/v1/commission/refund",timeout=timeout, cb_threshold=cb_threshold)
        res = mojito.os_api_customLogistics_rates_P_P_v1(self, shop_id_os_logistik, destination_id, mojito.host_production, headers=headers, name=mojito.host_production+"/os/api/v1/customlogistics/rates/{shop_id}/{destination_id}",timeout=timeout, cb_threshold=cb_threshold)
        res = mojito.os_api_brands_isofficial_P_v1(self,shop_id, mojito.host_production, name=mojito.host_production+"/os/api/v1/brands/isofficial/{shop_id}",timeout=timeout, cb_threshold=cb_threshold)
        res = mojito.os_api_paymentLimitValidate_v1(self, mojito.host_production, method="POST",json=json_paymentLimitValidation, name=mojito.host_production+"/os/api/v1/payment/limit-level/validate",timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = "https://mojito.tokopedia.com"
    task_set = OfficialStore
    min_wait = 1000
    max_wait = 1500
