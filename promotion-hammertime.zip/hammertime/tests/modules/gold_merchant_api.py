from locust import HttpLocust, TaskSet, task
from modules import gold_merchant
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class GoldMerchant(TaskSet):

    def on_start(self):
        if not hasattr(GoldMerchant, 'config_loaded'):
			GoldMerchant.test_config = self.configuration['production']
			GoldMerchant.config_loaded = True

    @task(1)
    def task1(self):

        shop_id = str(random.randint(100000,150000))
        product_id = str(random.randint(2500000,2600000))
        user_id = str(random.randint(500000,700000))

        bodies_cashback = {
            "data": [{"shop_id": 1533162, "product_ids": [244523383, 289606914, 281390559, 289602173, 281038287, 273169858, 272166988, 268641498, 272139977, 272358376]
            }]
        }

        timeout     = (GoldMerchant.test_config['timeout'][0],GoldMerchant.test_config['timeout'][1])
        cb_threshold = GoldMerchant.test_config['cb_threshold']

        res = gold_merchant.shopStats_shopScoreSum_P_v1(self, gold_merchant.host_production, shop_id, method='GET', name=gold_merchant.host_production+"/v1/shopstats/shopscore/sum/{shop_id}", timeout=timeout, cb_threshold=cb_threshold)
        res = gold_merchant.shopStats_getBuyerGraph_P_v2(self, gold_merchant.host_production, shop_id, method='GET', name=gold_merchant.host_production+"/v2/shop_stats/get_buyer_graph/{shop_id}", timeout=timeout, cb_threshold=cb_threshold)
        res = gold_merchant.shopStats_getBuyerTable_P_v2(self, gold_merchant.host_production, shop_id, method='GET', name=gold_merchant.host_production+"/v2/shop_stats/get_buyer_table/{shop_id}", timeout=timeout, cb_threshold=cb_threshold)
        res = gold_merchant.shopStats_getBuyerLocation_P_v2(self, gold_merchant.host_production, shop_id, method='GET', name=gold_merchant.host_production+"/v2/shop_stats/get_buyer_location/{shop_id}", timeout=timeout, cb_threshold=cb_threshold)
        res = gold_merchant.shopStats_getTransactionGraph_P_v2(self, gold_merchant.host_production, shop_id, method='GET', name=gold_merchant.host_production+"/v2/shop_stats/get_transaction_graph/{shop_id}", timeout=timeout, cb_threshold=cb_threshold)
        res = gold_merchant.shopStats_getTransactionStat_P_v2(self, gold_merchant.host_production, shop_id, method='GET', name=gold_merchant.host_production+"/v2/shop_stats/get_transaction_stat/{shop_id}", timeout=timeout, cb_threshold=cb_threshold)
        res = gold_merchant.shopStats_getTransactionTable_P_v2(self, gold_merchant.host_production, shop_id, method='GET', name=gold_merchant.host_production+"/v2/shop_stats/get_transaction_table/{shop_id}", timeout=timeout, cb_threshold=cb_threshold)
        res = gold_merchant.shopStats_getProductGraph_P_v2(self, gold_merchant.host_production, shop_id, method='GET', name=gold_merchant.host_production+"/v2/shop_stats/get_product_graph/{shop_id}", timeout=timeout, cb_threshold=cb_threshold)
        res = gold_merchant.shopStats_getPopularProduct_P_v2(self, gold_merchant.host_production, shop_id, method='GET', name=gold_merchant.host_production+"/v2/shop_stats/get_popular_product/{shop_id}", timeout=timeout, cb_threshold=cb_threshold)
        res = gold_merchant.shopStats_getProductTable_P_v2(self, gold_merchant.host_production, shop_id, method='GET', name=gold_merchant.host_production+"/v2/shop_stats/get_product_table/{shop_id}", timeout=timeout, cb_threshold=cb_threshold)

        res = gold_merchant.product_video_v1(self, gold_merchant.host_production, product_id, method='GET', name=gold_merchant.host_production+"/v1/product/video/{product_id}", timeout=timeout, cb_threshold=cb_threshold)
        res = gold_merchant.mobile_featuredProduct_P_v1(self, gold_merchant.host_production, shop_id, method='GET', name=gold_merchant.host_production+"/v1/mobile/featured_product/{shop_id}", timeout=timeout, cb_threshold=cb_threshold)
        res = gold_merchant.user_shop_P_v1(self, gold_merchant.host_production, user_id, method='GET', name=gold_merchant.host_production+"/v1/user/{user_id}/shop", timeout=timeout, cb_threshold=cb_threshold)
        res = gold_merchant.tx_cashback_v1(self, gold_merchant.host_production, method='POST', json = bodies_cashback, name=gold_merchant.host_production+"/v1/tx/cashback", timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = GoldMerchant
    min_wait = 3000
    max_wait = 5000
