from locust import HttpLocust, TaskSet, task
from modules import tokopedia, graphql
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class RedeemOnly(TaskSet):

    def on_start(self):
       if not hasattr(RedeemOnly, 'config_loaded') :
           RedeemOnly.test_config = self.configuration['production']
           RedeemOnly.large_users = self.team_configuration(RedeemOnly.test_config['dexter']['20k_accounts'])
           RedeemOnly.config_loaded = True
       self.account = ah.get_account(self, accounts=RedeemOnly.large_users, login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id = self.account ['user_id']
        headers = {
            'Cookie': ah.get_sid_cookie(user_id),
            'Authorization':'TKPD Tokopedia:/qygTKKOPX2W2olsPJ+6XJTSAh4=',
            'X-Method':'POST',
            'Date':'Tue, 09 Jan 2018 16:37:39 +0700',
            'Content-MD5':'acce038869bfb60d24de0e70d6c2f8fc',
            'Content-Type':'application/json'
        }

        timeout_graphql = (RedeemOnly.test_config['timeout_graphql'][0],RedeemOnly.test_config['timeout_graphql'][1])
        cb_threshold = RedeemOnly.test_config["cb_threshold"]

        redeemVariables = {
            "catalog_id": 1246,
            "is_gift": 0
        }


        #gql
        res = graphql.graphql_validateRedeem(self, graphql.host_graphql, headers=headers, json={"variables":redeemVariables,"operationName":"validateRedeem"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_redeemCoupon(self, graphql.host_graphql, headers=headers, json={"variables":redeemVariables,"operationName":"redeemCoupon"}, timeout=timeout_graphql, cb_threshold=cb_threshold)


class WebsiteUser(HttpLocust):
    host = ""
    task_set = RedeemOnly
    min_wait = 1000
    max_wait = 1000
