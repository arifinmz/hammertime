from locust import HttpLocust, TaskSet, task
from modules import tokopedia, accounts, graphql
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class TokopointsPage(TaskSet):
    def on_start(self):
       if not hasattr(TokopointsPage, 'config_loaded') :
           TokopointsPage.test_config = self.configuration['production']
           TokopointsPage.large_users = self.team_configuration(TokopointsPage.test_config['dexter']['20k_accounts'])
           TokopointsPage.config_loaded = True
       self.account = ah.get_account(self, accounts=TokopointsPage.large_users, login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        cb_threshold = TokopointsPage.test_config['cb_threshold']
        timeout = (TokopointsPage.test_config['timeout'][0], TokopointsPage.test_config['timeout'][1])
        timeout_graphql = (TokopointsPage.test_config['timeout_graphql'][0], TokopointsPage.test_config['timeout_graphql'][1])        
        timeout_page = (TokopointsPage.test_config['timeout_page'][0], TokopointsPage.test_config['timeout_page'][1])

        headers = {
            'cookie': ah.get_sid_cookie(user_id)
        }
        tickerHeaders = {
            "cookie":ah.get_sid_cookie(user_id),
            "origin":"https://www.tokopedia.com"
        }
        homeTabsGoQueryVariables = {
            "sortID": 1,
            "categoryID": 0,
            "pointRange": 0,
            "page": 1,
            "limit": 5
        }
        isAuthenticatedQueryVariables = {
            "key": "/tokopoints/tukar-point"
        }
        sessionQueryVariables = {
            "source": user_id
        }

        # gql
        res = graphql.graphql_UserPointsQuery(self, graphql.host_graphql, headers=headers, json={"variables":{},"operationName":"UserPointsQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_QuestTickerQuery(self, graphql.host_graphql, headers=tickerHeaders, json={"variables":{},"operationName":"QuestTickerQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold) 
        res = graphql.graphql_TokopointsMainGolangQuery(self, graphql.host_graphql, headers=headers, json={"variables":{},"operationName":"TokopointsMainGolangQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold) 
        res = graphql.graphql_HomeTabsGoQuery(self, graphql.host_graphql, headers=headers, json={"variables":homeTabsGoQueryVariables,"operationName":"HomeTabsGoQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold) 
        res = graphql.graphql_hachikoMainQuery(self, graphql.host_graphql, headers=headers, json={"variables":{},"operationName":"HachikoMainQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold) 
        res = graphql.graphql_isAuthenticatedQuery(self, graphql.host_graphql, headers=headers, json={"variables":isAuthenticatedQueryVariables,"operationName":"isAuthenticatedQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold) 
        res = graphql.graphql_FloatingEggQuery(self, graphql.host_graphql, headers=headers, json={"variables":{},"operationName":"FloatingEggQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold) 
        res = graphql.graphql_sessionQuery(self, graphql.host_graphql, headers=headers, json={"variables":sessionQueryVariables,"operationName":"SessionQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = TokopointsPage
    min_wait = 1000
    max_wait = 1000