from locust import HttpLocust, TaskSet, task
from modules import graphql
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class TokopointsPage(TaskSet):
    def on_start(self):
       if not hasattr(TokopointsPage, 'config_loaded') :
           TokopointsPage.test_config = self.configuration['production']
           TokopointsPage.large_users = self.team_configuration(TokopointsPage.test_config['dexter']['20k_accounts'])
           TokopointsPage.config_loaded = True
       self.account = ah.get_account(self, accounts=TokopointsPage.large_users, login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        cb_threshold = TokopointsPage.test_config['cb_threshold']
        timeout_graphql = (TokopointsPage.test_config['timeout_graphql'][0], TokopointsPage.test_config['timeout_graphql'][1])        

        headers = {
            'Cookie': ah.get_sid_cookie(user_id),
            'Authorization':'TKPD Tokopedia:/qygTKKOPX2W2olsPJ+6XJTSAh4=',
            'X-Method':'POST',
            'Date':'Tue, 09 Jan 2018 16:37:39 +0700',
            'Content-MD5':'acce038869bfb60d24de0e70d6c2f8fc',
            'Content-Type':'application/json'   
        }

        # gql
        res = graphql.graphql_FloatingEggQuery(self, graphql.host_graphql, headers=headers, json={"variables":{},"operationName":"FloatingEggQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold) 
        print(res.content)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = TokopointsPage
    min_wait = 1000
    max_wait = 1000