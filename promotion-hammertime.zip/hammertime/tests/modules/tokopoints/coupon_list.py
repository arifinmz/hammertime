from locust import HttpLocust, TaskSet, task
from modules import tokopedia, accounts, graphql
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class CouponList(TaskSet):
    def on_start(self):
       if not hasattr(CouponList, 'config_loaded') :
           CouponList.test_config = self.configuration['production']
           CouponList.large_users = self.team_configuration(CouponList.test_config['dexter']['20k_accounts'])
           CouponList.config_loaded = True
       self.account = ah.get_account(self, accounts=CouponList.large_users, login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        cb_threshold = CouponList.test_config['cb_threshold']
        timeout = (CouponList.test_config['timeout'][0], CouponList.test_config['timeout'][1])
        timeout_graphql = (CouponList.test_config['timeout_graphql'][0], CouponList.test_config['timeout_graphql'][1])        
        timeout_page = (CouponList.test_config['timeout_page'][0], CouponList.test_config['timeout_page'][1])

        headers = {
            'cookie': ah.get_sid_cookie(user_id)
        }
        myCouponsListGoQueryVariables = {
            "includeExtraInfo": 1,
            "categoryIDCoupon": 0,
            "page": 1,
            "limit": 10
        }

        res = graphql.graphql_MyCouponsListGoQuery(self, graphql.host_graphql, headers=headers, json={"variables":myCouponsListGoQueryVariables,"operationName":"MyCouponsListGoQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = CouponList
    min_wait = 1000
    max_wait = 1000