from locust import HttpLocust, TaskSet, task
from modules import tokopedia, graphql
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class CatalogDetailPage(TaskSet):

    def on_start(self):
       if not hasattr(CatalogDetailPage, 'config_loaded') :
           CatalogDetailPage.test_config = self.configuration['production']
           CatalogDetailPage.large_users = self.team_configuration(CatalogDetailPage.test_config['dexter']['20k_accounts'])
           CatalogDetailPage.config_loaded = True
       self.account = ah.get_account(self, accounts=CatalogDetailPage.large_users, login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id = self.account ['user_id']
        slug = random.choice (['TDISC','FS10B','FCGMTIX','FCGENT','FS20B','CB50B','CB100B','JNE15','JT15','DATAH','EMAS50','PLNH'])
        headers = {
            'Cookie': ah.get_sid_cookie(user_id),
            'Authorization':'TKPD Tokopedia:/qygTKKOPX2W2olsPJ+6XJTSAh4=',
            'X-Method':'POST',
            'Date':'Tue, 09 Jan 2018 16:37:39 +0700',
            'Content-MD5':'acce038869bfb60d24de0e70d6c2f8fc',
            'Content-Type':'application/json'
            
        }

        timeout_page = (CatalogDetailPage.test_config['timeout_page'][0],CatalogDetailPage.test_config['timeout_page'][1])
        timeout_graphql = (CatalogDetailPage.test_config['timeout_graphql'][0],CatalogDetailPage.test_config['timeout_graphql'][1])
        cb_threshold = CatalogDetailPage.test_config["cb_threshold"]
        catalog_detail_page = ('/tokopoints/detail/'+slug)

        catalogDetailVariables = {
            "slug": slug
        }
        isAuthenticatedQueryVariables = {
            "key": ("/tokopoints/detail"+slug)
        }
        sessionQueryVariables = {
            "source": user_id
        }

        #catalog detail page
        res = tokopedia.page(self, tokopedia.host_production_m, catalog_detail_page, name=tokopedia.host_production_m+"/tokopoints/detail/{slug}", headers=headers, timeout=timeout_page)
 
        #gql
        res = graphql.graphql_hachikoMainQuery(self, graphql.host_graphql, headers=headers, json={"variables":{},"operationName":"HachikoMainQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_isAuthenticatedQuery(self, graphql.host_graphql, headers=headers, json={"variables":isAuthenticatedQueryVariables,"operationName":"isAuthenticatedQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)  
        res = graphql.graphql_TokopointsMainGolangQuery(self, graphql.host_graphql, headers=headers, json={"variables":{},"operationName":"TokopointsMainGolangQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_UserPointsQuery(self, graphql.host_graphql, headers=headers, json={"variables":{},"operationName":"UserPointsQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_sessionQuery(self, graphql.host_graphql, headers=headers, json={"variables":sessionQueryVariables,"operationName":"SessionQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_hachikoCatalogDetailQuery(self, graphql.host_graphql, headers=headers, json={"variables":catalogDetailVariables,"operationName":"hachikoCatalogDetailQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = CatalogDetailPage
    min_wait = 1000
    max_wait = 1000
