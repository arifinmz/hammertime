from locust import HttpLocust, TaskSet, task
from modules import tokopedia, graphql
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class TukarPoints(TaskSet):

    def on_start(self):
       if not hasattr(TukarPoints, 'config_loaded') :
           TukarPoints.test_config = self.configuration['production']
           TukarPoints.large_users = self.team_configuration(TukarPoints.test_config['dexter']['20k_accounts'])
           TukarPoints.config_loaded = True
       self.account = ah.get_account(self, accounts=TukarPoints.large_users, login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):
        user_id = self.account ['user_id']
        device_id = 'b'
        headers = {
            'Cookie': ah.get_sid_cookie(user_id),
            'Authorization':'TKPD Tokopedia:/qygTKKOPX2W2olsPJ+6XJTSAh4=',
            'X-Method':'POST',
            'Date':'Tue, 09 Jan 2018 16:37:39 +0700',
            'Content-MD5':'acce038869bfb60d24de0e70d6c2f8fc',
            'Content-Type':'application/json'
            
        }

        tukar_point_domain = '/tokopoints/tukar-point'
        timeout_graphql = (TukarPoints.test_config['timeout_graphql'][0],TukarPoints.test_config['timeout_graphql'][1])
        cb_threshold = TukarPoints.test_config["cb_threshold"]
        
        isAuthenticatedQueryVariables = {
            "key": "/tokopoints/tukar-point"
        }
        tokopointsCatalogListVariables = {
            "sortID": 1,
            "categoryID": 1,
            "pointRange": 0,
            "page": 1,
            "limit": 25
        }
        redeemVariables = {
            "catalog_id": 1132,
            "is_gift": 0
        }
        sessionQueryVariables = {
            "source": user_id
        }
        
        #gql tukar points
        res = graphql.graphql_CatalogListGoQuery(self, graphql.host_graphql, headers=headers, json={"variables":tokopointsCatalogListVariables,"operationName":"CatalogListGoQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold) 
        res = graphql.graphql_hachikoMainQuery(self, graphql.host_graphql, headers=headers, json={"variables":{},"operationName":"HachikoMainQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_isAuthenticatedQuery(self, graphql.host_graphql, headers=headers, json={"variables":isAuthenticatedQueryVariables,"operationName":"isAuthenticatedQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)  
        res = graphql.graphql_TokopointsMainGolangQuery(self, graphql.host_graphql, headers=headers, json={"variables":{},"operationName":"TokopointsMainGolangQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_UserPointsQuery(self, graphql.host_graphql, headers=headers, json={"variables":{},"operationName":"UserPointsQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_FloatingEggQuery(self, graphql.host_graphql, headers=headers, json={"variables":{},"operationName":"FloatingEggQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_sessionQuery(self, graphql.host_graphql, headers=headers, json={"variables":sessionQueryVariables,"operationName":"SessionQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_tokopointsCarouselQuery(self, graphql.host_graphql, headers=headers, json={"variables":{},"operationName":"TokopointsCarouselQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        #gql redeem
        res = graphql.graphql_validateRedeem(self, graphql.host_graphql, headers=headers, json={"variables":redeemVariables,"operationName":"validateRedeem"}, timeout=timeout_graphql, cb_threshold=cb_threshold)
        res = graphql.graphql_redeemCoupon(self, graphql.host_graphql, headers=headers, json={"variables":redeemVariables,"operationName":"redeemCoupon"}, timeout=timeout_graphql, cb_threshold=cb_threshold)


class WebsiteUser(HttpLocust):
    host = ""
    task_set = TukarPoints
    min_wait = 1000
    max_wait = 1000