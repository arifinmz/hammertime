from locust import HttpLocust, TaskSet, task
from libs import bearer_token
from modules import ws_v4, accounts, events_api
from tests.helper.account_helper import AccountHelper
import json, random, time, string, datetime

ah = AccountHelper()

class EventsAPI(TaskSet):

    def on_start(self):
        if not hasattr(EventsAPI, 'config_loaded') :
            EventsAPI.test_config = self.configuration["production"]
            EventsAPI.config_loaded = True
        self.account = ah.get_account(self, accounts=EventsAPI.test_config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_APP)
        self.events_account = EventsAPI.test_config["events"]["accounts"][0]

    @task(1)
    def task1(self):
        user_id = self.account["user_id"]
        user_email = self.account["email"]
        user_name = self.events_account["name"]
        identity_id = self.events_account["identity_id"]
        bday = self.events_account["birthday"]
        age = self.events_account["age"]
        gender = self.events_account["gender"]
        ver_phone = self.events_account["phone"]
        bearer_token = ah.get_token(user_id)
        test_failed = False
        timeout = (EventsAPI.test_config['timeout'][0],EventsAPI.test_config['timeout'][1])
        cb_threshold = EventsAPI.test_config["cb_threshold"]

        product = group = qty = price =invoice_id = invoice_item = commision =  0
        product_forms = []
        commision_type = ''
        desc = display_name = provider_ticket_id = entity_product_name = ev_display_name = title = ''
        phone = phone_masked = full_name = entity_image = thumbnail_image = min_start_date = start_date = end_date = tnc = ''
        category = mrp = discounted_price = 0

        # GET EVENT LIST
        res = events_api.api_h_event_v1(self, events_api.host_production, timeout=timeout, cb_threshold=cb_threshold)

        # SEARCH EVENT BY CATEGORY
        child_category_id = "4"
        query = "tags=&time=&child_category_ids=%s" % (child_category_id)
        res = events_api.api_s_event_v1(self, events_api.host_production, query=query, timeout=timeout, cb_threshold=cb_threshold)            

        # GET EVENT DETAIL

        seo_url = 'seaworld'

        res = events_api.api_p_P_v1(self, events_api.host_production, seo_url, timeout=timeout, 
            cb_threshold=cb_threshold,  catch_response=True, 
            name=events_api.host_production+"/v1/api/p/{seo_url}")            
        if res is not None and hasattr(res, "status_code") and res.status_code == 200:
            try:
                json_list = res.json()
                product = json_list["data"]["id"]
                category = json_list["data"]["category_id"]
                ev_display_name = json_list["data"]["display_name"]
                title = json_list["data"]["title"]
                tnc = json_list["data"]["tnc"]

                schedule_index = random.randint(0,len(json_list["data"]["schedules"])-1)
                schedule = json_list["data"]["schedules"][schedule_index]["schedule"]["id"]

                group = json_list["data"]["schedules"][schedule_index]["groups"][0]["id"]

                package_index = random.randint(0,len(json_list["data"]["schedules"][schedule_index])-1)
                package = json_list["data"]["schedules"][schedule_index]["groups"][0]["packages"][package_index]["id"]
                
                qty = json_list["data"]["schedules"][schedule_index]["groups"][0]["packages"][package_index]["min_qty"]
                price = json_list["data"]["schedules"][schedule_index]["groups"][0]["packages"][package_index]["sales_price"]

                forms = json_list["data"]["forms"]
                if forms is not None:
                    for x in forms:
                        require = x['required']
                        x['required'] = str(require)
                        x['value'] = identity_id
                        product_forms.append(x)


                entity_image = json_list["data"]["image_web"]
                thumbnail_image = json_list["data"]["thumbnail_web"]

                jsonpath_minstartdate = json_list["data"]["min_start_date"]
                min_start_date = datetime.datetime.fromtimestamp(jsonpath_minstartdate).strftime('%d/%m/%Y %H:%M:%S')

                jsonpath_startdate = json_list["data"]["schedules"][schedule_index]["groups"][0]["packages"][package_index]["start_date"]
                start_date = datetime.datetime.fromtimestamp(jsonpath_startdate).strftime('%d/%m/%Y %H:%M:%S')

                jsonpath_enddate = json_list["data"]["schedules"][schedule_index]["groups"][0]["packages"][package_index]["end_date"]
                end_date = datetime.datetime.fromtimestamp(jsonpath_enddate).strftime('%d/%m/%Y %H:%M:%S')

                test_failed = False
                res.success()
            except Exception as e:
                test_failed = True
                res.failure(res.content + " " + str(e))
        else:
            try:
                test_failed = True
                res.raise_for_status()
            except Exception as e:
                res.failure(e)
        
        if test_failed :
            return



        # VALIDATE_SELECTION
        bodies = {
            "product_id":product,
            "schedule_id":schedule,
            "group_id":group,
            "package_id":package,
            "quantity":qty
        }
        res = events_api.api_event_validateSelection_v1(self, events_api.host_production, json=bodies, 
            timeout=timeout, cb_threshold=cb_threshold)

        total_price= price*qty
        bodies = {
            "cart_items": [
                {
                    "configuration": {
                    "price": total_price,
                    "sub_config": {
                        "name": user_name
                    }
                    },
                    "meta_data": {
                    "entity_category_id": category,
                    "entity_category_name": "",
                    "entity_group_id": group,
                    "entity_packages": [
                        {
                        "package_id": package,
                        "quantity": qty,
                        "description": "",
                        "price_per_seat": price,
                        "area_code": [],
                        "seat_ids": [],
                        "seat_row_ids": [],
                        "seat_physical_row_ids": [],
                        "actual_seat_nos": [],
                        "session_id": "",
                        "product_id": product,
                        "group_id": group,
                        "schedule_id": schedule,
                        "area_id": ""
                        }
                    ],
                    "total_ticket_count": qty,
                    "entity_product_id": product,
                    "entity_schedule_id": schedule,
                    "entity_passengers": product_forms,
                    "entity_address": {
                        "Name": "",
                        "address": "",
                        "city": "",
                        "email": user_email,
                        "mobile": ver_phone,
                        "latitude": "",
                        "longitude": ""
                    },
                    "city_searched": "",
                    "entity_end_time": "",
                    "entity_start_time": "",
                    "tax_per_quantity": [
                        {
                        "entertainment": 0
                        },
                        {
                        "service": 0
                        }
                    ],
                    "other_charges": [
                        {
                        "conv_fee": 0
                        }
                    ],
                    "total_tax_amount": 0,
                    "total_other_charges": 0,
                    "total_ticket_price": total_price,
                    "entity_image": ""
                    },
                    "quantity": qty,
                    "product_id": product
                }
                ],
                "promocode": ""
        }
        
        res = events_api.api_expresscart_verify_v1(self, events_api.host_production, user_id, bearer_token, json=bodies, name =events_api.host_production+"/v1/api/expresscart/verify", 
            timeout=timeout, cb_threshold=cb_threshold,  catch_response=True)
        if res is not None and hasattr(res, "status_code") and res.status_code == 200:
            try:
                json_list = res.json()
                invoice_id = json_list["data"]["cart"]["cart_items"][0]["meta_data"]["entity_packages"][0]["tkp_invoice_id"]
                invoice_item = json_list["data"]["cart"]["cart_items"][0]["meta_data"]["entity_packages"][0]["tkp_invoice_item_id"]
                commision = json_list["data"]["cart"]["cart_items"][0]["meta_data"]["entity_packages"][0]["commision"]
                commision_type = json_list["data"]["cart"]["cart_items"][0]["meta_data"]["entity_packages"][0]["commision_type"]
                desc = json_list["data"]["cart"]["cart_items"][0]["meta_data"]["entity_packages"][0]["description"]
                display_name = json_list["data"]["cart"]["cart_items"][0]["meta_data"]["entity_packages"][0]["display_name"]
                provider_ticket_id = json_list["data"]["cart"]["cart_items"][0]["meta_data"]["entity_packages"][0]["provider_ticket_id"]
                try:
                    forms = json_list["data"]["cart"]["cart_items"][0]["meta_data"]["entity_passengers"]
                except Exception:
                    forms = ''
                phone = json_list["data"]["cart"]["user"]["phone"]
                phone_masked = json_list["data"]["cart"]["user"]["phone_masked"]
                mrp = json_list["data"]["cart"]["cart_items"][0]["mrp"]
                discounted_price = json_list["data"]["cart"]["cart_items"][0]["discounted_price"]
                full_name = json_list["data"]["cart"]["user"]["full_name"]
                test_failed = False
                res.success()
            except Exception as e:
                test_failed = True
                res.failure(res.content + " " + str(e))
        else:
            try:
                test_failed = True
                res.raise_for_status()
            except Exception as e:
                res.failure(e)
        
        if test_failed :
            return



        # EXPRESSCART CHECKOUT
        bodies = {
            "cart_items": [
                {
                    "product_id": product,
                    "quantity": qty,
                    "meta_data": {
                        "city_searched": "",
                        "end_date": end_date,
                        "entity_address": {
                            "address": "",
                            "city": "",
                            "district": "",
                            "email": user_email,
                            "latitude": "",
                            "longitude": "",
                            "mobile": phone,
                            "name": "",
                            "state": ""
                        },
                        "entity_category_id": category,
                        "entity_category_name": "",
                        "entity_end_time": "",
                        "entity_group_id": group,
                        "entity_image": thumbnail_image,
                        "entity_invoice_id": 0,
                        "entity_packages": [
                            {
                                "actual_seat_nos": [],
                                "address": "Indonesia",
                                "base_price": 0,
                                "city": "41+ Kota",
                                "commision": commision,
                                "commision_type": commision_type,
                                "description": desc,
                                "dimension": "",
                                "display_name": display_name,
                                "error_message": "",
                                "group_id": group,
                                "group_name": "",
                                "invoice_status": "BOOKED",
                                "package_id": package,
                                "package_price": price,
                                "payment_type": "-",
                                "price_per_seat": price,
                                "product_id": product,
                                "provider_invoice_indentifier": identity_id,
                                "provider_schedule_id": str(schedule),
                                "provider_ticket_id": provider_ticket_id,
                                "quantity": qty,
                                "schedule_id": schedule,
                                "show_date": "",
                                "str_seatinfo": "",
                                "tkp_invoice_id": invoice_id,
                                "tkp_invoice_item_id": invoice_item,
                                "total_ticket_count": qty,
                                "validity": "",
                                "venue_detail": "",
                                "vouchers": None
                            }
                        ],
                        "entity_product_id": product,
                        "entity_product_name": entity_product_name,
                        "entity_provider_id": 3,
                        "entity_schedule_id": schedule,
                        "entity_start_time": "",
                        "links": "",
                        "max_end_date": "",
                        "min_start_date": min_start_date,
                        "other_charges": [
                            {
                                "conv_fee": 0
                            }
                        ],
                        "start_date": start_date,
                        "tax_per_quantity": [
                            {
                                "entertainment": 0
                            },
                            {
                                "service": 0
                            }
                        ],
                        "total_other_charges": 0,
                        "total_tax_amount": 0,
                        "total_ticket_count": qty,
                        "total_ticket_price": total_price,
                        "use_pdf": 0
                    },
                    "configuration": {
                        "price": total_price,
                        "conv_fee": 0,
                        "sub_config": {
                            "name": full_name
                        }
                    },
                    "display_sequnce": 1,
                    "category_id": 0,
                    "image_url": "",
                    "item_id": "345pid",
                    "product_name": "",
                    "title": "Events",
                    "product": {
                        "id": product,
                        "category_id": category,
                        "provider_id": 0,
                        "display_name": ev_display_name,
                        "title": title,
                        "action_text": "",
                        "censor": "",
                        "genre": "",
                        "url": "",
                        "seo_url": "",
                        "image_web": entity_image,
                        "thumbnail_web": thumbnail_image,
                        "image_app": entity_image,
                        "thumbnail_app": thumbnail_image,
                        "tnc": tnc,
                        "offer_text": "",
                        "promotion_text": "",
                        "autocode": "",
                        "mrp": 0,
                        "sales_price": price,
                        "child_category": None,
                        "merchant": None
                    },
                    "price": price,
                    "mrp": mrp,
                    "total_price": total_price,
                    "discounted_price": discounted_price,
                    "fulfillment_service_id": 1
                }
            ],
            "total_conv_fee": 0,
            "total_price": total_price,
            "grand_total": total_price,
            "promocode": "",
            "promocode_discount": 0,
            "promocode_cashback": 0,
            "promocode_failure_message": "",
            "promocode_success_message": "",
            "promocode_status": "",
            "count": qty,
            "user": {
                "name": "",
                "full_name": full_name,
                "email": user_email,
                "secondary_email": "",
                "user_id": user_id,
                "bday": bday,
                "gender": gender,
                "age": age,
                "phone": phone,
                "secondary_phone": "",
                "phone_masked": phone_masked,
                "register_date": "2015-12-15T09:25:29Z",
                "lang": "id",
                "phone_verified": True,
                "roles": None,
                "profile_picture": "https://imagerouter.tokopedia.com/img/100-square/default_v3-usrnophoto2.png",
                "status": 0,
                "created_password": False,
                "client_id": "",
                "completion": 0,
                "remember": 0,
                "access_token": "",
                "w_refresh_token": "",
                "Balance": {
                    "is_active": False,
                    "balance": 0,
                    "balance_text": "",
                    "useable_balance": 0,
                    "useable_balance_text": "",
                    "limit": 0,
                    "limit_text": "",
                    "threshold": 0,
                    "threshold_text": "",
                    "threshold_limit": 0,
                    "threshold_limit_text": ""
                }
              }
            }

        if forms:
            bodies["cart_items"]["meta_data"]["entity_passengers"] = forms
            
        res = events_api.api_expresscart_checkout_v1(self, events_api.host_production, user_id, bearer_token, 
            json=bodies, timeout=timeout, cb_threshold=cb_threshold)


class WebsiteUser(HttpLocust):
    host = ""
    task_set = EventsAPI
    min_wait = 3000
    max_wait = 5000
