from locust import HttpLocust, TaskSet, task
from modules import mojito

class UserBehavior(TaskSet):

    @task(1)
    def task1(self):
        os_type = 1
        device_id = 'b'
        user_id = '5480842'
        product_ids = '14253495,14265790,617168,580447,14286849,14286862,14286861,14286863,14288593,14131163'

        res = mojito.api_tickers_v1(self, mojito.host_staging, user_id=user_id)
        res = mojito.api_slides_v1(self, mojito.host_staging)
        res = mojito.os_api_brands_list_widget_P_v2(self, mojito.host_staging, "desktop")
        res = mojito.users_P_wishlist_check_P_v2(self, mojito.host_staging, user_id, device_id, product_ids, name=mojito.host_staging+"/users/"+user_id+"/wishlist/check/"+product_ids+"/v2")
        res = mojito.layout_category_v1_3(self, mojito.host_staging)
        res = mojito.users_P_recentview_products_v1(self, mojito.host_staging, user_id, device_id, name=mojito.host_staging+"/users/"+user_id+"/recentview/products/v1")
        res = mojito.users_P_wishlist_products_v1_0_3(self, mojito.host_staging, user_id, device_id, name=mojito.host_staging+"/v1.0.3/users/"+user_id+"/wishlist/products")

class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 3000
    max_wait = 5000
