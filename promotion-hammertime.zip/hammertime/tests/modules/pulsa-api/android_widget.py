from locust import HttpLocust, TaskSet, task
from libs import bearer_token
from modules import ws_v4, accounts, pulsa_api
from tests.helper.account_helper import AccountHelper
import json, random

ah = AccountHelper()

class AndroidWidget(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]      
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        user_id = self.account["user_id"]
        user_email = self.account["email"]
        bearer_token = ah.get_token(user_id)
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        os_type = self.config["os_type"]
        device_id = "4"
        category_id_1 = category_id_2 = category_id_3 = category_id_4 = 0
        test_failed = False

    	# GET STATUS
        res = pulsa_api.status_v1_4(self, pulsa_api.host_production, timeout=timeout, cb_threshold=cb_threshold)

    	# GET CATEGORY LIST
        res = pulsa_api.category_list_v1_4(self, pulsa_api.host_production, timeout=timeout, cb_threshold=cb_threshold)
    		
        try:
            json_list = res.json()
            category_id_1 = json_list["data"][0]["id"]
            category_id_2 = json_list["data"][1]["id"]
            category_id_3 = json_list["data"][2]["id"]
            category_id_4 = json_list["data"][3]["id"]
    		
        except Exception as e:
            test_failed = True

        # GET CATEGORY BASED ON CATEGORY_ID
        if not test_failed:
            res = pulsa_api.category_P_v1_4(self, pulsa_api.host_production, category_id_1, name= pulsa_api.host_production+'/v1.4/category/{category_id}',timeout=timeout, cb_threshold=cb_threshold)
            res = pulsa_api.category_P_v1_4(self, pulsa_api.host_production, category_id_2, name= pulsa_api.host_production+'/v1.4/category/{category_id}',timeout=timeout, cb_threshold=cb_threshold)	
            res = pulsa_api.category_P_v1_4(self, pulsa_api.host_production, category_id_3, name= pulsa_api.host_production+'/v1.4/category/{category_id}',timeout=timeout, cb_threshold=cb_threshold)
            res = pulsa_api.category_P_v1_4(self, pulsa_api.host_production, category_id_4, name= pulsa_api.host_production+'/v1.4/category/{category_id}',timeout=timeout, cb_threshold=cb_threshold)

            # GET FAVORITE LIST OF EACH CATEGORY_ID
            query = 'os_type=%s&device_id=%s&user_id=%s&category_id=%s' % (os_type, device_id, user_id, category_id_1)
            res = pulsa_api.favorite_list_v1_4(self, pulsa_api.host_production, user_id, query=query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
            
            query = 'os_type=%s&device_id=%s&user_id=%s&category_id=%s' % (os_type, device_id, user_id, category_id_2)
            res = pulsa_api.favorite_list_v1_4(self, pulsa_api.host_production, user_id, query=query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

            query = 'os_type=%s&device_id=%s&user_id=%s&category_id=%s' % (os_type, device_id, user_id, category_id_3)
            res = pulsa_api.favorite_list_v1_4(self, pulsa_api.host_production, user_id, query=query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

            query = 'os_type=%s&device_id=%s&user_id=%s&category_id=%s' % (os_type, device_id, user_id, category_id_4)
            res = pulsa_api.favorite_list_v1_4(self, pulsa_api.host_production, user_id, query=query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = AndroidWidget
    min_wait = 3000
    max_wait = 5000