from locust import HttpLocust, TaskSet, task
from libs import bearer_token
from modules import pulsa_api, ws_v4, accounts
from tests.helper.account_helper import AccountHelper
import random

authorization = {}
ah = AccountHelper()

class CheckoutVgame(TaskSet):

    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        if not hasattr(CheckoutVgame, 'config_loaded') :
            CheckoutVgame.test_config = self.configuration["production"]
            CheckoutVgame.config_loaded = True
        self.account = ah.get_account(self, accounts=CheckoutVgame.test_config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        user_id = self.account["user_id"]
        device_id = CheckoutVgame.test_config["device_id"]
        os_type = CheckoutVgame.test_config["os_type"]
        timeout = (CheckoutVgame.test_config['timeout'][0],CheckoutVgame.test_config['timeout'][1])
        cb_threshold = CheckoutVgame.test_config["cb_threshold"]
        category_id = '6'
        query = 'os_type=%s&device_id=%s&user_id=%s' % (os_type, device_id, user_id)
        test_failed = False

        # GET CATEGORY DETAIL
        res = pulsa_api.category_P_v1_4(self, pulsa_api.host_production,category_id,cb_threshold=cb_threshold, timeout=timeout)

        # GET OPERATOR LIST
        res = pulsa_api.operator_list_v1_4(self, pulsa_api.host_production,cb_threshold=cb_threshold, timeout=timeout)

        # GET PRODUCT LIST
        res = pulsa_api.product_list_v1_4(self, pulsa_api.host_production,cb_threshold=cb_threshold, timeout=timeout)

        # GET FAVORITE LIST
        res = pulsa_api.favorite_list_v1_4(self, pulsa_api.host_production, user_id,cb_threshold=cb_threshold, timeout=timeout, query=query, hide_query=True)

       # add to cart
        json = {  
            "data":{  
                "attributes":{  
                    "device_id":4,
                    "fields":[  
                        {  
                        "name":"client_number",
                        "value":""
                        }
                    ],
                    "identifier":{  
                        "device_token":device_id,
                        "os_type":os_type,
                        "user_id":user_id,
                    },
                    "instant_checkout":False,
                    "ip_address":"",
                    "product_id":349,
                    "user_agent":"dexter/hammertime",
                    "user_id":user_id
                },
                "type":"add_cart"
            }
        }

        cart_response = pulsa_api.cart_v1_4(self, pulsa_api.host_production, user_id, name=pulsa_api.host_production+"/v1.4/cart{megaxus}", json=json,cb_threshold=cb_threshold)
        
        # checkout
        if cart_response is not None and cart_response.status_code is 200 :
            try :
                atc_response = cart_response.json()
                json = {  
                    "data":{  
                        "type":"checkout",
                        "attributes":{  
                            "voucher_code":"QACASHBACK",
                            "transaction_amount":atc_response['data']['attributes']['price_plain'],
                            "access_token":"",
                            "wallet_refresh_token":"",
                            "ip_address":"",
                            "user_agent":"dexter/hammertime"
                        },
                        "relationships":{  
                            "cart":{  
                                "data":{  
                                "type":"cart",
                                "id":atc_response['data']['id']
                                }
                            }
                        }
                    }
                }
            except Exception, e:
                test_failed=True
            
            if not test_failed:
                res = pulsa_api.checkout_v1_4(self, pulsa_api.host_production, user_id, json=json, name=pulsa_api.host_production+"/v1.4/checkout{megaxus}", hide_query=True, query=query,cb_threshold=cb_threshold,timeout=timeout)

class WebsiteUser(HttpLocust):
    host = pulsa_api.host_production
    task_set = CheckoutVgame
    min_wait = 1000
    max_wait = 2000