from locust import HttpLocust, TaskSet, task
from libs import bearer_token
from modules import ws_v4, accounts, pulsa_api
from tests.helper.account_helper import AccountHelper
import json, random

ah = AccountHelper()

class AndroidNativePage(TaskSet):    

    def on_start(self):
        self.config = self.configuration["production"]      
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        user_id = self.account["user_id"]
        user_email = self.account["email"]
        bearer_token = ah.get_token(user_id)
        category_id = "1"
        device_id = "4"
        test_failed = False
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        os_type = self.config["os_type"]


        # GET CATEGORY BASED ON CATEGORY_ID
    	res = pulsa_api.category_P_v1_4(self, pulsa_api.host_production, category_id, name= pulsa_api.host_production+'/v1.4/category/{category_id}', timeout=timeout, cb_threshold=cb_threshold)

    	# GET FAVORITE LIST OF EACH CATEGORY_ID
        query = 'os_type=%s&device_id=%s&user_id=%s&category_id=%s' % (os_type, device_id, user_id, category_id)
        res = pulsa_api.favorite_list_v1_4(self, pulsa_api.host_production, user_id, query=query, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)


class WebsiteUser(HttpLocust):
    host = ""
    task_set = AndroidNativePage
    min_wait = 3000
    max_wait = 5000