from locust import HttpLocust, TaskSet, task
from modules import pulsa_api, ws_v4, accounts
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class CheckoutVgame(TaskSet):

    def on_start(self):
        if not hasattr(CheckoutVgame, 'config_loaded') :
            CheckoutVgame.test_config = self.configuration["production"]
            CheckoutVgame.config_loaded = True
        self.account = ah.get_account(self, accounts=CheckoutVgame.test_config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_APP)
    
    # add to cart
    @task(1)
    def task1(self):
        user_id = self.account["user_id"]
        device_id = CheckoutVgame.test_config["device_id"]
        os_type = CheckoutVgame.test_config["os_type"]
        timeout = (CheckoutVgame.test_config['timeout'][0],CheckoutVgame.test_config['timeout'][1])
        cb_threshold = CheckoutVgame.test_config["cb_threshold"]

        bodies = {  
            "data":{  
                "attributes":{  
                    "device_id":4,
                    "fields":[  
                        {  
                        "name":"client_number",
                        "value":""
                        }
                    ],
                    "identifier":{  
                        "device_token":device_id,
                        "os_type":os_type,
                        "user_id":user_id,
                    },
                    "instant_checkout":False,
                    "ip_address":"",
                    "product_id":349,
                    "user_agent":"Android Tokopedia Application/com.tokopedia.customerappp v.2.8.1.9 (OPPO A33fw; Android; API_22; Version5.1.1)",
                    "user_id":user_id
                },
                "type":"add_cart"
            }
        }
        cart_response = pulsa_api.cart_v1_4(self, pulsa_api.host_production, user_id, json=bodies, 
            timeout=timeout, cb_threshold=cb_threshold)

        # checkout
        if cart_response.status_code == 200 :
            atc_response = cart_response.json()
            bodies = {  
                "data":{  
                    "type":"checkout",
                    "attributes":{  
                        "voucher_code":"QACASHBACK",
                        "transaction_amount":atc_response['data']['attributes']['price_plain'],
                        "access_token":"",
                        "wallet_refresh_token":"",
                        "ip_address":"",
                        "user_agent":"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:51.0) Gecko/20100101 Firefox/51.0"
                    },
                    "relationships":{  
                        "cart":{  
                            "data":{  
                            "type":"cart",
                            "id":atc_response['data']['id']
                            }
                        }
                    }
                }
            }
            query = 'os_type=%s&device_id=%s&user_id=%s' % (os_type, device_id, user_id)
            res = pulsa_api.checkout_v1_4(self, pulsa_api.host_production, user_id, json=bodies, hide_query=True, 
                timeout=timeout, query=query, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = CheckoutVgame
    min_wait = 1000
    max_wait = 2000
