from locust import HttpLocust, TaskSet, task
from libs import bearer_token
from modules import ws_v4, accounts, pulsa_api
from tests.helper.account_helper import AccountHelper
from android_widget import AndroidWidget
from android_ios_widget_see_all import AndroidIosWidgetSeeAll
from android_native_page import AndroidNativePage
from ios_widget import IosWidget
from homepage_desktop import HomepageDesktop
from marketplace_widget import MarketplaceWidget
import json, random

ah = AccountHelper()

class HomeAll(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"]
        account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BOTH)

        self.AndroidWidget = AndroidWidget(self)
        self.AndroidWidget.config = self.config
        self.AndroidWidget.account = account

        self.AndroidIosWidgetSeeAll = AndroidIosWidgetSeeAll(self)
        self.AndroidIosWidgetSeeAll.config = self.config

        self.AndroidNativePage = AndroidNativePage(self)
        self.AndroidNativePage.config = self.config
        self.AndroidNativePage.account = account

        self.IosWidget = IosWidget(self)
        self.IosWidget.config = self.config
        self.IosWidget.account = account

        self.HomepageDesktop = HomepageDesktop(self)
        self.HomepageDesktop.config = self.config
        self.HomepageDesktop.account = account

        self.MarketplaceWidget = MarketplaceWidget(self)
        self.MarketplaceWidget.config = self.config
        self.MarketplaceWidget.account = account


    @task(1)
    def task1(self):          
        # user access android widget (ios apps homepage)
        self.AndroidWidget.task1()

        # user access android widget lihat semua
        self.AndroidIosWidgetSeeAll.task1()

        # user access android native page
        self.AndroidNativePage.task1()

        # user access ios widget (ios apps homepage)
        self.IosWidget.task1()

        # user access ios widget lihat semua
        self.AndroidIosWidgetSeeAll.task1()

        # user access desktop homepage
        self.HomepageDesktop.task1()

        # user access marketplace widget
        self.MarketplaceWidget.task1()


class WebsiteUser(HttpLocust):
    host = ""
    task_set = HomeAll
    min_wait = 3000
    max_wait = 5000