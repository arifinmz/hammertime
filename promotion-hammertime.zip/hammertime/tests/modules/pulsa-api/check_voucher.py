from locust import HttpLocust, TaskSet, task
from modules import pulsa_api, ws_v4, accounts
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class UserBehavior(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['pulsa']['accounts'], login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        user_id = self.account["user_id"]
        device_id = self.config["device_id"]
        os_type = self.config["os_type"]
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        category_id = '14'
        voucher_code = self.config["pulsa"]["voucher_codes"][0]

        query = 'category_id='+category_id+'&voucher_code='+voucher_code+'&os_type='+os_type+'device_id='+device_id+'&user_id='+user_id
        res = pulsa_api.voucher_check_v1_4(self, pulsa_api.host_production, user_id, name='/v1.4/voucher/check?category_id='+category_id+'&voucher_code='+voucher_code, query=query)
    
    @task(1)
    def task2(self):
        user_id = self.account["user_id"]
        device_id = self.config["device_id"]
        os_type = self.config["os_type"]
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        category_id = '6'
        voucher_code = self.config["pulsa"]["voucher_codes"][1]

        query = 'category_id='+category_id+'&voucher_code='+voucher_code+'&os_type='+os_type+'device_id='+device_id+'&user_id='+user_id
        res = pulsa_api.voucher_check_v1_4(self, pulsa_api.host_production, user_id, name='/v1.4/voucher/check?category_id='+category_id+'&voucher_code='+voucher_code, query=query)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 1000
    max_wait = 2000
