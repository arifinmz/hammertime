from locust import HttpLocust, TaskSet, task
from modules import mojito

class AndroidIosWidgetSeeAll(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]

    	# MOJITO
    	res = mojito.layout_category_v1_3(self, mojito.host_production, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = AndroidIosWidgetSeeAll
    min_wait = 3000
    max_wait = 5000