from locust import HttpLocust, TaskSet, task
from modules import pulsa_api
import random

class UserBehavior(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]

        res = pulsa_api.operator_list_v1_4(self, pulsa_api.host_production)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 1000
    max_wait = 2000
