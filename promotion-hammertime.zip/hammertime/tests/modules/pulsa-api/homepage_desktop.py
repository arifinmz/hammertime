from locust import HttpLocust, TaskSet, task
from libs import bearer_token
from modules import ws_v4, accounts, pulsa_api, pulsa
from tests.helper.account_helper import AccountHelper
import json

ah = AccountHelper()

class HomepageDesktop(TaskSet):    

    def on_start(self):
        self.config = self.configuration["production"]      
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        user_id = self.account["user_id"]
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        device_id = "4"
        test_failed = False       
        
        headers = {
            'cookie' :ah.get_sid_cookie(user_id)
        }

        cookies = headers['cookie']
        idx = cookies.find("Path") - 1
        cookies2 = cookies[:idx]

        # GET DATA FROM AJAX LOGIN - ini always 200 meskipun ga ada cookie
        header_pulsa = {
            'cookie': cookies2
        }
        
        res_login = pulsa.login_ajax(self, pulsa.host_production, timeout=timeout, headers=header_pulsa, cb_threshold=cb_threshold)

        # GET OPERATOR LIST
        res = pulsa_api.operator_list_v1_4(self, pulsa_api.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        # GET AJAX FAVORITE LAST ORDER -  ini always 200 meskipun ga ada cookie
        res = pulsa.favorite_lastOrders(self, pulsa.host_production, timeout=timeout, headers=headers, cb_threshold=cb_threshold)

        # GET PRODUCT LIST
        query = 'device=' + device_id
        res = pulsa_api.product_list_v1_4(self, pulsa_api.host_production, query=query, headers=headers, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        # GET BANNER
        query = 'device_id=2&partner_id=0'
        res = pulsa_api.banner_v1_4(self, pulsa_api.host_production, query=query, headers=headers, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)
    		
class WebsiteUser(HttpLocust):
    host = ""
    task_set = HomepageDesktop
    min_wait = 3000
    max_wait = 5000