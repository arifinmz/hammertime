from locust import HttpLocust, TaskSet, task
from modules import pulsa_api, ws_v4, accounts
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class UserBehavior(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        user_id = self.account["user_id"]
        device_id = self.config["device_id"]
        os_type = self.config["os_type"]
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]

        query = 'os_type=%s&device_id=%s&user_id=%s' % (os_type, device_id, user_id)
        res = pulsa_api.lastOrder_v1_4(self, pulsa_api.host_production, user_id, query=query, hide_query=True)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 1000
    max_wait = 2000
