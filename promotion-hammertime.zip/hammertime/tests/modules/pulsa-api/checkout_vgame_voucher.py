from locust import HttpLocust, TaskSet, task
from modules import pulsa_api, ws_v4, accounts
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class UserBehavior(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config["pulsa"]["massive_nonqa_accounts"], login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        user_id = self.account["user_id"]
        device_id = self.config["device_id"]
        os_type = self.config["os_type"]
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        category_id = '6'
        voucher_code = self.config["pulsa"]["voucher_codes"][0]

        bodies = {  
            "data":{  
                "attributes":{  
                    "device_id":4,
                    "fields":[  
                        {  
                        "name":"client_number",
                        "value":""
                        }
                    ],
                    "identifier":{  
                        "device_token":device_id,
                        "os_type":os_type,
                        "user_id":user_id,
                    },
                    "instant_checkout":False,
                    "ip_address":"",
                    "product_id":514,
                    "user_agent":"Android Tokopedia Application/com.tokopedia.customerappp v.2.8.1.9 (OPPO A33fw; Android; API_22; Version5.1.1)",
                    "user_id":user_id
                },
                "type":"add_cart"
            }
        }
        cart_response = pulsa_api.cart_v1_4(self, pulsa_api.host_production, user_id, json=bodies, cb_threshold=cb_threshold)

        # check-voucher
        query = 'category_id='+category_id+'&voucher_code='+voucher_code+'&os_type='+os_type+'device_id='+device_id+'&user_id='+user_id
        res = pulsa_api.voucher_check_v1_4(self, pulsa_api.host_production, user_id, name=pulsa_api.host_production+'/v1.4/voucher/check?category_id={category_id}&voucher_code='+voucher_code, query=query, cb_threshold=cb_threshold)
    
        # checkout with voucher
        if cart_response.status_code == 200 :
            atc_response = cart_response.json()
            bodies = {  
                "data":{  
                    "type":"checkout",
                    "attributes":{  
                        "voucher_code":"MAINLAGI",
                        "transaction_amount":atc_response['data']['attributes']['price_plain'],
                        "access_token":"",
                        "wallet_refresh_token":"",
                        "ip_address":"",
                        "user_agent":"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:51.0) Gecko/20100101 Firefox/51.0"
                    },
                    "relationships":{  
                        "cart":{  
                            "data":{  
                            "type":"cart",
                            "id":atc_response['data']['id']
                            }
                        }
                    }
                }
            }
            query = 'os_type=%s&device_id=%s&user_id=%s' % (os_type, device_id, user_id)
            res = pulsa_api.checkout_v1_4(self, pulsa_api.host_production, user_id, json=bodies, hide_query=True, query=query, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 1000
    max_wait = 2000
