from locust import HttpLocust, TaskSet, task
from libs import bearer_token
from modules import ws_v4, accounts, pulsa_api, pulsa
from tests.helper.account_helper import AccountHelper
import json, random

ah = AccountHelper()

class MarketplaceWidget(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]      
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        user_id = self.account["user_id"]
        user_email = self.account["email"]
        bearer_token = ah.get_token(user_id)
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        device_id = "8"

        headers = {
            'cookie' :ah.get_sid_cookie(user_id)
        }

    	# GET CATEGORY LIST
        query = 'device_id=' + device_id
        res = pulsa_api.category_list_v1_4(self, pulsa_api.host_production, query=query, headers=headers, hide_query=True, timeout=timeout, cb_threshold=cb_threshold)

        # GET OPERATOR LIST
        res = pulsa_api.operator_list_v1_4(self, pulsa_api.host_production, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        # GET PRODUCT LIST
        res = pulsa_api.product_list_v1_4(self, pulsa_api.host_production, query=query, hide_query=True, headers=headers, timeout=timeout, cb_threshold=cb_threshold)

        # GET AJAX FAVORITE LAST ORDER -  ini always 200 meskipun ga ada cookie
        res = pulsa.favorite_lastOrders(self, pulsa.host_production, timeout=timeout, headers=headers, cb_threshold=cb_threshold)
    		
class WebsiteUser(HttpLocust):
    host = ""
    task_set = MarketplaceWidget
    min_wait = 3000
    max_wait = 5000