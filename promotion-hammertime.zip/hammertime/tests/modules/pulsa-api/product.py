from locust import HttpLocust, TaskSet, task
from modules import pulsa_api
import random

class UserBehavior(TaskSet):
    device_ids = ['2','4','5','7']

    def on_start(self):
        self.config = self.configuration["production"]

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        device_id = random.choice(self.device_ids)

        res = pulsa_api.product_list_v1_4(self, pulsa_api.host_production, query='device_id='+device_id)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 1000
    max_wait = 2000
