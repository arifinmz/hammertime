from locust import HttpLocust, TaskSet, task
from modules import graphql
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class UserBehavior(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, accounts = self.config["pulsa"]["accounts"])
    
    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        bearer_token = ah.get_token(user_id)
        timeout_graphql = (self.config['timeout_graphql'][0],self.config['timeout_graphql'][1])
        cb_threshold    = self.config['cb_threshold']

        response = graphql.graphql_rechargeCategoryDetailApps(self, graphql.host_graphql, headers={}, json={"variables":{"category_id": 1,
            "is_seller": 0}},cb_threshold=cb_threshold, timeout=timeout_graphql)
        response = graphql.graphql_rechargeFavoriteNumber(self, graphql.host_graphql, headers={'accounts-authorization': bearer_token}, json={"variables":{"category_id": 1}},cb_threshold=cb_threshold, timeout=timeout_graphql)

class WebsiteUser(HttpLocust):
    host     = ""
    task_set = UserBehavior
    min_wait = 3000
    max_wait = 5000