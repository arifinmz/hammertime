import random
from locust import HttpLocust, TaskSet, task
from modules import chat, ws_v4
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

def random_msg_id(msg_ids):
    """Return a random msg_ids"""
    random.shuffle(msg_ids)
    return msg_ids[0]

class Chat(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config["topchat"]["accounts"], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        device_id = self.config['device_id']
        user_id = self.account['user_id']
        shop_id = self.account['shop_id']
        msg_id = random_msg_id(self.account['msg_ids'])
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']

        headers = {
            'cookie': ah.get_sid_cookie(user_id), 
            'origin': 'https://www.tokopedia.com'
        }

        res = chat.tc_response_shop_P_v1(self, chat.host_production, shop_id, headers=headers, name=chat.host_production+"/tc/v1/response/shop/{shop_id}", cb_threshold=cb_threshold, timeout=timeout)
        res = chat.tc_templates_v1(self, chat.host_production, headers=headers, name=chat.host_production+"/tc/v1/templates", cb_threshold=cb_threshold, timeout=timeout)
        res = chat.tc_chat_templates_v1(self, chat.host_production, headers=headers, name=chat.host_production+"/tc/v1/chat_templates", cb_threshold=cb_threshold, timeout=timeout)
        res = chat.tc_list_message_v1(self, chat.host_production, user_id, device_id, headers=headers, name=chat.host_production+"/tc/v1/list_message", cb_threshold=cb_threshold, timeout=timeout)
        res = chat.tc_list_reply_P_v1(self, chat.host_production, user_id, device_id, msg_id, headers=headers, name=chat.host_production+"/tc/v1/list_reply/{message_id}", cb_threshold=cb_threshold, timeout=timeout)
        res = chat.tc_list_reply_P_v2(self, chat.host_production, user_id, device_id, msg_id, headers=headers, name=chat.host_production+"/tc/v2/list_reply/{message_id}", cb_threshold=cb_threshold, timeout=timeout)
        # res = chat.tc_search_v1(self, chat.host_production, user_id, device_id, headers=headers, name=chat.host_production+"/tc/v1/search", cb_threshold=cb_threshold, timeout=timeout)
        res = chat.tc_existing_chat_v1(self, chat.host_production, user_id, device_id, headers=headers, name=chat.host_production+"/tc/v1/existing_chat", cb_threshold=cb_threshold, timeout=timeout)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = Chat
    min_wait = 1000
    max_wait = 1500
