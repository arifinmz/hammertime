import random
from locust import HttpLocust, TaskSet, task
from modules import chat, ws_v4
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

def random_msg_id(msg_ids):
    """Return a random msg_ids"""
    random.shuffle(msg_ids)
    return msg_ids[0]

class ChatWidget(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config["topchat"]["accounts"], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        device_id = self.config['device_id']
        user_id = self.account['user_id']
        shop_id = self.account['shop_id']
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        timeout2s = (2,2)
        cb_threshold = self.config['cb_threshold']

        headers = {
            'cookie': ah.get_sid_cookie(user_id), 
            'origin': 'https://www.tokopedia.com'
        }

        res = chat.tc_response_shop_P_v1(self, chat.host_production, shop_id, headers=headers, name=chat.host_production+"/tc/v1/response/shop/{shop_id}", cb_threshold=cb_threshold, timeout=timeout)
        res = chat.tc_uploadapp_v1(self, chat.host_production, headers=headers, name=chat.host_production+"/tc/v1/uploadapp", cb_threshold=cb_threshold, timeout=timeout)
        
        # res = chat.pages_inbox(self, chat.host_production, headers=headers, name=chat.host_production+"/pages/inbox", cb_threshold=cb_threshold, timeout=timeout2s)
        res = chat.pages_widget(self, chat.host_production, headers=headers, name=chat.host_production+"/pages/widget", cb_threshold=cb_threshold, timeout=timeout2s)
        res = chat.pages_widget_getvar(self, chat.host_production, headers=headers, name=chat.host_production+"/pages/widget/getvar", cb_threshold=cb_threshold, timeout=timeout2s)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = ChatWidget
    min_wait = 1000
    max_wait = 1500
