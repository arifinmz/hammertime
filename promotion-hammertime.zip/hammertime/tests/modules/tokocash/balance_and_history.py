from locust import HttpLocust, TaskSet, task
from modules import tokocash
import random

class BalanceAndHistory(TaskSet):


    def on_start(self):
        self.config = self.configuration['production']

    @task(5)
    def wallet_balance(self):

        bearer = random.choice(self.config['wallet']['bearer'])

        header = {
            'Authorization': 'Bearer '+bearer
        }

        tokocash.api_wallet_balance_v1(self,tokocash.host_production, headers=header)

    @task(1)
    def me_balance(self):
        bearer = random.choice(self.config['wallet']['bearer'])

        header = {
            'Authorization': 'Bearer ' + bearer
        }

        tokocash.api_me_balance_v1(self, tokocash.host_production, headers=header)

    @task(1)
    def me_wallet(self):
        bearer = random.choice(self.config['wallet']['bearer'])

        header = {
            'Authorization': 'Bearer ' + bearer
        }

        tokocash.api_me_wallet_v1(self, tokocash.host_production, headers=header)

    @task(1)
    def me_history(self):
        bearer = random.choice(self.config['wallet']['bearer'])

        header = {
            'Authorization': 'Bearer ' + bearer
        }

        tokocash.api_me_history_v1(self, tokocash.host_production, headers=header, query='page=1&no_limit=false')

    @task(1)
    def me_history_pending(self):
        bearer = random.choice(self.config['wallet']['bearer'])

        header = {
            'Authorization': 'Bearer ' + bearer
        }

        tokocash.api_me_history_v1(self, tokocash.host_production, headers=header, query='page=1&no_limit=false&type=pending')

class WebsiteUser(HttpLocust):
    host = ""
    task_set = BalanceAndHistory
    min_wait = 1500
    max_wait = 2500