import random
from locust import HttpLocust, TaskSet, task
from modules import topads  
from numpy.random import choice
import os
import json
import logging
import string


logger = logging.getLogger(__name__)

keyword_list = list()
user_path = os.environ['PYTHONPATH'].split(os.pathsep)[-1] + "/tests/modules/topads/"

with open(user_path+"keywordlist.txt") as kw:
    keyword = kw.readlines()
    keyword = [x.strip() for x in keyword]
    for word in keyword:
        keyword_list.append(word)

keyword_list = keyword_list[:10000]


class TopadsSearch(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"]
        self.topads_config = self.team_configuration(self.config["topads"]["topads_config"])
        json_topads = self.topads_config
        self.key_probs = self.topads_config["kw_probs_10k"]

    @task(20)
    def product_search_logged_in(self):
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        user_id = random.choice(self.topads_config["user_id"])
        search_keyword = choice(keyword_list, p=self.key_probs)

        query = 'src=search&ep=product&item=10&device=desktop&page=1&'
        res = topads.promo_display_ads_v1_1(self, topads.host_production,
                                            timeout=timeout,
                                            cb_threshold=cb_threshold,
                                            query=query + "q=" + search_keyword + "&user_id=" + user_id,
                                            name=topads.host_production+"/promo/v1.1/display/ads?src=search&ep=product")
        
    @task(2)
    def headline_search(self):
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        user_id = random.choice(self.topads_config["user_id"])
        keyword_cpm_desc = random.choice(self.topads_config["keyword_cpm_desc"])
        query = 'page=1&ep=cpm&item=1&src=search&device=desktop&template_id=2%2C3%2C4&'
        res = topads.promo_display_ads_v1_1(self, topads.host_production,
                                            timeout=timeout,
                                            cb_threshold=cb_threshold,
                                            query=query + "user_id=" + user_id + "q=" + keyword_cpm_desc,
                                            name=topads.host_production+"/promo/v1.1/display/ads?ep=cpm&src=search")

    @task(5)
    def product_search_non_logged_in(self):
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        search_keyword = choice(keyword_list, p=self.key_probs)

        query = 'src=search&ep=product&item=10&device=desktop&page=1&'
        sid = ''.join([random.choice(string.letters) for x in range(32)])
        res = topads.promo_display_ads_v1_1(self, topads.host_production,
                                            timeout=timeout,
                                            cb_threshold=cb_threshold,
                                            query=query + "q=" + search_keyword + "&sid=" + sid,
                                            name=topads.host_production+"/promo/v1.1/display/ads?src=search&ep=product&user_id=0")


class WebsiteUser(HttpLocust):
    host = ""
    task_set = TopadsSearch
    min_wait = 1000
    max_wait = 1500
