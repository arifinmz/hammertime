from locust import HttpLocust, TaskSet, task
from modules import topads
import random
import os
import json
import logging


class DashboardDeposit(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"]
        self.topads_config = self.team_configuration(self.config["topads"]["topads_config"])
        self.topads_account = self.topads_config["user_id_deposit"]

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        index_user = random.choice(self.topads_account)
        user_id = index_user["user_id"]                                                                                                                                                                                                                                                                                         
        shop_id = index_user["shop_id"]
        query = "shop_id="+shop_id
        res = topads.dashboard_deposit_v1_1(self, topads.host_production, user_id, timeout=timeout, cb_threshold=cb_threshold, query=query, name=topads.host_production+"/v1.1/dashboard/deposit")

class WebsiteUser(HttpLocust):
    host = ""
    task_set = DashboardDeposit
    min_wait = 1000
    max_wait = 1500