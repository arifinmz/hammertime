from locust import HttpLocust, TaskSet, task
from modules import topads
import random
import os
import json
import logging

class TopadsHome(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"]
        self.topads_config = self.team_configuration(self.config["topads"]["topads_config"])
        self.device_list = ["android" for x in range(20)]
        self.device_list += ["ios" for x in range(2)]
        self.device_list += ["mobile"]

    @task(1)
    def browse_home(self):
        #https://ta.tokopedia.com/promo/v1.1/display/ads?ep=product&item=4&src=home&device=android&page=1&user_id=16386956&dep_id=0&search_nf=0
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        user_id = random.choice(self.topads_config["user_id"])
        device = random.choice(self.device_list)
        query = '&page=1&dep_id=0&search_nf=0'
        res = topads.promo_display_ads_v1_1(self, topads.host_production,
                                            timeout=timeout,
                                            cb_threshold=cb_threshold,
                                            query=query + "user_id=" + user_id + "device=" + device,
                                            name=topads.host_production + "/promo/v1.1/display/ads?ep=product&item=4&src=home")


class WebsiteUser(HttpLocust):
    host = ""
    task_set = TopadsHome   
    min_wait = 1000
    max_wait = 1500
