from locust import HttpLocust, TaskSet, task
from modules import topads  
import random
import os
import json
import logging

class TopadsBrowseFeed(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"]
        self.topads_config = self.team_configuration(self.config["topads"]["topads_config"])

    @task(1)
    def browse_feed(self):
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        user_id = random.choice(self.topads_config["user_id"])
        query = 'src=fav_product&ep=&item=6%2C1&device=desktop&page=1&'
        res = topads.promo_display_ads_v1_1(self, topads.host_production,
                                            timeout=timeout,
                                            cb_threshold=cb_threshold,
                                            query=query + "user_id=" + user_id,
                                            name=topads.host_production+"/promo/v1.1/display/ads?src=fav_product")

class WebsiteUser(HttpLocust):
    host = ""
    task_set = TopadsBrowseFeed
    min_wait = 1000
    max_wait = 1500
