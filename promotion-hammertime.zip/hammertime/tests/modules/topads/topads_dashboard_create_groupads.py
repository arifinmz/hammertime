from locust import HttpLocust, TaskSet, task
from modules import topads, tome
import json
import datetime
import random
import string
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class CreateGroupads(TaskSet):
    

    def on_start(self):
        self.config = self.configuration["production"]
        self.topads_config = self.team_configuration(self.config["topads"]["topads_config"])
        self.account = ah.get_account(self, accounts=self.topads_config["topads_massive_account"], login_type=ah.LOGIN_TYPE_BROWSER)
    
    @task(1)
    def generate_hmac(self):
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        user_id = self.account['user_id']
        shop_id = self.account["shop_id"]
        cookie = ah.get_sid_cookie(str(user_id))  
        headers={
            'cookie':ah.get_sid_cookie(user_id),
            'content-type':'application/json',
            'x-device':'desktop'
        }
        query_hmac_searchgroups = "method=GET&url=/v1.1/dashboard/search_groups&content=shop_id="+shop_id+"&view_all=1&group_type=1"
        query_hmac_searchproducts = "method=GET&url=/v1.1/dashboard/search_products&content=shop_id="+shop_id+"&rows=50&is_promoted=1&content-type="
        query_hmac_deposit = "method=GET&url=/v1.1/dashboard/deposit&content=shop_id="+shop_id+"&content-type="
        res = topads.dashboard_hmac_v1(self, topads.host_production, user_id, timeout=timeout, cb_threshold=cb_threshold, query=query_hmac_searchgroups, headers=headers, name=topads.host_production+"/v1.1/dashboard/hmac/search_groups")
        res = topads.dashboard_hmac_v1(self, topads.host_production, user_id, timeout=timeout, cb_threshold=cb_threshold, query=query_hmac_searchproducts, headers=headers, name=topads.host_production+"/v1.1/dashboard/hmac/search_products")
        res = topads.dashboard_hmac_v1(self, topads.host_production, user_id, timeout=timeout, cb_threshold=cb_threshold, query= query_hmac_deposit, headers=headers, name=topads.host_production+"/v1.1/dashboard/hmac/deposit")
        


    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        index_user = random.choice(self.topads_config["topads_massive_account"])
        user_id = str(index_user["user_id"])
        shop_id = str(index_user["shop_id"])
        query_etalase="shop_id="+shop_id
        query_search_products = "shop_id="+shop_id+"&rows=50&is_promoted=1"
        query_search_groups = "shop_id="+shop_id+"&view_all=1&group_type=1"
        query_deposit = "shop_id="+shop_id
        test_failed = False
        group_id = None
        group_name = ''.join([random.choice(string.letters) for x in range(10)])
        
        res = topads.webService_shop_getEtalase_v1(self, tome.host_production, timeout=timeout, cb_threshold=cb_threshold, query=query_etalase, name=tome.host_production+"/v1/web-service/shop/get_etalase")
        res = topads.dashboard_searchGroups_v1_1(self, topads.host_production, user_id, timeout=timeout, cb_threshold=cb_threshold, query=query_search_groups, name=topads.host_production+"/v1.1/dashboard/search_groups")
        res = topads.dashboard_deposit_v1_1(self, topads.host_production, user_id, timeout=timeout, cb_threshold=cb_threshold, query=query_deposit, name=topads.host_production+"/v1.1/dashboard/deposit")
        res = topads.dashboard_searchProducts_v1_1(self, topads.host_production, user_id, timeout=timeout, cb_threshold=cb_threshold, query=query_search_products, name=topads.host_production+"/v1.1/dashboard/search_products")
        
        search_products = json.loads(res.content)
        ad_id = search_products["data"][0]["ad_id"]
        is_promoted = str(search_products["data"][0]["product_is_promoted"])
        product_id = str(search_products["data"][0]["product_id"])
        bulk_ads = {
            "data":{
                "action":"delete",
                "ads":[{"ad_id":str(ad_id)}],
                "shop_id":shop_id
            }
        }

        try:
            #check if product already promoted or not
            if is_promoted == "True":
                test_failed = False
                #if product is promoted, run delete ads function
                res = topads.promo_bulk_v2(self, topads.host_production, user_id, timeout=timeout, cb_threshold=cb_threshold, json=bulk_ads, name=topads.host_production+"/v2.1/promo/bulk")
                
            else:
                bodies = {
                   "data":{
                      "group_name":str(group_name),
                      "shop_id":shop_id,
                      "price_bid":350,
                      "previous_bid":0,
                      "price_daily":6500,
                      "group_budget":"0",
                      "group_schedule":"0",
                      "group_start_date":"",
                      "group_start_time":"",
                      "group_end_date":"",
                      "group_end_time":"",
                      "sticker_id":"0",
                      "group_total":"1",
                      "source":"dashboard_user_add_product",
                      "ads":[
                         {
                            "item_id":product_id,
                            "ad_type":"1",
                            "ad_id":"0",
                            "group_id":"0"
                         }
                      ],
                      "suggested_bid_value":350,
                      "is_suggestion_bid_button":"-11"
                   }
                }
                #if product is not promoted, create groupads    
                res = topads.promo_group_v2_1(self, topads.host_production, user_id, timeout=timeout, cb_threshold=cb_threshold, json=bodies, name=topads.host_production+"/v2.1/promo/group")
        except Exception as e:
            res.failure(res.content)
            test_failed = True

class WebsiteUser(HttpLocust):
    host = ""
    task_set = CreateGroupads
    min_wait = 1000
    max_wait = 1500