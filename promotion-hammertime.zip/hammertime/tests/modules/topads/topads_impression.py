import base64
from locust import HttpLocust, TaskSet, task 
from modules import topads  
import random
import string
import time


custom_key = "nCmAJVcIU-GbHo6vezZ_1u39ygqQrP8wKxisjBMSt2k0DWX5Fhap7OfRdNET4YLl"
standard_key = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

ENCODE_TRANS = string.maketrans(standard_key, custom_key)
DECODE_TRANS = string.maketrans(custom_key, standard_key)

viewed_ads = set()
clicked_ads = set()

slave_count = 119

# production
max_ad_id = 17367620
test_ad_size = 2500000
partition_size = 21000

# test
# max_ad_id = 17306750
# test_ad_size = 5
# partition_size = 5
# custom_cpc = 1

test_id_range = list(range(max_ad_id-test_ad_size, max_ad_id))
partioned_id_range = list()
for id in range(slave_count):
    start_index = id*partition_size
    end_index = (id+1)*partition_size
    partioned_id_range.append(test_id_range[id:(id+1)*partition_size])


def ad_id_generator(partition_start=0):
    ad_id = max_ad_id-test_ad_size + partition_start
    while True:
        yield ad_id
        ad_id += 1


def encode(input_str):
    return base64.b64encode(input_str).translate(ENCODE_TRANS)


def decode(input_str):
    pad_len = len(input_str) % 4
    if pad_len != 0:
        input_str = input_str + pad_len * "="
    return base64.b64decode(input_str.translate(DECODE_TRANS))


view_encoded_str = "H_tp6sJRHpyR6Anh6sJEH_tho_U7H_JaH_1p6MusrprXPcY0QRCBgcBxbMNBPmY2Q3r5yfVsqc15HsnFb9ohP3VagZYFrMYjP3o7b_J5Hsnhoa4hHZ4hbpJdHAKR6_JfbpJdHAKR6_Jf9fuBo3JdgcVsb_rfgsnWoAn7oaOi6_jRb_uxHAj7gArfgM-BHu4RHsCwopUFbM2FgptEHAtFbsn76_K76_2B812kgJxGgBBXZSgjH7NDZ325q1OAZ9o-Q1dFyfFN8B29zSBgHMP2_fB-P7B2PfBxHByOgAUN8u2c692gHsBN3Bo-ojBke3BHe72OysUOqB2_Z_g-QuBE_jPzo1OI3MOHuJjp3BzzPJNIZ_zgq_n7_M2V8jh1QcWqqMhD33OgHV2kyR2ve7BpZ37N83V9gICiQABRyf7Nqfz9_sCyHMh0Z325q1OAZ9o-Q_BNyuPjrc-D692xzpBR3A-Dq7BkQfBoe7BpZ3N6qMUpZMhyHj2Nysoj8B2_Z_g-qjuO_Oz-8JOJ3_C6ucDh_7zCo1Y11_Coq1BpZ3N6qMUpZMhyH7ND3uxGqMVAZ_g-qjuO_Ozz81NEe_C68j1a_M2SH7NJu9Bo81tN"
view_decoded_str = decode(view_encoded_str)
view_decoded_split = view_decoded_str.split(":")

click_encoded_str = "HpthopHfopKFH_th6sJEH_1aoAefosnpHsthHAtF6snXHAUa6_yd6MuNZM2jZJ2M33NGPMep_Mh-qMY2_1o-r7BW_sCsQABE3BPc8ujagfBvq1BRZ3BRq3JausujHsBN3jyN8Bja69Bq17jfZ32Cq1hAZSuiHsuk3Bo-ojBWz_-oHjBd_s-3q7h1Qc2oqjB7_jzcqJO2HAzquVjO_Vzs8BBEu9xvuO-W33OZqJOAZ9o-Q_BNyuPjrc-D69PsQ_B0gVP6HVKaQcW-qMY2_1o-r7BW69BxufzFyMFN8MVI69PyHMh0Z325q1OAZ9o-QjNkysoGQVKaZSBiHfzE3Bo-ojBkZ9uozcWd_S2uH1OkqpoouJON_M2V8jNNZ9o-QjNkysoGQVKp_Mhg3J2ky1o-ojBkZ9uozcWd_S2uH1OkqpoouJON_M2V8jNNZsj"
click_decoded_str = decode(click_encoded_str)
click_decoded_split = click_decoded_str.split(":")


class TopadsImpression(TaskSet):

    def on_start(self):
        print("client index: %d" % self.runners.client_index)
        self.slave_index = self.runners.client_index
        self.current_ad_id = 0

    def compose_view_url(self, ad_id):
        view_decoded_split[2] = str(ad_id)
        view_decoded_split[5] = str(int(time.time()))

        new_decoded_str = ":".join([x for x in view_decoded_split])
        new_encoded_str = encode(new_decoded_str)
        stripped_new_encoded_str = new_encoded_str.split("=")[0]
        view_url = stripped_new_encoded_str
        return view_url

    @task(1)
    def hit_impression(self):
        rand_sid = ''.join([random.choice(string.letters) for x in range(32)])

        if len(viewed_ads) < partition_size and len(partioned_id_range[self.slave_index]) != 0:

            try:
                self.current_ad_id = partioned_id_range[self.slave_index].pop()

                if self.current_ad_id < max_ad_id:
                    viewed_ads.add(self.current_ad_id)
                    viewport = self.compose_view_url(self.current_ad_id)
                    query = 'alg=stm&is_search=1&uid=13244715&post_alg=cpc_shop_unq&keywords=stelan&n_candidate_ads=67&' \
                            'number_of_ads=10&t=desktop&number_ads_req=10&src=search&ab_test=N&page=1&render=false'
                    res = topads.promo_views_P_v1(self, topads.host_production,
                                                  viewport=viewport, query=query+"&sid="+"123",
                                                  name=topads.host_production+"/promo/v1/views/")
                    # print("view counter: %d, ad_id: %d" % (len(viewed_ads), self.current_ad_id))
                    time.sleep(random.uniform(0.01, 0.07))
            except IndexError as e:
                print(e)
        else:
            print("Test object exhausted")
            self.runners.stop()


class WebsiteUser(HttpLocust):
    host = ""
    task_set = TopadsImpression
    min_wait = 1000
    max_wait = 1500
