from locust import HttpLocust, TaskSet, task
from modules import topads  
import random
import os
import json
import logging

class TopadsBrowse(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"]
        self.topads_config = self.team_configuration(self.config['topads']['topads_config'])


    @task(4)
    def browse_feed(self):
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        user_id = random.choice(self.topads_config["user_id"])
        query = 'src=fav_product&ep=&item=6%2C1&device=desktop&page=1&ab_test=a&dep_id=379%2C1518%2C1808&'
        res = topads.promo_display_ads_v1_1(self, topads.host_production,
                                            timeout=timeout,
                                            cb_threshold=cb_threshold,
                                            query=query + "user_id=" + user_id,
                                            name=topads.host_production+"/promo/v1.1/display/ads?src=fav_product")

    @task(1)
    def browse_directory_headline(self):
        # https://ta.tokopedia.com/promo/v1.1/display/ads?user_id=6240715&ep=cpm&item=1&src=directory&device=desktop&template_id=2%2C3&dep_id=63
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        user_id = random.choice(self.topads_config["user_id"])
        dep_id = random.choice(self.topads_config["directory_dep_id"])
        query = 'src=directory&ep=cpm&item=1&device=desktop&template_id=2%2C3'
        res = topads.promo_display_ads_v1_1(self, topads.host_production,
                                            timeout=timeout,
                                            cb_threshold=cb_threshold,
                                            query=query + "&dep_id=" + dep_id + "&user_id=" + user_id,
                                            name=topads.host_production+"/promo/v1.1/display/ads?src=directory")

    @task(1)
    def browse_directory_shop(self):
        # https://ta.tokopedia.com/promo/v1.1/display/ads?item=3&user_id=6240715&ep=shop&src=directory&device=desktop&dep_id=63
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        user_id = random.choice(self.topads_config["user_id"])
        dep_id = random.choice(self.topads_config["directory_dep_id"])
        query = 'src=directory&ep=shop&item=3&device=desktop'
        res = topads.promo_display_ads_v1_1(self, topads.host_production,
                                            timeout=timeout,
                                            cb_threshold=cb_threshold,
                                            query=query + "&dep_id=" + dep_id + "&user_id=" + user_id,
                                            name=topads.host_production+"/promo/v1.1/display/ads?src=directory")

    @task(1)
    def browse_directory_product(self):
        # https://ta.tokopedia.com/promo/v1.1/display/ads?user_id=6240715&ep=product&item=8&src=directory&device=desktop&dep_id=63&fshop=1
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        user_id = random.choice(self.topads_config["user_id"])
        dep_id = random.choice(self.topads_config["directory_dep_id"])
        query = 'src=directory&ep=product&item=8&device=desktop&fshop=1'
        res = topads.promo_display_ads_v1_1(self, topads.host_production,
                                            timeout=timeout,
                                            cb_threshold=cb_threshold,
                                            query=query + "&dep_id=" + dep_id + "&user_id=" + user_id,
                                            name=topads.host_production+"/promo/v1.1/display/ads?src=directory")

    @task(2)
    def browse_hotlist(self):
        # https://ta.tokopedia.com/promo/v1.1/display/ads?user_id=6240715&h=14561&ep=product&item=10&src=hotlist&device=desktop&page=1&pmin=0&pmax=0&fshop=1
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        user_id = random.choice(self.topads_config["user_id"])
        hotlist_id = random.choice(self.topads_config["hotlist_id"])
        query = 'src=hotlist&ep=product&item=10&device=desktop&page=1&pmin=0&pmax=0&fshop=1'
        res = topads.promo_display_ads_v1_1(self, topads.host_production,
                                            timeout=timeout,
                                            cb_threshold=cb_threshold,
                                            query=query + "&h=" + hotlist_id + "&user_id=" + user_id,
                                            name=topads.host_production+"/promo/v1.1/display/ads?src=hotlist")


class WebsiteUser(HttpLocust):
    host = ""
    task_set = TopadsBrowse
    min_wait = 1000
    max_wait = 1500
