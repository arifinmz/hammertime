from locust import HttpLocust, TaskSet, task
from modules import ws_v4
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class UserBehavior(TaskSet):

    def on_start(self):
        self.config = self.configuration['production']
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_APP)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        device_id = self.config['device_id']
        os_type = self.config['os_type']

        query = "os_type=%s&device_id=%s&user_id=%s" % (os_type,device_id,user_id)
        res = ws_v4.deposit_getDeposit_pl_v4(self, ws_v4.host_production, user_id, device_id, query=query, name=ws_v4.host_production+"/v4/deposit/get_deposit.pl?"+query)
        res = ws_v4.notification_getNotification_pl_v4(self, ws_v4.host_production, user_id, device_id, query=query, name=ws_v4.host_production+"/v4/notification/get_notification.pl?"+query)
        bodies  = {
            'per_page': 20,
            'device_id': device_id,
            'os_type': os_type,
            'user_id': user_id,
            'page': 1
        }
        res = ws_v4.home_getFavoriteShop_pl_v4(self, ws_v4.host_production, user_id, device_id, bodies=bodies)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 3000
    max_wait = 5000
