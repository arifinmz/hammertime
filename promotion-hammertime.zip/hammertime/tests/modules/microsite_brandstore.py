from locust import HttpLocust, TaskSet, task
from modules import mojito, tokopedia

class MicrositeBrandstore(TaskSet):

    def on_start(self):
      self.config = self.configuration['production']
      self.cb_threshold = self.config['cb_threshold']
      self.timeout = (self.config['timeout'][0],self.config['timeout'][1])

    @task(1)
    def levelzero(self):
        query = "level2=0"
        res = mojito.os_api_category_levelzero_v2(self, mojito.host_production, query=query, name = mojito.host_production + "/os/api/v2/category/levelzero", cb_threshold=self.cb_threshold, timeout=self.timeout)

    @task(1)
    def banner_desktop(self):
        query =  "source=0&device=1&category_id=0"
        res = mojito.os_api_brands_microsite_banners_v1(self, mojito.host_production, query=query, name = mojito.host_production + "/os/api/v1/brands/microsite/banners", cb_threshold=self.cb_threshold, timeout=self.timeout)

    @task(1)
    def banner_mobile(self):
        query =  "source=0&device=2&category_id=0"
        res = mojito.os_api_brands_microsite_banners_v1(self, mojito.host_production, query=query, name = mojito.host_production + "/os/api/v1/brands/microsite/banners", cb_threshold=self.cb_threshold, timeout=self.timeout)

    @task(1)
    def banner_android(self):
        query =  "source=0&device=4&category_id=0"
        res = mojito.os_api_brands_microsite_banners_v1(self, mojito.host_production, query=query, name = mojito.host_production + "/os/api/v1/brands/microsite/banners", cb_threshold=self.cb_threshold, timeout=self.timeout)

    @task(1)
    def banner_ios(self):
        query =  "source=0&device=8&category_id=0"
        res = mojito.os_api_brands_microsite_banners_v1(self, mojito.host_production, query=query, name = mojito.host_production + "/os/api/v1/brands/microsite/banners", cb_threshold=self.cb_threshold, timeout=self.timeout)

    @task(1)
    def brandlist_desktop(self):
        query =  "source=microsite"
        res = mojito.os_api_brands_list_widget_desktop_v3(self, mojito.host_production, query=query, name = mojito.host_production + "/os/api/v3/brands/list/widget/desktop", cb_threshold=self.cb_threshold, timeout=self.timeout)
    
    @task(1)
    def brandlist_mobile(self):
        query =  "source=microsite"
        res = mojito.os_api_brands_list_widget_mobile_v3(self, mojito.host_production, query=query, name = mojito.host_production + "/os/api/v3/brands/list/widget/mobile", cb_threshold=self.cb_threshold, timeout=self.timeout)

    @task(1)
    def brandlist_android(self):
        query =  "source=microsite"
        res = mojito.os_api_brands_list_widget_android_v3(self, mojito.host_production, query=query, name = mojito.host_production + "/os/api/v3/brands/list/widget/android", cb_threshold=self.cb_threshold, timeout=self.timeout)

    @task(1)
    def brandlist_ios(self):
        query =  "source=microsite"
        res = mojito.os_api_brands_list_widget_ios_v3(self, mojito.host_production, query=query, name = mojito.host_production + "/os/api/v3/brands/list/widget/ios", cb_threshold=self.cb_threshold, timeout=self.timeout)

    @task(1)
    def flashsale_desktop(self):
        query =  "device=desktop"
        res = mojito.os_api_brands_microsite_flashsale_v1(self, mojito.host_production, query=query, name = mojito.host_production + "/os/api/v1/brands/microsite/flashsale", cb_threshold=self.cb_threshold, timeout=self.timeout)

    @task(1)
    def flashsale_mobile(self):
        query =  "device=mobile"
        res = mojito.os_api_brands_microsite_flashsale_v1(self, mojito.host_production, query=query, name = mojito.host_production + "/os/api/v1/brands/microsite/flashsale", cb_threshold=self.cb_threshold, timeout=self.timeout)

    @task(1)
    def officialstore(self):
        res = tokopedia.officialstore(self, tokopedia.host_production, name = tokopedia.host_production + "/official-store", cb_threshold=self.cb_threshold, timeout=self.timeout)
        
class WebsiteUser(HttpLocust):
    task_set = MicrositeBrandstore
    host = ""
    min_wait = 1000
    max_wait =  2500