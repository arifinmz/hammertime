from locust import HttpLocust, TaskSet, task
from modules import iris
from libs import tkpdhmac
import random, json, os

class IrisEvent(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"]

    @task(1)
    def task1(self):
        body = {
            'data': {
                'container': 'hammertime_dexter',
                'event': 'dummy_test'
            }
        }

        for i in range(100):
            body['data']['dummy{num}'.format(num=i)] = tkpdhmac.random_generator(20)
        
        timeout = (self.config['timeout'][0], self.config['timeout'][1])
        res = iris.api_event_tracking(self, host=iris.host_production, json=body, timeout=timeout)

class WebsiteUser(HttpLocust):
    host = iris.host_nsq
    task_set = IrisEvent
    min_wait = 1000
    max_wait = 1500