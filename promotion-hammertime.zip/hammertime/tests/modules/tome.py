from locust import HttpLocust, TaskSet, task
from modules import tome
from tests.helper.account_helper import AccountHelper
import random

class Tome(TaskSet):
    def on_start(self):   
        if not hasattr(Tome, 'config_loaded'):
			Tome.test_config = self.configuration['production']
			Tome.config_loaded = True

    @task(1)
    def task1(self):

        product_id = random.choice(Tome.test_config["merchant_tribe"]["product-variant"])
        timeout = (Tome.test_config['timeout'][0], Tome.test_config['timeout'][1])
        timeout_variant = (Tome.test_config ['timeout_variant'][0],Tome.test_config['timeout_variant'][1])
        cb_threshold = Tome.test_config['cb_threshold']
        product_arr = product_id

        for x in range (1,50):
			product_id = random.choice(Tome.test_config["merchant_tribe"]["product-variant"])
			product_arr = product_arr+","+product_id
        
        res = tome.product_P_v2_1(self, tome.host_production, product_id, name=tome.host_production+"/v2.1/product/{product_id}", timeout=timeout_variant, cb_threshold=cb_threshold)
        
        headers = {
            "Origin" : "https://www.tokopedia.com"
            }
        res = tome.product_P_variant_v2(self, tome.host_production, product_id, name=tome.host_production+"/v2/product/{product_id}}/variant", timeout=timeout_variant, cb_threshold=cb_threshold, headers=headers)
        
        query = "product_id=" + product_arr
        res = tome.product_getSummary_v1(self, tome.host_production, name=tome.host_production+"/v1/product/get_summary/", timeout=timeout, cb_threshold=cb_threshold, query=query)


class WebsiteUser(HttpLocust):
    host = ""
    task_set = Tome
    min_wait = 1000
    max_wait = 1500
