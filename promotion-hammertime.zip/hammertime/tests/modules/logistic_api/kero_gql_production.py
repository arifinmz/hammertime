from locust import HttpLocust, TaskSet, task
from modules import gw, graphql
from libs import bearer_token, tkpdhmac
from random import choice, uniform
import random
import time


class KeroGqlRates(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]

    @task(1)
    def task1(self):
        timeout_graphql = (self.config['timeout_graphql'][0], self.config['timeout_graphql'][1])
        cb_threshold = self.config["cb_threshold"]
        names = random.choice(self.config['kero']['logistic_names'].values())
        origin_postal = self.config['kero']['origin_postal']
        destination_postal = self.config['kero']['destination_postal']
        category_id = str(random.randrange(1, 200))
        order_value = str(random.randrange(500, 200000))
        product_insurance = str(random.randrange(0,2))
        insurance = str(random.randrange(0,2))

        # random districtId
        district = range(2253, 2260) + range(2262, 2271) + \
            range(2273, 2280) + range(2282, 2287) + range(2289, 2298)
        origin_district = str(random.choice(district))
        destination_district = str(random.choice(district))

        # random latitude
        origin_latitude = str(random.uniform(-6.149573, -6.247871))
        destination_latitude = str(random.uniform(-6.149573, -6.247871))

        # random longtitude
        origin_longtitude = str(random.uniform(106.751159, 106.900907))
        destination_longtitude = str(
            random.uniform(106.751159, 106.900907))

        ongkir_json = {
            "variables": {
                "input": {
                    "names": names,
                    "origin": origin_district+"|"+origin_postal+"|"+origin_latitude + ","+origin_longtitude,
                    "destination": destination_district+"|"+destination_postal+"|"+destination_latitude+","+destination_longtitude,
                    "weight": "1",
                    "from": "client",
                    "insurance": insurance,
                    "product_insurance": product_insurance,
                    "order_value": order_value,
                    "cat_id": category_id
                }
            }
        }

        res = graphql.graphql_logisticRateQuery(self, graphql.host_graphql, json=ongkir_json, cb_threshold=cb_threshold, timeout=timeout_graphql)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = KeroGqlRates
    min_wait = 1500
    max_wait = 2500
