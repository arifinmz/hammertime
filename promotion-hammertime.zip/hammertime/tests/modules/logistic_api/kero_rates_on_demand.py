from locust import HttpLocust, TaskSet, task
from modules import gw
from libs import bearer_token, tkpdhmac
from random import choice, uniform
import random, time

class KeroratesOnDemand(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"]
        self.kero_rates = self.config['kero']['list_address'][0]

        self.os_type = '1'
        self.device_id = 'b'
        self.user_id = '5480842'
        self.timeout = (self.config['timeout'][0],self.config['timeout'][1])
        self.cb_threshold = self.config["cb_threshold"]

    def randomize_address(self):
        #Random districtId
        district_id = range(2253,2260) + range (2262,2271) + range (2273,2280) + range (2282,2287) + range (2289,2298)
        self.origin_district = str(random.choice(district_id))
        self.destination_district = str(random.choice(district_id))

        #Random latitude
        self.origin_latitude = str(random.uniform(-6.149573, -6.247871))
        self.destination_latitude = str(random.uniform(-6.149573, -6.247871))

        #Random longtitude
        self.origin_longtitude = str(random.uniform(106.751159, 106.900907))
        self.destination_longtitude = str(random.uniform(106.751159, 106.900907))

#Simulating Go-Send request
    @task(10)
    def task2(self):
        self.randomize_address()
        query_gojek = "destination="+self.destination_district+"|"+self.kero_rates["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longtitude+"&origin="+self.origin_district+"|"+self.kero_rates["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longtitude+"&weight=1"+"&names="+self.kero_rates["logistic_gojek"]
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, timeout=self.timeout, cb_threshold=self.cb_threshold, query=query_gojek, name=gw.host_production+"/rates/v1?names="+self.kero_rates["logistic_gojek"]) 

#Simulating REX, Grab request
    @task(4)
    def task5(self):
        self.randomize_address()
        logistic_names_rexgrab = random.choice([self.kero_rates["logistic_rex"], self.kero_rates["logistic_grab"]])
        query_logistic_names_rexgrab = "destination="+self.destination_district+"|"+self.kero_rates["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longtitude+"&origin="+self.origin_district+"|"+self.kero_rates["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longtitude+"&weight=1"+"&names="+logistic_names_rexgrab
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, timeout=self.timeout, cb_threshold=self.cb_threshold, query=query_logistic_names_rexgrab, name=gw.host_production+"/rates/v1?names="+logistic_names_rexgrab)

#Simulating Ninja request
    @task(1)
    def task6(self):
        self.randomize_address()
        logistic_names_ninja = self.kero_rates["logistic_ninja"]
        query_logistic_names_ninja = "destination="+self.destination_district+"|"+self.kero_rates["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longtitude+"&origin="+self.origin_district+"|"+self.kero_rates["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longtitude+"&weight=1"+"&names="+logistic_names_ninja
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, timeout=self.timeout, cb_threshold=self.cb_threshold, query=query_logistic_names_ninja, name=gw.host_production+"/rates/v1?names="+logistic_names_ninja )

#Simulating all ondemand logistic request
    @task(4)
    def task8(self):
        self.randomize_address()
        query_ondemand = "destination="+self.destination_district+"|"+self.kero_rates["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longtitude+"&origin="+self.origin_district+"|"+self.kero_rates["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longtitude+"&weight=1"+"&names="+self.kero_rates["logistic_ondemand"]
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, timeout=self.timeout, cb_threshold=self.cb_threshold, query=query_ondemand, name=gw.host_production+"/rates/v1?names="+self.kero_rates["logistic_ondemand"])

class WebsiteUser(HttpLocust):
    host = ""
    task_set = KeroratesOnDemand
    min_wait = 1000
    max_wait = 1000