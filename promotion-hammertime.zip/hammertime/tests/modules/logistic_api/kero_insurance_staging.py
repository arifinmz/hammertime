from locust import HttpLocust, TaskSet, task
from modules import gw
from libs import bearer_token, tkpdhmac
from random import choice, uniform, randrange
import random, time

class Kerorates(TaskSet):
    
    def on_start(self):
        self.config = self.configuration["production"]
        self.kero_rates = self.config['kero']['list_address'][0]

    @task(1)
    def task1(self):
        os_type = '1'
        device_id = 'b'
        user_id = '5480842'

#Random districtId
        district_id = range(2253,2260) + range (2262,2271) + range (2273,2280) + range (2282,2287) + range (2289,2298)
        origin_district = str(random.choice(district_id))
        destination_district = str(random.choice(district_id))

#Random latitude
        origin_latitude = str(random.uniform(-6.149573, -6.247871))
        destination_latitude = str(random.uniform(-6.149573, -6.247871))

#Random longtitude
        origin_longtitude = str(random.uniform(106.751159, 106.900907))
        destination_longtitude = str(random.uniform(106.751159, 106.900907))

        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config["cb_threshold"]
        
#random price
        product_price = str(random.randrange(500, 200000))

#random product category
        product_category = str(random.randrange(1, 200))

#insurance options
        query_noinsurance = "&insurance=0"+"&product_insurance=1"+"&cat_id="+product_category+"&order_value="+product_price
        query_optionalinsurance = "&insurance=1"+"&product_insurance=0"+"&cat_id="+product_category+"&order_value="+product_price
        query_mustinsurance = "&insurance=1"+"&product_insurance=1"+"&cat_id="+product_category+"&order_value="+product_price

#random insurance option
        random_insurance = random.choice([query_noinsurance, query_optionalinsurance, query_mustinsurance])

#logistic
        query_conventional = "destination="+destination_district+"|"+self.kero_rates["destination_postal"]+"|"+destination_latitude+","+destination_longtitude+"&origin="+origin_district+"|"+self.kero_rates["origin_postal"]+"|"+origin_latitude+","+origin_longtitude+"&weight=1"+"&names="+self.kero_rates["logistic_conventional"]
        query_ondemand = "destination="+destination_district+"|"+self.kero_rates["destination_postal"]+"|"+destination_latitude+","+destination_longtitude+"&origin="+origin_district+"|"+self.kero_rates["origin_postal"]+"|"+origin_latitude+","+origin_longtitude+"&weight=1"+"&names="+self.kero_rates["logistic_ondemand"]

#random logistic option
        random_logistic = random.choice([query_conventional, query_ondemand])

#courier grouping
        query_service_instant = "&service="+self.kero_rates["service_instant"]
        query_service_sameday = "&service="+self.kero_rates["service_sameday"]
        query_service_nextday = "&service="+self.kero_rates["service_nextday"]
        query_service_regular = "&service="+self.kero_rates["service_regular"]
        query_service_cargo = "&service="+self.kero_rates["service_cargo"]
        query_service_all = "&service="+self.kero_rates["service_all"]

        random_grouping_conventional = random.choice([query_service_regular, query_service_nextday, query_service_all])
        random_grouping_ondemand = random.choice([query_service_instant, query_service_sameday, query_service_regular, query_service_cargo, query_service_all])

#insurance without grouping
        res = gw.rates_v1(self, gw.host_staging, device_id, user_id, timeout=timeout, cb_threshold=cb_threshold, query=random_logistic+random_insurance, hide_query=True)

#insurance with grouping
        res = gw.rates_v1(self, gw.host_staging, device_id, user_id, timeout=timeout, cb_threshold=cb_threshold, query=query_ondemand+random_grouping_ondemand+random_insurance, hide_query=True)
        res = gw.rates_v1(self, gw.host_staging, device_id, user_id, timeout=timeout, cb_threshold=cb_threshold, query=query_conventional+random_grouping_conventional+random_insurance, hide_query=True)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = Kerorates
    min_wait = 800
    max_wait = 1000