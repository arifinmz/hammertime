from locust import HttpLocust, TaskSet, task
from modules import ongkirapp
from libs import bearer_token, tkpdhmac
from random import choice, uniform
import random, time

class OngkirappRates(TaskSet):
    def on_start(self):
        if not hasattr(OngkirappRates, 'config_loaded') :
                OngkirappRates.config = self.configuration['production']
                OngkirappRates.config_loaded = True

#Random districtId
        district_id = range(2253,2260) + range (2262,2271) + range (2273,2280) + range (2282,2287) + range (2289,2298)
        self.origin_district = str(random.choice(district_id))
        self.destination_district = str(random.choice(district_id))

#Random latitude
        self.origin_latitude = str(random.uniform(-6.149573, -6.247871))
        self.destination_latitude = str(random.uniform(-6.149573, -6.247871))

#Random longtitude
        self.origin_longitude = str(random.uniform(106.751159, 106.900907))
        self.destination_longitude = str(random.uniform(106.751159, 106.900907))

#Simulating JNE request
    @task(20)
    def task1(self):
        query_jne = "service="+OngkirappRates.config['kero']['list_address'][0]['service_all']+"&destination="+self.destination_district+"|"+OngkirappRates.config['kero']['list_address'][0]["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longitude+"&origin="+self.origin_district+"|"+OngkirappRates.config['kero']['list_address'][0]["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longitude+"&weight=1"+"&names="+OngkirappRates.config['kero']['list_address'][0]["logistic_jne"]
        res = ongkirapp.rates_v2(self, ongkirapp.host_production, OngkirappRates.config['kero']["device_id"], OngkirappRates.config['kero']['user_id'], timeout=(OngkirappRates.config['timeout'][0],OngkirappRates.config['timeout'][1]), cb_threshold=OngkirappRates.config["cb_threshold"], query=query_jne, name=ongkirapp.host_production+"/v2/rates?names="+OngkirappRates.config['kero']['list_address'][0]["logistic_jne"])        
        
#Simulating Go-Send request
    @task(10)
    def task2(self):
        query_gojek = "service="+OngkirappRates.config['kero']['list_address'][0]['service_all']+"&destination="+self.destination_district+"|"+OngkirappRates.config['kero']['list_address'][0]["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longitude+"&origin="+self.origin_district+"|"+OngkirappRates.config['kero']['list_address'][0]["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longitude+"&weight=1"+"&names="+OngkirappRates.config['kero']['list_address'][0]["logistic_gojek"]
        res = ongkirapp.rates_v2(self, ongkirapp.host_production, OngkirappRates.config['kero']["device_id"], OngkirappRates.config['kero']['user_id'], timeout=(OngkirappRates.config['timeout'][0],OngkirappRates.config['timeout'][1]), cb_threshold=OngkirappRates.config["cb_threshold"], query=query_gojek, name=ongkirapp.host_production+"/v2/rates?names="+OngkirappRates.config['kero']['list_address'][0]["logistic_gojek"]) 
        
#Simulating J&T request   
    @task(5)
    def task3(self):
        query_jnt = "service="+OngkirappRates.config['kero']['list_address'][0]['service_all']+"&destination="+self.destination_district+"|"+OngkirappRates.config['kero']['list_address'][0]["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longitude+"&origin="+self.origin_district+"|"+OngkirappRates.config['kero']['list_address'][0]["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longitude+"&weight=1"+"&names="+OngkirappRates.config['kero']['list_address'][0]["logistic_jnt"]
        res = ongkirapp.rates_v2(self, ongkirapp.host_production, OngkirappRates.config['kero']["device_id"], OngkirappRates.config['kero']['user_id'], timeout=(OngkirappRates.config['timeout'][0],OngkirappRates.config['timeout'][1]), cb_threshold=OngkirappRates.config["cb_threshold"], query=query_jnt, name=ongkirapp.host_production+"/v2/rates?names="+OngkirappRates.config['kero']['list_address'][0]["logistic_jnt"])
        
#Simulating Wahana request
    @task(3)
    def task4(self):
        query_wahana = "service="+OngkirappRates.config['kero']['list_address'][0]['service_all']+"&destination="+self.destination_district+"|"+OngkirappRates.config['kero']['list_address'][0]["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longitude+"&origin="+self.origin_district+"|"+OngkirappRates.config['kero']['list_address'][0]["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longitude+"&weight=1"+"&names="+OngkirappRates.config['kero']['list_address'][0]["logistic_wahana"]
        res = ongkirapp.rates_v2(self, ongkirapp.host_production, OngkirappRates.config['kero']["device_id"], OngkirappRates.config['kero']['user_id'], timeout=(OngkirappRates.config['timeout'][0],OngkirappRates.config['timeout'][1]), cb_threshold=OngkirappRates.config["cb_threshold"], query=query_wahana, name=ongkirapp.host_production+"/v2/rates?names="+OngkirappRates.config['kero']['list_address'][0]["logistic_wahana"])
        
#Simulating TIKI, REX, Pos, Grab request
    @task(4)
    def task5(self):
        logistic_names_tikiposgrab = random.choice([OngkirappRates.config['kero']['list_address'][0]["logistic_tiki"], OngkirappRates.config['kero']['list_address'][0]["logistic_rex"], OngkirappRates.config['kero']['list_address'][0]["logistic_pos"], OngkirappRates.config['kero']['list_address'][0]["logistic_grab"]])
        query_logistic_names_tikiposgrab = "service="+OngkirappRates.config['kero']['list_address'][0]['service_all']+"&destination="+self.destination_district+"|"+OngkirappRates.config['kero']['list_address'][0]["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longitude+"&origin="+self.origin_district+"|"+OngkirappRates.config['kero']['list_address'][0]["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longitude+"&weight=1"+"&names="+logistic_names_tikiposgrab
        res = ongkirapp.rates_v2(self, ongkirapp.host_production, OngkirappRates.config['kero']["device_id"], OngkirappRates.config['kero']['user_id'], timeout=(OngkirappRates.config['timeout'][0],OngkirappRates.config['timeout'][1]), cb_threshold=OngkirappRates.config["cb_threshold"], query=query_logistic_names_tikiposgrab, name=ongkirapp.host_production+"/v2/rates?names="+logistic_names_tikiposgrab)
        
#Simulating First, SiCepat, Ninja request
    @task(1)
    def task6(self):
        logistic_names_firstsicepatninja = random.choice([OngkirappRates.config['kero']['list_address'][0]["logistic_first"], OngkirappRates.config['kero']['list_address'][0]["logistic_sicepat"], OngkirappRates.config['kero']['list_address'][0]["logistic_ninja"]])
        query_logistic_names_firstsicepatninja = "service="+OngkirappRates.config['kero']['list_address'][0]['service_all']+"&destination="+self.destination_district+"|"+OngkirappRates.config['kero']['list_address'][0]["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longitude+"&origin="+self.origin_district+"|"+OngkirappRates.config['kero']['list_address'][0]["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longitude+"&weight=1"+"&names="+logistic_names_firstsicepatninja
        res = ongkirapp.rates_v2(self, ongkirapp.host_production, OngkirappRates.config['kero']["device_id"], OngkirappRates.config['kero']['user_id'], timeout=(OngkirappRates.config['timeout'][0],OngkirappRates.config['timeout'][1]), cb_threshold=OngkirappRates.config["cb_threshold"], query=query_logistic_names_firstsicepatninja, name=ongkirapp.host_production+"/v2/rates?names="+logistic_names_firstsicepatninja)
        
#Simulating all conventional logistic request
    @task(4)
    def task7(self):
        query_conventional = "service="+OngkirappRates.config['kero']['list_address'][0]['service_all']+"&destination="+self.destination_district+"|"+OngkirappRates.config['kero']['list_address'][0]["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longitude+"&origin="+self.origin_district+"|"+OngkirappRates.config['kero']['list_address'][0]["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longitude+"&weight=1"+"&names="+OngkirappRates.config['kero']['list_address'][0]["logistic_conventional"]
        res = ongkirapp.rates_v2(self, ongkirapp.host_production, OngkirappRates.config['kero']["device_id"], OngkirappRates.config['kero']['user_id'], timeout=(OngkirappRates.config['timeout'][0],OngkirappRates.config['timeout'][1]), cb_threshold=OngkirappRates.config["cb_threshold"], query=query_conventional, name=ongkirapp.host_production+"/v2/rates?names="+OngkirappRates.config['kero']['list_address'][0]["logistic_conventional"])
        
#Simulating all ondemand logistic request
    @task(4)
    def task8(self):
        query_ondemand = "service="+OngkirappRates.config['kero']['list_address'][0]['service_all']+"&destination="+self.destination_district+"|"+OngkirappRates.config['kero']['list_address'][0]["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longitude+"&origin="+self.origin_district+"|"+OngkirappRates.config['kero']['list_address'][0]["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longitude+"&weight=1"+"&names="+OngkirappRates.config['kero']['list_address'][0]["logistic_ondemand"]
        res = ongkirapp.rates_v2(self, ongkirapp.host_production, OngkirappRates.config['kero']["device_id"], OngkirappRates.config['kero']['user_id'], timeout=(OngkirappRates.config['timeout'][0],OngkirappRates.config['timeout'][1]), cb_threshold=OngkirappRates.config["cb_threshold"], query=query_ondemand, name=ongkirapp.host_production+"/v2/rates?names="+OngkirappRates.config['kero']['list_address'][0]["logistic_ondemand"])
        
#Simulating all conventional logistic  weight 10kg request
    @task(4)
    def task8(self):
        query_conventional = "service="+OngkirappRates.config['kero']['list_address'][0]['service_all']+"&destination="+self.destination_district+"|"+OngkirappRates.config['kero']['list_address'][0]["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longitude+"&origin="+self.origin_district+"|"+OngkirappRates.config['kero']['list_address'][0]["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longitude+"&weight=10"+"&names="+OngkirappRates.config['kero']['list_address'][0]["logistic_conventional"]
        res = ongkirapp.rates_v2(self, ongkirapp.host_production, OngkirappRates.config['kero']["device_id"], OngkirappRates.config['kero']['user_id'], timeout=(OngkirappRates.config['timeout'][0],OngkirappRates.config['timeout'][1]), cb_threshold=OngkirappRates.config["cb_threshold"], query=query_conventional, name=ongkirapp.host_production+"/v2/rates?names="+OngkirappRates.config['kero']['list_address'][0]["logistic_conventional"]+"&weight=10")
        
#Simulating all ondemand logistic request
    @task(4)
    def task9(self):
        query_ondemand = "service="+OngkirappRates.config['kero']['list_address'][0]['service_all']+"&destination="+self.destination_district+"|"+OngkirappRates.config['kero']['list_address'][0]["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longitude+"&origin="+self.origin_district+"|"+OngkirappRates.config['kero']['list_address'][0]["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longitude+"&weight=10"+"&names="+OngkirappRates.config['kero']['list_address'][0]["logistic_ondemand"]
        res = ongkirapp.rates_v2(self, ongkirapp.host_production, OngkirappRates.config['kero']["device_id"], OngkirappRates.config['kero']['user_id'], timeout=(OngkirappRates.config['timeout'][0],OngkirappRates.config['timeout'][1]), cb_threshold=OngkirappRates.config["cb_threshold"], query=query_ondemand, name=ongkirapp.host_production+"/v2/rates?names="+OngkirappRates.config['kero']['list_address'][0]["logistic_ondemand"]+"&weight=10")
        
#Simulating all logistic  with product insurance request
    @task(4)
    def task10(self):
        query_all_ins = "service="+OngkirappRates.config['kero']['list_address'][0]['service_all']+"&destination="+self.destination_district+"|"+OngkirappRates.config['kero']['list_address'][0]["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longitude+"&origin="+self.origin_district+"|"+OngkirappRates.config['kero']['list_address'][0]["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longitude+"&weight=100"+"&names="+OngkirappRates.config['kero']['list_address'][0]["logistic_all"]+"&product_insurance=1"
        res = ongkirapp.rates_v2(self, ongkirapp.host_production, OngkirappRates.config['kero']["device_id"], OngkirappRates.config['kero']['user_id'], timeout=(OngkirappRates.config['timeout'][0],OngkirappRates.config['timeout'][1]), cb_threshold=OngkirappRates.config["cb_threshold"], query=query_all_ins, name=ongkirapp.host_production+"/v2/rates?names="+OngkirappRates.config['kero']['list_address'][0]["logistic_all"]+"&product_insurance=1")
        
#Simulating all logistic  with product insurance = 0 request
    @task(4)
    def task10(self):
        query_all_no_ins = "service="+OngkirappRates.config['kero']['list_address'][0]['service_all']+"&destination="+self.destination_district+"|"+OngkirappRates.config['kero']['list_address'][0]["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longitude+"&origin="+self.origin_district+"|"+OngkirappRates.config['kero']['list_address'][0]["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longitude+"&weight=100"+"&names="+OngkirappRates.config['kero']['list_address'][0]["logistic_all"]+"&product_insurance=0"
        res = ongkirapp.rates_v2(self, ongkirapp.host_production, OngkirappRates.config['kero']["device_id"], OngkirappRates.config['kero']['user_id'], timeout=(OngkirappRates.config['timeout'][0],OngkirappRates.config['timeout'][1]), cb_threshold=OngkirappRates.config["cb_threshold"], query=query_all_no_ins, name=ongkirapp.host_production+"/v2/rates?names="+OngkirappRates.config['kero']['list_address'][0]["logistic_all"]+"&product_insurance=0")
        
class WebsiteUser(HttpLocust):
    host = ""
    task_set = OngkirappRates
    min_wait = 1000
    max_wait = 1000