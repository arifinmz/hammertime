from locust import HttpLocust, TaskSet, task
from modules import kero
from libs import bearer_token, tkpdhmac
from random import choice, uniform, randint
import random, time

class Kerotrack(TaskSet):

    def on_start(self):
        self.config = self.configuration["staging"]
        self.kero_rates1 = self.config['kero']['list_address'][0]
        self.os_type = '1'
        self.device_id = 'b'
        self.user_id = '5480842'

        self.timeout = (self.config['timeout'][0],self.config['timeout'][1])
        self.cb_threshold = self.config["cb_threshold"]

    @task(20)
    def task1(self):
#random JNE AWB
        self.kero_AWB_JNE = random.choice(self.kero_rates1["JNE"])
        path_jne = "/jne/"+self.kero_AWB_JNE

        res = kero.tracking_v1(self, kero.host_staging, self.device_id, self.user_id, path_jne, timeout=self.timeout, cb_threshold=self.cb_threshold, hide_query=True, name=kero.host_staging+"/tracking/v1/jne")


    @task(10)
    def task2(self):
#random gojek AWB
        self.kero_AWB_GOJEK = random.choice(self.kero_rates1["GOJEK"])  

        path_jne = "/gojek/"+self.kero_AWB_GOJEK        
        res = kero.tracking_v1(self, kero.host_staging, self.device_id, self.user_id, path_jne, timeout=self.timeout, cb_threshold=self.cb_threshold, hide_query=True, name=kero.host_staging+"/tracking/v1/gojek")

    @task(1)
    def task3(self):
#random pos AWB
        self.kero_AWB_POS = random.choice(self.kero_rates1["POS"])  

        path_jne = "/pos/"+self.kero_AWB_POS        
        res = kero.tracking_v1(self, kero.host_staging, self.device_id, self.user_id, path_jne, timeout=self.timeout, cb_threshold=self.cb_threshold, hide_query=True, name=kero.host_staging+"/tracking/v1/pos")         

class WebsiteUser(HttpLocust):
    host = ""
    task_set = Kerotrack
    min_wait = 1000
    max_wait = 3000