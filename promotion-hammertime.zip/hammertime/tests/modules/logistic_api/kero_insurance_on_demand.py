from locust import HttpLocust, TaskSet, task
from modules import gw
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class KeroInsurance(TaskSet):
    
    def on_start(self):
        self.config = self.configuration["production"]
        self.kero_rates = self.config['kero']['list_address'][0]
        self.large_users = self.team_configuration(self.config['dexter']['20k_accounts'])
        self.account = ah.get_account(self, accounts=self.large_users, login_type=ah.LOGIN_TYPE_BROWSER)

        self.device_id = self.config['device_id']
        self.user_id = self.account['user_id']

        self.timeout = (self.config['timeout'][0],self.config['timeout'][1])
        self.cb_threshold = self.config["cb_threshold"]

        self.instant_service_query= "service="+self.kero_rates["service_instant"]
        self.same_day_service_query = "service="+self.kero_rates["service_sameday"]
        self.regular_service_query = "service="+self.kero_rates["service_regular"]
        self.cargo_service_query = "service="+self.kero_rates["service_cargo"]
        self.all_services_query= "service="+self.kero_rates["service_all"]
        
    def randomize_address(self):
        #Random districtId
        district_id = range(2253,2260) + range (2262,2271) + range (2273,2280) + range (2282,2287) + range (2289,2298)
        self.origin_district = str(random.choice(district_id))
        self.destination_district = str(random.choice(district_id))

        #Random latitude
        self.origin_latitude = str(random.uniform(-6.149573, -6.247871))
        self.destination_latitude = str(random.uniform(-6.149573, -6.247871))

        #Random longtitude
        self.origin_longtitude = str(random.uniform(106.751159, 106.900907))
        self.destination_longtitude = str(random.uniform(106.751159, 106.900907))

    def randomize_price(self):
        self.product_price = str(random.randrange(500, 200000))

    def randomize_category(self):
        self.product_category = str(random.randrange(1, 200))

    def generate_no_insurance_query(self):
        self.randomize_category()
        self.randomize_price()
        self.no_insurance_query = "insurance=0&product_insurance=0&cat_id="+self.product_category+"&order_value="+self.product_price

    def generate_optional_insurance_query(self):
        self.randomize_category()
        self.randomize_price()
        self.optional_insurance_query = "insurance=1&product_insurance=0&cat_id="+self.product_category+"&order_value="+self.product_price

    def generate_must_insurance_query(self):
        self.randomize_category()
        self.randomize_price()
        self.must_insurance_query = "insurance=1&product_insurance=1&cat_id="+self.product_category+"&order_value="+self.product_price

    def generate_on_demand_query(self):
        self.randomize_address()
        self.on_demand_query = "destination="+self.destination_district+"|"+self.kero_rates["destination_postal"]+"|"+self.destination_latitude+","+self.destination_longtitude+"&origin="+self.origin_district+"|"+self.kero_rates["origin_postal"]+"|"+self.origin_latitude+","+self.origin_longtitude+"&weight=1"+"&names="+self.kero_rates["logistic_ondemand"]

    # simulate no insurance without any service
    @task(1)
    def task1(self):
        self.generate_no_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.no_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&{no_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

    # simulate no insurance with instant service
    @task(1)
    def task2(self):
        self.generate_no_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.instant_service_query + "&" + self.no_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&" + self.instant_service_query + "&{no_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)
    
    # simulate no insurance with same day service
    @task(1)
    def task3(self):
        self.generate_no_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.same_day_service_query + "&" + self.no_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&" + self.same_day_service_query + "&{no_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

    # simulate no insurance with regular service
    @task(1)
    def task4(self):
        self.generate_no_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.regular_service_query + "&" + self.no_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&" + self.regular_service_query + "&{no_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

    # simulate no insurance with cargo service
    @task(1)
    def task5(self):
        self.generate_no_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.cargo_service_query + "&" + self.no_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&" + self.cargo_service_query + "&{no_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

    # simulate no insurance with all service
    @task(1)
    def task6(self):
        self.generate_no_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.all_services_query + "&" + self.no_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&" + self.all_services_query + "&{no_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

    # simulate optional insurance without any service
    @task(1)
    def task7(self):
        self.generate_optional_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.optional_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&{optional_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

    # simulate optional insurance with instant service
    @task(1)
    def task8(self):
        self.generate_optional_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.instant_service_query + "&" + self.optional_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&" + self.instant_service_query + "&{optional_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

    # simulate optional insurance with same day service
    @task(1)
    def task9(self):
        self.generate_optional_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.same_day_service_query + "&" + self.optional_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&" + self.same_day_service_query + "&{optional_insurance}"
        rres = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

    # simulate optional insurance with regular service
    @task(1)
    def task10(self):
        self.generate_optional_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.regular_service_query + "&" + self.optional_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&" + self.regular_service_query + "&{optional_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

    # simulate optional insurance with cargo service
    @task(1)
    def task11(self):
        self.generate_optional_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.cargo_service_query + "&" + self.optional_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&" + self.cargo_service_query + "&{optional_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

    # simulate optional insurance with all service
    @task(1)
    def task12(self):
        self.generate_optional_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.all_services_query + "&" + self.optional_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&" + self.all_services_query + "&{optional_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

    # simulate must insurance without any service
    @task(1)
    def task13(self):
        self.generate_must_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.must_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&{must_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

    # simulate must insurance with instant service
    @task(1)
    def task14(self):
        self.generate_must_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.instant_service_query + "&" + self.must_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&" + self.instant_service_query + "&{must_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)


    # simulate must insurance with same day service
    @task(1)
    def task15(self):
        self.generate_must_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.same_day_service_query + "&" + self.must_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&" + self.same_day_service_query + "&{must_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

    # simulate must insurance with regular service
    @task(1)
    def task16(self):
        self.generate_must_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.regular_service_query + "&" + self.must_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&" + self.regular_service_query + "&{must_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

    # simulate must insurance with cargo service
    @task(1)
    def task17(self):
        self.generate_must_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.cargo_service_query + "&" + self.must_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&" + self.cargo_service_query + "&{must_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

    # simulate must insurance with all service
    @task(1)
    def task18(self):
        self.generate_must_insurance_query()
        self.generate_on_demand_query()
        query = self.on_demand_query + "&" + self.all_services_query + "&" + self.must_insurance_query
        name = gw.host_production+"/rates/v1?names="+ self.kero_rates["logistic_ondemand"] + "&" + self.all_services_query + "&{must_insurance}"
        res = gw.rates_v1(self, gw.host_production, self.device_id, self.user_id, query=query, name=name, timeout=self.timeout, cb_threshold=self.cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = KeroInsurance
    min_wait = 1500
    max_wait = 2500