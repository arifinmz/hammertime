import json, random, time, string, datetime
from locust import HttpLocust, TaskSet, task
from modules import galadriel
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class ValidatePayment(TaskSet):

    def on_start(self):
       if not hasattr(ValidatePayment, 'config_loaded') :
           ValidatePayment.test_config = self.configuration['production']
           ValidatePayment.large_users = self.team_configuration(ValidatePayment.test_config['dexter']['20k_accounts'])
           ValidatePayment.config_loaded = True
       self.account = ah.get_account(self, accounts=ValidatePayment.large_users, login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):

        user_id = int(self.account ['user_id'])
        payment_id = int(random.randint(-1000000, -1))
    
        cb_threshold = ValidatePayment.test_config['cb_threshold']
        timeout = (ValidatePayment.test_config['timeout'][0], ValidatePayment.test_config['timeout'][1])


        #Validate Payment        
        bodies_validate_payment = {
            "data": {
              "promo_code_id": 37091706110,
              "scrooge_gateway_id": 32,
              "payment_id": payment_id,
              "user_id": user_id,
              "scrooge_merchant_code": "tokopedia",
              "service_data": {},
              "language": "id",
              "payment_amount": 332000,
              "service_id": 731644293353960,
              "klik_bca_user_name": "mzn1234"
            }
        }
        print(bodies_validate_payment)

        res = galadriel.validate_payment(self, galadriel.host_production, method="POST", json=bodies_validate_payment, name=galadriel.host_production+"/promo_codes/validate/payment",timeout=timeout, cb_threshold=cb_threshold)        
        print('VALIDATE PAYMENT : ', res.content)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = ValidatePayment
    min_wait = 1500
    max_wait = 2500
