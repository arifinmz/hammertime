import json, random, time, string, datetime
from locust import HttpLocust, TaskSet, task
from modules import galadriel
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()


class PromoCodeFlow(TaskSet):

    def on_start(self):
       if not hasattr(PromoCodeFlow, 'config_loaded') :
           PromoCodeFlow.test_config = self.configuration['production']
           PromoCodeFlow.large_users = self.team_configuration(PromoCodeFlow.test_config['dexter']['20k_accounts'])
           PromoCodeFlow.config_loaded = True
       self.account = ah.get_account(self, accounts=PromoCodeFlow.large_users, login_type=ah.LOGIN_TYPE_LITE)
       self.task1()
    #Validate Use

    @task(4)
    def task1(self):
        self.user_id = int(self.account ['user_id'])
        self.email = str(self.account ['email'])
        self.msisdn = str(self.account ['phone'])
        self.payment_id = random.randint(-1000000, -1)
        self.cb_threshold = PromoCodeFlow.test_config['cb_threshold']
        self.timeout = (PromoCodeFlow.test_config['timeout'][0], PromoCodeFlow.test_config['timeout'][1])
        
        #VALIDATE USE BOOK FALSE
        bodies_book_false = {
            "data": {
                "code": "SUPER100QA",
                "user_id": self.user_id,
                "email": self.email,
                "msisdn": self.msisdn,
                "msisdn_verified": 1,
                "grand_total": 332000,
                "first_shipping_price": 30000,
                "total_shipping_price": 30000,
                "product_id_list": [
                "155389293"
                ],
                "menu_id_list": [
                "6573270"
                ],
                "orders": [
                {
                    "shop_id": 1962185,
                    "total_weight": 3020,
                    "is_gold_shop": bool("false"),
                    "dest_city": 463,
                    "dest_province": 11,
                    "shipping_price": 30000,
                    "shipping_id": 14,
                    "sp_id": 27,
                    "total_product_price": 302000,
                    "insurance_price": 0,
                    "additional_fee": 0,
                    "product_details": [
                    {
                        "etalase_id": 6573270,
                        "product_id": 155389293,
                        "quantity": 302,
                        "product_name": "Produk 1 (Karpet)",
                        "price_per_item": 1000,
                        "category_id": 1053,
                        "total_price": 302000
                    }
                    ]
                }
                ],
                "deposit_amount": 0,
                "first_purchase_app": bool("true"),
                "device_type": "default_v3",
                "device_id": "",
                "book": bool("false"),
                "language": "id",
                "service_id": 731644293353960,
                "is_qc_acc": 1,
                "secret_key": "9136a5d48e5883ffbe731e1b322cd5b7dfb4f6a6",
                "app_version": "",
                "is_suggested": bool("true"),
                "user_agent": "",
                "ip_address": "",
                "advertisement_id": ""
            }
        }

        res = galadriel.validate_use(self, galadriel.host_production, method="POST", json=bodies_book_false, name=galadriel.host_production+"/promo_codes/validate/use",timeout=self.timeout, cb_threshold=self.cb_threshold)        

        #VALIDATE USE BOOK TRUE
        bodies_book_true = {
            "data": {
                "code": "SUPER100QA",
                "user_id": self.user_id,
                "email": self.email,
                "msisdn": self.msisdn,
                "msisdn_verified": 1,
                "grand_total": 332000,
                "first_shipping_price": 30000,
                "total_shipping_price": 30000,
                "product_id_list": [
                "155389293"
                ],
                "menu_id_list": [
                "6573270"
                ],
                "orders": [
                {
                    "shop_id": 1962185,
                    "total_weight": 3020,
                    "is_gold_shop": bool("false"),
                    "dest_city": 463,
                    "dest_province": 11,
                    "shipping_price": 30000,
                    "shipping_id": 14,
                    "sp_id": 27,
                    "total_product_price": 302000,
                    "insurance_price": 0,
                    "additional_fee": 0,
                    "product_details": [
                    {
                        "etalase_id": 6573270,
                        "product_id": 155389293,
                        "quantity": 302,
                        "product_name": "Produk 1 (Karpet)",
                        "price_per_item": 1000,
                        "category_id": 1053,
                        "total_price": 302000
                    }
                    ]
                }
                ],
                "deposit_amount": 0,
                "first_purchase_app": bool("true"),
                "device_type": "default_v3",
                "device_id": "",
                "book": bool("false"),
                "language": "id",
                "service_id": 731644293353960,
                "is_qc_acc": 1,
                "secret_key": "9136a5d48e5883ffbe731e1b322cd5b7dfb4f6a6",
                "app_version": "",
                "is_suggested": bool("true"),
                "user_agent": "",
                "ip_address": "",
                "advertisement_id": ""
            }
        }

        res = galadriel.validate_use(self, galadriel.host_production, method="POST", json=bodies_book_true, name=galadriel.host_production+"/promo_codes/validate/use",timeout=self.timeout, cb_threshold=self.cb_threshold)        

        #get promo_code_id from validate use book true response
        jsonTrue = res.json()
        self.promo_code_id = jsonTrue['data']['promo_code_id']

    #VALIDATE PAYMENT 
    @task(2)
    def task2(self):
        bodies_validate_payment = {
            "data": {
              "promo_code_id": self.promo_code_id,
              "scrooge_gateway_id": 524288,
              "payment_id": int(self.payment_id),
              "user_id": self.user_id,
              "scrooge_merchant_code": "tokopedia",
              "service_data": {},
              "language": "id",
              "payment_amount": 332000,
              "service_id": 731644293353960
            }
        }

        res = galadriel.validate_payment(self, galadriel.host_production, method="POST", json=bodies_validate_payment, name=galadriel.host_production+"/promo_codes/validate/payment",timeout=self.timeout, cb_threshold=self.cb_threshold)        

    #NOTIFY SUCCESS
    @task(1)
    def task3(self):
        bodies_notify_success = {
            "data": {
              "user_id": self.user_id,
              "msisdn": self.msisdn,
              "voucher_code": "SUPER100QA",
              "promo_code_id": self.promo_code_id,
              "discount_amount": 0,
              "cashback_amount": 0,
              "payment_id": self.payment_id,
              "payment_amount": 2,
              "payment_gateway": 21,
              "email": self.email,
              "device_id": "",
              "is_qc_load_test":bool("true"),
              "cashback_top_cash_amount": 1,
              "bank_account_number": "",
              "mandiri_click_pay_number": "",
              "klik_bca_user_name": "",
              "credit_card_number": "",
              "cc_exp_month": 0,
              "cc_exp_year": 0,
              "cc_hash": "",
              "card_type_id": 0,
              "service_id": 731644293353960,
              "is_qc_acc": 1,
              "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.81 Safari/537.36",
              "ip_address": "202.179.187.226",
              "advertisement_id": "",
              "orders": [
                {
                  "order_id": 201494655,
                  "shop_id": 1962185,
                  "total_product_price": 32000,
                  "shipping_id": 2,
                  "shipping_price": 9000,
                  "sp_id": 3,
                  "is_gold_shop": bool("false"),
                  "total_weight": 0.32,
                  "dest_province": 11,
                  "dest_city": 463,
                  "insurance_price": 0,
                  "additional_fee": 0,
                  "product_details": [
                    {
                      "total_price": 32000,
                      "product_id": 155389293,
                      "category_id": 1053,
                      "quantity": 32,
                      "price_per_item": 1000,
                      "product_name": "Produk 1 (Karpet)",
                      "OrderDetailID": 348764747,
                      "etalase_id": 6573270
                    }
                  ],
                  "address": {
                    "id": 23356447,
                    "province": 11,
                    "city": 463,
                    "district": 1613,
                    "postal": "123123",
                    "address_name": "pondok aren pondok aren pondok aren pondok aren pondok aren pondok aren",
                    "phone": "123123",
                    "receiver_name": "maizan",
                    "country_name": "Indonesia",
                    "latitude": "-6.284574899999992",
                    "longitude": "106.6974924"
                  },
                  "invoice_ref_num": "INV/20180910/XVIII/IX/201542785"
                }
              ]
            }
        }

        res = galadriel.notify_success(self, galadriel.host_production, method="POST", json=bodies_notify_success, name=galadriel.host_production+"/promo_codes/notify/success",timeout=self.timeout, cb_threshold=self.cb_threshold)        

class WebsiteUser(HttpLocust):
    host = ""
    task_set = PromoCodeFlow
    min_wait = 1500
    max_wait = 2500
