import json, random, time, string, datetime
from locust import HttpLocust, TaskSet, task
from modules import galadriel
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()


class ValidateUse(TaskSet):

    def on_start(self):
       if not hasattr(ValidateUse, 'config_loaded') :
           ValidateUse.test_config = self.configuration['production']
           ValidateUse.large_users = self.team_configuration(ValidateUse.test_config['dexter']['20k_accounts'])
           ValidateUse.config_loaded = True
       self.account = ah.get_account(self, accounts=ValidateUse.large_users, login_type=ah.LOGIN_TYPE_LITE)

    @task(1)
    def task1(self):

        user_id = int(self.account ['user_id'])
        email = str(self.account ['email'])
        msisdn = str(self.account ['phone'])


        cb_threshold = ValidateUse.test_config['cb_threshold']
        timeout = (ValidateUse.test_config['timeout'][0], ValidateUse.test_config['timeout'][1])

#Validate Use Book : False
        bodies_book_false = {
            "data": {
                "code": "MPEMPLOYEE",
                "user_id": user_id,
                "email": email,
                "msisdn": msisdn,
                "msisdn_verified": 1,
                "grand_total": 332000,
                "first_shipping_price": 30000,
                "total_shipping_price": 30000,
                "product_id_list": [
                "155389293"
                ],
                "menu_id_list": [
                "6573270"
                ],
                "orders": [
                {
                    "shop_id": 1962185,
                    "total_weight": 3020,
                    "is_gold_shop": bool("false"),
                    "dest_city": 463,
                    "dest_province": 11,
                    "shipping_price": 30000,
                    "shipping_id": 14,
                    "sp_id": 27,
                    "total_product_price": 302000,
                    "insurance_price": 0,
                    "additional_fee": 0,
                    "product_details": [
                    {
                        "etalase_id": 6573270,
                        "product_id": 155389293,
                        "quantity": 302,
                        "product_name": "Produk 1 (Karpet)",
                        "price_per_item": 1000,
                        "category_id": 1053,
                        "total_price": 302000
                    }
                    ]
                }
                ],
                "deposit_amount": 0,
                "first_purchase_app": bool("true"),
                "device_type": "default_v3",
                "device_id": "",
                "book": bool("false"),
                "language": "id",
                "service_id": 731644293353960,
                "is_qc_acc": 1,
                "secret_key": "9136a5d48e5883ffbe731e1b322cd5b7dfb4f6a6",
                "app_version": "",
                "is_suggested": bool("true"),
                "user_agent": "",
                "ip_address": "",
                "advertisement_id": ""
            }
        }
        #print(bodies_book_false)

        res = galadriel.validate_use(self, galadriel.host_production, method="POST", json=bodies_book_false, name=galadriel.host_production+"/promo_codes/validate/use",timeout=timeout, cb_threshold=cb_threshold)        
        print('BOOK FALSE : ', res.content)
        
class WebsiteUser(HttpLocust):
    host = ""
    task_set = ValidateUse
    min_wait = 1500
    max_wait = 2500
