from locust import HttpLocust, TaskSet, task
from modules import ace

class UserBehavior(TaskSet):
    @task(1)
    def task1(self):

        res = ace.hoth_toppicks_widget(self, ace.host_staging)
        res = ace.hoth_hotlist_home_v1(self, ace.host_staging)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 1000
    max_wait = 1500
