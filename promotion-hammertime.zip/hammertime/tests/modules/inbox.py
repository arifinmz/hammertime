from locust import HttpLocust, TaskSet, task
from modules import inbox, accounts, ws_v4, inbox
import random

class InboxTest(TaskSet):

    # Access Inbox via Desktop & Apps
    # Access PDP Talk via Apps
    # TO DO: Access Shop Response
    
    # Ratio
    # v1/read               1
    # v1/read latest        5
    # v1/comment            1
    # v2/read               1
    # v2/read latest        15
    # v2/comment            1
    # v2/comment latest     10 
    # v1/inbox              1
    # v2/inbox              1
    # v1/response           2

    def on_start(self):

        if not hasattr(InboxTest, 'config_loaded'):
            InboxTest.test_config = self.configuration["production"]
            InboxTest.list_user_id = InboxTest.test_config['inbox']['user_id']
            InboxTest.list_product_id = InboxTest.test_config['inbox']['product_id']
            InboxTest.list_shop_id = InboxTest.test_config['inbox']['shop_id']
            InboxTest.device_id = InboxTest.test_config['device_id']
            InboxTest.os_type = InboxTest.test_config['os_type']
            InboxTest.timeout = (InboxTest.test_config['timeout'][0],InboxTest.test_config['timeout'][1])
            InboxTest.cb_threshold = InboxTest.test_config['cb_threshold']
            InboxTest.latest_talk_id = ""
            InboxTest.talk_id_string = ""
            InboxTest.config_loaded = True
    
    @task(1)
    def readInboxV1(self):
        number = random.randint(0,len(InboxTest.list_user_id)-1)
        user_now = InboxTest.list_user_id[number]
        timeout = InboxTest.timeout
        cb_threshold = InboxTest.cb_threshold
        device_id = InboxTest.device_id

        query = "master=0&filter=all&talktype=inbox&start=0&platform=desktop&user_id=" + str(user_now)+"&loadtest="+ str(user_now)+"-0"

        res = inbox.talk_inbox_v1(self, inbox.host_production, user_now, device_id, name=inbox.host_production + "/talk/v1/inbox", query=query, timeout=timeout, cb_threshold=cb_threshold)

    @task(1)
    def readInboxV2(self):
        number = random.randint(0,len(InboxTest.list_user_id)-1)
        user_now = InboxTest.list_user_id[number]
        timeout = InboxTest.timeout
        cb_threshold = InboxTest.cb_threshold
        device_id = InboxTest.device_id
        
        bodies = {
            'page':1,
            'nav':'inbox-talk',
            'device_id': device_id,
            'user_id':str(user_now),
            'filter':'all',
            'os_type': self.os_type,
            'loadtest':str(user_now)+"-0",
        }

        res = inbox.talk_inbox_v2(self, inbox.host_production, user_now, device_id, name=inbox.host_production + "/talk/v2/inbox", bodies=bodies, timeout=timeout, cb_threshold=cb_threshold)

    @task(1)
    def readCommentV1(self):
        number = random.randint(0,len(InboxTest.list_user_id)-1)
        user_now = InboxTest.list_user_id[number]
        
        if InboxTest.talk_id_string != "" :
            timeout = InboxTest.timeout
            cb_threshold = InboxTest.cb_threshold
            device_id = InboxTest.device_id
            talk = InboxTest.latest_talk_id

            query = "type=multi&loadtest="+ str(user_now)+"-0"

            res = inbox.talk_comment_v1(self,inbox.host_production, talk, name=inbox.host_production+'/talk/v1/comment/', talk=talk, query=query, timeout=timeout, cb_threshold=cb_threshold)

    @task(5)
    def readCommentLatestV1(self):
        number = random.randint(0,len(InboxTest.list_user_id)-1)
        user_now = InboxTest.list_user_id[number]
        
        if InboxTest.latest_talk_id != "" :
            timeout = InboxTest.timeout
            cb_threshold = InboxTest.cb_threshold
            device_id = InboxTest.device_id
            talk = InboxTest.latest_talk_id

            query = "source=sneak_peak&page=1&loadtest="+ str(user_now)+"-0"
            
            res = inbox.talk_comment_v1(self, inbox.host_production, talk, name=inbox.host_production+'/talk/v1/comment/latest', talk=talk, query=query, timeout=timeout, cb_threshold=cb_threshold)
    
    @task(1)
    def readCommentV2(self):
        if InboxTest.latest_talk_id != "":
            number = random.randint(0,len(InboxTest.list_user_id)-1)
            user_now = InboxTest.list_user_id[number]
            timeout = InboxTest.timeout
            cb_threshold = InboxTest.cb_threshold
            device_id = InboxTest.device_id
            
            query = "type=single&talk_id=" + InboxTest.latest_talk_id

            res = inbox.talk_comment_v2(self,inbox.host_production, device_id, user_now, name=inbox.host_production+'/talk/v2/comment/', query=query, timeout=timeout, cb_threshold=cb_threshold)
      
    @task(10)
    def readCommentLatestV2(self):
        if InboxTest.latest_talk_id != "" :
            number = random.randint(0,len(InboxTest.list_user_id)-1)
            user_now = InboxTest.list_user_id[number]
            timeout = InboxTest.timeout
            cb_threshold = InboxTest.cb_threshold
            device_id = InboxTest.device_id

            query = "source=sneak_peak&page=1&talk_id=" + InboxTest.latest_talk_id

            res = inbox.talk_comment_v2(self, inbox.host_production, device_id, user_now, name=inbox.host_production+'/talk/v2/comment/latest', query=query, timeout=timeout, cb_threshold=cb_threshold)
        
    @task(1)
    def readPDPV1(self) :   
        number = random.randint(0,len(InboxTest.list_user_id)-1)
        user_now = InboxTest.list_user_id[number]
        product_id = random.randint(0,len(InboxTest.list_product_id)-1)
        product_now = InboxTest.list_product_id[product_id]
        timeout = InboxTest.timeout
        cb_threshold = InboxTest.cb_threshold
        device_id = InboxTest.device_id
        
        query = "type=p&page=1&product_id="+str(product_now)+"&sort=newest&loadtest=" + str(user_now) + "-0"
        
        res = inbox.talk_read_P_v1(self, inbox.host_production, product_now, name=inbox.host_production + "/talk/v1/read", query=query, timeout=timeout, cb_threshold=cb_threshold)
        if res.status_code == 200:
            try:
                json_talk   = res.json()
                if json_talk['status'] == 1:
                    if len(json_talk['talks']) > 0:
                        talk_ids = []
                        for talk in json_talk['talks']:
                            talk_ids.append(str(talk['id']))
                            InboxTest.latest_talk_id = str(talk['id'])
                        InboxTest.talk_id_string = '~'.join(talk_ids)
                else:
                    raise Exception('talk status != 1')
            except Exception as e:
                print(e)
        else:
            try:
                res.raise_for_status()
            except Exception as e:
                print(e)

    @task(5)
    def readLatestPDPV1(self):
        number = random.randint(0,len(InboxTest.list_user_id)-1)
        user_now = InboxTest.list_user_id[number]
        product_id = random.randint(0,len(InboxTest.list_product_id)-1)
        product_now = InboxTest.list_product_id[product_id]
        timeout = InboxTest.timeout
        cb_threshold = InboxTest.cb_threshold

        query = "source=sneak_peak&product_id="+str(product_now)+"&per_page=1&master=0&page=1&sort=&talkId=&type=p&loadtest=1234-0"

        res = inbox.talk_read_P_v1(self, inbox.host_production, product_now, name=inbox.host_production + "/talk/v1/read/latest", query=query, timeout=timeout, cb_threshold=cb_threshold)
        if res.status_code == 0:
            res.success()

    @task(1)
    def readPDPV2(self):
        number = random.randint(0,len(InboxTest.list_user_id)-1)
        user_now = InboxTest.list_user_id[number]
        product_id = random.randint(0,len(InboxTest.list_product_id)-1)
        product_now = InboxTest.list_product_id[product_id]
        timeout = InboxTest.timeout
        cb_threshold = InboxTest.cb_threshold
        device_id = InboxTest.device_id

        query = "type=p&page=1&product_id="+str(product_now)+"&os_type="+device_id+"&shop_domain=&sort=newest&hash=cc55438207cf2f9a38c098ce6da875ab&device_time=1489983755&loadtest=" + str(user_now) + "-0"

        res = inbox.talk_read_P_v2(self, inbox.host_production, name=inbox.host_production + "/talk/v2/read", query=query, timeout=timeout, cb_threshold=cb_threshold)
    
    @task(15)
    def readLatestPDPV2(self):
        number = random.randint(0,len(InboxTest.list_user_id)-1)
        user_now = InboxTest.list_user_id[number]
        product_id = random.randint(0,len(InboxTest.list_product_id)-1)
        product_now = InboxTest.list_product_id[product_id]
        timeout = InboxTest.timeout
        cb_threshold = InboxTest.cb_threshold

        query = "source=sneak_peak&product_id="+str(product_now)+"&per_page=1&master=0&page=1&sort=&talkId=&type=p&loadtest=1234-0"

        res = inbox.talk_read_P_v2(self, inbox.host_production, name=inbox.host_production + "/talk/v2/read/latest", query=query, timeout=timeout, cb_threshold=cb_threshold)

    @task(2)
    def readResponseV1(self):
        shop_id = random.randint(0,len(InboxTest.list_shop_id)-1)
        shop_now = InboxTest.list_user_id[shop_id]
        timeout = InboxTest.timeout
        cb_threshold = InboxTest.cb_threshold

        res = inbox.talk_response_P_v1(self, inbox.host_production, shop_now, name=inbox.host_production + "/talk/v1/response", timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = InboxTest
    min_wait = 1000
    max_wait = 1500
