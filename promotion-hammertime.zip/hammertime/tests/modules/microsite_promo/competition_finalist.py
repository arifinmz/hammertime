from locust import HttpLocust, TaskSet, task
from modules import api

class CompetitionFinalist(TaskSet):
    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.config = self.configuration["production"]
        
    @task(1)
    def task1(self):
        cb_threshold = self.config["cb_threshold"]

        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        
        res = api.microsites_finalist_v1(self, api.host_production, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = api.host_production
    task_set = CompetitionFinalist
    min_wait = 1500
    max_wait = 2500