from locust import HttpLocust, TaskSet, task
from modules import tokopedia
from tests.helper.account_helper import AccountHelper

ah = AccountHelper(no_login=True)

class UlangTahun(TaskSet):
    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.config = self.configuration["production"]
        self.account = ah.get_account(self, accounts=self.config['dexter']['massive_accounts'], login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        cb_threshold = self.config["cb_threshold"]

        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])

        Ultah_domain = "/ulang-tahun/"
        res = tokopedia.page(self, tokopedia.host_production, Ultah_domain, timeout=timeout_page)

class WebsiteUser(HttpLocust):
    host = tokopedia.host_production
    task_set = UlangTahun
    min_wait = 1500
    max_wait = 2500