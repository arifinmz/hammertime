from locust import HttpLocust, TaskSet, task
from modules import tokopedia, api
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class GrammyLanding(TaskSet):
    def on_start(self):
        if not hasattr(GrammyLanding, 'config_loaded') :
            GrammyLanding.config = self.configuration['production']
            GrammyLanding.config_loaded = True

    @task(1)
    def task1(self):
        timeout = (GrammyLanding.config['timeout'][0],GrammyLanding.config['timeout'][1])
        timeout_page = (GrammyLanding.config['timeout_page'][0],GrammyLanding.config['timeout_page'][1])
        cb_threshold = GrammyLanding.config['cb_threshold']
        domain = "/9tahunbersama"
        res = tokopedia.page(self, tokopedia.host_production, domain, timeout=timeout_page)
        res = api.microsites_grammy_v1(self, api.host_production, timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = tokopedia.host_production
    task_set = GrammyLanding
    min_wait = 600
    max_wait = 800