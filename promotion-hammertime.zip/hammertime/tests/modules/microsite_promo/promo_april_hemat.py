from locust import HttpLocust, TaskSet, task
from modules import tokopedia

class PromoAprilHemat(TaskSet):
    def on_start(self):
        self.config = self.configuration["production"]

    @task(1)
    def task1(self): 
        device_id = self.config["device_id"]
        os_type = self.config["os_type"]

        cb_threshold = self.config["cb_threshold"]

        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        timeout_page = (self.config['timeout_page'][0],self.config['timeout_page'][1])

        aprilhemat_domain = "/april-hemat/"
        res = tokopedia.page(self, tokopedia.host_production, aprilhemat_domain, timeout=timeout_page)
        res = tokopedia.flash_sale_v1(self, tokopedia.host_production, timeout=timeout, cb_threshold=cb_threshold)
        

class WebsiteUser(HttpLocust):
    host = ""
    task_set = PromoAprilHemat
    min_wait = 1500
    max_wait = 2500