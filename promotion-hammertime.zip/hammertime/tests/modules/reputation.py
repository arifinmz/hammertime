from locust import HttpLocust, TaskSet, task
from modules import reputationapp
import random

class Reputation(TaskSet):
	def on_start(self):
		if not hasattr(Reputation, 'config_loaded'):
			Reputation.test_config = self.configuration['production']
			Reputation.config_loaded = True
		
	@task(1)
	def task1(self):

		product_id = random.choice(Reputation.test_config["merchant_tribe"]["reputation_product"])
		shop_id = random.choice(Reputation.test_config["merchant_tribe"]["featured_product"])
		product_gimmick = random.choice(Reputation.test_config["merchant_tribe"]["product_gimmick"])
		user_id=str(random.randint(500000,700000))
		shop_arr = shop_id
		user_arr = user_id
        
		for x in range (1,10):
			shop_id = random.choice(Reputation.test_config["merchant_tribe"]["featured_product"])
			shop_arr = shop_arr+","+shop_id

			user_id=str(random.randint(500000,700000))
			user_arr = user_arr+","+user_id

		timeout     = (Reputation.test_config['timeout'][0],Reputation.test_config['timeout'][1])
		cb_threshold = Reputation.test_config['cb_threshold']
        
		query = "product_id=" + product_id + "&page=1&per_page=10&rating="
		res = reputationapp.reputationapp_review_api_product_P_v1(self, reputationapp.host_production, name=reputationapp.host_production+"/reputationapp/review/api/v1/product", timeout=timeout, cb_threshold=cb_threshold, query=query)
		query = "product_id=" + product_id +"&month_range=1"
		res = reputationapp.reputationapp_review_api_mostHelpful_v1(self, reputationapp.host_production, name=reputationapp.host_production+"/reputationapp/review/api/v1/mosthelpful", timeout=timeout, cb_threshold=cb_threshold,query=query)
		query = "review_ids=57560508&user_id=3045008&shop_id=67726"
		res = reputationapp.reputationapp_review_api_likedDislike_v1(self, reputationapp.host_production, name=reputationapp.host_production+"/reputationapp/review/api/v1/likedislike", timeout=timeout, cb_threshold=cb_threshold,query=query)
		query = "shop_domain=qc45&shop_id=394674&page=1&per_page=10"
		res = reputationapp.reputationapp_review_api_shop_v1(self, reputationapp.host_production, name=reputationapp.host_production+"/reputationapp/review/api/v1/shop", timeout=timeout, cb_threshold=cb_threshold, query=query)
		query = "product_id=" + product_id
		res = reputationapp.reputationapp_review_api_rating_v1(self, reputationapp.host_production,name=reputationapp.host_production+"/reputationapp/review/api/v1/rating", timeout=timeout, cb_threshold=cb_threshold, query=query)
		res = reputationapp.reputationapp_review_api_total_p_product(self, reputationapp.host_production, product_id, name=reputationapp.host_production+"/reputationapp/review/api/v1/total/p/", timeout=timeout, cb_threshold=cb_threshold)
		query = "cut=shop_id:1466145|finish_date:20180620-"
		res = reputationapp.reputationapp_shopSpeed_cube_shopSpeedDaily_aggregate (self, reputationapp.host_slicer, method='GET', name=reputationapp.host_slicer +"/shop-speed/cube/shop_speed_daily/aggregate", timeout=timeout, cb_threshold=cb_threshold, query=query)
		res = reputationapp.reputationapp_statistic_api_shop_speed_daily_v2 (self, reputationapp.host_production, shop_id, method='GET', name=reputationapp.host_production +"/reputationapp/statistic/api/v2/shop/{shop_id}/speed/daily", timeout=timeout, cb_threshold=cb_threshold)
		query= "product_id=" + product_gimmick
		res = reputationapp.reputationapp_rewiew_api_reviewGimmick_v2 (self, reputationapp.host_production, method='GET', name=reputationapp.host_production +"/reputationapp/review/api/v2/review-gimmick", timeout=timeout, cb_threshold=cb_threshold, query=query)	
		query= "page=1&total=10"
		res = reputationapp.reputationapp_review_api_product_P_v2 (self, reputationapp.host_production, product_gimmick, method='GET', name=reputationapp.host_production +"/reputationapp/review/api/v2/product/{product_id}", timeout=timeout, cb_threshold=cb_threshold, query=query)
		res = reputationapp.reputationapp_reputation_api_user_P_v1(self, reputationapp.host_production, user_arr, method='GET', name=reputationapp.host_production +"/reputationapp/reputation/api/v1/user/{user_arr}", timeout=timeout, cb_threshold=cb_threshold)
		res = reputationapp.reputationapp_reputation_api_shop_P_v1(self, reputationapp.host_production, shop_arr, method='GET', name=reputationapp.host_production +"/reputationapp/reputation/api/v1/shop/{shop_arr}", timeout=timeout, cb_threshold=cb_threshold)

class WebsiteUser (HttpLocust):
	task_set = Reputation
	host = ""
	min_wait = 1000
	max_wait =  2500
