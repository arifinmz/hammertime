import json, random, time, string
from locust import HttpLocust, TaskSet, task
from modules import tokopedia, accounts, ws_v4, flight
from datetime import datetime, date, timedelta
from tests.helper.account_helper import AccountHelper

ah = AccountHelper(bearer_host=accounts.host_production, login_host=ws_v4.host_production)

def random_date(start, end):
    """Generate a random datetime between `start` and `end`"""
    return start + timedelta(
        # Get a random amount of seconds between `start` and `end`
        seconds=random.randint(0, int((end - start).total_seconds())),
    )

def random_words(words):
    """Return a random words"""
    random.shuffle(words)
    return words[0]

def calculate_new_price(price_onward,price_return,journey_onward,json_price):
    total_price = price_onward+price_return
    try:
        for p in json_price['data']['attributes']['flight']['new_price']:
            if p['id'] == journey_onward:
                total_price = total_price+int(p['fare']['adult_numeric'])-price_onward
            else:
                total_price = total_price+int(p['fare']['adult_numeric'])-price_return
    except Exception as e:
        print ("exception",e)
    return total_price

class FlightEndToEnd(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self)
    
    @task(1)
    def task1(self):
        user_id = self.account['user_id']  
        device_id = self.config["device_id"]
        email = self.config["flight"]["contact"]["email"]
        """Because flight first travel use phone number as unique key, we need to generate random phone number"""
        phone = str(random.randint(80000, 89999)) + str(random.randint(10000, 99999)) + "000"
        country = self.config["flight"]["contact"]["country"]
        voucher_code = self.config["flight"]["voucher_code"][0]
        ip_address = self.config["flight"]["ip_address"][0]
        name_list = self.config["flight"]["passenger_name"]
        contact_name = random_words(name_list)
        first_name = random_words(name_list)
        last_name = random_words(name_list)
        passport_number = random.randint(100000, 999999)
        test_failed = False
        refresh_time = 7
 
        """Call function to populate search param"""
        """First travel only support routes from AAC to AAD"""
        departure  = "AAC"
        arrival = "AAD"
        """Add 10 days to current date"""  
        today = datetime.now()+timedelta(days=10)
        """Add 6 months from today"""
        until = datetime.now() + timedelta(6*365/12)
        """Random departure date from today to until-7 days to avoid error when randoming return date"""
        departure_date = random_date(today,until-timedelta(days=7))
        """Change date to required format to the API"""
        departure_date_string = departure_date.strftime("%Y-%m-%d")
        """Random return date from departure_date+1 day to avoid same day departure"""
        return_date = random_date(departure_date+timedelta(days=1),until)
        return_date_string = return_date.strftime("%Y-%m-%d")

        """Search onward flight"""
        need_refresh = True
        counter = 0
        while need_refresh:
            bodies ="""{
                        "data": {
                        "type": "search_single",
                        "attributes": {
                            "departure": "%s",
                            "arrival": "%s",
                            "date": "%s",
                            "adult": 1,
                            "child": 0,
                            "infant": 0,
                            "class": 1
                            }
                        }
                    }""" % (departure,arrival,departure_date_string)
            bodies_json= json.loads(bodies)
            res = flight.travel_flight_search_single_v1(self, flight.host_production_api, user_id, device_id, json=bodies_json)
            try:
                json_onward = res.json()
                need_refresh = json_onward['meta']['need_refresh']
                max_retry = json_onward['meta']['max_retry']
                refresh_time = json_onward['meta']['refresh_time']
                counter = counter+1
                """If already have at least 1 journey, stop searching"""
                if (len(json_onward['data'])) > 0:
                    need_refresh = False
                """If reached max_retry, then set test as failed"""
                if max_retry==counter:
                    need_refresh = False
                    test_failed = True
            except Exception as e:
                need_refresh = False
                test_failed = True
            time.sleep(refresh_time)  

        """Search return flight"""
        need_refresh = True
        counter = 0
        while need_refresh:
            bodies ="""{
                        "data": {
                        "type": "search_single",
                        "attributes": {
                            "departure": "%s",
                            "arrival": "%s",
                            "date": "%s",
                            "adult": 1,
                            "child": 0,
                            "infant": 0,
                            "class": 1
                            }
                        }
                    }""" % (arrival,departure,return_date_string)
            bodies_json= json.loads(bodies)
            res = flight.travel_flight_search_single_v1(self, flight.host_production_api, user_id, device_id, json=bodies_json)
            try:
                json_return = res.json()
                need_refresh = json_return['meta']['need_refresh']
                max_retry = json_return['meta']['max_retry']
                refresh_time = json_return['meta']['refresh_time']
                counter = counter+1
                """If already have at least 1 journey, stop searching"""
                if (len(json_return['data'])) > 0:
                    need_refresh = False
                """If reached max_retry, then set test as failed"""
                if max_retry==counter:
                    need_refresh = False
                    test_failed = True
            except Exception as e:
                need_refresh = False
                test_failed = True
            time.sleep(refresh_time)       
        
        """Handling if no flight found"""
        try:
            journey_onward = json_onward['data'][0]['id']
            term_onward = json_onward['data'][0]['attributes']['term']
            price_onward = int(json_onward['data'][0]['attributes']['total_numeric'])
            journey_return = json_return['data'][0]['id']
            term_return = json_return['data'][0]['attributes']['term']
            price_return = int(json_return['data'][0]['attributes']['total_numeric'])
        except Exception as e:
            test_failed = True

        """Handling if search failed"""
        if not test_failed:
            """Add to cart the flight"""
            total_price = price_onward+price_return
            bodies ="""{
                        "data": {
                            "type": "add_cart",
                            "attributes": {
                                "flight": {
                                    "destination": [
                                        {
                                            "journey_id": "%s",
                                            "term": "%s"
                                        },
                                        {
                                            "journey_id": "%s",
                                            "term": "%s"
                                        }
                                    ],
                                    "adult": 1,
                                    "child": 0,
                                    "infant": 0,
                                    "class": 1,
                                    "combo_key": "",
                                    "price": %d,
                                    "price_currency": 1
                                },
                                "ip_address": "%s",
                                "user_agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:51.0) Gecko/20100101 Firefox/51.0",
                                "did": 5
                                }
                            }
                        }""" % (journey_onward, term_onward, journey_return, term_return,total_price,ip_address)
            bodies_json = json.loads(bodies)
            res = flight.travel_flight_cart_v1(self, flight.host_production_api, user_id, device_id, json=bodies_json)
            try:
                json_cart = res.json()
                cart_id = json_cart['data']['id']
                total_price = calculate_new_price(price_onward,price_return,journey_onward,json_cart)
            except Exception as e:
                test_failed = True
        
        """Handling if cart failed"""
        if not test_failed:
            """Check voucher"""    
            query = "cart_id=%s&voucher_code=QADISKON" % (cart_id)
            res = flight.travel_flight_voucher_check_v1(self, flight.host_production_api, user_id, device_id , query=query, hide_query=True)

            """Verify"""
            bodies ="""{
                        "data": {
                            "type": "verify_cart",
                            "attributes": {
                            "cart_items": [
                                {
                                "product_id": 27,
                                "quantity": 1,
                                "meta_data": {
                                    "cart_id": "%s",
                                    "contact_name": "%s",
                                    "email": "%s",
                                    "phone": "%s",
                                    "country": "%s",
                                    "ip_address": "%s",      
                                    "user_agent": "Load Testing",
                                    "passengers": [
                                    {
                                        "type": 0,
                                        "title": 1,
                                        "first_name": "%s",
                                        "last_name": "%s",
                                        "dob": "1993-07-10T00:00:00Z",
                                        "nationality": "ID",
                                        "passport_country": "ID",
                                        "passport_expiry": "2022-02-25T00:00:00Z",
                                        "passport_no": "%d",
                                        "amenities": []
                                    }
                                    ]
                                },
                                "configuration": {
                                    "price": %d
                                }
                                }
                            ],
                            "promocode": "%s"
                            }
                        }
                        }""" % (cart_id, contact_name, email, phone, country, ip_address, first_name, last_name, passport_number, total_price, voucher_code)
            bodies_json = json.loads(bodies)
            res = flight.travel_oms_verify_v1(self, flight.host_production_api, user_id, device_id, json=bodies_json)
            try:
                json_verify = res.json()
                cart_id = json_verify['data']['attributes']['cart_items'][0]['meta_data']['cart_id']
                invoice_id = json_verify['data']['attributes']['cart_items'][0]['meta_data']['invoice_id']
            except Exception as e:
                test_failed=True

        """Handling if verify failed"""
        if not test_failed:
            """Checkout"""
            bodies ="""{
                        "data": {
                            "type": "checkout_cart",
                            "attributes": {
                            "cart_items": [
                                {
                                "product_id": 27,
                                "quantity": 1,
                                "meta_data": {
                                    "cart_id": "%s",
                                    "invoice_id": "%s",
                                    "ip_address": "%s",
                                    "user_agent": "Load Testing",
                                    "did": 4
                                },
                                "configuration": {
                                    "price": %d
                                }
                                }
                            ],
                            "promocode": "%s"
                            }
                        }
                        }""" % (cart_id, invoice_id, ip_address, total_price, voucher_code)
            bodies_json = json.loads(bodies)
            res = flight.travel_oms_checkout_v1(self, flight.host_production_api, user_id, device_id, json=bodies_json)

            """Publish order to NSQ"""
            bodies ="""{
                        "data": {
                            "type": "notify",
                            "attributes": {
                            "invoice_id": "%s",
                            "user_id": %s,
                            "oms_id": 0,
                            "security": "",
                            "force_requeue": true
                            }
                        }
                        }""" % (invoice_id, user_id)
            bodies_json = json.loads(bodies)
            res = flight.travel_flight_recharge_notify_v1(self, flight.host_production_api, user_id, device_id, json=bodies_json)

            """Order list"""
            res = flight.travel_flight_order_list_v1(self, flight.host_production_api, user_id, device_id, query=query, hide_query=True)

            """Order list with invoice_id"""
            res = flight.travel_flight_order_list_with_invoice_id_v1(self, flight.host_production_api, user_id, device_id, invoice_id, query=query, hide_query=True, name=flight.host_production_api+"/travel/v1/flight/order/")

class WebsiteUser(HttpLocust):
    host = ""
    task_set = FlightEndToEnd
    min_wait = 1500
    max_wait = 2500
