import json, random, time, string
from locust import HttpLocust, TaskSet, task
from modules import tokopedia, accounts, ws_v4, flight
from datetime import datetime, date, timedelta
from tests.helper.account_helper import AccountHelper

ah = AccountHelper(bearer_host=accounts.host_production, login_host=ws_v4.host_production)

def generate_airport():
    """Generate random airport for departure and arrival"""
    airport = ["AAC","AAD"]
    random.shuffle(airport)
    departure = airport[0]
    arrival = airport[1]
    return departure, arrival

def random_date(start, end):
    """Generate a random datetime between `start` and `end`"""
    return start + timedelta(
        # Get a random amount of seconds between `start` and `end`
        seconds=random.randint(0, int((end - start).total_seconds())),
    )

def random_words(words):
    """Return a random words"""
    random.shuffle(words)
    return words[0]

def calculate_new_price(price_onward,price_return,journey_onward,json_price):
    total_price = price_onward+price_return
    try:
        for p in json_price['data']['attributes']['flight']['new_price']:
            if p['id'] == journey_onward:
                total_price = total_price+int(p['fare']['adult_numeric'])-price_onward
            else:
                total_price = total_price+int(p['fare']['adult_numeric'])-price_return
    except Exception as e:
        print ("exception",e)
    return total_price

class FlightEndToEnd(TaskSet):

    def on_start(self):
        
        self.config = self.configuration["production"]
        self.account = ah.get_account(self)
    
    @task(1)
    def task1(self):
        user_id = self.account['user_id']  
        device_id = self.config["device_id"]
        refresh_time = 7
 
        """Call function to populate search param"""
        departure, arrival = generate_airport()
        """Add 30 days to current date to avoid flight sold out error"""  
        today = datetime.now()+timedelta(days=30)
        """Add 6 months from today to avoid no flight found during search"""
        until = datetime.now() + timedelta(6*365/12)
        """Random departure date from today to until-7 days to avoid error when randoming return date"""
        departure_date = random_date(today,until-timedelta(days=7))
        """Change date to required format to the API"""
        departure_date_string = departure_date.strftime("%Y-%m-%d")

        """Search flight"""
        need_refresh = True
        counter = 0
        while need_refresh:
            bodies ="""{
                        "data": {
                        "type": "search_single",
                        "attributes": {
                            "departure": "%s",
                            "arrival": "%s",
                            "date": "%s",
                            "adult": 1,
                            "child": 0,
                            "infant": 0,
                            "class": 1
                            }
                        }
                    }""" % (departure,arrival,departure_date_string)
            bodies_json= json.loads(bodies)
            res = flight.travel_flight_search_single_v1(self, flight.host_production_api, user_id, device_id, json=bodies_json)
            try:
                json_onward = res.json()
                need_refresh = json_onward['meta']['need_refresh']
                max_retry = json_onward['meta']['max_retry']
                refresh_time = json_onward['meta']['refresh_time']
                counter = counter+1
                """If already have at least 1 journey, stop searching"""
                if (len(json_onward['data'])) > 0:
                    need_refresh = False
                """If reached max_retry, then set test as failed"""
                if max_retry==counter:
                    need_refresh = False
            except Exception as e:
                need_refresh = False
            time.sleep(refresh_time)  

class WebsiteUser(HttpLocust):
    host = ""
    task_set = FlightEndToEnd
    min_wait = 1500
    max_wait = 2500
