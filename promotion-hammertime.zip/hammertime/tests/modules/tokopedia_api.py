from locust import HttpLocust, TaskSet, task
from modules import tokopedia
from modules import ws_v4
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class UserBehavior(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        device_id = self.config['device_id']
        user_id = self.account['user_id']
        shop_id = self.account['shop_id']
        os_type = self.config['os_type'] 
        headers = {
            'cookie' : ah.get_sid_cookie(user_id)
        }
        res = tokopedia.reputationapp_reputation_api_shop_P_v1(self, tokopedia.host_production, shop_id, method='GET')
        res = tokopedia.ajax_notification_pl(self, tokopedia.host_production, query='action=reload_data&is_interval=1', method='GET')
        res = tokopedia.ajax_nav_deposit_pl(self, tokopedia.host_production, query='action=reload_data&is_interval=1', method='GET')
        res = tokopedia.ajax_verification_number_pl(self, tokopedia.host_production, query='is_fluid=1', headers=headers, method='GET')
        res = tokopedia.ajax_check_quick_guide_pl(self, tokopedia.host_production, query='type=guide_home', method='GET')
        res = tokopedia.ajax_check_quick_guide_pl(self, tokopedia.host_production, query='type=guide_gmstat_home', method='GET')
        res = tokopedia.ajax_check_quick_guide_pl(self, tokopedia.host_production, query='type=guide_fr_home', method='GET')
        res = tokopedia.ajax_r3global_pl(self, tokopedia.host_production, method='GET')
        res = tokopedia.ajax_tx_myshop_pl(self, tokopedia.host_production, query='action=show_dialog_retry_notif', method='GET')

class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 3000
    max_wait = 5000
