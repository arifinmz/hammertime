from locust import HttpLocust, TaskSet, task
from modules import pulsa

class UserBehavior(TaskSet):
    @task(1)
    def task1(self):
        os_type = 1
        device_id = 'b'
        user_id = '5480842'

        query='action=get_deposit'
        res = pulsa.ajax_orderList(self, pulsa.host_staging, query=query)
        res = pulsa.ajax_getlastorder(self, pulsa.host_staging)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 1000
    max_wait = 1500
