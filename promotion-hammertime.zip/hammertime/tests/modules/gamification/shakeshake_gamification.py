from locust import HttpLocust, TaskSet, task
from modules import tokopedia, graphql, booking, accounts, ws_v4
from tests.helper.account_helper import AccountHelper
import random

ah = AccountHelper()

class Gamification(TaskSet):

    def on_start(self):
       if not hasattr(Gamification, 'config_loaded') :
           Gamification.test_config = self.configuration['production']
           Gamification.large_users = self.team_configuration(Gamification.test_config['dexter']['20k_accounts'])
           Gamification.config_loaded = True
       self.account = ah.get_account(self, accounts=Gamification.large_users, login_type=ah.LOGIN_TYPE_BOTH)


    @task(1)
    def task1(self):
        user_id = self.account ['user_id']
        gamificationHeaders = {
            'Cookie': ah.get_sid_cookie(user_id),
            'Authorization':'TKPD Tokopedia:/qygTKKOPX2W2olsPJ+6XJTSAh4=',
            'X-Method':'POST',
            'Date':'Tue, 09 Jan 2018 16:37:39 +0700',
            'Content-MD5':'acce038869bfb60d24de0e70d6c2f8fc',
            'Content-Type':'application/json'
        }
        os_type = Gamification.test_config['os_type']
        device_id = Gamification.test_config['device_id']
        timeout = (Gamification.test_config['timeout'][0], Gamification.test_config['timeout'][1])
        timeout_graphql = (Gamification.test_config['timeout_graphql'][0],Gamification.test_config['timeout_graphql'][1])
        cb_threshold = Gamification.test_config["cb_threshold"]

        # Define Header for Shake2
        shakeShakeHeaders = {
            'Authorization' : ah.get_token(user_id),
            'X-Device' : 'android-2.27',
            'Tkpd-UserId' :	user_id
        }

        #Calling Shake-Shake API
        res = booking.trigger_api_campaign_av_verify_v1(self, booking.host_production, timeout=timeout, headers=shakeShakeHeaders, cb_threshold=cb_threshold, query='is_audio=false&is_qc=1', hide_query=True)
        
        #Floating Egg : the egg
        res = graphql.graphql_FloatingEggQuery(self, graphql.host_graphql, headers=gamificationHeaders, json={"variables":{},"operationName":"FloatingEggQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold) 

        #Token User
        res = graphql.graphql_TokenUser(self, graphql.host_graphql, headers=gamificationHeaders, json={"variables":{}}, timeout=timeout_graphql, cb_threshold=cb_threshold)

        #Crack Egg : crack the egg
        res = graphql.graphql_CrackEgg(self, graphql.host_graphql, headers=gamificationHeaders, timeout=timeout_graphql, cb_threshold=cb_threshold)
        
        #Get URL from Crack Egg response
        jsonCrack = res.json()
        coupon_url = jsonCrack['data']['crackResult']['returnButton']['url']
        coupon_code = coupon_url.replace("https://www.tokopedia.com/tokopoints/kupon-saya/", "")
        couponDetailVariables = {
            'code': coupon_code
        }

        #Coupon Detail : page that will be shown after crack the egg
        res = graphql.graphql_hachikoCouponDetailQuery(self, graphql.host_graphql, headers=gamificationHeaders, json={"variables":couponDetailVariables,"operationName":"hachikoCouponDetailQuery"}, timeout=timeout_graphql, cb_threshold=cb_threshold)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = Gamification
    min_wait = 1000
    max_wait = 1000