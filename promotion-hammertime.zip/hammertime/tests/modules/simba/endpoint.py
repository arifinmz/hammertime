from locust import HttpLocust, TaskSet, task
import json, random
from modules import simba

class EndPoint(TaskSet):

    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.config = self.configuration["production"]

    @task(1)
    def task1(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = ""
        device_id = self.config['device_id']
        customer_id = random.randint(1,1000000)
        json_precheck_mp_email = """{
                                "account":{
                                "customer_id":"""+ str(customer_id) +""",
                                "user_email" : "Wodfodrow1@autongocok.xyz",
                                "msisdn":"082110581991",
                                "user_agent":"Mozilla/5.0 (iPod; CPU iPhone OS 5_0_1 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A405 Safari/7534.48.3",
                                "ip_address":"180.254.96.129",
                                "device":"device",
                                "register_time":1234511116,
                                "is_qa":false
                                },
                          "transaction" : {
                            "promo_id":4400,
                            "base_code": "YAYCASHBACK",
                            "voucher_code":"YAYCASHBACK"
                          },
                          "source" : "marketplace",
                          "rules":[ "email"],
                          "custom_message" : "{\\"client_number\\": \\"6281237411811133\\", \\"category\\": 1,\\"binary_promo_type\\": 32,\\"ads_id\\": \\"12345\\", \\"is_referral_promo\\": false}"
                          }"""
        bodies_json = json.loads(json_precheck_mp_email)

        res = simba.api_promo_v1_validation(self, simba.host_production, user_id, device_id, json=bodies_json, timeout=timeout, cb_threshold=cb_threshold, name=simba.host_production+'/promo/v1/validation/precheck_mp_email')

    @task(1)
    def task2(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = ""
        device_id = self.config['device_id']
        customer_id = random.randint(1,1000000)
        json_precheck_mp_msisdn = """{
                                "account":{
                                "customer_id":"""+ str(customer_id) +""",
                                "user_email" : "alexius@tokopedia.com",
                                "msisdn":"6283106653367",
                                "user_agent":"Mozilla/5.0 (iPod; CPU iPhone OS 5_0_1 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A405 Safari/7534.48.3",
                                "ip_address":"180.254.96.129",
                                "device":"device",
                                "register_time":1234511116,
                                "is_qa":false
                                },
                          "transaction" : {
                            "promo_id":4400,
                            "base_code": "YAYCASHBACK",
                            "voucher_code":"YAYCASHBACK"
                          },
                          "source" : "marketplace",
                          "rules":["msisdn"],
                          "custom_message" : "{\\"client_number\\": \\"6281237411811133\\", \\"category\\": 1,\\"binary_promo_type\\": 32,\\"ads_id\\": \\"123456\\", \\"is_referral_promo\\": false}"
                          }"""
        bodies_json = json.loads(json_precheck_mp_msisdn)

        res = simba.api_promo_v1_validation(self, simba.host_production, user_id, device_id, json=bodies_json, timeout=timeout, cb_threshold=cb_threshold, name=simba.host_production+'/promo/v1/validation/precheck_mp_msisdn')

    @task(1)
    def task3(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = ""
        device_id = self.config['device_id']
        customer_id = random.randint(1,1000000)
        json_precheck_mp_adsid = """{
                                "account":{
                                "customer_id":"""+ str(customer_id) +""",
                                "user_email" : "alexius@tokopedia.com",
                                "msisdn":"082110581991",
                                "user_agent":"Mozilla/5.0 (iPod; CPU iPhone OS 5_0_1 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A405 Safari/7534.48.3",
                                "ip_address":"180.254.96.129",
                                "device":"device",
                                "register_time":1234511116,
                                "is_qa":false
                                },
                          "transaction" : {
                            "promo_id":4400,
                            "base_code": "YAYCASHBACK",
                            "voucher_code":"YAYCASHBACK"
                          },
                          "source" : "marketplace",
                          "rules":["ads_id"],
                          "custom_message" : "{\\"client_number\\": \\"6281237411811133\\", \\"category\\": 1,\\"binary_promo_type\\": 32,\\"ads_id\\": \\"e504a457-6eb9-45d4-82fe-9cffd2a8e56a\\",\\"is_referral_promo\\": false}"
                          }"""
        bodies_json = json.loads(json_precheck_mp_adsid)

        res = simba.api_promo_v1_validation(self, simba.host_production, user_id, device_id, json=bodies_json, timeout=timeout, cb_threshold=cb_threshold, name=simba.host_production+'/promo/v1/validation/precheck_mp_adsid')

    @task(1)
    def task4(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = ""
        device_id = self.config['device_id']
        customer_id = random.randint(1,1000000)
        json_precheck_digital_email = """{
                                "account":{
                                "customer_id":"""+ str(customer_id) +""",
                                "user_email" : "bimibimo19@gmail.com",
                                "msisdn":"082110581991",
                                "user_agent":"Android Tokopedia Application/com.tokopedia.customerappp v.2.19.1 (OPPO X9009; Android; API_22; Version5.1)",
                                "ip_address":"10.7.240.96",
                                "device":"device",
                                "register_time":1234511116,
                                "is_qa":false
                                },
                          "transaction" : {
                            "promo_id":3889,
                            "base_code": "PULSAHEMAT",
                            "voucher_code":"PULSAHEMAT"
                          },
                          "source" : "digital",
                          "rules":["email"],
                          "custom_message" : "{\\"client_number\\": \\"6281237411811133\\", \\"category\\": 1,\\"binary_promo_type\\": 32,\\"ads_id\\": \\"8d580bea-45c3-42dc-b600-3930ee92447a\\",\\"is_referral_promo\\": false}"
                          }"""
        bodies_json = json.loads(json_precheck_digital_email)

        res = simba.api_promo_v1_validation(self, simba.host_production, user_id, device_id, json=bodies_json, timeout=timeout, cb_threshold=cb_threshold, name=simba.host_production+'/promo/v1/validation/precheck_digital_email')

    @task(1)
    def task5(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = ""
        device_id = self.config['device_id']
        customer_id = random.randint(1,1000000)
        json_precheck_digital_msisdn = """{
                                "account":{
                                "customer_id":"""+ str(customer_id) +""",
                                "user_email" : "alexius@tokopedia.com",
                                "msisdn":"628118801717",
                                "user_agent":"Android Tokopedia Application/com.tokopedia.customerappp v.2.19.1 (OPPO X9009; Android; API_22; Version5.1)",
                                "ip_address":"10.7.240.96",
                                "device":"device",
                                "register_time":1234511116,
                                "is_qa":false
                                },
                          "transaction" : {
                            "promo_id":3889,
                            "base_code": "PULSAHEMAT",
                            "voucher_code":"PULSAHEMAT"
                          },
                          "source" : "digital",
                          "rules":["msisdn"],
                          "custom_message" : "{\\"client_number\\": \\"6281237411811133\\", \\"category\\": 1,\\"binary_promo_type\\": 32,\\"ads_id\\": \\"abcdefg-hijklmn-opqrstu\\",\\"is_referral_promo\\": false}"
                          }"""
        bodies_json = json.loads(json_precheck_digital_msisdn)

        res = simba.api_promo_v1_validation(self, simba.host_production, user_id, device_id, json=bodies_json, timeout=timeout, cb_threshold=cb_threshold, name=simba.host_production+'/promo/v1/validation/precheck_digital_msisdn')

    @task(1)
    def task6(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = ""
        device_id = self.config['device_id']
        customer_id = random.randint(1,1000000)
        json_precheck_digital_adsid = """{
                                "account":{
                                "customer_id":"""+ str(customer_id) +""",
                                "user_email" : "alexius@tokopedia.com",
                                "msisdn":"082110581991",
                                "user_agent":"Android Tokopedia Application/com.tokopedia.customerappp v.2.19.1 (OPPO X9009; Android; API_22; Version5.1)",
                                "ip_address":"10.7.240.96",
                                "device":"device",
                                "register_time":1234511116,
                                "is_qa":false
                                },
                          "transaction" : {
                            "promo_id":3889,
                            "base_code": "PULSAHEMAT",
                            "voucher_code":"PULSAHEMAT"
                          },
                          "source" : "digital",
                          "rules":["ads_id"],
                          "custom_message" : "{\\"client_number\\": \\"6281237411811133\\", \\"category\\": 1,\\"binary_promo_type\\": 32,\\"ads_id\\": \\"624d9c30-bd44-494e-9e79-12919bdbee3b\\",\\"is_referral_promo\\": false}"
                          }"""
        bodies_json = json.loads(json_precheck_digital_adsid)

        res = simba.api_promo_v1_validation(self, simba.host_production, user_id, device_id, json=bodies_json, timeout=timeout, cb_threshold=cb_threshold, name=simba.host_production+'/promo/v1/validation/precheck_digital_adsid')

    @task(1)
    def task7(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = ""
        device_id = self.config['device_id']
        customer_id = random.randint(1,1000000)
        json_precheck_digital_client_number = """{
                                            "account":{
                                            "customer_id":"""+ str(customer_id) +""",
                                            "user_email" : "alexius@tokopedia.com",
                                            "msisdn":"082110581991",
                                            "user_agent":"Android Tokopedia Application/com.tokopedia.customerappp v.2.19.1 (OPPO X9009; Android; API_22; Version5.1)",
                                            "ip_address":"10.7.240.96",
                                            "device":"device",
                                            "register_time":1234511116,
                                            "is_qa":false
                                            },
                                      "transaction" : {
                                        "promo_id":3889,
                                        "base_code": "PULSAHEMAT",
                                        "voucher_code":"PULSAHEMAT"
                                      },
                                      "source" : "digital",
                                      "rules":["client_number"],
                                      "custom_message" : "{\\"client_number\\": \\"6282114425786\\", \\"category\\": 1,\\"binary_promo_type\\": 32,\\"ads_id\\": \\"d3e6e620-b816-4e1b-a790-203b71fed562\\"}"
                                      }"""
        bodies_json = json.loads(json_precheck_digital_client_number)

        res = simba.api_promo_v1_validation(self, simba.host_production, user_id, device_id, json=bodies_json, timeout=timeout, cb_threshold=cb_threshold, name=simba.host_production+'/promo/v1/validation/precheck_digital_client_number')

    @task(1)
    def task8(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = ""
        device_id = self.config['device_id']
        customer_id = random.randint(1,1000000)
        json_precheck_digital_referral_count = """{
                                                 "account":{
                                                 "customer_id":"""+ str(customer_id) +""",
                                                 "user_email" : "alexius@tokopedia.com",
                                                 "msisdn":"082110581991",
                                                 "user_agent":"Android Tokopedia Application/com.tokopedia.customerappp v.2.19.1 (OPPO X9009; Android; API_22; Version5.1)",
                                                 "ip_address":"10.7.240.96",
                                                 "device":"device",
                                                 "register_time":1234511116,
                                                 "is_qa":false
                                                 },
                                           "transaction" : {
                                             "promo_id":3889,
                                             "base_code": "PULSAHEMAT",
                                             "voucher_code":"PULSAHEMAT"
                                           },
                                           "source" : "digital",
                                           "custom_message" : "{\\"client_number\\": \\"6282114425786\\", \\"category\\": 1,\\"binary_promo_type\\": 32,\\"ads_id\\": \\"d3e6e620-b816-4e1b-a790-203b71fed562\\"}"
                                           }"""
        bodies_json = json.loads(json_precheck_digital_referral_count)

        res = simba.api_promo_v1_validation(self, simba.host_production, user_id, device_id, json=bodies_json, timeout=timeout, cb_threshold=cb_threshold, name=simba.host_production+'/promo/v1/validation/precheck_digital_referral_count')

    @task(1)
    def task9(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = ""
        device_id = self.config['device_id']
        customer_id = random.randint(1,1000000)
        json_precheck_mp_referral_count = """{
                                "account":{
                                "customer_id":"""+ str(customer_id) +""",
                                "user_email" : "alexius@tokopedia.com",
                                "msisdn":"082110581991",
                                "user_agent":"Mozilla/5.0 (iPod; CPU iPhone OS 5_0_1 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A405 Safari/7534.48.3",
                                "ip_address":"180.254.96.129",
                                "device":"device",
                                "register_time":1234511116,
                                "is_qa":false
                                },
                          "transaction" : {
                            "promo_id":4400,
                            "base_code": "YAYCASHBACK",
                            "voucher_code":"YAYCASHBACK"
                          },
                          "source" : "marketplace",
                          "custom_message" : "{\\"client_number\\": \\"6281237411811133\\", \\"category\\": 1,\\"binary_promo_type\\": 32,\\"ads_id\\": \\"e504a457-6eb9-45d4-82fe-9cffd2a8e56a\\",\\"is_referral_promo\\": false}"
                          }"""
        bodies_json = json.loads(json_precheck_mp_referral_count)

        res = simba.api_promo_v1_validation(self, simba.host_production, user_id, device_id, json=bodies_json, timeout=timeout, cb_threshold=cb_threshold, name=simba.host_production+'/promo/v1/validation/precheck_mp_referral_count')

    @task(1)
    def task10(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = ""
        device_id = self.config['device_id']
        customer_id = random.randint(1,1000000)
        json_precheck_digital_adsid_appsflyer = """{
                                "account":{
                                "customer_id":"""+ str(customer_id) +""",
                                "user_email" : "alexius@tokopedia.com",
                                "msisdn":"082110581991",
                                "user_agent":"Android Tokopedia Application/com.tokopedia.customerappp v.2.19.1 (OPPO X9009; Android; API_22; Version5.1)",
                                "ip_address":"10.7.240.96",
                                "device":"device",
                                "register_time":1234511116,
                                "is_qa":false
                                },
                          "transaction" : {
                            "promo_id":3889,
                            "base_code": "PULSAHEMAT",
                            "voucher_code":"PULSAHEMAT"
                          },
                          "source" : "digital",
                          "rules":["ads_id"],
                          "custom_message" : "{\\"client_number\\": \\"6281237411811133\\", \\"category\\": 1,\\"binary_promo_type\\": 32,\\"ads_id\\": \\"c67bb4b9-7490-4261-9378-3b3d7298bb13\\",\\"is_referral_promo\\": false}"
                          }"""
        bodies_json = json.loads(json_precheck_digital_adsid_appsflyer)

        res = simba.api_promo_v1_validation(self, simba.host_production, user_id, device_id, json=bodies_json, timeout=timeout, cb_threshold=cb_threshold, name=simba.host_production+'/promo/v1/validation/precheck_digital_adsid_appsflyer')

    @task(1)
    def task11(self):
        timeout = (self.config['timeout'][0],self.config['timeout'][1])
        cb_threshold = self.config['cb_threshold']
        user_id = ""
        device_id = self.config['device_id']
        customer_id = random.randint(1,1000000)
        json_precheck_mp_adsid_appsflyer = """{
                                "account":{
                                "customer_id":"""+ str(customer_id) +""",
                                "user_email" : "alexius@tokopedia.com",
                                "msisdn":"082110581991",
                                "user_agent":"Android Tokopedia Application/com.tokopedia.customerappp v.2.19.1 (OPPO X9009; Android; API_22; Version5.1)",
                                "ip_address":"10.7.240.96",
                                "device":"device",
                                "register_time":1234511116,
                                "is_qa":false
                                },
                          "transaction" : {
                            "promo_id":6155,
                            "base_code": "TOPEDSERU",
                            "voucher_code":"TOPEDSERU"
                          },
                          "source" : "marketplace",
                          "rules":["ads_id"],
                          "custom_message" : "{\\"client_number\\": \\"6281237411811133\\", \\"category\\": 1,\\"binary_promo_type\\": 32,\\"ads_id\\": \\"c65b19ac-ec6d-4ee5-96d5-144cf32519c5\\",\\"is_referral_promo\\": false}"
                          }"""
        bodies_json = json.loads(json_precheck_mp_adsid_appsflyer)

        res = simba.api_promo_v1_validation(self, simba.host_production, user_id, device_id, json=bodies_json, timeout=timeout, cb_threshold=cb_threshold, name=simba.host_production+'/promo/v1/validation/precheck_mp_adsid_appsflyer')

class WebsiteUser(HttpLocust):
    host = simba.host_production
    task_set = EndPoint
    min_wait = 1500
    max_wait = 2500
