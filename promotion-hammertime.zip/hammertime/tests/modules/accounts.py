from locust import HttpLocust, TaskSet, task
from modules import accounts, tokopedia
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class UserBehavior(TaskSet):
    

    def on_start(self):
        
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        phone   = self.account['phone']
        env     = 'production'
        os_type = self.config['os_type']
        device_id = self.config['device_id']

        response = accounts.info(self, accounts.host_production, method='GET', query='os_type=%s&device_id=%s&user_id=%s' %(os_type, device_id, user_id))
        response = accounts.api_wallet_balance_v1(self, accounts.host_production, method='GET', query='os_type=%s&device_id=%s&user_id=%s' %(os_type, device_id, user_id))
        response = accounts.api_wallet_balance(self, tokopedia.host_production, method='GET', headers={'origin':accounts.host_production, 'cookie':ah.get_sid_cookie(user_id)})
        response = accounts.login_iframe(self, accounts.host_production, method='GET', query='theme=iframe&p=https%3A%2F%2Fwwww.tokopedia.com%2F&t=1502251636879')

class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 3000
    max_wait = 5000
