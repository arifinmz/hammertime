from locust import HttpLocust, TaskSet, task
from modules import pulsa_api

class UserBehavior(TaskSet):
    @task(1)
    def task1(self):
        os_type = 1
        device_id = 'b'
        user_id = '5480842'

        query= 'os_type=%s&device_id=%s&user_id=%s' % (os_type, device_id, user_id)
        res = pulsa_api.recentNumber_v1_4(self, pulsa_api.host_staging, user_id, query=query, name=pulsa_api.host_staging+"/v1.4/recent-number?"+query)
        query= 'os_type=%s&device_id=%s&user_id=%s' % (os_type, device_id, user_id)
        res = pulsa_api.lastOrder_v1_4(self, pulsa_api.host_staging, user_id, query=query, name=pulsa_api.host_staging+'/v1.4/last-order?'+query)
        res = pulsa_api.status_v1_4(self, pulsa_api.host_staging)
        query='device_id=4'
        res = pulsa_api.product_list_v1_4(self, pulsa_api.host_staging, query=query)
        res = pulsa_api.banner_v1_4(self, pulsa_api.host_staging, query=query)
        res = pulsa_api.operator_list_v1_4(self, pulsa_api.host_staging)
        res = pulsa_api.category_list_v1_4(self, pulsa_api.host_staging)

class WebsiteUser(HttpLocust):
    host = ""
    task_set = UserBehavior
    min_wait = 3000
    max_wait = 5000
