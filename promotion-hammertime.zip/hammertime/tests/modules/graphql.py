from locust import HttpLocust, TaskSet, task
from modules import graphql
from tests.helper.account_helper import AccountHelper

ah = AccountHelper()

class UserBehavior(TaskSet):

    def on_start(self):
        self.config = self.configuration["production"] 
        self.account = ah.get_account(self, login_type=ah.LOGIN_TYPE_BROWSER)

    @task(1)
    def task1(self):
        user_id = self.account['user_id']
        cookie = ah.get_sid_cookie(user_id)

        # without session
        response = graphql.graphql_loggedInStatus(self, graphql.host_production)
        response = graphql.graphql_accountData(self, graphql.host_production, json={"variables":{"source":"web"}})
        response = graphql.graphql_digitalData(self, graphql.host_production)

        # with session
        response = graphql.graphql_loggedInStatus(self, graphql.host_production, headers={'cookie': cookie})
        response = graphql.graphql_accountData(self, graphql.host_production, headers={'cookie': cookie}, json={"variables":{"source":"web"}})
        response = graphql.graphql_digitalData(self, graphql.host_production, headers={'cookie': cookie})
        response = graphql.graphql_feedPlus(self, graphql.host_production, headers={'cookie': cookie}, json={"variables":{"cursor": "","limit": 3,"page": 1,"userID":user_id}})

class WebsiteUser(HttpLocust):
    host     = ""
    task_set = UserBehavior
    min_wait = 3000
    max_wait = 5000
