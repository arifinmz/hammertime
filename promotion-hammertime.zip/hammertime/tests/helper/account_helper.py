from modules import accounts, ws_v4, graphql
from libs import bearer_token
from gevent.lock import Semaphore
import time, datetime
import random

class AccountHelper :
    '''
    Class with an algorithm to maximize effectiveness of choosing random user account from given user list.
    '''
    authorization = {}
    cookies = {}
    not_logged_in = []
    logged_in = []
    sem = Semaphore(value=1)
    accounts_loaded = False

    '''Login via /authorize'''
    LOGIN_TYPE_BROWSER = "BROWSER"
    '''Login via /make_login.pl'''
    LOGIN_TYPE_APP = "APP"
    '''Login via /authorize and /make_login.pl'''
    LOGIN_TYPE_BOTH = "BOTH"
    '''Login via /authorize and getTLiteSession'''
    LOGIN_TYPE_LITE = "LITE"


    def __init__(self, **kwargs):
        '''
        available optional parameters :
          1. `no_login`. Set this to True if you want to choose account without need to do /v4/session/make_login.pl first. default is False
          2. `bearer_host`. Set this with new value if you want to change /token host. default is https://accounts.tokopedia.com
          3. `login_host`. Set this with new value if you want to change /v4/session/make_login.pl host. default is https://ws.tokopedia.com
        '''
        self._bearer_host = kwargs.get('bearer_host',bearer_token.host_production)
        self._login_host = kwargs.get('login_host',ws_v4.host_production)
        self._no_login = kwargs.get('no_login', False)

    def get_account(self, test_object, accounts=list(), **kwargs):
        '''
        Get an account from given account list. 
        It will automatically do /v4/session/make_login.pl if `no_login` is False (default).
        optional parameters :
          1. `accounts`. Set this with new list if you want to give your own account list. default is config['accounts']
          2. `login_type`. Set this with one of served options to specify your login type. default is LOGIN_TYPE_APP
        '''
        list_accounts = accounts
        device_id     = kwargs.get('device_id','b')
        os_type       = kwargs.get('os_type','1')
        login_type    = kwargs.get('login_type', self.LOGIN_TYPE_APP)
        
        # the first concurrent have to assign list of not_logged_in
        if not self.accounts_loaded :
            self.sem.acquire()
            try:
                self.not_logged_in = list_accounts
                self.accounts_loaded = True
            finally:
                self.sem.release()
        # other concurrents will wait until not_logged_in assigned
        while not self.accounts_loaded : pass
        # trying to get an account from not_logged_in list
        try:
            selected_account_index = random.randint(0,len(self.not_logged_in)-1)
            selected_account = self.not_logged_in[selected_account_index]
            # trying to delete an account from not_logged_in.
            # There will be no other conccurents who can take taken account unless not_logged_in list empty
            del self.not_logged_in[selected_account_index]

            if self._no_login is False :
                if login_type == self.LOGIN_TYPE_APP or login_type == self.LOGIN_TYPE_BOTH:
                    status = self._login_app(test_object, selected_account["email"], selected_account["password"], selected_account["user_id"],  os_type, device_id)

                if login_type == self.LOGIN_TYPE_BROWSER or login_type == self.LOGIN_TYPE_LITE or login_type == self.LOGIN_TYPE_BOTH :
                    status = self._login_browser(test_object, selected_account["email"], selected_account["password"], selected_account['user_id'])
                    if login_type == self.LOGIN_TYPE_LITE or login_type == self.LOGIN_TYPE_BOTH:
                        status = self._get_cookie_lite(test_object, selected_account["user_id"])

                if status :
                    self.logged_in.append(selected_account)
                else :
                    self.not_logged_in.append(selected_account)
            else : 
                self.logged_in.append(selected_account)

        except (ValueError, IndexError, AssertionError) as e:
            # the concurrent which can't delete an index at not_logged_in, failed to get data from /token, failed to login will try to get account from logged_in list
            if self.logged_in:
                selected_account = random.choice(self.logged_in)
            else :
                time.sleep(1)
                selected_account = self.get_account(test_object, **kwargs)
        return selected_account

    def get_token(self, user_id):
        '''
        Get authorization token from logged in account
        '''
        try:
            return self.authorization[user_id]
        except Exception:
            return ''

    def get_sid_cookie(self, user_id):
        '''
        Get cookie from logged in account
        '''
        try:
            return self.cookies[user_id]
        except Exception:
            return ''
    
    def _login_browser(self, test_object, email, password, user_id):
        res = accounts.authorize(test_object, accounts.host_production, method="GET", headers={'cookie':''}, query="client_id=1001&p=https%3A%2F%2Fwww.tokopedia.com&redirect_uri=https%3A%2F%2Fwww.tokopedia.com%2Fappauth%2Fcode&response_type=code&state=eyJyZWYiOiJodHRwczovL3d3dy50b2tvcGVkaWEuY29tIiwidXVpZCI6ImE4YjY1MDQ1LTgwOTEtNGVkZS1iODgzLWYwZTAwNmVlZGZmNCJ9", catch_response=True, hide_query=True)
        new_time = datetime.datetime.fromtimestamp(time.time()) + datetime.timedelta(days=2)
        try :
            self.cookies[user_id] = '_SID_Tokopedia_='+res.cookies['_SID_Tokopedia_'] + "; Path=/; Domain=tokopedia.com; Expires="+new_time.strftime('%a, %d %b %Y %H:%M:%S %z')+" GMT; Max-Age=43200; HttpOnly; Secure; l=1; "
        except Exception as e:
            return False
        bodies = {
            'theme':'default',
            'email': email,
            'password': password,
            'remember_me':'on'
        }
        res = accounts.authorize(test_object, accounts.host_production, bodies=bodies, method="POST", query="client_id=1001&p=https%3A%2F%2Fwww.tokopedia.com&redirect_uri=https%3A%2F%2Fwww.tokopedia.com%2Fappauth%2Fcode&response_type=code&state=eyJyZWYiOiJodHRwczovL3d3dy50b2tvcGVkaWEuY29tIiwidXVpZCI6ImE4YjY1MDQ1LTgwOTEtNGVkZS1iODgzLWYwZTAwNmVlZGZmNCJ9",  catch_response=True, hide_query=True)
        try:
            if email in res.content : 
                res.success()
                return True
            else : 
                res.failure("failed to login")
                return False
        except UnicodeDecodeError, e:
            res.failure("Can't decode, return response have unknown char")
            return False
        except Exception, e:
            res.failure(e)
            return False

    def _login_app(self, test_object, email, password, user_id,  os_type, device_id):
        self._token(email, password, user_id, test_object)
        message = "failed to login, token not generated correctly"

        # trying to call /v4/session/make_login.pl
        # Login marked as success if only the value of ['data']['is_login'] from the response is true
        if user_id in self.authorization :
            bodies = {
                'user_id':user_id,
                'device_id':device_id,
                'os_type':os_type
            }
            res = ws_v4.session_makeLogin_pl_v4(test_object, self._login_host, headers={'Authorization': self.authorization[user_id]}, bodies=bodies, catch_response=True)
            if res.status_code == 200:
                try:
                    response = res.json()
                    if response["data"]["is_login"] == "true" :
                        res.success()
                        return True
                    else:
                        message = "failed to login, probably SQ blocked"
                except Exception, e:
                    message = res.content
            else :
                # if response is not 200, throw the error to locust as failed api call
                try :
                    res.raise_for_status()
                except Exception, e:
                    message = e
            res.failure(message)
        return False

    def _get_cookie_lite(self, test_object, user_id):
        headers = {
            'cookie': self.get_sid_cookie(user_id)
        }

        lite = graphql.status(test_object, graphql.host_production, headers=headers)
        try :
            self.cookies[user_id] = self.cookies[user_id]+lite.headers['set-cookie']
            return True
        except Exception:
            return False

    def _token(self, email, password, user_id, test_object):
        bearer_data = {
            'username':email,
            'password':password,
            'client_id':1001,
            'grant_type':'password'
        }
        token = bearer_token.generate(test_object, self._bearer_host, bodies=bearer_data)
        if token : self.authorization[user_id] = token
    
    @property
    def no_login(self):
        '''
        get status if it's required to login to get an account.
        '''
        return self._no_login

    @no_login.setter
    def no_login(self, value):
        '''
        set the status of if it's required to login to get an account.
        '''
        self._no_login = value
    
    @property
    def bearer_host(self):
        '''
        get /token host.
        '''
        return self._bearer_host

    @bearer_host.setter
    def bearer_host(self, value):
        '''
        set /token host.
        '''
        self._bearer_host = value

    @property
    def login_host(self):
        '''
        get /v4/session/make_login.pl host.
        '''
        return self._login_host

    @login_host.setter
    def login_host(self, value):
        '''
        set /v4/session/make_login.pl host.
        '''
        self._login_host = value