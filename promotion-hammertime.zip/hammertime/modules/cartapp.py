from libs import ht, tkpdhmac

host_production = "https://api.tokopedia.com"
host_staging    = "https://api-staging.tokopedia.com"

def add_product_cart_v1(self, host, **kwargs):
    path = "/cart/v1/add_product_cart"
    default = {
        "method": "POST"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def add_product_cart_v2(self, host, **kwargs):
    path = "/cart/v2/add_product_cart"
    default = {
        "method": "POST"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def cart_list(self, host, **kwargs):
    path = "/cart/v1/cart_list"
    default = {
        "method": "GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def cart_list_v2(self, host, **kwargs):
    path = "/cart/v2/cart_list"
    default = {
        "method": "GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def check_promo_code(self, host, **kwargs):
    path = "/cart/v1/check_promo_code"
    default = {
        "method": "POST"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def check_promo_code_v2(self, host, **kwargs):
    path = "/cart/v2/check_promo_code"
    default = {
        "method": "POST"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def remove_from_cart(self, host, **kwargs):
    path = "/cart/v1/remove_product_cart"
    default = {
        "method": "POST"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def remove_from_cart_v2(self, host, **kwargs):
    path = "/cart/v2/remove_product_cart"
    default = {
        "method": "POST"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def update_cart(self, host, **kwargs):
    path = "/cart/v1/update_cart"
    default = {
        "method": "POST"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def update_cart_v2(self, host, **kwargs):
    path = "/cart/v2/update_cart"
    default = {
        "method": "POST"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def cart_notif_counter(self, host, **kwargs):
    path = "/cart/v1/counter"
    default = {
        "method": "GET"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def cart_notif_counter_v2(self, host, **kwargs):
    path = "/cart/v2/counter"
    default = {
        "method": "GET"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def shipment_address_form(self, host, **kwargs):
    path = "/cart/v1/shipment_address_form"
    default = {
        "method": "GET"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def shipment_address_form_v2(self, host, **kwargs):
    path = "/cart/v2/shipment_address_form"
    default = {
        "method": "GET"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def check_promo_code_final(self, host, **kwargs):
    path = "/cart/v1/check_promo_code_final"
    default = {
        "method": "POST"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def check_promo_code_final_v2(self, host, **kwargs):
    path = "/cart/v2/check_promo_code_final"
    default = {
        "method": "POST"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def check_promo_code_final_params(promo_code, address_id, shop_id, shipping_id, sp_id, product_id, notes, quantity):
    param = '{"promo_code":"' + str(promo_code) + '","data":[{"address_id":' + str(address_id) + ',"shop_products":[{"shop_id":' + str(shop_id) \
            + ',"is_preorder":0,"finsurance":0,"shipping_info":{"shipping_id":' + str(shipping_id) + ',"sp_id":' + str(sp_id) \
            + '},"product_data":[{"product_id":' + str(product_id) + ',"product_notes":"' + str(notes) + '","product_quantity":' + str(quantity) \
            + '}],"fcancel_partial":0}]}]}'
    return param

def checkout(self, host, **kwargs):
    path = '/cart/v1/checkout'
    default = {
        'method': 'POST'
    }
    return ht.call(self, host, path, default=default, **kwargs)

def checkout_v2(self, host, **kwargs):
    path = '/cart/v2/checkout'
    default = {
        'method': 'POST'
    }
    return ht.call(self, host, path, default=default, **kwargs)

def cart_i_reset_cart_item_v1(self, host, user_id, device_id, **kwargs):
    path = '/cart/i/v1/reset_cart_item'
    default = {
        'method': 'POST'
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies'))
    return ht.call(self, host, path, default=default, **kwargs)

def remove_product_param(cart_ids, add_wishlist):
    param = '{"cart_ids":[' + str(cart_ids) + '],"add_wishlist":' + str(add_wishlist) + '}'
    return param

def shipping_address_v2(self, host, **kwargs):
    path = '/cart/v2/shipping_address'
    default = {
        'method': 'POST'
    }
    return ht.call(self, host, path, default=default, **kwargs)

def get_notification_v4(self, host, **kwargs):
    path = '/v4/notification/get_notification.pl'
    default = {
        'method': 'GET'
    }
    return ht.call(self, host, path, default=default, **kwargs)


