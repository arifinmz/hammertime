import re, time, json, random, string
from bs4 import BeautifulSoup
from libs import tkpdhmac, ht
from modules import ws_v4

host_production_api = "https://api.tokopedia.com"
host_staging_api = "https://api-staging.tokopedia.com"

def travel_flight_dropdown_airline_v1(self, host, **kwargs):
    path = "/travel/v1/flight/dropdown/airline"
    response = ht.call(self, host, path, **kwargs)
    return response

def travel_flight_search_single_v1(self, host, user_id, device_id, **kwargs):
    path = "/travel/v1/flight/search/single"
    default = {
        "method":"POST"
    }
    path2 = "/v1/flight/search/single"
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_flight(kwargs.get('method', default['method']), path2, user_id, device_id, kwargs.get('headers'), kwargs.get('json'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def travel_flight_cart_v1(self, host, user_id, device_id, **kwargs):
    path = "/travel/v1/flight/cart"
    default = {
        "method":"POST"
    }
    path2 = "/v1/flight/cart"
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_flight(kwargs.get('method', default['method']), path2, user_id, device_id, kwargs.get('headers'), kwargs.get('json'))
    random_char = ''.join(random.choice(string.ascii_letters) for _ in range(5))
    kwargs['headers']['Idempotency-Key'] = "%s-%.20f-%s" % (user_id,time.time(),random_char)
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def travel_flight_voucher_check_v1(self, host, user_id, device_id, **kwargs):
    path = "/travel/v1/flight/voucher/check"
    default = {
        "method":"GET",
        "query":""
    }
    path2 = "/v1/flight/voucher/check"
    kwargs['headers'],kwargs['query'] = tkpdhmac.generate_flight(kwargs.get('method', default['method']), path2, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def travel_oms_verify_v1(self, host, user_id, device_id, **kwargs):
    path = "/travel/v1/oms/verify"
    default = {
        "method":"POST"
    }
    path2 = "/v1/oms/verify"
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_flight(kwargs.get('method', default['method']), path2, user_id, device_id, kwargs.get('headers'), kwargs.get('json'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def travel_oms_checkout_v1(self, host, user_id, device_id, **kwargs):
    path = "/travel/v1/oms/checkout"
    default = {
        "method":"POST"
    }
    path2 = "/v1/oms/checkout"
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_flight(kwargs.get('method', default['method']), path2, user_id, device_id, kwargs.get('headers'), kwargs.get('json'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def travel_flight_recharge_notify_v1(self, host, user_id, device_id, **kwargs):
    path = "/travel/v1/flight/recharge/notify"
    default = {
        "method":"POST"
    }
    path2 = "/v1/flight/recharge/notify"
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_flight(kwargs.get('method', default['method']), path2, user_id, device_id, kwargs.get('headers'), kwargs.get('json'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def travel_flight_order_list_v1(self, host, user_id, device_id, **kwargs):
    path = "/travel/v1/flight/order/list"
    default = {
        "method":"GET",
        "query":""
    }
    path2 = "/v1/flight/order/list"
    kwargs['headers'],kwargs['query'] = tkpdhmac.generate_flight(kwargs.get('method', default['method']), path2, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def travel_flight_order_list_with_invoice_id_v1(self, host, user_id, device_id, invoice_id, **kwargs):
    path = "/travel/v1/flight/order/"+invoice_id
    default = {
        "method":"GET",
        "query":""
    }
    path2 = "/v1/flight/order/"+invoice_id
    kwargs['headers'],kwargs['query'] = tkpdhmac.generate_flight(kwargs.get('method', default['method']), path2, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response