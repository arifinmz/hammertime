from libs import ht

host_production = "https://notifier.tokopedia.com"
host_staging    = "https://notifier-staging.tokopedia.com"

# Purpose : send notification to user
# Session : session only (with userid), but no cookie needed
# Required Parameters : self, host, 
#                       postfixquery can be filled with ''  or with '/smart'
# author: haries.efrika
def send_v2(self, host, postfixquery, **kwargs):
    path1 = '/api/v2/send'
    path2 = path1+postfixquery
    default = {
        'method': 'POST'
    }
    return ht.call(self, host, path2, default=default, **kwargs)
    