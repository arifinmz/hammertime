from libs import ht, tkpdhmac

host_production = "https://chat.tokopedia.com"
host_staging    = "https://chat-staging.tokopedia.com"

# Purpose : to get unread chat notification
# Session : session
# Required Parameters : self, host
def tc_notifUnreads_v1(self, host, **kwargs):
    path = "/tc/v1/notif_unreads"
    default = {
        "method":'GET'
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to get chat
# Session : no session
# Required Parameters : self, host, shop_id
def tc_response_shop_P_v1(self, host, shop_id, **kwargs):
    path        = "/tc/v1/response/shop/%s" % (shop_id)
    response    = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to get chat's template
# Session : no session
# Required Parameters : self, host
def tc_templates_v1(self, host, **kwargs):
    path        = "/tc/v1/templates"
    default = {
        "method": "GET"
    }
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to read list of chat
# Session : session
# Required Parameters : self, host
def tc_list_message_v1(self, host, user_id, device_id,  **kwargs):
    path = "/tc/v1/list_message"
    default = {
        "query":"tab=inbox&filter=all&page=1&per_page=10&platform=desktop&ts=1521626686096",
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_chat(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))    
    response = ht.call(self, host, path, default=default, **kwargs)
    return response
 
# Purpose : to read list of chat reply
# Session : session
# Required Parameters : self, host, msg_id
def tc_list_reply_P_v1(self, host, user_id, device_id,  msg_id, **kwargs):
    path = "/tc/v1/list_reply/%s" % (msg_id)
    default = {
        "query":"page=1&per_page=15",
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response
 
# Purpose : to read list of chat reply v2
# Session : session
# Required Parameters : self, host, msg_id
def tc_list_reply_P_v2(self, host, user_id, device_id,  msg_id, **kwargs):
    path = "/tc/v2/list_reply/%s" % (msg_id)
    default = {
        "query": "page=1&per_page=15",
        "method": "GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to search chat list
# Session : session
# Required Parameters : self, host
def tc_search_v1(self, host, user_id, device_id,  **kwargs):
    path = "/tc/v1/search"
    default = {
        "query": "keyword=locust&status=1&page=1&size=10&by=",
        "method": "GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to get existing chat
# Session : session
# Required Parameters : self, host
def tc_existing_chat_v1(self, host, user_id, device_id,  **kwargs):
    path = "/tc/v1/existing_chat"
    default = {
        "query": "source=shop&to_shop_id=1263613",
        "method": "GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response
 
# Purpose : to get templates chat old version apps
# Session : session
# Required Parameters : self, host
def tc_chat_templates_v1(self, host, **kwargs):
    path = "/tc/v1/chat_templates"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to get server info uploadapp
# Session : session
# Required Parameters : self, host
def tc_uploadapp_v1(self, host, **kwargs):
    path = "/tc/v1/uploadapp"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to get inbox chat pages
# Session : session
# Required Parameters : self, host
def pages_inbox(self, host, **kwargs):
    path = "/pages/inbox?no_gossinc=2"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to get widget chat
# Session : session
# Required Parameters : self, host
def pages_widget(self, host, **kwargs):
    path = "/pages/widget"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to get widget chat var
# Session : session
# Required Parameters : self, host
def pages_widget_getvar(self, host, **kwargs):
    path = "/pages/widget/getvar"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to Send new chat
# Session : session
# Required Parameter : self, host
# Optional Parameter : headers, name, bodies
def tc_send_v1(self, host, user_id, device_id, **kwargs):
    path = "/tc/v1/send"
    default = {
        "method": "POST",
        "bodies": {
            'to_shop_id': '1263613',
            'message': 'test default dari locust'
        }
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to get all list of channel
# Session : session
# Required Parameters : self, host
def gcn_api_channels_v1(self, host, **kwargs):
    path = "/gcn/api/v1/channels"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to view specific channel by id
# Session : session
# Required Parameters : self, host, channel_id
def gcn_api_channel_P_v1(self, host, channel_id, **kwargs):
    path = "/gcn/api/v1/channel/" + channel_id
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to view specific channel by id
# Session : session
# Required Parameters : self, host, poll_id, option_id
def gmf_api_poll_P_vote_v1(self, host, poll_id, **kwargs):
    path = "/gmf/api/v1/poll/" + poll_id + "/vote"
    response = ht.call(self, host, path, **kwargs)
    return response