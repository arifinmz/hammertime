from libs import ht

host_production = "https://merlin.tokopedia.com"
host_staging = "https://merlin-staging.tokopedia.com"
host_nsq = 'http://161.117.70.201:4151'

def api_event_tracking(self, host, **kwargs):
    path = "/iris/v1/track/event"
    
    default = {
        "method":"POST"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def publish_nsq(self, host, **kwargs):
    """
    publish_nsq directly publishes hammertime messages to nsq as avro messages
    """

    path = '/pub?topic=Iris_Event_Tracking'
    default = {
        "method": "POST"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response