from libs import ht, tkpdhmac

host_production = "https://www.tokopedia.com"
host_staging    = "https://staging.tokopedia.com"
host_slicer = "https://slicer.tokopedia.com"

def reputationapp_review_api_product_P_v1 (self, host, **kwargs):

	path = "/reputationapp/review/api/v1/product"

	response = ht.call (self, host, path, **kwargs)
	return response


def reputationapp_review_api_mostHelpful_v1 (self, host, **kwargs):

	path = "/reputationapp/review/api/v1/mosthelpful"

	response = ht.call (self, host, path, **kwargs)
	return response


def reputationapp_review_api_likedDislike_v1 (self, host, **kwargs):

	path = "/reputationapp/review/api/v1/likedislike"

	response = ht.call (self, host, path, **kwargs)
	return response


def reputationapp_review_api_shop_v1 (self, host, **kwargs):

	path = "/reputationapp/review/api/v1/shop"

	response = ht.call (self, host, path, **kwargs)
	return response

def reputationapp_review_api_rating_v1 (self, host, **kwargs):

	path = "/reputationapp/review/api/v1/rating"

	response = ht.call (self, host, path, **kwargs)
	return response

def reputationapp_review_api_catalog_v1 (self, host, catalog_id, **kwargs):

	path = "/reputationapp/review/api/v1/catalog"
	default = {
		"query": catalog_id + "&page=1&per_page=10"
	}

	response = ht.call (self, host, path, default=default, **kwargs)
	return response

def reputationapp_review_api_total_p_product (self, host,  product_id, **kwargs):

	path = "/reputationapp/review/api/v1/total/p/" + product_id

	response = ht.call (self, host, path, **kwargs)
	return response

def reputationapp_reputation_api_inbox_v1(self, host, **kwargs):

	path = "/reputationapp/reputation/api/v1/inbox"

	response = ht.call (self, host, path, **kwargs)
	return response

def reputationapp_shopSpeed_cube_shopSpeedDaily_aggregate (self, host, **kwargs):
    path = "/shop-speed/cube/shop_speed_daily/aggregate"

    response = ht.call (self, host, path, **kwargs)
    return response

def reputationapp_statistic_api_shop_speed_daily_v2 (self, host,shop_id, **kwargs):

    path = "/reputationapp/statistic/api/v2/shop/"+ shop_id +"/speed/daily"

    response = ht.call (self, host, path, **kwargs)
    return response


def reputationapp_rewiew_api_reviewGimmick_v2 (self, host, **kwargs):

    path = "/reputationapp/review/api/v2/review-gimmick"

    response = ht.call (self, host, path, **kwargs)
    return response

def reputationapp_review_api_product_P_v2 (self, host, product_id, **kwargs):

	path = "/reputationapp/review/api/v2/product/" + product_id

	response = ht.call (self, host, path, **kwargs)
	return response

def reputationapp_reputation_api_user_P_v1 (self, host, user_id, **kwargs):

	path = "/reputationapp/reputation/api/v1/user/" + user_id

	response = ht.call (self, host, path, **kwargs)
	return response

def reputationapp_reputation_api_shop_P_v1 (self, host, shop_id, **kwargs):

	path = "/reputationapp/reputation/api/v1/shop/" + shop_id

	response = ht.call (self, host, path, **kwargs)
	return response
