from libs import bearer_token, tkpdhmac, ht

host_production = "https://accounts.tokopedia.com"
host_staging    = "https://accounts-staging.tokopedia.com"

# Purpose: get user information, use at android
# Description: For header need Authorization (token type and access token). For query need os type, device id, user id
# Session: after login
# Required parameters: host
# Optional parameters: method, name, headers, query
def info(self, host, **kwargs):
    path     = '/info'
    default = {
        "query":'os_type=1&device_id=b&user_id=5480842'
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose: get wallet balance, use at android
# Description: for header need Authorization (token type and access token). For query need os type, device id, user id
# Session: after login
# Required parameters: host
# Optional parameters: method, name, headers, query
def api_wallet_balance_v1(self, host, **kwargs):
    path = '/api/v1/wallet/balance'
    default = {
        "query":'os_type=1&device_id=b&user_id=5480842'
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose: get wallet balance, use at desktop
# Description:  for header need cookie and origin (host)
# Session: after login
# Required parameters: self, host
# Optional parameters: method, name, headers
def api_wallet_balance(self, host, **kwargs):
    path = '/api/wallet/balance'
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose: to extend cookie expiration time
# Session: before, after login
# Required parameters: self, host
# Optional parameters: method, name, headers, query
def marketplace_pixel(self, host, **kwargs):
    path     = '/marketplace/pixel'
    response = ht.call(self, host, path, **kwargs)
    return response

def authorize(self,host, **kwargs):
    path = '/authorize'
    default = {
        'method' : "GET"
    }    
    response = ht.call(self, host, path, **kwargs)
    return response

def token(self, host, **kwargs):
    path= '/token'
    default = {
        'method':'POST',
        'headers': {
            'authorization':'Basic MTAwMTo3YzcxNDFjMTk3Zjg5Nzg3MWViM2I1YWY3MWU1YWVjNzAwMzYzMzU1YTc5OThhNGUxMmMzNjAwYzdkMzE='
        }
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response