from libs import tkpdhmac, ht
import time
import random

host_production = "https://pulsa-api.tokopedia.com"
host_staging    = "https://pulsa-api-staging.tokopedia.com"

# Purpose : get recent number in pulsa
# Required Params: host, user_id
# Optional Params: headers, query(os_type, device_id, user_id), name, method
# Session: need make login, match the device_id, need hmac pulsa for authorization
def recentNumber_v1_4(self, host, user_id, **kwargs):
    path = '/v1.4/recent-number'
    default = {
        "query":"os_type=1&device_id=b&user_id="+user_id,
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_pulsa(kwargs.get('method', default['method']), path, user_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : get favorite list
# Required Params: host, user_id
# Optional Params: headers, query(os_type, device_id, user_id), name, method
# Session: need make login, match the device_id, need hmac pulsa for authorization
def favorite_list_v1_4(self, host, user_id, **kwargs):
    path = '/v1.4/favorite/list'
    default = {
        "headers":{},
        "query":"os_type=1&device_id=b&user_id="+user_id,
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_pulsa(kwargs.get('method', default['method']), path, user_id, kwargs.get('headers', default['headers']), kwargs.get('query', default['query']))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : get user last order in pulsa
# Required Params: host, user_id
# Optional Params: headers, query(os_type, device_id, user_id), name, method
# Session: need make login, match the device_id, need hmac pulsa for authorization
def lastOrder_v1_4(self, host, user_id, **kwargs):
    path = '/v1.4/last-order'
    default = {
        "query":"os_type=1&device_id=b&user_id="+user_id,
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_pulsa(kwargs.get('method', default['method']), path, user_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : get user status in pulsa
# Required Params: host
# Optional Params: headers, query(os_type, device_id, user_id), name, method
# Session: can be access with/out login
def status_v1_4(self, host, **kwargs):
    path = '/v1.4/status'
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : get all product list in pulsa
# Required Params: host
# Optional Params: headers, query(os_type, device_id, user_id), name, method
# Session: can be access with/out login
def product_list_v1_4(self, host, **kwargs):
    path = '/v1.4/product/list'
    default = {
        "query":"device_id=4"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : get operator list in pulsa
# Required Params: host
# Optional Params: headers, query(os_type, device_id, user_id), name, method
# Session: can be access with/out login, cookie is not mandatory, can be access with/out cookie
def operator_list_v1_4(self, host, **kwargs):
    path = '/v1.4/operator/list'
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : get category list in pulsa
# Required Params: host
# Optional Params: headers, query(os_type, device_id, user_id), name, method
# Session: can be access with/out login, cookie is not mandatory, can be access with/out cookie
def category_list_v1_4(self, host, **kwargs):
    path = '/v1.4/category/list'
    response = ht.call(self, host, path, **kwargs)
    return response

def category_P_v1_4(self, host, category_id, **kwargs):
    path = '/v1.4/category/' + category_id
    response = ht.call(self, host, path, **kwargs)
    return response



# Purpose : get category pulsa
# Required Params: host
# Optional Params: headers, query(os_type, device_id, user_id), name, method
# Session: can be access with/out login, cookie is not mandatory, can be access with/out cookie
def category_pulsa_v1_4(self, host, **kwargs):
    path = '/v1.4/category/1'
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose: get list of recharge product category
# Description: no need cookie for using session
# Session: before, after login
# Required parameters: self, host
# Optional parameters: method, name, headers, query
def category_list_v1_1(self, host, **kwargs):
    path = '/v1.1/category/list'
    response = ht.call(self, host, path, **kwargs)
    return response


# Purpose : get banner pulsa
# Required Params: host
# Optional Params: headers, query(os_type, device_id, user_id), name, method
# Session: can be access with/out login, cookie is not mandatory, can be access with/out cookie
def banner_v1_4(self, host, **kwargs):
    path = '/v1.4/banner'
    default = {
        "query":"device_id=4"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def voucher_check_v1_4(self, host, user_id, **kwargs):
    path = '/v1.4/voucher/check'
    default = {
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_pulsa(kwargs.get('method', default['method']), path, user_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def cart_v1_4(self, host, user_id, **kwargs):
    path = '/v1.4/cart'
    default = {
        "method":"POST"
    }
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_pulsa(kwargs.get('method', default['method']), path, user_id, kwargs.get('headers'), kwargs.get('json'))
    kwargs['headers']['Idempotency-Key'] = "%.20f" % time.time() 
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def checkout_v1_4(self, host, user_id, **kwargs):
    path = '/v1.4/checkout'
    default = {
        "method":"POST"
    }
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_pulsa(kwargs.get('method', default['method']), path, user_id, kwargs.get('headers'), kwargs.get('json'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response
