from libs import tkpdhmac, ht

host_staging = "https://slicer-staging.tokopedia.com"
host_production = "https://slicer.tokopedia.com"


#creator        : noor putera utama
#session        : no need session or login, need tkpdhmac
#purpose        : function to get or check slicer shop speed
#required param : host, device_id, user_id, shop_id
#dynamic param  : method, header
def shopSpeed_cube_shopSpeedDaily_aggregate(self, host, device_id, user_id, **kwargs):
    path = "/shop-speed/cube/shop_speed_daily/aggregate"
    default = {
        "method":'GET'
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response