from libs import tkpdhmac, ht

host_production = "https://hades.tokopedia.com"
host_staging    = "https://hades-staging.tokopedia.com"

#purpose        : get category version
#session        : -
#required param : self, host, platform
#optional param : method, query, headers, name
def categories_version_v1(self, host, user_id, device_id, **kwargs):
    path = "/v1/categories_version"
    default = {
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response


#purpose        : get category which is displayed in home page
#session        : -
#required param : self, host
#optional param : method, query, headers, name
def categories_v1(self, host, **kwargs):
    path = "/v1/categories"
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : get more item options which related to toppicks
# Session : no session
# Required Parameters : self, host, category_key
def categories_P_v1(self, host, category_key, **kwargs):
    path = "/v1/categories/"+category_key
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : get more item options which related to toppicks
# Session : no session
# Required Parameters : self, host, category_id
def categories_P_detail_v1(self, host, category_id, **kwargs):
    path = "/v1/categories/"+category_id+"/detail"
    response = ht.call(self, host, path, **kwargs)
    return response

#purpose        : get category which is displayed after searching products
#session        : -
#required param : self, host
#optional param : headers
def categories_v2(self, host, **kwargs):
    path = "/v2/categories"
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#purpose        : get category intermediary
#session        : -
#required param : self, host
#optional param : headers
def categories_P_features_v2(self, host, category_id, **kwargs):
    path = "/v2/categories/" + category_id +"/features"
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def categories_P_detail_v2(self, host, category_id, **kwargs):
    path = "/v2/categories/" + category_id + "/detail"
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#purpose        : v1 get all category by ID
#session        : -
#required param : self, host
#optional param : headers
def categoriesFilter_v1(self, host, **kwargs):
    path     = "/v1/categories"
    default = {
        "query":"filter=type%3D%3Dtree"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#purpose        : v0 get all categories by ID
#session        : -
#required param : self, host
#optional param : headers
def categories_v0_P(self, host, category_id, **kwargs):
    path = "/v0/categories/%s" % (category_id)
    response = ht.call(self, host, path, **kwargs)
    return response

#purpose        : v0 get all categories by ID
#session        : -
#required param : self, host
#mandatory param : headers X-Device
def categories_P_detail_v3(self, host, category_id, **kwargs):
    path = "/v3/categories/" + category_id + "/detail"
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#purpose        : v2 get all category layout by ID
#session        : -
#required param : self, host
#optional param : headers
def categoriesLayout_v1_P(self, host, category_id, **kwargs):
    path = "/v1/category_layout/%s" % (category_id)
    response = ht.call(self, host, path, **kwargs)
    return response

#purpose        : v1 get categories version
#session        : -
#required param : self, host
#optional param : headers
def categoriesVersion2_v1(self, host, **kwargs):
    path = "/v1/categories_version"
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#purpose        : v2 get categories with feature by ID
#session        : -
#required param : self, host
#optional param : headers
def categoriesFeatures_v2_P(self, host, category_id, **kwargs):
    path = "/v2/categories/%s/features" % (category_id)
    response = ht.call(self, host, path, **kwargs)
    return response

    #purpose        : v1 get categories image sample by ID
#session        : -
#required param : self, host
#optional param : headers
def categoriesImageSample_v1_P(self, host, category_id, **kwargs):
    path = "/v1/categories/%s/image_sample" % (category_id)
    response = ht.call(self, host, path, **kwargs)
    return response

#purpose        : v2 get categories description by ID
#session        : -
#required param : self, host
#optional param : headers
def categoriesDescription_v2_P(self, host, category_id, **kwargs):
    path = "/v2/categories/%s/description" % (category_id)
    response = ht.call(self, host, path, **kwargs)
    return response

#purpose        : v1 get categories image by ID
#session        : -
#required param : self, host
#optional param : headers
def categoryCuratedGet_v1_P(self, host, category_id, **kwargs):
    path = "/v1/category_curated/get/%s" % (category_id)
    response = ht.call(self, host, path, **kwargs)
    return response

#purpose        : v1 get categories Breadcrumb
#session        : -
#required param : self, host
#optional param : headers
def categoriesBreadcrumb_v1_P(self, host, category_id, **kwargs):
    path     = "/v1/categories/%s" % (category_id)
    default = {
        "query":"filter=type==list%3Blevel==breadcrumb"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

