from libs import ht

host_production = "https://booking.tokopedia.com"
host_staging    = "https://booking-staging.tokopedia.com"

def trigger_api_campaign_qr_verify_v1(self, host, **kwargs):
    path = "/trigger/v1/api/campaign/qr/verify"

    response = ht.call(self, host, path, **kwargs)
    return response

def trigger_api_campaign_av_verify_v1(self, host, **kwargs):
    path = "/trigger/v1/api/campaign/av/verify"

    response = ht.call(self, host, path, **kwargs)
    return response 