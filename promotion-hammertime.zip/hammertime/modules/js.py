from libs import ht

host_production = "https://js.tokopedia.com"
host_staging    = "https://js-staging.tokopedia.com"

#creator        : fernanda panca prima
#session        : No Session
#purpose        : function to get shop login data
#required param : host
#optional param : method, query, headers, name
def js_shoplogin(self, host, **kwargs):
    path = '/js/shoplogin'
    default = {
        "query":"id=479507&callback=show_last_online"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : fernanda panca prima
#session        : No Session
#purpose        : function to get product statistic
#required param : host
#optional param : method, query, headers, name
def productstats_check(self, host, **kwargs):
    path     = '/productstats/check'
    default = {
        "query":"pid=14286207&callback=show_product_stats"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response
