from libs import ht, tkpdhmac

host_production = "https://gw.tokopedia.com"
host_staging    = "https://gw-staging.tokopedia.com"

def rates_v2(self, host, device_id, user_id, **kwargs):
    path = '/v2/rates'
    default = {
        "method":"GET"
    }
    token, device_time = tkpdhmac.generate_kero_token(kwargs.get('method', default['method']), path)
    kwargs['query'] = "%s&token=%s&ut=%s" %(kwargs['query'] , token, device_time)
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_kero(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response