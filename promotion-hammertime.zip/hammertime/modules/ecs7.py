from libs import ht

host_production       = "https://ecs7.tokopedia.net"

# Purpose : get recharge widget on desktop
# Session : Not Required
# Required Parameters : self, host
# Optional Parameters : query, method, name, headers
def scripts_rechargeWidgetDesktop_v3(self, host, **kwargs):
    path = "/scripts/recharge-widget-desktop-v3.js"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : get recharge widget on mobile web
# Session : Not Required
# Required Parameters : self, host
# Optional Parameters : query, method, name, headers
def scripts_rechargeWidgetMobile(self, host, **kwargs):
    path = "/scripts/recharge-widget-mobile.js"
    response = ht.call(self, host, path, **kwargs)
    return response
