from libs import ht, tkpdhmac

host_production = "https://ace.tokopedia.com"
host_staging    = "https://ace-staging.tokopedia.com"

# Purpose : to get toppicks
# Session : session or no session is applicable, add cookies if session needed
# Required Parameters : self, host
# Optional Parameters : method, query, name, headers
# Example query : source=home&device=android&item=4&count=4&random=true
def hoth_toppicks_widget(self, host, **kwargs):
    path = "/hoth/toppicks/widget"
    default = {
        "query":"source=home&device=desktop&item=4&count=4"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to get tickers
# Session : session or no session is applicable, add cookies if session needed
# Required Parameters : self, host
# Optional Parameters : method, name, headers
def hoth_hotlist_home_v1(self, host, **kwargs):
    path = "/hoth/hotlist/v1/home"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to get ace hoth category
# Session : session or no session is applicable, add cookies if session needed
# Required Parameters : self, host
# Optional Parameters : method, name, headers
def hoth_hotlist_category_v1(self, host, **kwargs):
    path = "/hoth/hotlist/v1/category"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to get ace hotlist tab
# Session : session or no session is applicable, add cookies if session needed
# Required Parameters : self, host
# Optional Parameters : method, name, headers
def hoth_hotlist_v1(self, host, **kwargs):
    path = "/hoth/hotlist/v1"
    response = ht.call(self, host, path, **kwargs)
    return response

def hoth_hotlist_get_v1_1(self, host, **kwargs):
    path = "/hoth/hotlist/v1.1/get"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to get toppicks list
# Description : for header need cookie
# Session : after login
# Required Parameters : self, host, cookie
# Optional Parameters : method, name, headers
def hoth_toppicks_list(self, host, **kwargs):
    path = "/hoth/toppicks/list"
    default = {
        "query":"source=homepage&device=desktop&page=1&perPage=1&items=4&userid=9370471"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to search products
# Session : before login
# Required Parameters : self, host, product_id, shop_id
# Optional Parameters : method, query, name, headers
def search_product_v1(self, host, **kwargs):
    path = "/search/v1/product"
    default = {
        "query":"-id=177749132&shop_id=74500"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to get product of search result
# Description : for header need user-agent
# Session : before, after login
# Required Parameters : self, host, headers (user-agent)
# Optional Parameters : method, name, query, headers
def search_product_v2_4(self, host, **kwargs):
    path = '/search/v2.4/product'
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to get product of search result
# Description : for header need user-agent
# Session : before, after login
# Required Parameters : self, host, headers (user-agent)
# Optional Parameters : method, name, query, headers
def search_product_v2_5(self, host, **kwargs):
    path = '/search/v2.5/product'
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : get search result of product
# Description : for header need cookie (if use session)
# Session : before, after login
# Required Parameters : self, host
# Optional Parameters : method, name, headers, query
def search_product_v2_6(self, host, **kwargs):
    path = '/search/v2.6/product'
    default = {
        "query":"&callback=searchMobile&q=kacamata&device=mobile&breadcrumb=true&image_size=200&image_square=true&unique_id=13260e47013a49d191e5077989280115&full_domain=m.tokopedia.com&scheme=https&source=search&start=0&rows=10&ob=23"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to get catalog of search result
# Description : for header need user-agent
# Session : before, after login
# Required Parameters : self, host, headers (user-agent)
# Optional Parameters : method, name, query, headers
def search_catalog_v2_1(self, host, **kwargs):
    path = '/search/v2.1/catalog'
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : get search result of catalog
# Description : for header need cookie (if use session)
# Session : before, after login
# Required Parameters : self, host
# Optional Parameters : method, name, headers, query
def search_catalog_v1(self, host, **kwargs):
    path = '/search/v1/catalog'
    default = {
        "query":"callback=searchMobileCatalog&q=kacamata"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to get shop of search result
# Description : for header need user-agent
# Session : before, after login
# Required Parameters : self, host, headers (user-agent)
# Optional Parameters : method, name, query, headers
def search_shop_v1(self, host, **kwargs):
    path = '/search/v1/shop'
    default = {
        "query":"callback=searchMobile&q=kacamata&device=mobile&breadcrumb=true&full_domain=m.tokopedia.com&scheme=https&source=search&start=0&rows=10"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def dynamicAttributes_v1(self, host, **kwargs):
    path = "/v1/dynamic_attributes"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to get search filter dynamic attribute
# Description : for header need cookie
# Session : before, after login
# Required Parameters : self, host
# Optional Parameters : method, name, headers, query
def dynamicAttributes_v1_1(self, host, **kwargs):
    path  = '/v1.1/dynamic_attributes'
    response = ht.call(self, host, path, **kwargs)
    return response

#creator : erlangga krisnamukti
#description : check angular json response of dynamic web attribute
#session : before
#required parameters : self, host
#optional parameters : method, query
def dynamic_attributes_v2(self, host, **kwargs):
    path = "/v2/dynamic_attributes"
    default = {
        "query":"st=product&q=baju&ob=23&source=search&device=desktop&callback=angular.callbacks._0"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def dynamic_attributes_v4(self, host, **kwargs):
    path = "/v4/dynamic_attributes"
    response = ht.call(self, host, path, **kwargs)
    return response

#creator : erlangga krisnamukti
#description : check angular json response of Product SRP
#session : before
#required parameters : self, host
#optional parameters : method, query
def search_product_v3(self, host, **kwargs):
    path = "/search/product/v3"
    default = {
        "query":"st=product&q=baju&ob=23&source=search&device=desktop&scheme=https&page=1&rows=60&catalog_rows=10&unique_id=13c5010a68b64a2e8d6b80ae020b215d&start=0&full_domain=www.tokopedia.com&callback=angular.callbacks._1"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator : erlangga krisnamukti
#description : check angular json response of related product in SRP
#session : before
#required parameters : self, host
#optional parameters : method, query
def related_v1(self, host, **kwargs):
    path = "/related/v1"
    default = {
        "query":"source=search&device=desktop&q=baju&st=product&callback=angular.callbacks._2"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#session : after
#required parameters : self, host
#optional parameters : method, query
def universe_v3(self, host, **kwargs):
    path = "/universe/v3"
    default = {
        "query":"q=&device=android&count=5&source=searchbar&unique_id="
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def universe_v6(self, host, **kwargs):
    path = "/universe/v6"
    response = ht.call(self, host, path, **kwargs)
    return response

#session : after
#required parameters : self, host
#optional parameters : method, query
def guide_v1(self, host, **kwargs):
    path = "/guide/v1"
    default = {
        "query":"q=baju"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#session : no session
#required parameters : self, host, search_key
#optional parameters : method, query
def hoth_discovery_api_page_P(self, host, search_key, **kwargs):
    path = "/hoth/discovery/api/page/"+search_key
    response = ht.call(self, host, path, **kwargs)
    return response

def webService_shop_getShopProduct_v1(self, host, user_id, device_id, **kwargs):
    path = "/v1/web-service/shop/get_shop_product"
    default = {
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query', {}))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def r3_recommendation_bypage_v1(self, host, **kwargs):
    path = "/r3/v1/recommendation/bypage"
    response = ht.call(self, host, path, **kwargs)
    return response

def r3_bypage_feeds_v1(self, host, user_id, **kwargs):
    path = "/r3/v1/recommendation/bypage"
    default = {
        "query": "page=1&page_name=feeds&recommendation_size=16&user_id="+user_id+"&xdevice=engine&xsource=loadtest"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def r3_ulabel_v1(self, host, user_id, **kwargs):
    path = "/r3/v1/ulabel"
    default = {
        "query": "user_id="+user_id+"&label=category1,category2,category3,location,user_gender,cluster,price_level,loyalty&xsource=engine&xdevice=loadtest"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response


#session : no session
#required parameters : self, host, search_key
#optional parameters : method, query
def hoth_discovery_api_component_flashsale_P(self, host, search_key, **kwargs):
    path = "/hoth/discovery/api/component/flash-sale/"+search_key
    response = ht.call(self, host, path, **kwargs)
    return response

def hoth_discovery_api_component_sprintSaleTest2_P(self, host, search_key, **kwargs):
    path = "/hoth/discovery/api/component/sprint-sale-test-2/"+search_key
    response = ht.call(self, host, path, **kwargs)
    return response


#session : no session
#required parameters : self, host, component (can be desktop or mobile), campaignid is fixed number (ask discovery team)
#optional parameters : method, query
def hoth_discovery_render_component_flashsale_P(self, host, component, campaignid, **kwargs):
    path = "/hoth/discovery/render/component/"+component+"/flash-sale/"+str(campaignid)
    response = ht.call(self, host, path, **kwargs)
    return response
    
def search_redirect(self, host, **kwargs):
    path = "/search/redirect"
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host
#mandatory parameters : body
def rani_discovery_grpc(self, host, **kwargs):
    path = "/rani/discovery/grpc_test"
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host
#mandatory parameters : body
def rani_discovery_page_preview(self, host, **kwargs):
    path = "/rani/discovery/page_review"
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host
def rani_discovery_admin_page_new(self, host, **kwargs):
    path = "/rani/discovery/admin/component/new"
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host
def rani_discovery_admin_page_component_list(self, host, **kwargs):
    path = "/rani/discovery/admin/component/list"
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host
def rani_discovery_admin_component_ajax(self, host, **kwargs):
    path = "/rani/discovery/admin/component/ajax"
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host
def rani_discovery_admin_layout_new(self, host, **kwargs):
    path = "/rani/discovery/admin/layout/new"
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host
def rani_discovery_admin_layout_page_list(self, host, **kwargs):
    path = "/rani/discovery/admin/layout/list"
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host
def rani_discovery_admin_layout_ajax(self, host, **kwargs):
    path = "/rani/discovery/admin/layout/ajax"
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host
def rani_discovery_admin_page_ajax(self, host, **kwargs):
    path = "/rani/discovery/admin/page/ajax"
    response = ht.call(self, host, path, **kwargs)
    return response


#session : no session
#required parameters : self, host
def v3_dynamic_atributes(self, host, **kwargs):
    path = "/v3/dynamic_attributes"
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host
def v2_dynamic_atributes(self, host, **kwargs):
    path = "/v2/dynamic_attributes"
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host
def search_v2_6_product(self, host, **kwargs):
    path = "/search/v2.6/product"
    response = ht.call(self, host, path, **kwargs)
    return response
#session : no session
#required parameters : self, host
def universe_v5(self, host, **kwargs):
    path = "/universe/v5"
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host, search_key
#optional parameters : method, query
def hoth_discovery_api_component_P(self, host, identifier, component_id, **kwargs):
    path = "/hoth/discovery/api/component/"+identifier+"/"+component_id
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host, search_key
#optional parameters : method, query
def hoth_page_P(self, host, identifier, **kwargs):
    path = "/hoth/page/"+identifier
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host, search_key
#optional parameters : method, query
def hoth_page_mobile_P(self, host, identifier, **kwargs):
    path = "/hoth/mobile_page/"+identifier
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host, search_key
#optional parameters : method, query
def hoth_discovery_render_component_desktop_P(self, host, identifier, component_id, **kwargs):
    path = "/hoth/discovery/render/component/desktop/"+identifier+"/"+component_id
    response = ht.call(self, host, path, **kwargs)
    return response

#session : no session
#required parameters : self, host, search_key
#optional parameters : method, query
def hoth_discovery_render_component_mobile_P(self, host, identifier, component_id, **kwargs):
    path = "/hoth/discovery/render/component/mobile/"+identifier+"/"+component_id
    response = ht.call(self, host, path, **kwargs)
    return response

    
