from bs4 import BeautifulSoup
from libs import tkpdhmac, ht
from modules import ws_v4
import re

host_production = "https://www.tokopedia.com"
host_staging    = "https://staging.tokopedia.com"
host_beta       = "https://beta.tokopedia.com"
host_production_m = "https://m.tokopedia.com"
host_staging_m = "https://m-staging.tokopedia.com"
host_production_gw = "https://gw.tokopedia.com"

# Purpose : Get all static files for home page
# Session : Guest/Logged In(require cookie)
# Required Parameters : host, path
# Optional Parameters : headers, name, method, headers, query, assets
def page(self, host, path, **kwargs):
    url = ht.make_url(host, path, **kwargs)
    response = ht.page(self, url, **kwargs)
    return response

#creator        : erlangga krisnamukti
#session        : -
#purpose        : function to get reputation shop
#required param : host, shopid
#optional param : method, query
def reputationapp_reputation_api_shop_P_v1(self, host, shop_id, **kwargs):
    path = "/reputationapp/reputation/api/v1/shop/" + shop_id
    response = ht.call(self, host, path, **kwargs)
    return response

#creator        : erlangga krisnamukti
#session        : -
#purpose        : function to get json response for notification
#required param : host
#optional param : method, query
def ajax_notification_pl(self, host, **kwargs):
    path = "/ajax/notification.pl"
    default = {
        "query":"action=reload_data&is_interval=1"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : amadea kristina budiman
#session        : after login
#purpose        : function to get json response for notification
#required param : self, host
#optional param : method, query, name, headers
def ajaxNavNotification_pl(self, host, **kwargs):
    path     = "/ajax-nav-notification.pl"
    default = {
        "query":"callback=get_notification_handler&action=reload_data&is_interval=1"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : erlangga krisnamukti
#session        : -
#purpose        : function to get json response for nav-deposit
#required param : host
#optional param : method, query
def ajax_nav_deposit_pl(self, host, **kwargs):
    path = "/ajax/nav-deposit.pl"
    default = {
        "query":"action=reload_data&is_interval=1"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : amadea kristina budiman
#session        : after login
#purpose        : function to get json response for nav-deposit
#required param : self, host
#optional param : method, query, name, headers
def ajaxNavDeposit_pl(self, host, **kwargs):
    path     = "/ajax-nav-deposit.pl"
    default = {
        "query":"callback=get_deposit_handler&action=reload_data&is_interval=1"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : erlangga krisnamukti
#session        : need login first (only cookie)
#purpose        : function to get json response for verification number
#required param : host
#optional param : method, query
def ajax_verification_number_pl(self, host, **kwargs):
    path = "/ajax/verification_number.pl"
    default = {
        "query":"is_fluid=1"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : erlangga krisnamukti
#session        : -
#purpose        : function to get json response for quick guide
#required param : host
#optional param : method, query ('type=guide_home', 'type=guide_gmstat_home', 'type=guide_fr_home')
def ajax_check_quick_guide_pl(self, host, **kwargs):
    path = "/ajax/check-quick-guide.pl"
    default = {
        "query":"type=guide_home"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response


#creator        : erlangga krisnamukti
#session        : -
#purpose        : function to get json response for r3 endpoints
#required param : host
#optional param : method, query
def ajax_r3global_pl(self, host, **kwargs):
    path = "/ajax/r3global.pl"
    response = ht.call(self, host, path, **kwargs)
    return response

#creator        : erlangga krisnamukti
#session        : need cookies if using session
#purpose        : function to check for dialog retry notification
#required param : self, host
#optional param : method, query, name, headers
def ajax_tx_myshop_pl(self, host, **kwargs):
    path = "/ajax/tx/myshop.pl"
    default = {
        "query":"action=show_dialog_retry_notif"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : Check wishlist
# Session : No Session
# Required Parameters : host
# Optional Parameters : method, name, headers, query
def ajax_wishlist_pl(self, host, **kwargs):
    path     = "/ajax/wishlist.pl"
    default = {
        "query":"p_id=617168%2C580447%2C14286849%2C14286862%2C14286861%2C14286863%2C14288593%2C14131163%2C14262534%2C14286109&action=event_get_check_wishlist_key"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : fernanda panca prima
#session        : No Session
#purpose        : function to get review of product
#required param : host
#optional param : method, query, headers, name
def reputationapp_review_api_product_v1(self, host, **kwargs):
    path      = "/reputationapp/review/api/v1/product"
    default = {
        "query":"product_id=14286207&page=1&per_page=5"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def reputationapp_review_api_product_P_v2(self, host, product_id,**kwargs):
    path      = "/reputationapp/review/api/v2/product/" + product_id
    response = ht.call(self, host, path, **kwargs)
    return response

def reputationapp_review_api_reviewGimmick_v2(self, host, **kwargs):
    path      = "/reputationapp/review/api/v2/review-gimmick"
    response = ht.call(self, host, path, **kwargs)
    return response

#creator        : fernanda panca prima
#session        : No Session
#purpose        : function to get most helpful review of product
#required param : host
#optional param : method, query, headers, name
def reputationapp_review_api_mosthelpful_v1(self, host, **kwargs):
    path      = "/reputationapp/review/api/v1/mosthelpful"
    default = {
        "query":"product_id=14286207"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : fernanda panca prima
#session        : No Session
#purpose        : function to get total review of product
#required param : host, product_id
#optional param : method, query, headers, name
def reputationapp_review_api_total_p_P_v1(self, host, product_id, **kwargs):
    path      = "/reputationapp/review/api/v1/total/p/"+product_id
    response = ht.call(self, host, path, **kwargs)
    return response

#creator        : fernanda panca prima
#session        : No Session
#purpose        : function to get total like and dislike of review product
#required param : host
#optional param : method, query, headers, name
def reputationapp_review_api_like_dislike_v1(self, host, **kwargs):
    path      = "/reputationapp/review/api/v1/likedislike"
    default = {
        "query":"review_ids=56781993&user_id=8026131"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : fernanda panca prima
#session        : No Session
#purpose        : function to product management
#required param : host
#optional param : method, query, headers, name
def ajax_producte4_pl(self, host, **kwargs):
    path      = "/ajax/product-e4.pl"
    default = {
        "query":"p_id=14286207&action=increase_view"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : fernanda panca prima
#session        : No Session
#purpose        : function to load next and previous products
#required param : host
#optional param : method, query, headers, name
def ajax_productPrevNext_pl(self, host, **kwargs):
    path      = "/ajax/product-prev-next.pl"
    default = {
        "query":"p_id=14286207&action=prev_next&s_id=479507"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : fernanda panca prima
#session        : before, after login
#purpose        : function to check the prosecure service
#required param : self, host
#optional param : method, query, headers, name
def ajax_prosecure_pl(self, host, **kwargs):
    path      = "/ajax/prosecure.pl"
    default = {
        "query":"action=is_prosecure_shop&shop_id=479507"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#session        : No Session
#purpose        : function to check the review and talk count
#required param : host
#optional param : method, query, headers, name
def ajaxProductReviewTalkCount_pl(self, host, **kwargs):
    path        = "/ajax-product-review-talk-count.pl"
    default     = {
        "query":"callback=init_review_talk_count&p_id=36215174"
    }
    response    = ht.call(self, host, path, default=default, **kwargs)
    return response

#session        : No Session
#purpose        : function to increase view of product
#required param : host
#optional param : method, query, headers, name
def ajaxIncreaseView_pl(self, host, **kwargs):
    path      = "/ajax-increase-view.pl"
    default = {
        "query":"p_id=36215174&action=increase_view"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#session        : No Session
#purpose        : function to get shop notes
#required param : host
#optional param : method, query, headers, name
def iframeNotesProductPage_pl(self, host, **kwargs):
    path      = "/iframe-notes-product-page.pl"
    default = {
        "query":"s_id=962782&manage=0",
        "bodies": {
            'action' : 'get_shop_notes',
            's_id'   : '962782'
        }
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#session        : No Session
#purpose        : function to get the service worker of mobile web
#required param : host
#optional param : method, query, headers, name
def serviceWorker_js(self, host, **kwargs):
    path      = "/service-worker.js"
    response = ht.call(self, host, path, **kwargs)
    return response

#session        : Session (require cookie)
#purpose        : get the seller notification
def sellerinfo_api_notification_v1(self, host, **kwargs):
    path = "/sellerinfo/api/v1/notification"
    response = ht.call(self, host, path, **kwargs)
    return response

#creator        : fernanda panca prima
#session        : No Session
#purpose        : function to get product view counter
#required param : host
#optional param : method, query, headers, name
def provi_check(self, host, **kwargs):
    path     = '/provi/check'
    default = {
        "query":"pid=14286207&callback=show_product_view"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose: get wallet balance, use at desktop
# Description:  for header need cookie and origin (host)
# Session: after login
# Required parameters: self, host
# Optional parameters: method, name, headers
def api_wallet_balance(self, host, **kwargs):
    path = '/api/wallet/balance'
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : show preapprove programs (mitra toppers programs) to eligible merchant 
# Requirement : list shop id to wallet consul (wallet PIC: @sandra.puspa) so it will not get 412 error
# Session : session
# Required parameters : self, host, shop_id
def microfinance_micro_mt_preapprove_P(self, host, shop_id, **kwargs):
    path        = '/microfinance/micro/mt/preapprove/'+shop_id
    response    = ht.call(self, host, path, **kwargs)
    return response

#creator        : erlangga krisnamukti
#session        : -
#purpose        : function to get response for check-security-popup
#required param : host
#optional param : method, query
def ajax_check_security_popup(self, host, **kwargs):
    path = "/ajax/check-security-popup.pl"
    response = ht.call(self, host, path, **kwargs)
    return response

#creator        : erlangga krisnamukti
#session        : -
#purpose        : function to get response for check-security-popup
#required param : host
#optional param : method, query
def ajax_tx_cart_pl(self, host, **kwargs):
    path = "/ajax/tx/cart.pl"
    response = ht.call(self, host, path, **kwargs)
    return response
# Purpose : show official store page
# Requirement : none
# Session : none
# Required parameters : self and host
def officialstore(self, host, **kwargs):
    path        = '/official-store'
    response    = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to get cashback promo suggestions
# Session : session or no session is applicable, add cookies if session needed
# Required Parameters : self, host, target_type, device_type, user_id
# Optional Parameters : method, query, name, headers
def flash_sale_v1(self, host, **kwargs):
    path     = "/toppicks/wp-json/tkp/v1/flash-sale"
    response = ht.call(self, host, path,**kwargs)
    return response

    
#creator        : noor putera utama
#session        : -
#purpose        : function to get response shop charts on shop page
#required param : host
#optional param : method, query, bodies
def ajax_shop_shopCharts_pl(self, host, **kwargs):
    path = "/ajax/shop/shop-charts.pl"
    default = {
        "method":"POST",
        "bodies":{
            'action': 'get_shop_tx_stats',
            'shop_id': '67726'
        }
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : noor putera utama
#session        : -
#purpose        : function to get response shop notes on shop page
#required param : host
#optional param : method, query, bodies
def ajax_shopShopNotes(self, host, **kwargs):
    path = "/ajax/shop/shop-shop-notes.pl"
    default = {
        "method":"POST",
        "bodies":{
            'action': 'shop_notes',
            's_id': '67726'
        }
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response


def reputationapp_statistic_api_shop_P_rating_v1(self, host, shop_id, **kwargs):
    path ="/reputationapp/statistic/api/v1/shop/%s/rating" % (shop_id) 
    response = ht.call(self, host, path, **kwargs)
    return response

def reputationapp_review_api_rating_v1(self, host, **kwargs):
    path = "/reputationapp/review/api/v1/rating"
    response = ht.call(self, host, path, **kwargs)
    return response


def content_explore(self, host, **kwargs):
    path="/content/explore"
    default = {
        'query':'webview=true',
        'method':'GET'
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#author        : Dwi Aprian Widodo,  haries.efrika
#module         : resolution
#session        : Session (require cookie)
#purpose        : get inbox resolution buyer
def resolution_inbox_buyer_v2(self, host, **kwargs):
    path = "/resolution/v2/inbox/buyer"
    default = {
        "method" : "GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def login(self, host, **kwargs):
    path = "/login"
    default = {
        "method" : "GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def cart_updateCart(self, host, **kwargs):
    path = "/cart/update_cart"
    default = {
        "method" : "POST"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def cart_shipmentAddressForm(self, host, **kwargs):
    path = "/cart/shipment_address_form"
    default = {
        "method" : "GET",
        "query" : "lang=id"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def cart_add_product_cart(self, host, **kwargs):
    path = '/cart/add_product_cart'
    default = {
        'method':'POST'
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : rina lusiana
#session        : -
#purpose        : to specific hotlist page
#required param : -
#optional param : method, query
def hot_P(self, host, hot_name, **kwargs):
   path = "/hot/%s" % (hot_name)
   response = ht.call(self, host, path, **kwargs)
   return response

#creator        : rina lusiana
#session        : -
#purpose        : to hotlist page
#required param : -
#optional param : method, query
def hot(self, host, **kwargs):
   path = "/hot"
   response = ht.call(self, host, path, **kwargs)
   return response

#session        : -
#purpose        : to home page
#required param : -
#optional param : method, query
def home(self, host, **kwargs):
   path = "/"
   response = ht.call(self, host, path, **kwargs)
   return response
def cart_checkout(self, host, **kwargs):
    path = '/cart/checkout'
    default = {
        'method':'POST'
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response    

def cart_remove_product_cart(self, host, **kwargs):
    path = '/cart/remove_product_cart'
    default = {
        'method':'POST'
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response        

def title(self, host, path, **kwargs):
    response = ht.call(self, host, path, **kwargs)
    soup = BeautifulSoup(response.content, 'html.parser')
    return soup.title.string, response


def ulangTahun_flashSale(self, host, **kwargs):
    path = "/ulang-tahun/flash-sale/"
    default = {
        "method" : "GET"
    }
    return ht.call(self, host, path, default=default, **kwargs)

def tokopoints_hadiah(self, host, **kwargs):
    path = "/tokopoints/hadiah/"
    response = ht.call(self, host, path, **kwargs)
    return response