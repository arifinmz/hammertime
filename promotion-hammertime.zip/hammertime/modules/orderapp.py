from libs import tkpdhmac, ht

host_production = "https://ws.tokopedia.com"
host_staging    = "https://ws-staging.tokopedia.com"

def action_txCart_add_to_cart_v4(self, host, user_id, device_id, **kwargs):
    path = '/v4/action/tx-cart/add_to_cart.pl'
    default = {
        "method":"POST"
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies'))
    return ht.call(self, host, path, default=default, **kwargs)

def tx_pl_v4(self, host, user_id, device_id, **kwargs):
    path = '/v4/tx.pl'
    default = {
        'method': 'POST'
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies'))
    return ht.call(self, host, path, default=default, **kwargs)


def txVoucher_checkVoucherCode_pl_v4(self, host, user_id, device_id, **kwargs):
    path = '/v4/tx-voucher/check_voucher_code.pl'
    default = {
        "method": "POST"
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def action_tx_toppayGetParameter_pl_v4(self, host, user_id, device_id, **kwargs):
    path = '/v4/action/tx/toppay_get_parameter.pl'
    default = {
        'method': 'POST'
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def find_between(self, first, last):
    try:
        start = self.find(first)
        end = self.index(last, start)
        return self[start:end]
    except ValueError:
        return ""

def itemsList(items, attribute):
    attributes = []
    for detailOfItem in items:
        attributes.append(detailOfItem[attribute])
    return attributes

def desktop_add_to_cart_form(self, host, **kwargs):
    path = '/desktop/add_to_cart_form'
    default = {
        'method': 'POST'
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def tx_pl_desktop(self, host, **kwargs):
    path = '/tx.pl'
    default = {
        'method': 'GET'
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def tx_cart_pl_ajax(self, host, **kwargs):
    path = '/ajax/tx/cart.pl'
    default = {
        'method': 'POST',
    }
    response =ht.call(self, host, path, default=default, **kwargs)
    return response