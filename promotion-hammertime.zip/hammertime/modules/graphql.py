from libs import ht, tkpdhmac

host_production = 'https://m.tokopedia.com'
host_staging    = 'https://m-staging.tokopedia.com'
host_staging_3  = 'https://3-feature-m-staging.tokopedia.com'
host_staging_10 = 'https://10-feature-m-staging.tokopedia.com'
host_graphql    = 'https://gql.tokopedia.com'

# Purpose: to make request based on needs
# Required parameters: host, query, subname
def request(self, host, query, sub_name, **kwargs):
    path = '/'
    default = {
        'headers': {
            'origin':host,
            'content-type':'application/json'
        }
    }
    kwargs['name'] = host + path + sub_name
    kwargs['json'] = kwargs.get('json',{})
    if not kwargs['json'].has_key('query') : kwargs['json'].update( {"query":query})
    return ht.call(self, host, path, default=default, **kwargs)

# Purpose: check whether a user/guest is logged in or not, use at mobile web
# Description: for header need origin (host), cookie (only when use session), content-type (application/json)
# Session: before, after login
# Required parameters: host
# Optional parameters: headers
def graphql_loggedInStatus(self, host, **kwargs):
    query    = {"query":"query Query {\n  user {\n    isLoggedIn\n    __typename\n  }\n}\n","operationName":"Query"}
    sub_name = 'isLoggedIn'
    response = request(self, host, query, sub_name, **kwargs)
    return response

# Purpose: get user data (logged in status, user profile, shop profile, saldo, wallet, notification, cart, sales, purchase, inbox, ticker), use at mobile web
# Description: for header needs origin (host), cookie (only when use session), content-type (application/json)
# Session: before, after login
# Required parameters: host
# Optional parameters: headers
def graphql_accountData(self, host, **kwargs):
    query   = """query Query($source: String) {\n  user(source: $source) {\n    id\n    isLoggedIn\n    shouldRedirect\n   shouldRedirectLogout\n    profilePicture\n    name\n    email\n    phone_verified\n    gender\n    bday\n    __typename\n  }\n  shop {\n    shop_id\n    shop_url\n    domain\n    shop_name\n    shop_name_unfmt\n    shop_name_clean\n    is_gold\n    is_official\n    location\n    logo\n    shop_badge\n    __typename\n  }\n  points {\n    data {\n      attributes
    {\n        active\n        amount\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  saldo {\n    deposit_fmt\n    __typename\n  }\n  notifications {\n    status\n    data {\n      total_notif\n      total_cart\n      incr_notif\n      resolution\n      sales {\n        sales_new_order\n        sales_shipping_status\n        sales_shipping_confirm\n        __typename\n      }\n      inbox {\n        inbox_talk\n        inbox_ticket\n
    inbox_review\n        inbox_friend\n        inbox_message\n        inbox_wishlist\n        inbox_reputation\n        __typename\n      }\n      purchase {\n        purchase_reorder\n        purchase_payment_conf\n        purchase_order_status\n        purchase_payment_confirm\n        purchase_delivery_confirm\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  wallet {\n    linked\n    balance\n    errors {\n      name\n      message\n      __typename\n
    }\n    __typename\n  }\n  ticker {\n    meta {\n      total_data\n      __typename\n    }\n    tickers {\n      id\n      title\n      message\n      color\n      __typename\n    }\n    __typename\n  }\n  profile {\n    phone\n    __typename\n  }\n}\n"""
    sub_name= 'accountData'
    response = request(self, host, query, sub_name, **kwargs)
    return response

# Purpose: get digital product data and others (user info, user's shop, wallet, saldo, point, notification, ticker, recharge operator, recharge product, recharge category, recharge ticket), use at mobile web
# Description: for header needs origin (host), cookie (only when use session), content-type (application/json)
# Session: before, after login
# Required parameters: host
# Optional parameters: headers
def graphql_digitalData(self, host, **kwargs):
    query   = """{\n  user {\n    id\n    isLoggedIn\n    shouldRedirect\n    shouldRedirectLogout\n    profilePicture\n    name\n    email\n    phone_verified\n    gender\n    bday\n    __typename\n  }\n  points {\n    data {\n      attributes {\n        amount\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  saldo {\n    deposit_fmt\n    __typename\n  }\n  notifications {\n    status\n    data {\n      total_notif\n      total_cart\n
    incr_notif\n      resolution\n      sales {\n        sales_new_order\n        sales_shipping_status\n        sales_shipping_confirm\n        __typename\n      }\n      inbox {\n        inbox_talk\n        inbox_ticket\n        inbox_review\n        inbox_friend\n        inbox_message\n        inbox_wishlist\n        inbox_reputation\n        __typename\n      }\n      purchase {\n        purchase_reorder\n        purchase_payment_conf\n        purchase_order_status\n
    purchase_payment_confirm\n        purchase_delivery_confirm\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  wallet {\n    linked\n    balance\n    errors {\n      name\n      message\n      __typename\n    }\n    __typename\n  }\n  shop {\n    shop_id\n    shop_url\n    domain\n    shop_name\n    shop_name_unfmt\n    shop_name_clean\n    is_gold\n    is_official\n    location\n    logo\n    shop_badge\n    __typename\n  }\n  recharge_operator {\n    id\n
    name\n    weight\n    default_product_id\n    image\n    slug\n    minimum_length\n    maximum_length\n    show_product_list\n    show_product\n    product_text\n    show_price\n    prefix\n    __typename\n  }\n  recharge_product {\n    id\n    category_id\n    operator_id\n    status\n    price_plain\n    desc\n    detail\n    price\n    promo {\n      bonus_text\n      new_price\n      __typename\n    }\n    promo_price\n    __typename\n  }\n  recharge_category {\n    id\n
    name\n    slug\n    icon\n    validate_prefix\n    instant_checkout_available\n    default_operator_id\n    client_number {\n      is_shown\n      text\n      help\n      placeholder\n      operator_style\n      __typename\n    }\n    show_operator\n    operator_label\n    __typename\n  }\n  recharge_last_order {\n    client_number\n    operator_id\n    product_id\n    category_id\n    __typename\n  }\n  recharge_banner {\n    id\n    image_url\n    redirect_url\n    subtitle\n
    title\n    __typename\n  }\n  recharge_ticket {\n    num_id\n    id\n    name\n    display_name\n    city\n    status\n    island\n    __typename\n  }\n}\n"""
    sub_name= 'digitalData'
    response = request(self, host, query, sub_name, **kwargs)
    return response

# Purpose: get feed plus content, use at android
# Description: for header needs origin (host), cookie (only when use session), content-type (application/json)
# Session: after login
# Required parameters: host, user id
# Optional parameters: headers
def graphql_feedPlus(self, host, **kwargs):
    query   = """query Feeds($userID: Int!, $limit: Int!, $cursor: String, $page: Int!) {\n  feed(limit: $limit, cursor: $cursor, userID: $userID) {\n    __typename\n    data {\n      __typename\n      id\n      create_time\n      type\n      cursor\n      source {\n        __typename\n        type\n        shop {\n          __typename\n          id\n          name\n          avatar\n          isOfficial\n          isGold\n          url\n          shopLink\n
    shareLinkDescription\n          shareLinkURL\n        }\n      }\n      content {\n        __typename\n        type\n        total_product\n        products {\n          __typename\n          id\n          name\n          price\n          image\n          image_single\n          wholesale {\n            __typename\n            qty_min_fmt\n          }\n          freereturns\n          preorder\n          cashback\n          url\n          productLink\n          wishlist\n
    rating\n        }\n        promotions {\n          __typename\n          id\n          name\n          type\n          thumbnail\n          feature_image\n          description\n          periode\n          code\n          url\n          min_transcation\n        }\n        status_activity\n        new_status_activity {\n          __typename\n          source\n          activity\n          amount\n        }\n      }\n    }\n    links {\n      __typename \n     pagination {\n
    __typename\n        has_next_page\n      }\n    }\n    meta {\n      __typename\n      total_data\n    }\n  }\n  inspiration(userID: $userID, page: $page) {\n    __typename\n    data {\n      __typename\n      source\n      title\n      foreign_title\n      pagination {\n        __typename\n        current_page\n        next_page\n        prev_page\n      }\n      recommendation {\n        __typename\n        id\n        name\n        url\n        image_url\n        price\n      }\n    }\n
    }\n}\n"""
    sub_name = 'feedPlus'
    response = request(self, host, query, sub_name, **kwargs)
    return response

# author: haries.efrika
# Purpose: get feed plus content, use at android
# Description: for header needs origin (host), cookie (only when use session), content-type (application/json)
# Session: after login
# Required parameters: host, user id
# Optional parameters: headers
def graphql_homeFeedQuery(self, host, **kwargs):
    query   = "query HomeFeedQuery($userID: Int!, $limit: Int!, $cursor: String) {  feed(limit: $limit, cursor: $cursor, userID: $userID, source: \"home\") {    __typename    data {      __typename      id      create_time      type      cursor      source {        __typename        type        shop {          __typename          id          name          avatar          isOfficial          isGold          url          shopLink          shareLinkDescription          shareLinkURL        }      }      content {        __typename        type        inspirasi {          __typename          experiment_version          source          title          foreign_title          widget_url          pagination {            __typename            current_page            next_page            prev_page          }          recommendation {            __typename            id            name            url            click_url            app_url            image_url            price            recommendation_type          }        }        topads {          __typename          id          ad_ref_key          redirect          sticker_id          sticker_image          product_click_url          shop_click_url          product {            __typename            id            name            image {              __typename              s_url              s_ecs            }            price_format          }          shop {            __typename            id          }          applinks        }      }    }    links {      __typename      self      pagination {        __typename        has_next_page      }    }    meta {      __typename      total_data    }  }}"
    sub_name = 'homeFeedQuery'
    response = request(self, host, query, sub_name, **kwargs)
    return response


# author: haries.efrika
# description: this seems to be replacement for older userAttribute
def graphql_consumerDrawerData(self, host, **kwargs):
    query = "query ConsumerDrawerData($userID: Int!) {\n  status\n  shopInfoMoengage(userID: $userID) {\n    info {\n      date_shop_created\n      shop_id\n      shop_location\n      shop_name\n      shop_score\n      total_active_product\n      shop_avatar\n      shop_cover\n      shop_domain\n    }\n    owner {\n      is_gold_merchant\n      is_seller\n    }\n    stats {\n      shop_total_transaction\n      shop_item_sold\n    }\n  }\n  profile {\n    user_id\n    first_name\n    full_name\n    email\n    gender\n    bday\n    age\n    phone\n    register_date\n    profile_picture\n    completion\n  }\n  wallet {\n    linked\n    balance\n    rawBalance\n    text\n    total_balance\n    raw_total_balance\n    hold_balance\n    raw_hold_balance\n    redirect_url\n    applinks\n    ab_tags {\n      tag\n    }\n    action {\n      text\n      redirect_url\n      applinks\n      visibility\n    }\n  }\n  saldo {\n    deposit_fmt\n    deposit\n  }\n  paymentAdminProfile {\n    is_purchased_marketplace\n    is_purchased_digital\n    is_purchased_ticket\n    last_purchase_date\n  }\n  topadsDeposit(userID: $userID) {\n    topads_amount\n    is_topads_user\n  }\n  notifications {\n    total_cart\n    total_notif\n    resolution\n    shop_id\n    inbox {\n      talk\n      ticket\n      review\n      friend\n      wishlist\n      message\n      reputation\n    }\n    sales {\n      newOrder\n      shippingStatus\n      shippingConfirm\n    }\n    purchase {\n      reorder\n      paymentConfirm\n      orderStatus\n      deliveryConfirm\n    }\n    resolution_as {\n      buyer\n      seller\n    }\n    chat {\n      unreads\n    }\n  }\n}\n"
    sub_name = 'consumerDrawerData'
    response = request(self, host, query, sub_name, **kwargs)
    return response

# author: haries.efrika
# description: this seems to be replacement for older tokopoints api
def graphql_tokopointsToken(self, host, **kwargs):
    query = "{\n  tokopointsToken {\n    resultStatus {\n        code\n        message\n        status\n   }\n    offFlag\n    sumToken\n    sumTokenStr\n    tokenUnit\n    floating {\n      tokenId\n      pageUrl\n      applink\n      timeRemainingSeconds\n      isShowTime\n      unixTimestamp\n      tokenAsset {\n        name\n        version\n        floatingImgUrl\n      }\n    }\n    home {\n      emptyState{\n          title\n          buttonText\n          buttonApplink\n          buttonURL\n      }\n      countingMessage\n      tokensUser {\n        tokenUserID\n        campaignID\n        title\n        unixTimestampFetch\n        timeRemainingSeconds\n        isShowTime\n        backgroundAsset {\n          name\n          version\n          backgroundImgUrl\n        }\n        tokenAsset {\n          name\n          version\n          floatingImgUrl\n          smallImgUrl\n          spriteUrl\n          imageUrls\n        }\n      }\n    }\n  }\n}\n"
    sub_name = 'tokopointsToken'
    response = request(self, host, query, sub_name, **kwargs)
    return response



def graphql_userAttribute(self, host, **kwargs):
    query = """query UserAttribute($userID: Int!) {  shopInfoMoengage(userID: $userID) {    __typename    info {      __typename      date_shop_created      shop_id      shop_location      shop_name      shop_score      total_active_product    }    owner {      __typename      is_gold_merchant      is_seller    }    stats {      __typename      shop_total_transaction      shop_item_sold    }  }  profile {    __typename    user_id    first_name    full_name    email    gender    bday    age    phone    phone_verified    register_date  }  address {    __typename    addresses {      __typename      city_name      province_name    }  }  wallet {    __typename    linked    balance    rawBalance    errors {      __typename      name      message    }  }  saldo {    __typename    deposit_fmt    deposit  }  paymentAdminProfile {    __typename    is_purchased_marketplace    is_purchased_digital    is_purchased_ticket    last_purchase_date  }  topadsDeposit(userID: $userID) {    __typename    topads_amount    is_topads_user  }}"""
    sub_name = 'userAttribute'
    response = request(self, host, query, sub_name, **kwargs)
    return response

# Purpose: get feed content, use at desktop
# Description: for header needs origin (host), cookie (only when use session), content-type (application/json)
# Session: after login
# Required parameters: host, user id
# Optional parameters: headers
def graphql_feedQuery(self, host, **kwargs):
    query = "query FeedQuery($userID: Int!, $limit: Int!, $cursor: String) {\n  feed(limit: $limit, cursor: $cursor, userID: $userID) {\n    data {\n      id\n      createTime: create_time\n      type\n      source {\n        shop {\n          id\n          name\n          imageURL: avatar\n          isOfficial\n          isGold\n          url\n          shopLink\n          shareLinkDescription\n          shareLinkURL\n          __typename\n        }\n        __typename\n      }\n      content {\n        type\n        products {\n          id\n          name\n          price\n          imageURL: image\n          url\n          wishlist\n          __typename\n        }\n        promotions {\n          id\n          name\n          imageURL: feature_image\n          description\n          periode\n          code\n          url\n          __typename\n        }\n        officialStore: official_store {\n          id: shop_id\n          url: shop_defaultv3_url\n          name: shop_name\n          headerImgURL: mobile_img_url\n          imageURL: microsite_url\n          isOwner: is_owner\n          isNew: is_new\n          title\n          hexaColor: feed_hexa_color\n          products {\n            brandID: brand_id\n            brandLogo: brand_logo\n            data {\n              id\n              name\n              url\n              imageURL: image_url\n              price\n              originalPrice: original_price\n              discountPercentage: discount_percentage\n              badges {\n                title\n                imageURL: image_url\n                __typename\n              }\n              labels {\n                title\n                color\n                __typename\n              }\n              shop {\n                name\n                url\n                location\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          redirectURL: redirect_url_desktop\n          __typename\n        }\n        sellerStory: seller_story {\n          id\n          title\n          date\n          link\n          image\n          youtube\n          __typename\n        }\n        statusActivity: new_status_activity {\n          activity\n          amount\n          __typename\n        }\n        inspirasi {\n          title_id: title\n          title_en: foreign_title\n          recommendation {\n            id\n            name\n            url\n            imageURL: image_url\n            price\n            r3Type: recommendation_type\n            __typename\n          }\n          __typename\n        }\n        favoriteCTA: favorite_cta {\n          title_en\n          title_id\n          subtitle_en\n          subtitle_id\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    links {\n      pagination {\n        hasNextPage: has_next_page\n        __typename\n      }\n      __typename\n    }\n    meta {\n      total_data\n      lastcursor\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = 'FeedQuery'
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_productTrendInTokopedia(self, host, **kwargs):
    query = """\nquery Query($userID: Int!, $page: Int!, $pageName: String) {\n  inspiration(userID: $userID, page: $page, pageName: $pageName) {\n    data {\n      source\n      title\n      foreign_title\n      widget_url\n      pagination {\n        current_page\n        next_page\n        prev_page\n      }\n      recommendation {\n        id\n        name\n        url\n        click_url\n        app_url\n        image_url\n        price\n      }\n    }\n  }\n}\n"""
    sub_name = 'productTrendInTokopedia'
    response = request(self, host, query, sub_name, **kwargs)
    return response

# Purpose: get data on category detail native page
def graphql_rechargeCategoryDetailApps(self, host, **kwargs):
    query = "mutation RechargeCategoryDetail($category_id: Int!, $is_seller: Int!)  {  \n  recharge_category_detail(category_id:$category_id, is_seller: $is_seller) {\n    id\n    name\n    title\n    icon\n    icon_url\n    is_new\n    instant_checkout\n    slug\n    microsite_url\n    default_operator_id\n    operator_style\n    operator_label\n    additional_feature {\n   id\n   text\n   button_text\n   }\n    client_number {\n      name\n      type\n      text\n      placeholder\n      default\n      validation {\n        regex\n        error\n        __typename\n      }\n      __typename\n    }\n    other_banners {\n      type\n      id\n      attributes {\n        title\n        subtitle\n        promocode\n        link\n        image\n        data_title\n      }\n    }\n    banners {\n      type\n      id\n      attributes {\n        title\n        subtitle\n        promocode\n        link\n        image\n        data_title\n      }\n    }\n   guides{\n id\n    type\n  attributes{\n   title\n   source_link\n }\n }\n    operator {\n      type\n      id\n      attributes {\n        name\n        image\n        lastorder_url\n        default_product_id\n        prefix\n        ussd\n        product {\n          type\n          id\n          attributes {\n            desc\n            detail\n            detail_compact\n            detail_url\n            detail_url_text\n            info\n            price\n            price_plain\n            promo {\n              id\n              bonus_text\n              new_price\n              new_price_plain\n              tag\n              terms\n              value_text\n            }\n            status\n          }\n        }\n        rule {\n          maximum_length\n          product_text\n          product_view_style\n          show_price\n          enable_voucher\n          button_text\n        }\n        description\n        first_color\n        second_color\n        fields {\n          name\n          type\n          text\n          placeholder\n          default\n          validation {\n            regex\n            error\n          }\n        }\n      }\n    }\n  }\n}\n"
    sub_name = "rechargeCategoryDetailApps"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_digitalQuery(self, host, **kwargs):
    query = "query DigitalQuery($isLoggedIn: Boolean!) {\n  rechargeCategoryList {\n    id\n    name\n    is_new\n    slug\n    microsite_url\n    __typename\n  }\n  rechargeLastOrder(isLoggedIn: $isLoggedIn) {\n    client_number\n    operator_id\n    product_id\n    category_id\n    __typename\n  }\n  category {\n    categories {\n      name\n      items {\n        name\n        imageURI\n        url\n        type\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "DigitalQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_homeQuery(self, host, **kwargs):
    query = "query HomeQuery {\n  official_store {\n    id\n    name\n    logo_url\n    url\n    is_new\n    __typename\n  }\n  official_store_v3 {\n    category\n    shops {\n      shop_id\n      shop_name\n      shop_url\n      logo_url\n      is_new\n      __typename\n    }\n    __typename\n  }\n  category {\n    categories {\n      items {\n        name\n        type\n        identifier\n        imageURI\n        url\n        score\n        __typename\n      }\n      name\n      __typename\n    }\n    errors {\n      name\n      message\n      __typename\n    }\n    __typename\n  }\n  toppicks {\n    name\n    toppicks {\n      name\n      url\n      image_url\n      item {\n        name\n        url\n        image_url\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  hachikoNotification: hachikoDrawer {\n    off_flag\n    has_notif\n    pop_up_notif {\n      title\n      text\n      image_url\n      button_text\n      button_url\n      app_link\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = 'homeQuery'
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_RechargeCategoryDetail(self, host, **kwargs):
    query = "mutation RechargeCategoryDetail($category_id: Int!, $is_seller: Int!)  {  \n  recharge_category_detail(category_id:$category_id, is_seller: $is_seller) {\n    id\n    name\n    title\n    icon\n    icon_url\n    is_new\n    instant_checkout\n    slug\n    microsite_url\n    default_operator_id\n    operator_style\n    operator_label\n    additional_feature {\n   id\n   text\n   button_text\n   }\n    client_number {\n      name\n      type\n      text\n      placeholder\n      default\n      validation {\n        regex\n        error\n        __typename\n      }\n      __typename\n    }\n    other_banners {\n      type\n      id\n      attributes {\n        title\n        subtitle\n        promocode\n        link\n        image\n        data_title\n      }\n    }\n    banners {\n      type\n      id\n      attributes {\n        title\n        subtitle\n        promocode\n        link\n        image\n        data_title\n      }\n    }\n   guides{\n id\n    type\n  attributes{\n   title\n   source_link\n }\n }\n    operator {\n      type\n      id\n      attributes {\n        name\n        image\n        lastorder_url\n        default_product_id\n        prefix\n        ussd\n        product {\n          type\n          id\n          attributes {\n            desc\n            detail\n            detail_compact\n            detail_url\n            detail_url_text\n            info\n            price\n            price_plain\n            promo {\n              id\n              bonus_text\n              new_price\n              new_price_plain\n              tag\n              terms\n              value_text\n            }\n            status\n          }\n        }\n        rule {\n          maximum_length\n          product_text\n          product_view_style\n          show_price\n          enable_voucher\n          button_text\n        }\n        description\n        first_color\n        second_color\n        fields {\n          name\n          type\n          text\n          placeholder\n          default\n          validation {\n            regex\n            error\n          }\n        }\n      }\n    }\n  }\n}"
    sub_name = 'RechargeCategoryDetail'
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_rechargeCategoryDetail(self, host, **kwargs):
    query = "mutation rechargeCategoryDetail($category_id: Int!) {\n  recharge_category_detail(category_id: $category_id) {\n    id\n    name\n    title\n    icon\n    icon_url\n    is_new\n    instant_checkout\n    slug\n    microsite_url\n    default_operator_id\n    operator_style\n    operator_label\n    client_number {\n      name\n      type\n      text\n      placeholder\n      default\n      validation {\n        regex\n        error\n        __typename\n      }\n      __typename\n    }\n    operator {\n      type\n      id\n      attributes {\n        name\n        image\n        lastorder_url\n        default_product_id\n        prefix\n        ussd\n        product {\n          type\n          id\n          attributes {\n            desc\n            detail\n            detail_url\n            detail_url_text\n            info\n            price\n            price_plain\n            promo {\n              id\n              bonus_text\n              new_price\n              new_price_plain\n              tag\n              terms\n              value_text\n              __typename\n            }\n            status\n            __typename\n          }\n          __typename\n        }\n        rule {\n          maximum_length\n          product_text\n          product_view_style\n          show_price\n          enable_voucher\n          button_text\n          __typename\n        }\n        description\n        first_color\n        second_color\n        fields {\n          name\n          type\n          text\n          placeholder\n          default\n          validation {\n            regex\n            error\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = 'rechargeCategoryDetail'
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_searchFilterQuery(self, host, **kwargs):
    query = "query SearchFilterQuery($query: String, $source: String) {\n  search_filter_product(query: $query, source: $source) {\n    data {\n      filter {\n        title\n        search {\n          searchable\n          placeholder\n          __typename\n        }\n        options {\n          name\n          key\n          value\n          icon\n          input_type\n          total_data\n          val_min\n          val_max\n          hex_color\n          child {\n            key\n            value\n            name\n            icon\n            input_type\n            total_data\n            child {\n              key\n              value\n              name\n              icon\n              input_type\n              total_data\n              child {\n                key\n                value\n                name\n                icon\n                input_type\n                total_data\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      sort {\n        name\n        key\n        value\n        input_type\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  search_filter_catalog(query: $query, source: $source) {\n    data {\n      filter {\n        title\n        search {\n          searchable\n          placeholder\n          __typename\n        }\n        options {\n          name\n          key\n          value\n          icon\n          input_type\n          total_data\n          val_min\n          val_max\n          hex_color\n          child {\n            key\n            value\n            name\n            icon\n            input_type\n            total_data\n            child {\n              key\n              value\n              name\n              icon\n              input_type\n              total_data\n              child {\n                key\n                value\n                name\n                icon\n                input_type\n                total_data\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      sort {\n        name\n        key\n        value\n        input_type\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  search_filter_shop(query: $query, source: $source) {\n    data {\n      filter {\n        title\n        search {\n          searchable\n          placeholder\n          __typename\n        }\n        options {\n          name\n          key\n          value\n          icon\n          input_type\n          total_data\n          val_min\n          val_max\n          hex_color\n          child {\n            key\n            value\n            name\n            icon\n            input_type\n            total_data\n            child {\n              key\n              value\n              name\n              icon\n              input_type\n              total_data\n              child {\n                key\n                value\n                name\n                icon\n                input_type\n                total_data\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      sort {\n        name\n        key\n        value\n        input_type\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = 'searchFilterCategory'
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_searchModalQuery(self, host, **kwargs):
    query = "query SearchModalQuery($q: String, $uniqueId: String, $source: String, $device: String, $userId: Int) {\n  universeSearch(q: $q, uniqueId: $uniqueId, source: $source, device: $device, userId: $userId) {\n    universe {\n      recent {\n        id\n        name\n        items {\n          keyword\n          url\n          imageUrl: imageURI\n          __typename\n        }\n        __typename\n      }\n      popular {\n        id\n        name\n        items {\n          url\n          keyword\n          imageUrl: imageURI\n          __typename\n        }\n        __typename\n      }\n      digital {\n        id\n        name\n        items {\n          keyword\n          url\n          recom\n          imageUrl: imageURI\n          __typename\n        }\n        __typename\n      }\n      inCategory {\n        id\n        name\n        items {\n          keyword\n          url\n          recom\n          sc\n          __typename\n        }\n        __typename\n      }\n      autocomplete {\n        id\n        name\n        items {\n          keyword\n          url\n          __typename\n        }\n        __typename\n      }\n      category {\n        id\n        name\n        items {\n          recom\n          url\n          imageUrl: imageURI\n          sc\n          __typename\n        }\n        __typename\n      }\n      shop {\n        id\n        name\n        items {\n          keyword\n          url\n          imageUrl: imageURI\n          isOfficial\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "SearchModalQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_srcProdQueries(self, host, **kwargs):
    query = "query SearchProduct($q: String, $start: Int, $rows: Int, $ob: Int, $uniqueId: String, $filter: SearchProductFilterInput) {\n  searchProduct(q: $q, start: $start, rows: $rows, ob: $ob, filter: $filter, uniqueId: $uniqueId) {\n    query\n    source\n    shareUrl\n    isFilter\n    count\n    redirection {\n      redirectUrl\n      departmentId\n      __typename\n    }\n    suggestion {\n      currentKeyword\n      suggestion\n      suggestionCount\n      instead\n      insteadCount\n      text\n      query\n      __typename\n    }\n    products {\n      id\n      name\n      childs\n      url\n      imageUrl\n      imageUrlLarge\n      price\n      rating\n      countReview\n      preorder\n      cashback\n      wishlist\n      gaKey\n      catId\n      shop {\n        id\n        name\n        url\n        location\n        city\n        reputation\n        clover\n        goldmerchant\n        official\n        __typename\n      }\n      __typename\n    }\n    catalogs {\n      id\n      name\n      price\n      rawPrice\n      minPrice\n      maxPrice\n      rawMinPrice\n      rawMaxPrice\n      count\n      description\n      imageUrl\n      url\n      departmentId\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "SearchProduct"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_saldoQuery(self, host, **kwargs):
    query = "query SaldoQuery {\n  saldo {\n    deposit_fmt\n    __typename\n  }\n  wallet {\n    linked\n    balance\n    errors {\n      name\n      message\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "SaldoQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_productTopAdsManageQuery(self, host, **kwargs):
    query = "query ProductTopAdsManageQuery($shopID: String!, $itemID: String!) {\n  ProductTopAdsManageQuery(shop_id: $shopID, item_id: $itemID) {\n    manage_link\n    __typename\n  }\n}\n"
    sub_name = "ProductTopAdsManageQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_productTokenQuery(self, host, **kwargs):
    query = "query ProductTokenQuery($loggedIn: Boolean!) {\n  ProductTokenQuery\n  notifications @include(if: $loggedIn) {\n    total_cart\n    __typename\n  }\n}\n"
    sub_name = "ProductTokenQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_promoWidgetQuery(self, host, **kwargs):
    query = "query PromoWidgetQuery($userID: Int!, $deviceType: String!, $targetType: String!, $placeholder: String!, $lang: String!, $shopType: String!) {\n  PromoWidgetQuery(userID: $userID, deviceType: $deviceType, targetType: $targetType, placeholder: $placeholder, lang: $lang, shopType: $shopType) {\n    errors {\n      title\n      __typename\n    }\n    data {\n      cache_expire\n      list {\n        type\n        id\n        attributes {\n          short_desc\n          short_cond\n          short_desc_html\n          short_cond_html\n          code\n          code_html\n          target_url\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "PromoWidgetQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_productShopQuery(self, host, **kwargs):
    query = 'query ProductShopQuery($toShopId: Int) {\n  existingChat: chatExistingChat(toShopId: $toShopId, source: "pdp") {\n    messageId\n    contact {\n      id\n      role\n      attributes {\n        name\n        domain\n        thumbnail\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n'
    sub_name = "ProductShopQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_productVideoQuery(self, host, **kwargs):
    query = "query ProductVideoQuery($productID: String!) {\n  ProductVideoQuery(product_id: $productID) {\n    links {\n      self\n      __typename\n    }\n    data {\n      product_id\n      video {\n        url\n        type\n        default\n        status\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "ProductVideoQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_productReviewQuery(self, host, **kwargs):
    query = "query ProductReviewQuery($productID: String!) {\n  ProductReviewQuery(product_id: $productID) {\n    status\n    data {\n      list {\n        review_id\n        review_message\n        review_shop_id\n        review_reputation_id\n        review_user_id\n        review_user_label_id\n        review_user_name\n        review_user_label\n        review_user_image\n        product_rating\n        review_create_time {\n          date_time_fmt1\n          __typename\n        }\n        review_update_time {\n          date_time_fmt1\n          __typename\n        }\n        review_user_reputation {\n          negative\n          neutral\n          no_reputation\n          positive\n          positive_percentage\n          __typename\n        }\n        review_image_attachment {\n          attachment_id\n          uri_thumbnail\n          uri_large\n          description\n          __typename\n        }\n        review_response {\n          response_create_time\n          response_message\n          __typename\n        }\n        review_like_dislike {\n          total_like\n          total_dislike\n          __typename\n        }\n        review_product_owner {\n          user_shop_reputation\n          user_shop_name\n          user_label_id\n          user_label\n          user_shop_image\n          user_id\n          user_image\n          user_name\n          __typename\n        }\n        review_product_id\n        review_rate_accuracy\n        review_rate_accuracy_desc\n        review_rate_service\n        review_rate_service_desc\n        review_rate_speed\n        review_rate_speed_desc\n        review_rate_product\n        review_rate_product_desc\n        user {\n          user_id\n          full_name\n          user_image\n          user_label\n          user_url\n          user_reputation {\n            positive\n            neutral\n            negative\n            positive_percentage\n            no_reputation\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    is_most_helpful\n    __typename\n  }\n}\n"
    sub_name = "ProductReviewQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_PDPTalkQuery(self, host, **kwargs):
    query = "query PDPTalkQuery($productId: Int, $page: Int, $state: String, $pageId: Int, $source: String, $perPage: Int) {\n  talkProduct(productId: $productId, page: $page, state: $state, pageId: $pageId, source: $source, perPage: $perPage) {\n    hasNext\n    shop {\n      name\n      domain\n      __typename\n    }\n    talks {\n      id\n      isMine\n      isReported\n      shopId\n      userId\n      productId\n      message\n      createTime {\n        formatApp4\n        __typename\n      }\n      relation {\n        isFollow\n        __typename\n      }\n      user {\n        id\n        fullName\n        thumbnail\n        __typename\n      }\n      product {\n        id\n        name\n        thumbnail\n        url\n        price: priceWithIDR\n        __typename\n      }\n      totalComment\n      comments {\n        talkId\n        data {\n          isMine\n          id\n          products {\n            name\n            id\n            thumbnail\n            url\n            price: priceWithIDR\n            __typename\n          }\n          authorAvatar\n          authorName\n          authorShopId\n          message\n          talkId\n          user {\n            id\n            shop {\n              id\n              name\n              thumbnail\n              __typename\n            }\n            __typename\n          }\n          createdTime\n          updatedTime\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "PDPTalkQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_productCatalogQuery(self, host, **kwargs):
    query = "query ProductCatalogQuery($catalogID: String!) {\n  ProductCatalogQuery(catalog_id: $catalogID) {\n    header {\n      process_time\n      status\n      __typename\n    }\n    data {\n      catalog {\n        id\n        department_id\n        name\n        description\n        identifier\n        release_date\n        update_time\n        url\n        catalog_image {\n          image_url\n          is_primary\n          __typename\n        }\n        market_price {\n          min\n          max\n          min_fmt\n          max_fmt\n          date\n          name\n          __typename\n        }\n        expert_review {\n          source\n          review\n          good\n          bad\n          rating\n          url\n          image_url\n          max_score\n          source_id\n          __typename\n        }\n        specification {\n          name\n          row {\n            key\n            value\n            __typename\n          }\n          __typename\n        }\n        long_description {\n          title\n          description\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "ProductCatalogQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_pendingCashback(self, host, **kwargs):
    query = "query PendingCashback($userID: Int!, $msisdn: String!) {\n  pending_cashback(userID: $userID, msisdn: $msisdn) {\n    amount_text\n    amount\n    __typename\n  }\n  saldo {\n    deposit_fmt\n    __typename\n  }\n  wallet {\n    linked\n    balance\n    errors {\n      name\n      message\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "PendingCashback"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_hotListHome(self, host, **kwargs):
    query = "query HotListHome {\n  hot_product_home {\n    curr_page\n    per_page\n    max_page\n    items {\n      hot_product_id\n      title\n      url\n      image_url\n      price_start_from\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "HotListHome"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_feedInspirationQuery(self, host, **kwargs):
    query = "query FeedInspirationQuery($userID: Int!, $insLimit: Int!, $insCursor: String, $source: String) {\n  feedInspiration: feed(limit: $insLimit, cursor: $insCursor, userID: $userID, source: $source) {\n    data {\n      id\n      create_time\n      type\n      cursor\n      content {\n        type\n        inspirasi {\n          experiment_version\n          source\n          title\n          foreign_title\n          widget_url\n          pagination {\n            current_page\n            next_page\n            prev_page\n            __typename\n          }\n          recommendation {\n            id\n            name\n            url\n            click_url\n            app_url\n            image_url\n            price\n            price_int\n            recommendation_type\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    links {\n      self\n      pagination {\n        has_next_page\n        __typename\n      }\n      __typename\n    }\n    meta {\n      total_data\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "FeedInspirationQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response
 
def graphql_dynamicHome(self, host, **kwargs):
    query = "{ ticker { meta { total_data } tickers { id title message color } } slides { meta { total_data } slides { id title image_url redirect_url applink } } dynamicHomeIcon { dynamicIcon { id name url imageUrl applinks } } dynamicHomeChannel { channels { id name layout type header { id name url applink expiredTime backColor backImage } hero { id name url applink imageUrl attribution } grids { id name url applink price slashedPrice discount imageUrl label soldPercentage attribution } } } }"
    sub_name = "DynamicHome"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_dynamicHomeQuery(self, host, **kwargs):
    query = "query DynamicHomeQuery {\n  dynamicHomeIcon {\n    useCaseIcon {\n      id\n      name\n      url\n      imageUrl\n      applink: applinks\n      __typename\n    }\n    dynamicIcon {\n      id\n      name\n      url\n      imageUrl\n      applink: applinks\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "DynamicHomeQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_flashSaleWidget(self, host, **kwargs):
    query = "{ dynamicHomeChannel { channels { id name layout type header { id name url applink expiredTime backColor backImage } hero { id name url applink imageUrl attribution } grids { id name url applink price slashedPrice discount imageUrl label soldPercentage attribution } } } }"
    sub_name = "flashSaleWidgetAndroid"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_flashSaleWidgetMweb(self, host, **kwargs):
    query = "query DynamicHomeQuery { dynamicHomeChannel { channels { id name layout type header { id name url applink expiredTime backColor backImage __typename } hero { id name url applink imageUrl creativeName: attribution __typename } grids { id name url applink price originalPrice: slashedPrice soldPercentage discount imageUrl label creativeName: attribution __typename } __typename } __typename } dynamicHomeIcon { useCaseIcon { id name url imageUrl applink: applinks __typename } dynamicIcon { id name url imageUrl applink: applinks __typename } __typename } } "
    sub_name = "flashSaleWidgetMweb"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_addToCartMutation(self, host, **kwargs):
    query = "mutation addToCartMutation($productID: Int!, $shopID: Int!, $quantity: Int!, $notes: String, $lang: String, $attribution: String, $listTracker: String, $ucParams: String) {\n  add_to_cart(productID: $productID, shopID: $shopID, quantity: $quantity, notes: $notes, lang: $lang, attribution: $attribution, listTracker: $listTracker, ucParams: $ucParams) {\n    error_message\n    status\n    data {\n      success\n      message\n      cart_id\n      product_id\n      quantity\n      notes\n      shop_id\n      CustomerID\n      __typename\n    }\n    __typename\n  }\n}"
    sub_name = "addToCartMutation"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_productRecentViewTrigger(self, host, **kwargs):
    query = "mutation ProductRecentViewTrigger($productID: Int!) {\n  productRecentViewTrigger(product_id: $productID)\n}\n"
    sub_name = "ProductRecentViewTrigger"
    response = request(self, host, query, sub_name, **kwargs)
    return response
    
def graphql_cartListQuery(self, host, **kwargs):
    query = "query CartListQuery($lang: String!, $isReset: Boolean!) {\n  cart_list(lang: $lang, isReset: $isReset) {\n    data {\n      is_coupon_active\n      max_quantity\n      max_char_note\n      errors\n      default_promo_dialog_tab\n      autoapply {\n        success\n        code\n        is_coupon\n        discount_amount\n        title_description\n        message_success\n        promo_id\n        __typename\n      }\n      messages {\n        ErrorFieldBetween\n        ErrorFieldMaxChar\n        ErrorFieldRequired\n        ErrorProductAvailableStock\n        ErrorProductAvailableStockDetail\n        ErrorProductMaxQuantity\n        ErrorProductMinQuantity\n        __typename\n      }\n      promo_suggestion {\n        cta\n        cta_color\n        is_visible\n        promo_code\n        text\n        __typename\n      }\n      cart_list {\n        messages\n        errors\n        cart_id\n        shop {\n          shop_id\n          user_id\n          shop_name\n          shop_image\n          shop_url\n          shop_status\n          is_gold\n          is_gold_badge\n          is_official\n          is_free_returns\n          address_id\n          postal_code\n          latitude\n          longitude\n          district_id\n          district_name\n          origin\n          address_street\n          province_id\n          city_id\n          city_name\n          __typename\n        }\n        product {\n          product_tracker_data {\n            attribution\n            tracker_list_name\n            __typename\n          }\n          isWishlist\n          product_id\n          product_name\n          product_price_fmt\n          product_price\n          category_id\n          category\n          catalog_id\n          parent_id\n          wholesale_price {\n            qty_min_fmt\n            qty_max_fmt\n            qty_min\n            qty_max\n            prd_prc\n            prd_prc_fmt\n            __typename\n          }\n          product_weight_fmt\n          product_weight\n          product_condition\n          product_status\n          product_url\n          product_returnable\n          is_freereturns\n          is_preorder\n          product_cashback\n          product_min_order\n          product_rating\n          product_invenage_value\n          product_switch_invenage\n          product_price_currency\n          product_image {\n            image_src\n            image_src_200_square\n            image_src_300\n            image_src_square\n            __typename\n          }\n          product_all_images\n          product_notes\n          product_quantity\n          product_weight_unit_code\n          product_weight_unit_text\n          last_update_price\n          is_update_price\n          product_preorder {\n            duration_text\n            duration_day\n            duration_unit_code\n            duration_unit_text\n            duration_value\n            __typename\n          }\n          product_showcase {\n            name\n            id\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    error_message\n    status\n    __typename\n  }\n}"
    sub_name = "CartListQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_updateCart(self, host, **kwargs):
    query = "mutation updateCart($lang: String!, $carts: [ParamsCartUpdateCartType]) {\n  update_cart(lang: $lang, carts: $carts) {\n    error_message\n    status\n    data {\n      error\n      status\n      goto\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "UpdateCart"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_listAddress(self, host, **kwargs):
    query = "mutation listAddress {\n  list_address_mutation {\n    error\n    addresses {\n      addr_id\n      addr_name\n      receiver_name\n      status\n      address_1\n      address_2\n      postal_code\n      phone\n      country\n      province\n      city\n      district\n      province_name\n      city_name\n      district_name\n      latitude\n      longitude\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "ListAddress"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_updateCartCounterMutation(self, host, **kwargs):
    query = "mutation updateCartCounterMutation {\n  update_cart_counter {\n    count\n    __typename\n  }\n}\n"
    sub_name = "updateCartCounterMutation"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_getDiscoveryKolData(self, host, **kwargs):
    query = "query GetDiscoveryKolData($cursor: String!, $limit: Int!, $idcategory: Int, $search: String) {\n  get_discovery_kol_data(limit: $limit, cursor: $cursor, idcategory: $idcategory, search: $search) {\n    error\n    categories {\n      id\n      name\n      __typename\n    }\n    postKol {\n      isLiked\n      isFollow\n      id\n      commentCount\n      showComment\n      likeCount\n      createTime\n      description\n      content {\n        imageurl\n        tags {\n          id\n          type\n          url\n          link\n          price\n          caption\n          __typename\n        }\n        __typename\n      }\n      userName\n      userInfo\n      userIsFollow\n      userPhoto\n      userUrl\n      userId\n      userApplink\n      __typename\n    }\n    lastCursor\n    __typename\n  }\n}\n"
    sub_name = "getDiscoveryKolData"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_getWhitelistUserData(self, host, **kwargs):
    query = "query GetWhitelistUserData($cursor: String!, $limit: Int!, $search: String) {\n  get_whitelist_user(limit: $limit, cursor: $cursor, search: $search) {\n    error\n    data {\n      isFollowed\n      info\n      userId\n      userName\n      userPhoto\n      userApplink\n      __typename\n    }\n    lastCursor\n    __typename\n  }\n}\n"
    sub_name = "getWhitelistUserData"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_getProfileContent(self, host, **kwargs):
    query = "query GetProfileContent($userID: Int!){\n    get_user_profile_data(userID: $userID) {\n\t\terror\n        data {\n            followers\n            following\n            followed\n            id\n            info\n            bio\n            name\n            photo\n            favorite\n            iskol\n            favorite_fmt\n            followers_fmt\n            following_fmt\n            is_me\n        }\n    }\n    profile {\n            email_verified\n            gender_name\n            phone_verified\n            completion\n            user_id\n            full_name\n            email\n\t\t\tgender\n            gender_name\n            apps_bday\n            bday\n            age\n            phone\n            phone_masked\n            profile_picture\n            created_password\n    }\n        shopInfoByUserId(user_id: $userID) {\n            data {\n                shop_id\n                shop_url\n                user_id\n                admin_id\n                shop_name\n                domain\n                is_gold\n                is_gold_badge\n                is_official\n                is_free_returns\n                shop_status_title\n                shop_status_message\n                location\n                logo\n                reputation_badge\n                s_reputation {\n                    tooltip\n                    reputation_badge\n                    ReputationScore\n                    min_badge_score\n                    score\n                    badge_level\n                }\n                s_badges {\n                    title\n                    image_url\n                }\n                use_ace\n\t\t\t    last_online\n                applink\n                is_favorite\n            }\n        }\n    reputationByUserId(user_id: $userID) {\n        active\n        positive\n        neutral\n        negative\n        percentage\n    }\n}\n"
    sub_name = "getProfileContent"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_getUserKolPost(self, host, **kwargs):
    query = "query GetUserKolPost($userID: Int!, $limit: Int!, $cursor: String) {\n    get_user_kol_post(userID: $userID, cursor: $cursor, limit: $limit) {\n        error\n        data {\n          id\n          description\n          commentCount\n          showComment\n          likeCount\n          isLiked\n          isFollow\n          createTime\n          userName\n          userPhoto\n          userInfo\n          content {\n            imageurl\n            tags {\n              id\n              type\n              url\n              link\n              price\n              caption\n            }\n          }\n        }\n        lastCursor\n    }\n}\n"
    sub_name = "getUserKolPost"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_followKol(self, host, **kwargs):
    query = "mutation FollowKol($userID: Int!, $action: Int!) {  do_follow_kol(userID: $userID, action: $action) {    __typename    error    data {      __typename      status    }  }}"
    sub_name = kwargs.get('name','followKol')
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_getShipmentForm(self, host, **kwargs):
    query = 'query GetShipmentForm($lang: String = \"id\") {\n  get_shipment_form(lang: $lang) {\n    errors\n    error_code\n    group_address {\n      errors\n      user_address {\n        addr_id\n        address_id\n        address_name\n        addr_name\n        address\n        address_1\n        postal_code\n        phone\n        receiver_name\n        status\n        country\n        province_id\n        city_id\n        city_name\n        district_id\n        district\n        district_name\n        address_2\n        latitude\n        longitude\n        __typename\n      }\n      group_shop {\n        errors\n        shop {\n          shop_id\n          user_id\n          shop_name\n          shop_image\n          shop_url\n          shop_status\n          is_gold\n          is_gold_badge\n          is_official\n          is_free_returns\n          address_id\n          postal_code\n          latitude\n          longitude\n          district_id\n          district_name\n          origin\n          address_street\n          province_id\n          city_id\n          shop_id\n          __typename\n        }\n        shop_shipments {\n          ship_id\n          ship_name\n          ship_code\n          ship_logo\n          ship_prods {\n            ship_prod_id\n            ship_prod_name\n            ship_group_name\n            ship_group_id\n            additional_fee\n            minimum_weight\n            __typename\n          }\n          __typename\n        }\n        products {\n          errors\n          product_id\n          product_name\n          product_price_fmt\n          product_price\n          product_wholesale_price\n          product_wholesale_price_fmt\n          product_condition\n          product_url\n          product_returnable\n          product_is_free_returns\n          product_is_preorder\n          product_cashback\n          product_min_order\n          product_invenage_value\n          product_switch_invenage\n          product_price_currency\n          product_image_src_200_square\n          product_notes\n          product_quantity\n          product_menu_id\n          product_finsurance\n          product_fcancel_partial\n          product_shipment {\n            shipment_id\n            service_id\n            __typename\n          }\n          product_shipment_mapping {\n            shipment_id\n            shipping_ids\n            service_ids {\n              service_id\n              sp_ids\n              __typename\n            }\n            __typename\n          }\n          product_cat_id\n          product_catalog_id\n          product_weight\n          product_weight_fmt\n          product_tracker_data {\n            attribution\n            tracker_list_name\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    kero_token\n    kero_unix_time\n    enable_partial_cancel\n    donation {\n      Title\n      Nominal\n      Description\n      __typename\n    }\n    __typename\n  }\n}'
    sub_name = "GetShipmentForm"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_logisticRateQuery(self, host, **kwargs):
    query = "query LogisticsRateQuery($input: OngkirRatesInput!) {  ongkir(input: $input) {    __typename    rates {      __typename      id      type      attributes {        __typename        id        shipper_id        shipper_name         weight        products {          __typename          shipper_product_id          shipper_product_name          is_show_map          price          formatted_price          check_sum          ut          max_hours_id          desc_hours_id          insurance_price          insurance_type          insurance_used_type          insurance_used_info          insurance_used_default        }      }    }  }}"
    sub_name = "LogisticRateQuery"
    path = '/'
    tokenpath = '/rates/v1'
    tokenmethod = 'GET'

    default = {
        'headers': {
            'origin':host,
            'content-type':'application/json'
        }
    }
    kwargs['name'] = host + path + sub_name
    kwargs['json'] = kwargs.get('json',{})

    token, device_time = tkpdhmac.generate_kero_token(tokenmethod, tokenpath)
    kwargs['json']['variables']['input']['token'] = token
    kwargs['json']['variables']['input']['ut'] = str(device_time)
    if not kwargs['json'].has_key('query') : kwargs['json'].update( {"query":query})
    return ht.call(self, host, path, default=default, **kwargs)

def status(self, host, **kwargs):
    path = "/status"
    response = ht.call(self, host, path,**kwargs)
    return response

def graphql_headerQuery(self, host, **kwargs):
    query = "query HeaderQuery($loggedIn: Boolean!) {\n  userShopInfo {\n    info {\n      shop_id\n      shop_domain\n      shop_name\n      shop_avatar\n      shop_is_official\n      __typename\n    }\n    owner {\n      owner_id\n      is_gold_merchant\n      __typename\n    }\n    __typename\n  }\n  notifications @include(if: $loggedIn) {\n    total_notif\n    total_cart\n    incr_notif\n    resolution\n    resolution_as {\n      resolution_as_seller\n      resolution_as_buyer\n      __typename\n    }\n    sales {\n      sales_new_order\n      sales_shipping_status\n      sales_shipping_confirm\n      __typename\n    }\n    inbox {\n      inbox_talk\n      inbox_ticket\n      inbox_review\n      inbox_friend\n      inbox_message\n      inbox_wishlist\n      inbox_reputation\n      __typename\n    }\n    purchase {\n      purchase_reorder\n      purchase_order_status\n      purchase_payment_confirm\n      purchase_delivery_confirm\n      __typename\n    }\n    chat {\n      unreads\n      __typename\n    }\n    seller_info_notif {\n      notification\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "HeaderQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_rechargeFavoriteNumber(self, host, **kwargs):
    query = "mutation rechargeFavoriteNumber($category_id: Int!) {\n  recharge_favorite_number(categoryID: $category_id) {\n    category_id\n    operator_id\n    client_number\n    product_id\n    list {\n      category_id\n      operator_id\n      client_number\n      product_id\n      label\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "RechargeFavoriteNumber"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_footerQuery(self, host, **kwargs):
    query = "query FooterQuery($loggedIn: Boolean!) {\n  notifications @include(if: $loggedIn) {\n    chat {\n      unreads\n      __typename\n    }\n    inbox {\n      inbox_talk\n      inbox_review\n      inbox_ticket\n      __typename\n    }\n    total_cart\n    __typename\n  }\n}\n"
    sub_name = "FooterQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_getCourier(self, host, **kwargs):
    query = 'mutation GetCourier($couriers: [CourierQuoteRequestType]!, $origin: AddressPinpoint!, $destination: AddressPinpoint!, $weight: String!, $token: String!, $ut: String!, $insurance: Int!, $productInsurance: Int!, $orderValue: String!, $catId: [Int]!, $lang: String!) {\n  get_courier(couriers: $couriers, origin: $origin, destination: $destination, weight: $weight, token: $token, ut: $ut, insurance: $insurance, product_insurance: $productInsurance, order_value: $orderValue, cat_id: $catId, lang: $lang) {\n    id\n    shippings {\n      service_id\n      shipper_name\n      formatted_shipping_name\n      formatted_price_range\n      formatted_etd\n      courier_list {\n        shipper_id\n        shipper_product_id\n        shipper_name\n        shipper_product_name\n        price\n        formatted_price\n        is_show_map\n        insurance_price\n        insurance_type\n        max_hours_en\n        max_hours_id\n        desc_hours_en\n        desc_hours_id\n        insurance_type_info\n        tokopedia_insurance\n        tokopedia_insurance_default\n        tokopedia_insurance_info\n        format_etd\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n'
    sub_name = "GetCourier"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_getDistrictBoundary(self, host, **kwargs):
    query = 'query GetDistrictBoundary($districtId: String) {\n  get_district_boundary(districtId: $districtId) {\n    district_id\n    boundary\n    __typename\n  }\n}\n'
    sub_name = "GetDistrictBoundary"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_quickFilter(self, host, **kwargs):
    query = "query searchQuickFilter($source: String, $q: String) {\n  searchQuickFilter(source: $source, q: $q) {\n    filter {\n      title\n      options {\n        key\n        value\n        name\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "searchQuickFilter"
    response = request(self, host, query, sub_name, **kwargs)
    return response
    
def graphql_recentViewQuery(self, host, **kwargs):
    query = "query RecentViewQuery($userID: Int!) {\n  get_recent_view(userID: $userID) {\n    items {\n      product_id\n      product_url\n      product_name\n      product_image\n      product_price\n      shop_id/n      shop_url\n      shop_name\n      shop_location\n      shop_gold_status\n      badges {\n        title\n        image_url\n        __typename\n      }\n      labels {\n        title\n        color\n        __typename\n      }\n      wishlist\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "RecentViewQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_addFavorite(self, host, **kwargs):
    query = "mutation addFavorite($shopID: Int!, $userID: Int!, $adRefKey: String) {\n  favorite_add(shopID: $shopID, userID: $userID, adKey: $adRefKey) {\n    shop_id\n    success\n    __typename\n  }\n}\n"
    sub_name = "AddFavorite"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_contentData(self, host, **kwargs):
    query = "query ContentData($categoryId: Int!, $categories: [Int]!, $offset: Int = 0, $fetchingMore: Boolean!, $skipFlashsale: Boolean!) {\n  officialStoreBanners(categoryId: $categoryId) @skip(if: $fetchingMore) {\n    banners {\n      bannerId: id\n      description\n      device\n      expireTime\n      htmlId\n      imageUrl\n      isDefault\n      redirectAppUrl\n      redirectUrl\n      shopName\n      startTime\n      state\n      title\n      __typename\n    }\n    total\n    __typename\n  }\n  officialStoreFlashSale @skip(if: $skipFlashsale) {\n    saleId: id\n    bannerName\n    bannerPath\n    duration\n    expireTime\n    imageUrl\n    redirectUrl\n    redirectAppUrl\n    status\n    startTime\n    title\n    products {\n      productId: id\n      name\n      imageUrl\n      discountPercentage\n      originalPrice\n      price\n      __typename\n    }\n    __typename\n  }\n  officialStoreProducts(categories: $categories, offset: $offset) {\n    products {\n      productId: id\n      name\n      imageUrl\n      discountPercentage\n      originalPrice\n      price\n      isWishlist\n      shop {\n        shopID: id\n        name\n        logoUrl\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "ContentData"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_categoryData(self, host, **kwargs):
    query = "query CategoryData($lang: String!, $device: DeviceString) {\n  officialStoreCategories {\n    categories {\n      categoryId: id\n      name(lang: $lang)\n      categories {\n        categoryId: id\n        __typename\n      }\n      __typename\n    }\n    total\n    __typename\n  }\n  officialStoreBrands(lang: $lang, device: $device) {\n    category\n    shops {\n      shopId: id\n      city\n      clover\n      isGold\n      isNew\n      location\n      logoUrl\n      name\n      reputation\n      url\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "CategoryData"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_officialStoreProducts(self, host, **kwargs):
    query = "query OfficialStoreProducts($categories: [Int]!, $device: DeviceString = mobile, $offset: Int = 0) {\n  officialStoreProducts(categories: $categories, device: $device, offset: $offset) {\n    products {\n      id\n      name\n      imageUrl\n      isWishlist\n      originalPrice\n      price\n      url\n      shop {\n        name\n        logoUrl\n        url\n        __typename\n      }\n      __typename\n    }\n    hasNext\n    __typename\n  }\n}\n"
    sub_name = "OfficialStoreProducts"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_ssiOfficialStoreQuery(self, host, **kwargs):
    query = "query SSIOfficialStoreQuery($domain: String!) {\n  SSIOfficialStoreQuery(domain: $domain)\n}\n"
    sub_name = "SSIOfficialStoreQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_updateProductList(self, host, **kwargs):
    query = "mutation updateProductList($shopID: Int!, $userID: Int, $filter: SearchFilterQueryType!, $page: Int, $perPage: Int, $etalase: String, $query: String, $useace: Boolean, $isOfficial: Boolean) {\n  product_list(userID: $userID, shopID: $shopID, filter: $filter, page: $page, perPage: $perPage, etalase: $etalase, query: $query, useace: $useace, isOfficial: $isOfficial) {\n    paging {\n      uri_next\n      uri_previous\n      __typename\n    }\n    list {\n      id\n      image_url\n      image_url_700\n      badges {\n        image_url\n        title\n        __typename\n      }\n      name\n      price\n      url\n      isWishlist\n      campaignPrice\n      campaignPersentage\n      soldOutStatus\n      count_review\n      labels {\n        color\n        title\n        __typename\n      }\n      shop {\n        shop_id\n        shop_url\n        shop_name\n        is_gold\n        location\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "updateProductList"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_shopFollowers(self, host, **kwargs):
    query = "mutation shopFollowers($shopID: Int!, $perPage: Int!, $page: Int!) {\n  shop_followers(shopID: $shopID, perPage: $perPage, page: $page) {\n    links {\n      self\n      prev\n      next\n      __typename\n    }\n    data {\n      list {\n        id\n        name\n        url\n        photo\n        __typename\n      }\n      total\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "shopFollowers"
    response = request(self, host, query, sub_name, **kwargs)
    return response
    
def graphql_shopSummaryQuery(self, host, **kwargs):
    query = "query ShopSummaryQuery($toShopId: Int) {\n  existingChat: chatExistingChat(toShopId: $toShopId, source: \"shop\") {\n    messageId\n    contact {\n      id\n      role\n      attributes {\n        name\n        domain\n        thumbnail\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "ShopSummaryQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_shopCheckFavorite(self, host, **kwargs):
    query = "mutation shopCheckFavorite($userID: Int!, $shopID: Int!) {\n  shopCheckFavorite(userID: $userID, shopID: $shopID)\n}\n"
    sub_name = "shopCheckFavorite"
    response = request(self, host, query, sub_name, **kwargs)
    return response
    
def graphql_wishlistQuery(self, host, **kwargs):
    query = "query WishlistQuery($userID: Int!, $query: String!, $count: Int!, $page: Int!) {\n  wishlist(user_id: $userID, query: $query, count: $count, page: $page) {\n    count\n    has_next_page\n    total_data\n    items {\n      id\n      name\n      url\n      image_url\n      raw_price\n      price\n      prev_price\n      shop {\n        id\n        name\n        url\n        location\n        __typename\n      }\n      badges {\n        title\n        image_url\n        __typename\n      }\n      labels {\n        title\n        color\n        __typename\n      }\n      available\n      status\n      wishlist\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "WishlistQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_addWishlist(self, host, **kwargs):
    query = "mutation addWishlist($productID: Int!, $userID: Int!) {\n  wishlist_add(productID: $productID, userID: $userID) {\n    id\n    success\n    __typename\n  }\n}\n"
    sub_name = "addWishlist"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_removeWishlist(self, host, **kwargs):
    query = "mutation removeWishlist($productID: Int!, $userID: Int!) {\n  wishlist_remove(productID: $productID, userID: $userID) {\n    id\n    success\n    __typename\n  }\n}\n"
    sub_name = "removeWishlist"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_categoryProductsQuery(self, host, **kwargs):
    query = """query CategoryProductsQuery($category_id: Int!, $user_id: Int!, $user_search_id: String, $filter: SearchFilterQueryType!, $product_page: Int!, $catalog_page: Int!, $per_page: Int!, $tracker: ApiTracketType!) {\n  category_products(category_id: $category_id, user_search_id: $user_search_id, filter: $filter, page: $product_page, per_page: $per_page, user_id: $user_id, tracker: $tracker) {\n    header {\n      total_data\n      __typename\n    }\n    data {\n      id\n      department_id\n      condition\n      image_url\n      image_url_700\n      badges {\n        image_url\n        title\n        __typename\n      }\n      name\n      price\n      rating\n      url\n      isWishlist\n      count_review\n      wholesale_price {\n        quantity_min\n        quantity_max\n        price\n        __typename\n      }\n      labels {\n        color\n        title\n        __typename\n      }\n      shop {\n        shop_id\n        shop_url\n        domain\n        shop_name\n        shop_name_unfmt\n        shop_name_clean\n        is_gold\n        is_official\n        location\n        logo\n        shop_badge\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  category_catalog(category_id: $category_id, filter: $filter, page: $catalog_page, per_page: $per_page) {\n    total_data\n    items {\n      id\n      name\n      description\n      uri\n      image_uri\n      count_product\n      price_min\n      __typename\n    }\n    __typename\n  }\n}\n"""
    sub_name = 'categoryProductsQuery'
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_categoryDetail(self, host, **kwargs):
    query = """query CategoryDetail($id: String!, $device: String!, $user_id: Int!) {\n  category_detail(id: $id, device: $device, user_id: $user_id) {\n    child {\n      id\n      name\n      url\n      thumbnail_image\n      hidden\n      is_revamp\n      is_intermediary\n      __typename\n    }\n    curated_product {\n      category_id\n      sections {\n        title\n        products {\n          id\n          department_id\n          condition\n          image_url\n          image_url_700\n          badges {\n            image_url\n            title\n            __typename\n          }\n          name\n          price\n          rating\n          url\n          isWishlist\n          wholesale_price {\n            quantity_min\n            quantity_max\n            price\n            __typename\n          }\n          labels {\n            title\n            color\n            __typename\n          }\n          shop {\n            shop_id\n            shop_url\n            shop_name\n            location\n            __typename\n          }\n          count_review\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    banner {\n      images {\n        title\n        url\n        position\n        image_url\n        __typename\n      }\n      __typename\n    }\n    id\n    name\n    description\n    title_tag\n    meta_description\n    header_image\n    hidden\n    tree\n    view\n    template\n    is_revamp\n    is_intermediary\n    video {\n      youtube_id\n      title\n      description\n      video_url\n      __typename\n    }\n    featured_category {\n      id\n      name\n      featured_category_id\n      url\n      image_url\n      status\n      __typename\n    }\n    category_brand {\n      id\n      name\n      category_id\n      url\n      image_url\n      status\n      __typename\n    }\n    catalog_by_category {\n      id\n      name\n      file_path\n      url\n      image_url\n      bg_file_name\n      bg_image_url\n      color\n      type\n      catalogs {\n        id\n        name\n        catalog_id\n        url\n        image_url\n        market_price\n        status\n        __typename\n      }\n      __typename\n    }\n    root_category_id\n    __typename\n  }\n}\n"""
    sub_name = 'categoryDetail'
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_categoryFilterQuery(self, host, **kwargs):
    query = "query CategoryFilterQuery($category_id: Int!, $filter_source: String!) {\n  category_filter_and_sort(source: $filter_source, sc: $category_id) {\n    filter {\n      title\n      search {\n        searchable\n        placeholder\n        __typename\n      }\n      options {\n        name\n        key\n        value\n        icon\n        input_type\n        total_data\n        val_min\n        val_max\n        hex_color\n        child {\n          key\n          value\n          name\n          icon\n          input_type\n          total_data\n          child {\n            key\n            value\n            name\n            icon\n            input_type\n            total_data\n            child {\n              key\n              value\n              name\n              icon\n              input_type\n              total_data\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    sort {\n      name\n      key\n      value\n      input_type\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = 'categoryFilterQuery'
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_categoryBreadcrumb(self, host, **kwargs):
    query = "query Query($catID: Int!) {\n  category_breadcrumb(catID: $catID) {\n    categories {\n      id\n      name\n      identifier\n      url\n      tree\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = 'categoryBreadcrumb'
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_mainCategoriesQueries(self, host, **kwargs):
    query = "query mainCategoriesQueries($id: Int!, $query: String) {\n  categoryList(id: $id, query: $query) {\n    categories {\n      cat_id\n      url\n      name\n      title\n      parent\n      applinks\n      has_child\n      icon_image_url\n      __typename\n    }\n    errors {\n      name\n      message\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = 'mainCategoriesQueries'
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_intermediaryLifestyle(self, host, **kwargs):
    query = "query IntermediaryLifestyle($id: Int!, $user_id: Int!, $user_search_id: String, $filter: SearchFilterQueryType!, $product_page: Int!, $per_page: Int!, $page_name: String!, $xdevice: String!, $xsource: String!, $tracker: ApiTracketType!) {\n  category_hotlist(id: $id) {\n    id\n    title\n    url\n    img\n    img_share\n    img_promo\n    img_square\n    img_portrait\n    __typename\n  }\n  category_official_store(id: $id) {\n    shop_id\n    shop_url\n    shop_name\n    logo_url\n    is_new\n    __typename\n  }\n  category_products(category_id: $id, user_search_id: $user_search_id, filter: $filter, page: $product_page, per_page: $per_page, user_id: $user_id, tracker: $tracker) {\n    header {\n      total_data\n      __typename\n    }\n    data {\n      id\n      department_id\n      condition\n      image_url\n      image_url_700\n      badges {\n        image_url\n        title\n        __typename\n      }\n      name\n      price\n      rating\n      url\n      isWishlist\n      wholesale_price {\n        quantity_min\n        quantity_max\n        price\n        __typename\n      }\n      labels {\n        color\n        title\n        __typename\n      }\n      shop {\n        shop_id\n        shop_url\n        domain\n        shop_name\n        shop_name_unfmt\n        shop_name_clean\n        is_gold\n        is_official\n        location\n        logo\n        shop_badge\n        __typename\n      }\n      count_review\n      __typename\n    }\n    __typename\n  }\n  category_recommendation(page_name: $page_name, category: $id, xdevice: $xdevice, xsource: $xsource, user_id: $user_id) {\n    meta {\n      recommendation\n      size\n      __typename\n    }\n    data {\n      source\n      title\n      foreign_title\n      pagination {\n        current_page\n        next_page\n        prev_page\n        __typename\n      }\n      recommendation {\n        id\n        name\n        url\n        isWishlist\n        image_url\n        price\n        shop {\n          shop_id\n          shop_url\n          domain\n          shop_name\n          shop_name_unfmt\n          shop_name_clean\n          is_gold\n          is_official\n          location\n          logo\n          shop_badge\n          __typename\n        }\n        department_id\n        badges {\n          image_url\n          title\n          __typename\n        }\n        labels {\n          color\n          title\n          __typename\n        }\n        wholesale_price {\n          quantity_min\n          quantity_max\n          price\n          __typename\n        }\n        rating\n        count_review\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = 'intermediaryLifestyle'
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_HotlistDetailProductQuery(self, host, **kwargs):
    query = "query HotlistDetailProductQuery($filterAttribute: String, $rows: Int, $start: Int) {\n  hotlistDetailProduct(filterAttribute: $filterAttribute, rows: $rows, start: $start) {\n    totalData\n    products {\n      id\n      name\n      url\n      image_url\n      image_url_700\n      price\n      shop {\n        id\n        name\n        url\n        is_gold\n        location\n        city\n        reputation\n        clover\n        __typename\n      }\n      badges {\n        title\n        image_url\n        __typename\n      }\n      labels {\n        title\n        color\n        __typename\n      }\n      rating\n      count_review\n      wishlist\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "HotListDetailProductQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_resolutionInboxBuyerQuery(self, host, **kwargs):
    query = "query ResolutionInboxBuyerQuery($startID: Int, $sortBy: Int, $asc: Int, $filter: [Int], $limit: Int, $startTime: String, $endTime: String) {\n  resolution_inbox_buyer(limit: $limit, startID: $startID, sortBy: $sortBy, asc: $asc, filter: $filter, startTime: $startTime, endTime: $endTime) {\n    status\n    config\n    siteUrlLite\n    data {\n      inboxes {\n        id\n        resolution {\n          id\n          status {\n            int\n            string\n            __typename\n          }\n          read\n          responded\n          createTime {\n            time\n            string\n            __typename\n          }\n          lastReplyTime {\n            time\n            string\n            __typename\n          }\n          autoExecuteTime {\n            id\n            time\n            string\n            status\n            __typename\n          }\n          freeReturn\n          product {\n            id\n            images {\n              thumb\n              full\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        shop {\n          id\n          name\n          __typename\n        }\n        customer {\n          id\n          name\n          __typename\n        }\n        order {\n          awbNumber\n          refNum\n          __typename\n        }\n        __typename\n      }\n      actionBy\n      count {\n        unread\n        unanswered\n        finished\n        autoExecution\n        unfinished\n        __typename\n      }\n      __typename\n    }\n    messageError\n    __typename\n  }\n}\n"
    sub_name = "ResolutionInboxBuyerQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_chatListQuery(self, host, **kwargs):
    query = "query ChatListQuery($tab: String, $filter: String, $page: Int = 1, $perPage: Int = 10, $order: String = \"desc\", $platform: String = \"mobile\") {\n  chatList(tab: $tab, filter: $filter, page: $page, perPage: $perPage, order: $order, platform: $platform) {\n    list {\n      key\n      messageId\n      contact {\n        name\n        role\n        thumbnail\n        __typename\n      }\n      lastReplyMessage\n      lastReplyTime\n      readStatus\n      unreads\n      __typename\n    }\n    hasNext\n    showTimeMachine\n    __typename\n  }\n}\n"
    sub_name = "ChatListQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_TokopointsQuery(self, host, **kwargs):
    query = "query TokopointsQuery {\n  tokopoints {\n    resultStatus {\n      code\n      __typename\n    }\n    offFlag\n    status {\n      tier {\n        id\n        nameDesc\n        __typename\n      }\n      points {\n        reward\n        rewardStr\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "TokopointsQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_FloatingEggQuery(self, host, **kwargs):
    query = "query FloatingEggQuery {\n  floatingEgg: tokopointsToken {\n    resultStatus {\n      code\n      message\n      __typename\n    }\n    offFlag\n    sumToken\n    sumTokenStr\n    floating {\n      tokenId\n      tokenAsset {\n        name\n        version\n        floatingImgUrl\n        smallImgUrl\n        imageUrls\n        spriteUrl\n        __typename\n      }\n      tokenClaimCustomText\n      tokenClaimText\n      countingMessage\n      pageUrl\n      applink\n      timeRemainingSeconds\n      unixTimestamp\n      isShowTime\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "FloatingEggQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response
    
def graphql_hachikoMainQuery(self, host, **kwargs):
    query = "query HachikoMainQuery {\n  hachikoMain {\n    has_notif\n    pop_up_notif {\n      title\n      text\n      sender\n      button_text\n      button_url\n      app_link\n      notes\n      catalog {\n        cta\n        cta_desktop\n        title\n        sub_title\n        points\n        expired\n        image_url_mobile\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "HachikoMainQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_isAuthenticatedQuery(self, host, **kwargs):
    query = "query isAuthenticatedQuery {\n  isAuthenticated\n}\n"
    sub_name = "isAuthenticatedQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_wallet(self, host, **kwargs):
    query = "{\n  wallet{\n    linked\n    balance\n    rawBalance\n    errors{\n      name\n      message\n    }\n    text\n    total_balance\n    raw_total_balance\n    hold_balance\n    raw_hold_balance\n    redirect_url\n    applinks\n    ab_tags{\n      tag\n    }\n    action{\n      text\n      redirect_url\n      applinks\n      visibility\n    }\n  }\n}"
    sub_name = "wallet"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_tokopoints(self, host, **kwargs):
    query = "{\n  tokopoints {\n    offFlag\n    url {\n        mainPageURL\n    }\n    status {\n      tier {\n        id\n        name\n        nameDesc\n        imageURL\n      }\n      points {\n        reward\n        rewardStr\n      }\n    }\n    popupNotif(type:\"drawer\") {\n      title\n      text\n      imageURL\n      buttonText\n      buttonURL\n      appLink\n      }\n  }\n}"
    sub_name = "tokopoints"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_tokopointsNotificationQuery(self, host, **kwargs):
    query = "query TokopointsNotificationQuery {\n  tokopoints {\n    popupNotif(type: \"drawer\") {\n      title\n      text\n      imageURL\n      buttonText\n      buttonURL\n      appLink\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "TokopointsNotificationQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_productStockQuery(self, host, **kwargs):
    query = "query ProductStockQuery($productID: String!, $lang: String!) {\n  ProductStockQuery(productID: $productID, lang: $lang) {\n    data {\n      productID\n      enabled\n      variantType\n      alwaysAvailable\n      stock\n      stockWording\n      otherVariantStock\n      isLimitedStock\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "ProductStockQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_showCatalogQuery(self, host, **kwargs):
    query = "query ShowCatalogQuery($query: String, $page: Int, $per_page: Int, $ob: Int, $pmin: String, $pmax: String, $sc: String) {\n  show_catalog(query: $query, page: $page, per_page: $per_page, ob: $ob, pmin: $pmin, pmax: $pmax, sc: $sc) {\n    total_data\n    __typename\n  }\n  search_results_catalog(query: $query, page: $page, per_page: $per_page, ob: $ob, pmin: $pmin, pmax: $pmax, sc: $sc) {\n    items {\n      id\n      name\n      price_min\n      count_product\n      description\n      image_uri\n      uri\n      __typename\n    }\n    total_data\n    __typename\n  }\n}\n"
    sub_name = "showCatalogQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response
    
def graphql_notifcenterUnread(self, host, **kwargs):
    query = "{\n notifcenter_unread \n            {\n \n                notif_unread \n\n            }\n\n        }"
    sub_name = "notifcenterUnread"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_shopTopChatQuery(self, host, **kwargs):
    query = "query ShopTopChatQuery($toShopId: Int) {\n  existingChat: chatExistingChat(toShopId: $toShopId, source: \"shop\") {\n    messageId\n    contact {\n      id\n      role\n      attributes {\n        name\n        domain\n        thumbnail\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "ShopTopChatQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_shopFeaturedProduct(self, host, **kwargs):
    query = "query shopFeaturedProduct($shopID: Int!) {\n  shopFeaturedProduct(shopID: $shopID) {\n    data {\n      product_id\n      name\n      uri\n      price\n      image_uri\n      preorder\n      returnable\n      wholesale\n      wholesale_detail {\n        Qty\n        Price\n        __typename\n      }\n      cashback\n      labels {\n        title\n        color\n        __typename\n      }\n      badges {\n        title\n        image_url\n        __typename\n      }\n      rating\n      total_review\n      isWishlist\n      original_price\n      percentage_amount\n      is_os_campaign\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "shopFeaturedProduct"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_hachikoCatalogQuery(self, host, **kwargs):
    query = "query hachikoCatalogQuery($category_id: Int, $points_range: Int, $page: Int, $page_size: Int, $sort_id: Int) {\n  catalog: hachikoCatalogList(category_id: $category_id, points_range: $points_range, page: $page, page_size: $page_size, sort_id: $sort_id) {\n    catalogs {\n      id\n      promo_id\n      base_code\n      slug\n      expired\n      points\n      points_str\n      title\n      quota\n      sub_title\n      thumbnail_url\n      thumbnail_url_mobile\n      image_url\n      image_url_mobile\n      is_gift\n      __typename\n    }\n    has_next\n    __typename\n  }\n  myCoupons: hachikoMyCouponList(page: $page, page_size: $page_size) {\n    total_data\n    coupons {\n      catalog_id\n      usage {\n        active_count_down\n        expired_count_down\n        text\n        usage_str\n        btn_usage {\n          text\n          url\n          applink\n          type\n          __typename\n        }\n        __typename\n      }\n      promo_id\n      code\n      expired\n      title\n      sub_title\n      catalog_title\n      catalog_sub_title\n      description\n      icon\n      image_url\n      image_url_mobile\n      thumbnail_url\n      thumbnail_url_mobile\n      cta\n      cta_desktop\n      __typename\n    }\n    extra_info {\n      info_html\n      link_text\n      link_url\n      __typename\n    }\n    has_next\n    __typename\n  }\n}\n"
    sub_name = "hachikoCatalogQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_CatalogListQuery(self, host, **kwargs):
    query = "query CatalogListQuery($category_id: Int, $points_range: Int, $page: Int, $page_size: Int, $sort_id: Int) {\n  catalog: hachikoCatalogList(category_id: $category_id, points_range: $points_range, page: $page, page_size: $page_size, sort_id: $sort_id) {\n    catalogs {\n      id\n      promo_id\n      base_code\n      slug\n      expired\n      points\n      points_str\n      title\n      quota\n      sub_title\n      thumbnail_url\n      thumbnail_url_mobile\n      image_url\n      image_url_mobile\n      is_gift\n      __typename\n    }\n    has_next\n    __typename\n  }\n  myCoupons: hachikoMyCouponList(page: $page, page_size: $page_size) {\n    total_data\n    coupons {\n      catalog_id\n      usage {\n        active_count_down\n        expired_count_down\n        text\n        usage_str\n        btn_usage {\n          text\n          url\n          applink\n          type\n          __typename\n        }\n        __typename\n      }\n      promo_id\n      code\n      expired\n      title\n      sub_title\n      catalog_title\n      catalog_sub_title\n      description\n      icon\n      image_url\n      image_url_mobile\n      thumbnail_url\n      thumbnail_url_mobile\n      cta\n      cta_desktop\n      __typename\n    }\n    extra_info {\n      info_html\n      link_text\n      link_url\n      __typename\n    }\n    has_next\n    __typename\n  }\n}\n"
    sub_name = "CatalogListQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_UserPointsQuery(self, host, **kwargs):
    query = "query UserPointsQuery {\n  tokopoints {\n    resultStatus {\n      code\n      __typename\n    }\n    status {\n      points {\n        reward\n        rewardStr\n        loyalty\n        loyaltyStr\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "UserPointsQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_QuestTickerQuery(self, host, **kwargs):
    query = "query QuestTickerQuery {\n  tokopoints {\n    resultStatus {\n      code\n      message\n      __typename\n    }\n    ticker {\n      tickerList {\n        id\n        type\n        metadata {\n          image {\n            url\n            __typename\n          }\n          text {\n            content\n            color\n            format\n            __typename\n          }\n          link {\n            url\n            applink\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "QuestTickerQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_TokopointsMainGolangQuery(self, host, **kwargs):
    query = "query TokopointsMainGolangQuery($promotionSlug: String) {\n  tokopoints {\n    resultStatus {\n      code\n      message\n      status\n      __typename\n    }\n    offFlag\n    status {\n      tier {\n        id\n        name\n        nameDesc\n        imageURL\n        eggImageURL\n        __typename\n      }\n      points {\n        reward\n        rewardStr\n        loyalty\n        loyaltyStr\n        rewardExpiryInfo\n        loyaltyExpiryInfo\n        __typename\n      }\n      __typename\n    }\n    sheetHowToGet {\n      title\n      description\n      services {\n        icon\n        text\n        url\n        appLink\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  tokopointsCatalogFilter(slug: $promotionSlug) {\n    categories {\n      id\n      parentID\n      name\n      timeRemainingSeconds\n      imageID\n      imageURL\n      isSelected\n      index\n      subcategory {\n        id\n        parentID\n        name\n        categoryIndex\n        __typename\n      }\n      __typename\n    }\n    sortType {\n      id\n      text\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "TokopointsMainGolangQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_SearchRedirectionQuery(self, host, **kwargs):
    query = "query SearchRedirectionQuery($query: String) {\n  redirectionUrl(query: $query) {\n    redirection {\n      redirectUrl\n      departmentId\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "SearchRedirectionQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_SearchDynamicAttributes(self, host, **kwargs):
    query = "query DynamicAttributes($source: String, $q: String, $filter: DAfilterQueryType) {\n  dynamicAttribute(source: $source, q: $q, filter: $filter) {\n    data {\n      filter {\n        title\n        search {\n          searchable\n          placeholder\n          __typename\n        }\n        options {\n          name\n          key\n          icon\n          value\n          inputType\n          totalData\n          valMax\n          valMin\n          hexColor\n          child {\n            key\n            value\n            name\n            icon\n            inputType\n            totalData\n            child {\n              key\n              value\n              name\n              icon\n              inputType\n              totalData\n              child {\n                key\n                value\n                name\n                icon\n                inputType\n                totalData\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          isPopular\n          __typename\n        }\n        __typename\n      }\n      sort {\n        name\n        key\n        value\n        inputType\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "DynamicAttributes"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_ProductOtherQuery(self, host, **kwargs):
    query = "query ProductOtherQuery($productID: String!, $shopID: String!, $rows: Int, $start: Int) {\n  ProductOtherQuery(product_id: $productID, shop_id: $shopID, rows: $rows, start: $start) {\n    header {\n      total_data\n      process_time\n      __typename\n    }\n    data {\n      products {\n        id\n        name\n        url\n        image_url\n        image_url_700\n        price\n        shop {\n          id\n          name\n          url\n          is_gold\n          location\n          city\n          reputation\n          clover\n          __typename\n        }\n        wholesale_price {\n          quantity_min\n          quantity_max\n          price\n          __typename\n        }\n        condition\n        category_id\n        category_name\n        department_id\n        labels {\n          title\n          color\n          __typename\n        }\n        badges {\n          title\n          image_url\n          __typename\n        }\n        rating\n        original_price\n        count_review\n        wishlist\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "ProductOtherQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_ProductWishlistQuery(self, host, **kwargs):
    query = "query ProductWishlistQuery($productID: String!) {\n  ProductWishlistQuery(productID: $productID)\n}\n"
    sub_name = "ProductWishlistQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_OpenShopPopUp(self, host, **kwargs):
    query = "query OpenShopPopUp($userID: Int!) {\n  check_open_shop(userID: $userID) {\n    reserve_status\n    user_data {\n      shop_domain\n      reserve_time\n      shop_name\n      step\n      user_id\n      tag_line\n      short_desc\n      logo\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "OpenShopPopUp"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_PromoSliderQuery(self, host, **kwargs):
    query = "query PromoSliderQuery {\n  slides(device: 1) {\n    slides {\n      id\n      title\n      imageURL: image_url\n      url: redirect_url\n      promoCode: promo_code\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "PromoSliderQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_TokopointsTokenQuery(self, host, **kwargs):
    query = "query TokopointsTokenQuery {\n  tokopointsToken {\n    offFlag\n    tokenUnit\n    sum: sumToken\n    floating {\n      id: tokenId\n      url: pageUrl\n      timeRemaining: timeRemainingSeconds\n      isShowTime\n      tokenAsset {\n        imageURL: floatingImgUrl\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "TokopointsTokenQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_RechargeFavoriteNum(self, host, **kwargs):
    query = "mutation RechargeFavoriteNum($category_id: Int!, $operatorId: String!, $productId:String!, $clientNum:String!)  {\n  \n  recharge_favorite_number(categoryID: $category_id, operatorId :$operatorId, productId:$productId, clientNum: $clientNum) {\n    client_number\n    operator_id\n    product_id\n    category_id\n    list {\n      client_number\n      operator_id\n      product_id\n      category_id\n      label\n    }\n  }\n\n}"
    sub_name = "RechargeFavoriteNum"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_Carousel(self, host, **kwargs):
    query = "query Carousel {\n  slides {\n    data: slides {\n      id\n      title\n      imageUrl: image_url\n      redirectUrl: redirect_url\n      promoCode: promo_code\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "Carousel"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_SessionQuery(self, host, **kwargs):
    query = "query SessionQuery($source: String) {\n  user(source: $source) {\n    id\n    isLoggedIn\n    profilePicture\n    name\n    email\n    phone_verified\n    gender\n    bday\n    completion\n    createdPassword\n    registerDate\n    phone\n    phoneMasked\n    age\n    __typename\n  }\n  shop {\n    shop_id\n    shop_url\n    domain\n    shop_name\n    shop_name_unfmt\n    shop_name_clean\n    is_gold\n    is_official\n    location\n    logo\n    shop_badge\n    is_owner\n    reputation_badge\n    admin_id\n    __typename\n  }\n  address(default: true) {\n    error\n    addresses {\n      postal_code\n      district_name\n      city_name\n      province_name\n      country\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "SessionQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_dynamicChannel(self, host, **kwargs):
    query = "query DynamicChannel {\n  dynamicHomeChannel {\n    channels {\n      id\n      name\n      layout\n      type\n      header {\n        id\n        name\n        url\n        applink\n        expiredTime\n        backColor\n        backImage\n        __typename\n      }\n      hero {\n        id\n        name\n        url\n        applink\n        imageUrl\n        creativeName: attribution\n        __typename\n      }\n      grids {\n        id\n        name\n        url\n        applink\n        price\n        originalPrice: slashedPrice\n        soldPercentage\n        discount\n        imageUrl\n        label\n        creativeName: attribution\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "DynamicChannel"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_ticker(self, host, **kwargs):
    query = "query Ticker {\n  ticker {\n    meta {\n      total_data\n      __typename\n    }\n    tickers {\n      id\n      title\n      message\n      color\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "Ticker"
    response = request(self, host, query, sub_name, **kwargs)
    return response
    
def graphql_ProductInfoQuery(self, host, **kwargs):
    query = 'query ProductInfoQuery($shopDomain: String!, $productKey: String!, $lang: String = \"id\", $referrer: String) {\n  product: ProductInfoQuery(shop_domain: $shopDomain, product_key: $productKey, lang: $lang, referrer: $referrer) {\n    status\n    server_process_time\n    data {\n      info {\n        product_id\n        product_name\n        product_key\n        product_price\n        product_last_update\n        product_description\n        product_min_order_fmt\n        product_min_order\n        product_status\n        product_weight\n        product_weight_unit\n        product_condition\n        product_insurance\n        product_url\n        catalog_id\n        catalog_name\n        catalog_url\n        product_status_title\n        product_status_message\n        product_price_alert\n        product_etalase_id\n        product_etalase\n        product_etalase_url\n        product_returnable\n        return_info {\n          icon\n          color_hex\n          color_rgb\n          content\n          __typename\n        }\n        product_already_wishlist\n        product_installments {\n          id\n          name\n          icon\n          terms {\n            month_3 {\n              percentage\n              min_purchase\n              installment_price\n              __typename\n            }\n            month_6 {\n              percentage\n              min_purchase\n              installment_price\n              __typename\n            }\n            month_12 {\n              percentage\n              min_purchase\n              installment_price\n              __typename\n            }\n            month_18 {\n              percentage\n              min_purchase\n              installment_price\n              __typename\n            }\n            month_24 {\n              percentage\n              min_purchase\n              installment_price\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        installment_min_percentage\n        installment_min_price\n        wholesale_min_price\n        wholesale_min_quantity\n        has_variant\n        __typename\n      }\n      shop_info {\n        shop_owner_id\n        shop_id\n        shop_name\n        shop_url\n        shop_domain\n        shop_tagline\n        shop_description\n        shop_open_since\n        shop_reputation_badge\n        shop_min_badge_score\n        shop_status\n        shop_location\n        shop_avatar\n        shop_owner_last_login\n        shop_already_favorited\n        shop_total_favorit\n        shop_cover\n        shop_is_gold\n        shop_is_gold_badge\n        shop_lucky\n        shop_is_owner\n        shop_is_allow_manage\n        shop_has_terms\n        shop_is_closed_note\n        shop_is_closed_reason\n        shop_is_closed_until\n        shop_reputation\n        shop_status_title\n        shop_status_message\n        shop_gold_expired_time\n        shop_is_free_returns\n        shop_is_official\n        shop_official_top\n        shop_official_bot\n        badges {\n          title\n          image_url\n          __typename\n        }\n        shop_stats {\n          shop_badge_level {\n            level\n            set\n            __typename\n          }\n          shop_reputation_score\n          __typename\n        }\n        shop_shipments {\n          shipping_id\n          shipping_name\n          logo\n          package_names\n          __typename\n        }\n        __typename\n      }\n      rating {\n        product_accuracy_star_rate\n        product_accuracy_star_desc\n        product_netral_review_rate_accuracy\n        product_netral_review_rating\n        product_positive_review_rate_accuracy\n        product_positive_review_rating\n        product_negative_review_rate_accuracy\n        product_negative_review_rating\n        product_rate_accuracy\n        product_rate_accuracy_point\n        product_rating\n        product_rating_point\n        product_rating_star_point\n        product_rating_star_desc\n        product_review\n        product_rating_list {\n          rating_rating_star_point\n          rating_total_rate_accuracy_persen\n          rating_rate_service\n          rating_rating_star_desc\n          rating_rating_fmt\n          rating_total_rating_persen\n          rating_url_filter_rate_accuracy\n          rating_rating\n          rating_url_filter_rating\n          rating_rate_speed\n          rating_rate_accuracy\n          rating_rate_accuracy_fmt\n          rating_rating_point\n          __typename\n        }\n        __typename\n      }\n      preorder {\n        preorder_status\n        preorder_process_time_type\n        preorder_process_time_type_string\n        preorder_process_time\n        __typename\n      }\n      statistic {\n        product_sold_count\n        product_transaction_count\n        product_rating_point\n        product_cancel_rate\n        product_review_count\n        product_view_count\n        product_success_rate\n        product_success_rate\n        product_rating_desc\n        product_talk_count\n        __typename\n      }\n      wholesale_price {\n        wholesale_min\n        wholesale_max\n        wholesale_price\n        __typename\n      }\n      breadcrumb {\n        department_name\n        department_identifier\n        department_dir_view\n        department_id\n        department_tree\n        __typename\n      }\n      product_images {\n        image_id\n        image_src_300\n        image_status\n        image_description\n        image_primary\n        image_src\n        __typename\n      }\n      cashback {\n        product_cashback\n        product_cashback_value\n        __typename\n      }\n      campaign {\n        apps_only\n        applinks\n        is_active\n        campaign_type_name\n        original_price\n        original_price_fmt\n        discounted_percentage\n        discounted_price\n        discounted_price_fmt\n        campaign_type\n        start_date\n        end_date\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n'
    sub_name = 'ProductInfoQuery'
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_ProductTopChatQuery(self, host, **kwargs):
    query = 'query ProductTopchatQuery($toShopId: Int) {\n  existingChat: chatExistingChat(toShopId: $toShopId, source: \"pdp\") {\n    messageId\n    contact {\n      id\n      role\n      attributes {\n        name\n        domain\n        thumbnail\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n'
    sub_name = 'ProductTopChatQuery'
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_ProductVariantQuery(self, host, **kwargs):
    query = 'query ProductVariantQuery($productID: Int!, $lang: String!) {\n  ProductVariantQuery(productID: $productID, lang: $lang) {\n    status\n    data {\n      parent_id\n      default_child\n      variant {\n        name\n        identifier\n        unit_name\n        position\n        option {\n          id\n          value\n          hex\n          __typename\n        }\n        __typename\n      }\n      children {\n        name\n        url\n        product_id\n        price\n        price_fmt\n        stock\n        sku\n        option_ids\n        enabled\n        picture {\n          original\n          thumbnail\n          __typename\n        }\n        is_buyable\n        is_wishlist\n        campaign {\n          is_active\n          campaign_type_name\n          discounted_percentage\n          discounted_price\n          discounted_price_fmt\n          campaign_type\n          start_date\n          end_date\n          __typename\n        }\n        always_available\n        stock_wording\n        other_variant_stock\n        is_limited_stock\n        __typename\n      }\n      __typename\n    }\n    server_process_time\n    __typename\n  }\n}\n'
    sub_name = "ProductVariantQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response
    
def graphql_checkout(self, host, **kwargs):
    query = "mutation checkout($carts: String!) {\n  checkout_cart(carts: $carts) {\n    success\n    error\n    message\n    data {\n      product_list {\n        id\n        price\n        quantity\n        name\n        __typename\n      }\n      redirect_url\n      callback_url\n      parameter {\n        merchant_code\n        profile_code\n        customer_id\n        customer_name\n        customer_email\n        customer_msisdn\n        transaction_id\n        transaction_date\n        gateway_code\n        pid\n        nid\n        user_defined_value\n        amount\n        currency\n        language\n        signature\n        device_info {\n          device_time\n          device_version\n          __typename\n        }\n        payment_metadata\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}"
    sub_name = "checkout"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_CatalogListGoQuery(self, host, **kwargs):
    query = "query CatalogListGoQuery($categoryID: Int, $pointRange: Int, $page: Int, $limit: Int, $sortID: Int) {\n  catalog: tokopointsCatalogList(input: {categoryID: $categoryID, pointRange: $pointRange, page: $page, limit: $limit, sortID: $sortID}) {\n    catalogs: catalogList {\n      id\n      promoID\n      catalogType\n      expired\n      points\n      pointsStr\n      pointsSlash\n      pointsSlashStr\n      discountPercentageStr\n      quota\n      title\n      subtitle\n      thumbnailURL\n      thumbnailURLMobile\n      imageURL\n      imageUrlMobile\n      baseCode\n      slug\n      isGift\n      expiredLabel\n      expiredStr\n      isDisabled\n      isDisabledButton\n      disableErrorMessage\n      upperTextDesc\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "CatalogListGoQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_redeemCoupon(self, host, **kwargs):
    query = "mutation redeemCoupon($catalog_id: Int, $is_gift: Int, $gift_user_id: Int, $gift_email: String, $notes: String) {\n  hachikoRedeem(catalog_id: $catalog_id, is_gift: $is_gift, gift_user_id: $gift_user_id, gift_email: $gift_email, notes: $notes) {\n    coupons {\n      id\n      owner\n      promo_id\n      code\n      title\n      description\n      cta\n      cta_desktop\n      __typename\n    }\n    reward_points\n    __typename\n  }\n}"
    sub_name = "redeemCoupon"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_validateRedeem(self, host, **kwargs):
    query = "mutation validateRedeem($catalog_id: Int, $is_gift: Int, $gift_user_id: Int, $gift_email: String) {\n  hachikoValidateRedeem(catalog_id: $catalog_id, is_gift: $is_gift, gift_user_id: $gift_user_id, gift_email: $gift_email) {\n    is_valid\n    message_success\n    message_title\n    __typename\n  }\n}"
    sub_name = "validateRedeem"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_sessionQuery(self, host, **kwargs):
    query = "query SessionQuery($source: String) {\n  user(source: $source) {\n    id\n    isLoggedIn\n    profilePicture\n    name\n    email\n    phone_verified\n    gender\n    bday\n    completion\n    createdPassword\n    registerDate\n    phone\n    phoneMasked\n    age\n    __typename\n  }\n  shop {\n    shop_id\n    shop_url\n    domain\n    shop_name\n    shop_name_unfmt\n    shop_name_clean\n    is_gold\n    is_official\n    location\n    logo\n    shop_badge\n    is_owner\n    reputation_badge\n    admin_id\n    __typename\n  }\n  address(default: true) {\n    error\n    addresses {\n      postal_code\n      district_name\n      city_name\n      province_name\n      country\n      __typename\n    }\n    __typename\n  }\n}"
    sub_name = "sessionQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_tokopointsCarouselQuery(self, host, **kwargs):
    query = "query TokopointsCarouselQuery {\n  slides(device: 256) {\n    meta {\n      total_data\n      __typename\n    }\n    slides {\n      id\n      title\n      imageUrl: image_url\n      redirectUrl: redirect_url\n      promoCode: promo_code\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "tokopointsCarouselQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_hachikoCatalogDetailQuery(self, host, **kwargs):
    query = "query hachikoCatalogDetailQuery($slug: String, $catalog_id: Int) {\n  detail: hachikoCatalogDetail(slug: $slug, catalog_id: $catalog_id) {\n    id\n    catalog_type\n    expired\n    expired_label\n    expired_str\n    is_disabled\n    is_disabled_button\n    disable_error_message\n    points\n    points_slash\n    points_str\n    points_slash_str\n    discount_percentage_str\n    button_str\n    title\n    sub_title\n    thumbnail_url\n    thumbnail_url_mobile\n    image_url\n    image_url_mobile\n    overview\n    quota\n    is_gift\n    how_to_use\n    tnc\n    cta\n    upper_text_desc\n    __typename\n  }\n}\n"
    sub_name = "hachikoCatalogDetailQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_HomeTabsGoQuery(self, host, **kwargs):
    query = "query HomeTabsGoQuery($categoryID: Int, $pointRange: Int, $page: Int, $limit: Int, $sortID: Int) {\n  catalog: tokopointsCatalogList(input: {categoryID: $categoryID, pointRange: $pointRange, page: $page, limit: $limit, sortID: $sortID}) {\n    catalogs: catalogList {\n      id\n      promoID\n      catalogType\n      expired\n      points\n      pointsStr\n      pointsSlash\n      pointsSlashStr\n      discountPercentageStr\n      quota\n      title\n      subtitle\n      thumbnailURL\n      thumbnailURLMobile\n      imageURL\n      imageUrlMobile\n      baseCode\n      slug\n      isGift\n      expiredLabel\n      expiredStr\n      isDisabled\n      isDisabledButton\n      disableErrorMessage\n      upperTextDesc\n      __typename\n    }\n    __typename\n  }\n  myCoupons: tokopointsCouponList(input: {serviceID: \"\", categoryID: 0, categoryIDCoupon: 0, page: 1, limit: 10, includeExtraInfo: 1}) {\n    coupons: tokopointsCouponData {\n      catalogID: id\n      promoID\n      code\n      expired\n      title\n      catalogTitle\n      subTitle\n      catalogSubTitle\n      description\n      icon\n      imageUrl\n      imageUrlMobile\n      thumbnailUrl\n      thumbnailUrlMobile\n      imageV2Url\n      imageV2UrlMobile\n      thumbnailV2Url\n      thumbnailV2UrlMobile\n      cta\n      ctaDesktop\n      slug\n      usage {\n        activeCountdown\n        expiredCountdown\n        text\n        usageStr\n        buttonUsage {\n          text\n          url\n          appLink\n          type\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    tokopointsExtraInfo {\n      infoHTML\n      linkText\n      linkUrl\n      __typename\n    }\n    __typename\n  }\n}\n"
    sub_name = "HomeTabsGoQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_ProfileQuery(self, host, **kwargs):
    query = "{\n\tprofile {\n\t\tuser_id\n\t}\n}"
    sub_name = "ProfileQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response
    
def graphql_CatalogStatusGoQuery(self, host, **kwargs):
    query = "query CatalogStatusGoQuery($catalogIDs: [Int]) {\n  tokopointsCatalogStatus(input: {catalogIDs: $catalogIDs}) {\n    catalogStatus {\n      catalogID\n      quota\n      upperTextDesc\n      isDisabled\n      isDisabledButton\n      __typename\n    }\n    __typename\n  }\n}"
    sub_name = "CatalogStatusGoQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_MyCouponsListGoQuery(self, host, **kwargs):
    query = 'query MyCouponsListGoQuery($categoryIDCoupon: Int, $page: Int, $limit: Int, $includeExtraInfo: Int) {\n  myCoupons: tokopointsCouponList(input: {serviceID: "", categoryID: 0, categoryIDCoupon: $categoryIDCoupon, page: $page, limit: $limit, includeExtraInfo: $includeExtraInfo}) {\n    coupons: tokopointsCouponData {\n      catalogID: id\n      promoID\n      code\n      expired\n      title\n      catalogTitle\n      subTitle\n      catalogSubTitle\n      description\n      icon\n      imageUrl\n      imageUrlMobile\n      thumbnailUrl\n      thumbnailUrlMobile\n      imageV2Url\n      imageV2UrlMobile\n      thumbnailV2Url\n      thumbnailV2UrlMobile\n      cta\n      ctaDesktop\n      slug\n      usage {\n        activeCountdown\n        expiredCountdown\n        text\n        usageStr\n        buttonUsage {\n          text\n          url\n          appLink\n          type\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    tokopointsPaging {\n      hasNext\n      __typename\n    }\n    tokopointsExtraInfo {\n      infoHTML\n      linkText\n      linkUrl\n      __typename\n    }\n    __typename\n  }\n}'
    sub_name = "MyCouponsListGoQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_CrackEgg(self, host, **kwargs):
    query = "mutation {\n  crackResult(tokenUserID: 0, campaignID:1037) {\n    resultStatus {\n      code\n      message\n      status\n    }\n    imageUrl\n    benefitType\n    benefits {\n      text\n      color\n      size\n    }\n    ctaButton {\n      title\n      url\n      applink\n      type\n    }\n    returnButton {\n      title\n      url\n      applink\n      type\n    }\n  }\n}"
    sub_name = "CrackEgg"
    response = request(self, host, query, sub_name, **kwargs)
    return response
    
def graphql_TokenUser(self, host, **kwargs):
    query = "{\n  tokopointsToken {\n    resultStatus {\n        code\n        status\n        message\n   }\n    offFlag\n    sumToken\n    sumTokenStr\n    tokenUnit\n    floating {\n      tokenId\n      pageUrl\n      applink\n      timeRemainingSeconds\n      isShowTime\n      unixTimestamp\n      tokenAsset {\n        name\n        version\n        floatingImgUrl\n      }\n      tokenClaimCustomText\n      tokenClaimText\n      countingMessage\n    }\n    home {\n         emptyState{\n            title\n            buttonText\n            buttonURL\n            buttonApplink\n            backgroundImgUrl\n            imageUrl\n            version\n        }\n      countingMessage\n      tokensUser {\n        tokenUserID\n        campaignID\n        title\n        unixTimestampFetch\n        timeRemainingSeconds\n        isShowTime\n        backgroundAsset {\n          name\n          version\n          backgroundImgUrl\n        }\n        tokenAsset {\n          name\n          version\n          floatingImgUrl\n          smallImgUrl\n          spriteUrl\n          imageUrls\n        }\n      }\n    }\n  } \n}"
    sub_name = "TokenUser"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_hachikoCouponDetailQuery(self, host, **kwargs):
    query = "query hachikoCouponDetailQuery($code: String) {\n  detail: hachikoCouponDetail(code: $code) {\n    id\n    expired\n    real_code\n    points\n    title\n    minimum_usage\n    sub_title\n    image_url\n    image_url_mobile\n    thumbnail_url\n    thumbnail_url_mobile\n    overview\n    is_gift\n    how_to_use\n    tnc\n    cta\n    cta_desktop\n    usage {\n      active_count_down\n      expired_count_down\n      text\n      usage_str\n      btn_usage {\n        text\n        url\n        applink\n        type\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}"
    sub_name = "hachikoCouponDetailQuery"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_CartCoupon(self, host, **kwargs):
    query = "query CartCoupon($page: Int!) {\n  cart_coupon_list(page: $page) {\n    error_message\n    data {\n      total_data\n      has_next\n      coupons {\n        coupon_id\n        promo_id\n        code\n        expired\n        title\n        sub_title\n        description\n        icon\n        image_url\n        image_url_mobile\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}"
    sub_name = "CartCoupon"
    response = request(self, host, query, sub_name, **kwargs)
    return response

def graphql_tokopointsHadiahPage(self, host, **kwargs):
    query = "{profile {\n    user_id\n  }\n  tokopointsToken {\n    offFlag\n    sumToken\n    sumTokenStr\n    tokenUnit\n    home {\n      countingMessage\n      emptyState {\n        title\n        buttonText\n        buttonURL\n        buttonApplink\n      }\n      tokensUser {\n        tokenUserID\n        campaignID\n        title\n        unixTimestampFetch\n        timeRemainingSeconds\n        isShowTime\n        backgroundAsset {\n          name\n          version\n          backgroundImgUrl\n        }\n        tokenAsset {\n          name\n          version\n          floatingImgUrl\n          smallImgUrl\n          spriteUrl\n        }\n      }\n    }\n  }\n}"
    sub_name = "TokopointsHadiahPage"
    response = request(self, host, query, sub_name, **kwargs)
    return response