from libs import bearer_token, tkpdhmac, ht

host_production = "https://ws.tokopedia.com"
host_staging    = "https://ws-staging.tokopedia.com"

# Purpose : Do Login, bearer automatically called
# Session : Not Required, may require `Authorization` header for session
# Required Parameter : self, host
# Optional Parameter : headers, name, bodies
def session_makeLogin_pl_v4(self, host, **kwargs):
    path = "/v4/session/make_login.pl"
    default = {
        "method":"POST",
        "bodies":{
            'user_id':'5480842',
            'device_id':'b',
            'os_type':'1'
        }
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : get the amount of saldo user
# Required Params: host, user_id, device_id
# Optional Params: headers, query(os_type, device_id, user_id), name
# Session: need login, need hmac tokopedia for authorization
def deposit_getDeposit_pl_v4(self, host, user_id,device_id, **kwargs):
    path = '/v4/deposit/get_deposit.pl'
    default = {
        "method":"GET",
        "query":"os_type=1&device_id=b&user_id=5480842"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose: get list of favourited get_favorite_shop
# Required Params: host, user_id, device_id
# Optional Params: headers, bodies(device_id,per_page, os_type, page, user_id)
# Session: need login, need hmac tokopedia for authorization
def home_getFavoriteShop_pl_v4(self, host, user_id, device_id, **kwargs):
    path = '/v4/home/get_favorite_shop.pl'
    default = {
        "method":"POST",
        "bodies":{
            'device_id': 'b',
            'per_page': 20,
            'os_type': 1,
            'page': 1,
            'user_id': user_id
        }
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : get numbers of all notification
# Required Params: host, user_id, device_id
# Optional Params: headers, query(os_type, device_id, user_id), name
# Session: need login, need hmac tokopedia for authorization
def notification_getNotification_pl_v4(self, host, user_id,device_id, **kwargs):
    path = '/v4/notification/get_notification.pl'
    default = {
        "method":"GET",
        "query":"os_type=1&device_id=b&user_id=5480842"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response


# Purpose : get list of hotlist
# Required Params: host, user_id(can be empty string), device_id
# Optional Params: headers, query, name
# Session: need hmac tokopedia
def hotlist_getHotlist_pl_v4(self, host, user_id, device_id, **kwargs):
    path = '/v4/hotlist/get_hotlist.pl'
    default = {
        "method":"GET",
        "query":'per_page=30&query=&page=1&os_type=1&device_id='+device_id+'&user_id='+user_id
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : get a hotlist banner
# Required Params: self, host, user_id(can be empty string), device_id
# Optional Params: method, headers, query, name
# Session: before login
# Description: need tokopedia hmac
def hotlist_getHotlistBanner_pl_v4(self, host, user_id, device_id, **kwargs):
    path = '/v4/hotlist/get_hotlist_banner.pl'
    default = {
        "method":"GET",
        "query":'key=semua-serba-cetaphil'
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : get detail of product
# Required params : host, product_id, user_id, device_id
# Optional Params : method, headers, query, name
# Session : no login, need hmac
def product_getDetail_v4(self, host, product_id, user_id, device_id, **kwargs):
    path = '/v4/product/get_detail.pl'
    default = {
        "method":"GET",
        "query":'product_id='+product_id+'&device_id='+device_id+'&product_key=&os_type=1&shop_domain=&user_id='
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : check a voucher code whether the code can be used or not
# Required params : host, user_id, device_id
# Optional Params : method, headers, query, name
# Session : login, need hmac and bearer, for bodies need hash and device time
def txVoucher_checkVoucherCode_pl_v4(self, host, user_id, device_id, **kwargs):
    path = "/v4/tx-voucher/check_voucher_code.pl"
    default = {
        "method":"POST"
    }

    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : check buy before add to cart
# Required params : host, user_id, device_id
# Optional Params : method, headers, bodies
# Session : login, need hmac and bearer, for bodies need hash and device time
def action_txCart_add_to_cart_v4(self, host, user_id, device_id, **kwargs):
    path = '/v4/action/tx-cart/add_to_cart.pl'
    default = {
        "method":"POST",
        "bodies":{
            'address_street': 'Kl. Kemanggisan Utama',
            'product_id': '41747247',
            'address_province':'13',
            'insurance':0,
            'os_type':1,
            'address_postal_code':'11410',
            'shipping_id':1,
            'quantity': 1,
            'address_name':'Default Address',
            'shipping_product':1,
            'receiver_phone':'123456',
            'notes': '',
            'receiver_name': 'PRIME AUTOMATION',
            'address_city':'174',
            'address_id': '10930792',
            'user_id':'10930792',
            'device_id':'b'
        }
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies', default['bodies']))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def tx_pl_v4(self, host, user_id, device_id, **kwargs):
    path = '/v4/tx.pl'
    default = {
        "method":"POST"
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies', {}))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def action_txCart_cancel_cart_pl(self, host, user_id, device_id, **kwargs):
    path = '/v4/action/tx-cart/cancel_cart.pl'
    default = {
        "method":"POST"
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies', {}))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def txCart_get_add_to_cart_form_pl_v4(self, host, user_id, device_id, **kwargs):
    path = '/v4/tx-cart/get_add_to_cart_form.pl'
    default = {
        "method":"POST"
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies', {}))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def action_people_add_address_pl_v4(self, host, user_id, device_id, **kwargs):
    path = '/v4/action/people/add_address.pl'
    default = {
        "method":"POST"
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies', {}))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def txCart_calculate_cart_pl_v4(self, host, user_id, device_id, **kwargs):
    path = '/v4/tx-cart/calculate_cart.pl'
    default = {
        "method":"POST"
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies', {}))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response
    
def shop_getShopInfo_pl_v4(self, host, user_id, device_id, **kwargs):
    path = "/v4/shop/get_shop_info.pl"
    default = {
        "method":"POST"
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies', {}))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def shop_getShopEtalase_pl_v4(self, host, user_id, device_id, **kwargs):
    path = "/v4/shop/get_shop_etalase.pl"
    default = {
        "method":"GET"

    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query', {}))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def ssi_shopStatic_P_apps_top(self, host, shop_domain, user_id, device_id, **kwargs):
    path = "/ssi/shop-static/"+shop_domain+"/_apps/top"
    default = {
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query', {}))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response