from libs import tkpdhmac, bearer_token, ht

host_production = "https://sauron.tokopedia.com"
host_staging    = "https://sauron-staging.tokopedia.com"

# Purpose :
# Session : session or no session is applicable, add cookies if session needed
# Required Parameters : self, host, user_id
# Optional Parameters : method, query, name, headers
def orders_invalid_v1(self, host, user_id, **kwargs):
    path = "/orders/invalid/v1"
    default = {
        "query":"page=1&limit=5&since=1517009466&until=1522279866&filters=status%3D%3D1&sort=first_case",
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_sauron_token(kwargs.get('method', default['method']), path, user_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose :
# Session : session or no session is applicable, add cookies if session needed
# Required Parameters : self, host, user_id
# Optional Parameters : method, query, name, headers
def api_promo_v1_validation(self, host, user_id, device_id, **kwargs):
    path = "/promo/v1/validation"
    default = {
        "method":"POST"
    }
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_sauron_token(kwargs.get('method', default['method']), path, user_id, kwargs.get('headers', {}), kwargs.get('json'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response
