from libs import ht, tkpdhmac

host_production = "https://kero.tokopedia.com"
host_staging    = "https://kero-staging.tokopedia.com"


def rates_v1(self, host, device_id, user_id, **kwargs):
    path = '/rates/v1'
    default = {
        "method":"GET"
    }
    token, device_time = tkpdhmac.generate_kero_token(kwargs.get('method', default['method']), path)
    kwargs['query'] = "%s&token=%s&ut=%s" %(kwargs['query'] , token, device_time)
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_kero(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def tracking_v1(self, host, device_id, user_id, kurir_awb, **kwargs):
    path = '/tracking/v1'+ kurir_awb
    default = {
        "method":"GET"        
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def getDistrictDetails_v2(self, host, device_id, user_id, **kwargs):
    path = "/v2/get-district-details"
    default = {
        "method":"GET"
    }
    token, device_time = tkpdhmac.generate_kero_token(kwargs.get('method', default['method']), path)
    kwargs['query'] = "%s&token=%s&ut=%s" %(kwargs['query'] , token, device_time)
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_kero(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response
