from libs import tkpdhmac, ht

host_production = "https://mojito.tokopedia.com"
host_staging    = "https://mojito-staging.tokopedia.com"

# Purpose : to get tickers
# Session : session or no session is applicable, add cookies if session needed
# Required Parameters : self, host, user_id
# Optional Parameters : method, query, name, headers
def api_tickers_v1(self, host, **kwargs):
    path = "/api/v1/tickers"
    default = {
        "query":"page[size]=50&filter[device]=desktop&action=data_source_ticker"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to get slides
# Session : session or no session is applicable. for GET method, add cookies if session needed
# Required Parameters : self, host
# Optional Parameters : method, query, name, headers
def api_slides_v1(self, host, **kwargs):
    path = '/api/v1/slides'
    default = {
        "query":"page[size]=25&filter[device]=1&filter[state]=1&filter[expired]=0"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to get brand list
# Session : session or no session is applicable, add cookies if session needed
# Required Parameters : self, host, platform (android/desktop)
# Optional Parameters : method, name, headers
# In android, fill query with this: path     = '/os/api/v2/brands/list/widget/android'
def os_api_brands_list_widget_P_v2(self, host, platform, **kwargs):
    path = '/os/api/v2/brands/list/widget/%s' % (platform)
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to get users wishlist in desktop, session required
# Session : session and tkpdhmac required
# Required Parameters : self, host, user_id, device_id, product_ids
# Optional Parameters : method, headers, bodies
def users_P_wishlist_check_P_v2(self, host, user_id, device_id, product_ids, **kwargs):
    path = "/users/%s/wishlist/check/%s/v2" % (user_id, product_ids)
    default = {
        "headers":{
            "Content-Type":"application/json"
        },
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_mojito(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to get category list in android
# Session : session required
# Required Parameters : self, host
# Optional Parameters : method, name, headers
def layout_category_v1_3(self, host, **kwargs):
    path = "/api/v1.3/layout/category"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to see last viewed products
# Session : session  and tkpdhmac required
# Required Parameters : self, host, user_id, device_id
# Optional Parameters : method, name, headers, bodies
def users_P_recentview_products_v1(self, host, user_id, device_id, **kwargs):
    path = "/users/%s/recentview/products/v1" % (user_id)
    default = {
        "headers":{
            "X-User-ID" : user_id,
            "Content-Type" : "application/json"
        },
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_mojito(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to see product in wishlist
# Session : session  and tkpdhmac required
# Required Parameters : self, host, user_id, device_id
# Optional Parameters : method, name, headers, bodies
def users_P_wishlist_products_v1_0_3(self, host, user_id, device_id, **kwargs):
    path = "/v1.0.3/users/%s/wishlist/products" % (user_id)
    default = {
        "headers":{
            "X-User-ID" : user_id,
            "Content-Type" : "application/json"
        },
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_mojito(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to check whether a product is in wishlist or not
# Session : require bearer authorization
# Required Parameters : self, host, user_id, product_id
# Optional Parameters : method, name, headers
def users_P_wishlist_check_P_v1(self, host, user_id, product_id, **kwargs):
    path = "/v1/users/"+user_id+"/wishlist/check/"+product_id
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to get product detail based campaign
# Session : session not required
# Required Parameters : self, host, product_id
# Optional Parameters : method, name, headers, query
def os_campaign_productDetail_v1(self, host, **kwargs):
    path = "/os/v1/campaign/product_detail"
    default = {
        "query":"id=177749132"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : erlangga krisnamukti
#session        : -
#purpose        : check for shop list (staging)
#required param : host
#optional param : method, query, headers
def os_api_search_banner_default_v3(self, host, **kwargs):
    path = "/os/api/search/banner/default_v3"
    default = {
        "query":"keywords=baju"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#purpose        : get banner for search product page
#session        : -
#required param : self, host, platform
#optional param : method, query, headers, name
def os_api_search_banner_P(self, host, platform, **kwargs):
    path = "/os/api/search/banner/"+platform
    default = {
        "query":"keywords=skin%20cleanser"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to see products in official store promo
# Session : session or no session is applicable
# Required Parameters : self, host, user_id, device_id
# Optional Parameters : method, name, headers, bodies
def os_api_ospromo_topcontent_P_v1(self, host, promoslug ,**kwargs):
    path = "/os/api/v1/ospromo/topcontent/"+promoslug
    response = ht.call(self, host, path, **kwargs)
    return response

def os_api_ospromo_categories_v1(self, host, **kwargs):
    path = "/os/api/v1/ospromo/categories"
    
    response = ht.call(self, host, path, **kwargs)
    return response

def os_api_category_levelzero_v2(self, host, **kwargs):
    path = "/os/api/v2/category/levelzero"
    response = ht.call(self, host, path, **kwargs)
    return response

def os_api_brands_microsite_banners_v1(self, host, **kwargs):
    path = "/os/api/v1/brands/microsite/banners"
    response = ht.call(self, host, path, **kwargs)
    return response

def os_api_brands_list_widget_desktop_v3(self, host, **kwargs):
    path = "/os/api/v3/brands/list/widget/desktop"
    response = ht.call(self, host, path, **kwargs)
    return response

def os_api_brands_list_widget_mobile_v3(self, host, **kwargs):
    path = "/os/api/v3/brands/list/widget/mobile"
    response = ht.call(self, host, path, **kwargs)
    return response

def os_api_brands_list_widget_android_v3(self, host, **kwargs):
    path = "/os/api/v3/brands/list/widget/android"
    response = ht.call(self, host, path, **kwargs)
    return response

def os_api_brands_list_widget_ios_v3(self, host, **kwargs):
    path = "/os/api/v3/brands/list/widget/ios"
    response = ht.call(self, host, path, **kwargs)
    return response

def os_api_brands_microsite_flashsale_v1(self, host, **kwargs):
    path = "/os/api/v1/brands/microsite/flashsale"
    response = ht.call(self, host, path, **kwargs)
    return response

def os_api_brands_category_P_P_v1(self, host, platform, category_id, **kwargs):
    path = "/os/api/v1/brands/category/%s/%s" % (platform, category_id)
    response = ht.call(self, host, path, **kwargs)
    return response

def users_P_wishlist_P_v1_1(self, host, user_id, device_id, product_ids, **kwargs):
    path = "/users/%s/wishlist/%s/v1.1" % (user_id, product_ids)
    default = {
        "method":"POST"
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate_mojito(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response
#creator        : angelia agustina
#session        : -
#purpose        : (grpc) get campaign info
#required param : host, campaign_id (if 0 then it'll return current active flash sale)
#add. param     : device_id (if none, it'll return all banners)
def grpc_campaign_info(self, host, **kwargs):
    path = "/campaign/check/grpc/campaign"
    response = ht.call(self, host, path, **kwargs)
    return response

#creator        : angelia agustina
#session        : -
#purpose        : (grpc) get product id from campaign
#required param : host, campaign_id (if 0 then it'll return current active flash sale)
def grpc_campaign_products(self, host, **kwargs):
    path = "/campaign/check/grpc/campaign/products"
    response = ht.call(self, host, path, **kwargs)
    return response
    
#purpose        : get campaign product's info
#param          : pid
def os_campaign_product_info_v1(self, host, **kwargs):
    path = "/os/v1/campaign/product/info"
    response = ht.call(self, host, path, **kwargs)
    return response

def campaign_product_search(self, host, **kwargs):
    path = "/campaign/search/product_campaign/v1"
    response = ht.call(self, host, path, **kwargs)
    return response

def api_channel_v1(self, host, **kwargs):
    path = "/api/v1/channel"
    response = ht.call(self, host, path, **kwargs)
    return response
    
def os_api_brands_isofficial_P_v1(self,shop_id, host, **kwargs):
    path = "/os/api/v1/brands/isofficial/"+shop_id
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def os_api_commission_calculation_v1(self, host, **kwargs):
    path = "/os/api/v1/commission/calculation"
    default = {
        "method":"POST"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def os_api_commission_refund_v1(self, host, **kwargs):
    path = "/os/api/v1/commission/refund"
    default = {
        "method":"POST"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def os_api_customLogistics_rates_P_P_v1(self,shop_id_os_logistik, destination_id, host, **kwargs):
    path = "/os/api/v1/customlogistics/rates/"+shop_id_os_logistik+"/"+destination_id
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def os_api_paymentLimitValidate_v1(self, host, **kwargs):
    path = "/os/api/v1/payment/limit-level/validate"
    default = {
        "method":"POST"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response


def inventory_fs_P_stock_update_v1(self, fs_id, shop_id_fs, host, **kwargs):
    path = "/inventory/v1/fs/"+fs_id+"/stock/update?shop_id="+shop_id_fs
    default = {
        "method":"POST"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def api_home_v1(self, host, **kwargs):
    path = "/api/v1/home"
    response = ht.call(self, host, path, **kwargs)
    return response
def wishlist_count_v1(self, host, **kwargs):
    path = "/wishlist/count/v1"
    response = ht.call(self, host, path, **kwargs)
    return response
