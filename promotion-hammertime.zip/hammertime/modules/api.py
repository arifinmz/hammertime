from libs import ht

host_production = "https://api.tokopedia.com"
host_staging    = "https://api-staging.tokopedia.com"

#creator        : Dwi Aprian Widodo
#module         : resolution
#session        : Session (require cookie)
#purpose        : get inbox resolution buyer
def resolution_inbox_buyer_v2(self, host, **kwargs):
    path = "/resolution/v2/inbox/buyer"
    default = {
        "query":"limit=10"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def microsites_finalist_v1(self, host, **kwargs):
    path     = "/microsites/v1/finalist"
    response = ht.call(self, host, path, **kwargs)
    return response

def microsites_grammy_v1(self, host, **kwargs):
    path = "/microsites/v1/grammy"
    response = ht.call(self, host, path, **kwargs)
    return response
