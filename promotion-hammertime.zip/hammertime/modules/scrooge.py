from libs import ht
from bs4 import BeautifulSoup

host_production = "https://pay.tokopedia.com"
host_staging    = "https://pay-staging.tokopedia.com"

def payment_v2(self, host, **kwargs):
    path = '/v2/payment'
    default = {
        'method': 'POST'
    }
    return ht.call(self, host, path, default=default, **kwargs)

def get_value_from_selector(self, htmlcontent, attribute_selector, attribute_name):
    soup = BeautifulSoup(htmlcontent, "html.parser")
    result = soup.find(attrs={attribute_selector: attribute_name})
    return str(result.get('value'))

def get_values_from_selector(self, htmlcontent, attribute_selector, attribute_name):
    attributes = []
    soup = BeautifulSoup(htmlcontent, "html.parser")
    for x in attribute_name:
        result = soup.find(attrs={attribute_selector: x})
        attributes.append(str(result.get('value')))
    return attributes

def payment_confirm_P_v2(self, host, **kwargs):
    path = '/v2/payment/confirm/TOKOPEDIAWALLET'
    default = {
        'method': 'POST'
    }
    return ht.call(self, host, path, default=default, **kwargs)

def payment_thanks_P_v2(self, host, gateway_code, **kwargs):
    path = '/v2/payment/thanks/' + gateway_code
    default = {
        'method': 'POST'
    }
    return ht.call(self, host, path, default=default, **kwargs)

