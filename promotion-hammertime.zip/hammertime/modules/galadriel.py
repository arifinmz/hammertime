from libs import tkpdhmac, ht

host_production = "https://galadriel.tokopedia.com"
host_staging    = "https://galadriel-staging.tokopedia.com"

def promoSuggestion_widget_v1(self, host, **kwargs):
    path     = "/promo-suggestions/v1/widget"
    default = {
        "query":"placeholder=pdp_widget&target_type=guest&device_type=android&lang=id&user_id="
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def validate_use(self, host, **kwargs):
    path = "/promo_codes/validate/use"
    default = {
        "method": "POST"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def auto_apply(self, host, **kwargs):
    path = "/v2/promo-suggestions"
    default = {
        "method": "POST"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def validate_payment(self, host, **kwargs):
    path = "/promo_codes/validate/payment"
    default = {
        "method": "POST"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def notify_success(self, host, **kwargs):
    path = "/promo_codes/notify/success"
    default = {
        "method": "POST"
    }
    return ht.call(self, host, path, default=default, **kwargs)
