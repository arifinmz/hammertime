from libs import ht

host_production = "https://payment.tokopedia.com"
host_staging    = "https://payment-staging.tokopedia.com"

def action_tx_toppay_get_parameter_v4(self, host, **kwargs):
    path = '/v4/action/tx/toppay_get_paramater.pl'
    default = {
        'method': 'POST'
    }
    return ht.call(self, host, path, default=default, **kwargs)

def get_parameter(self, host, **kwargs):
    path = '/get_parameter'
    default = {
        'method': 'POST'
    }
    return ht.call(self, host, path, default=default, **kwargs)