from libs import tkpdhmac, ht
import string
from random import randint

host_production = "https://api.tokopedia.com"
host_staging    = "https://api-staging.tokopedia.com"

# Purpose: to get feeds for desktop platform
# Session: session required

def feeds_P(self, host, user_id, device_id, platform, **kwargs):
    path = "/feeds/feeds/"+user_id
    default = {
        "query":"source=&cursor=",
        "method":"GET"
    }
    if platform == 'android' or platform == 'ios':
        kwargs['headers'], kwargs['query'] = tkpdhmac.generate_spike(kwargs.get('method', default['method']), '/v1/feeds/'+user_id, user_id, device_id, platform, kwargs.get('headers'), kwargs.get('query'))
    
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def fees_activity_P(self, host, activity_id, **kwargs):
    path = "/feeds/activity/"+activity_id

    response = ht.call(self, host, path, **kwargs)
    return response