from libs import ht, tkpdhmac

host_production = "https://points.tokopedia.com"
host_staging    = "https://points-staging.tokopedia.com"

def app_v4(self, host, user_id, device_id, **kwargs):
    path = '/app/v4'
    default = {
        "method":"POST",
        "bodies":{
            'device_id': 'b',
            'os_type': 1,
            'user_id': user_id
        }
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response