from libs import tkpdhmac, ht

host_production = "https://booking.tokopedia.com"
host_staging = "https://booking-staging.tokopedia.com"

# Purpose : get events list on events homepage
# Required Params: host
# Optional Params: category
# Session: can be access with/out login, cookie is not mandatory, can be access with/out cookie
def api_h_event_v1(self, host, **kwargs):
    path = "/v1/api/h/event"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : get events list on events homepage
# Required Params: host
# Optional Params: category
# Session: can be access with/out login, cookie is not mandatory, can be access with/out cookie
def api_s_event_v1(self, host, **kwargs):
    path = "/v1/api/s/event"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : get details of an event
# Required Params: host, seo_url
# Session: can be access with/out login, cookie is not mandatory, can be access with/out cookie
def api_p_P_v1(self, host, seo_url, **kwargs):
    path = '/v1/api/p/' + seo_url
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : validate selection
# Required Params: host, category_id
# Optional Params: 
# Session: can be access with/out login, cookie is not mandatory, can be access with/out cookie
def api_event_validateSelection_v1(self, host, **kwargs):
    path = '/v1/api/event/validate-selection'
    default = {
        "method":"POST"
    }
    kwargs['headers'], kwargs['json'] = (kwargs.get('headers'), kwargs.get('json'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : get seat layout
# Required Params: host
def api_seatLayout_P_v1(self, host, path2, **kwargs):
    path = '/v1/api/seat-layout/' + path2
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response


# Purpose : verify a transaction
# Required Params: host
# Session: cannot be accessed without login
def api_expresscart_verify_v1(self, host, user_id, bearer_token, **kwargs):
    path = '/v1/api/expresscart/verify'
    default = {
        "method":"POST",
        "query":"book=true"
    }
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_event(kwargs.get('method', default['method']), path, user_id, bearer_token, kwargs.get('headers'), kwargs.get('json'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response


# Purpose : checkout a transaction
# Required Params: host
# Session: cannot be accessed without login
def api_expresscart_checkout_v1(self, host, user_id, bearer_token, **kwargs):
    path = '/v1/api/expresscart/checkout'
    default = {
        "method":"POST"
    }
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_event(kwargs.get('method', default['method']), path, user_id, bearer_token, kwargs.get('headers'), kwargs.get('json'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response