from libs import tkpdhmac, ht

host_production = "https://gw.tokopedia.com"
host_staging = "https://gw-staging.tokopedia.com"


def tokopoints_api_points_drawer_v1(self, host, user_id,device_id, **kwargs):
    path = "/tokopoints/api/v1/points/drawer"
    default = {
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def tokopoints_api_dv3points_drawer_v1(self, host, **kwargs):
    path        = "/tokopoints/api/v1/dv3points/drawer"
    response    = ht.call(self, host, path, **kwargs)
    return response

def sellerinfo_api_notification_v1(self, host, **kwargs):
    path        = "/sellerinfo/api/v1/notification"
    response    = ht.call(self, host, path, **kwargs)
    return response

def sellerinfo_api_info_list_v1(self, host, **kwargs):
    path        = "/sellerinfo/api/v1/info/list"
    response    = ht.call(self, host, path, **kwargs)
    return response

def sellerinfo_page(self, host, **kwargs):
    path        = "/seller-info.pl"
    response    = ht.call(self, host, path, **kwargs)
    return response

def rates_v1(self, host, device_id, user_id, **kwargs):
    path = '/rates/v1'
    default = {
        "method":"GET"
    }
    token, device_time = tkpdhmac.generate_kero_token(kwargs.get('method', default['method']), path)
    kwargs['query'] = "%s&token=%s&ut=%s" %(kwargs['query'] , token, device_time)
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_kero(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response


def rates_v2(self, host, device_id, user_id, **kwargs):
    path = '/v2/rates'
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response


def tokopoints_api_dv3points_main_v1(self, host, **kwargs):
    path = "/tokopoints/api/v1/dv3points/main"
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def tokopoints_api_dv3catalog_filter_v1(self, host, **kwargs):
    path = "/tokopoints/api/v1/dv3catalog/filter"
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def tokopoints_api_dv3catalog_list_v1(self, host, **kwargs):
    path = "/tokopoints/api/v1/dv3catalog/list"
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def tokopoints_api_dv3points_history_v1(self, host, **kwargs):
    path = "/tokopoints/api/v1/dv3points/history"
    default = {
        "method": "GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def tokopoints_api_dv3coupon_list_v1(self, host, **kwargs):
    path = "/tokopoints/api/v1/dv3coupon/list"
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response
