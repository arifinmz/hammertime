from libs import ht, tkpdhmac

host_production = "https://tome.tokopedia.com"
host_internal_1  = "http://172.21.42.22"
host_internal_2  = "http://172.21.45.18"
host_internal_3  = "http://172.21.45.17"
host_internal_4  = "http://172.21.44.245"
host_staging    = "https://tome-staging.tokopedia.com"

def product_P_v2_1 (self, host, product_id, **kwargs):
    path = "/v2.1/product/" + product_id
    response = ht.call (self, host, path, **kwargs)
    return response

def product_P_variant_v2 (self, host, product_id, **kwargs):
    path = "/v2/product/" + product_id + "/variant"
    print(host+path)
    response = ht.call (self, host, path, **kwargs)
    return response

def product_getSummary_v1 (self, host, **kwargs):
    path = "/v1/product/get_summary/"
    response = ht.call (self, host, path, **kwargs)
    return response

#session        : Session (require cookie)
#purpose        : get list of favorited shops
def webService_fav_shop_list_v1(self, host, **kwargs):
    path     = '/v1/web-service/fav_shop/list'
    default = {
        "query":"user_id=7490642"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to get product stock
# Session : no session
# Required Parameters : self, host, product_id
def product_P_stock_v2(self, host, product_id, **kwargs):
    path     = '/v2/product/'+product_id+'/stock'
    default = {
        'headers': {
            'origin':"https://www.tokopedia.com"
        }
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response


# Purpose : get product detail
# Session : no session
# Required Parameters : self, host, product_id
def product_P_v2(self, host, product_id, **kwargs):
    path       = '/v2/product/' + product_id
    default    = {
        "query":"p_id=36215174"
    }
    response   = ht.call(self, host, path, default=default, **kwargs)
    return response
    
#session        : 
#purpose        : 
def webService_product_getSummary_v1(self, host, **kwargs):
    path     = '/v1/product/get_summary'
    default = {
        "query":"product_id=7984268"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response
    

#session        : 
#purpose        : 
def webService_shop_getSummary_v1(self, host, **kwargs):
    path     = '/v1/shop/get_summary'
    default = {
        "query":"user_id=795901&domain=takeitorleaveit&shop_id=691551"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#session        : -
#purpose        : -
def shop_shopNote_v1(self, host, **kwargs):
    path     = '/v1/shop/shop_note'
    default = {
        "query":"shop_id=67726"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#session        : -
#purpose        : -
def shop_P_showcase_v2(self, host,shop_id, **kwargs):
    path     = '/v2/shop/'+shop_id+'/showcase'
    default = {
        "query":"shop_id="+shop_id
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response



#creator        : erlangga krisnamukti
#session        : Session
#purpose        : favorite/unfavorite shop
#required param : host
#optional param : 
def addFavorite(self, host, **kwargs):
   path = "/shop/favorite-shop"
   response = ht.call(self, host, path, **kwargs)
   return response

#creator        : erlangga krisnamukti
#session        : Session
#purpose        : ssi tome merchant
#required param : host
#optional param : 
def ssi_user_following_v1(self, host, **kwargs):
   path = "/v1/ssi/user/isfollowing"
   response = ht.call(self, host, path, **kwargs)
   return response

#session        : -
#purpose        : -
def shop_favorite_shop(self, host, **kwargs):
    path     = '/shop/favorite-shop?s_id=67726'
    response = ht.call(self, host, path, **kwargs)
    return response

def webService_shop_getShopInfo_v1(self, host, **kwargs):
    path = '/v1/web-service/shop/get_shop_info'
    response = ht.call(self, host, path, **kwargs)
    return response

def shop_getShopProduct_v1(self, host, **kwargs):
    path = '/v1/shop/get_shop_product'
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

