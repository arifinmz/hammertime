from libs import tkpdhmac, bearer_token, ht

host_production = "https://www.tokocash.com"
host_staging    = "https://wallet-staging.tokopedia.id"
host_oauth_production = "https://accounts.tokopedia.id"
host_oauth_staging = "https://accounts-staging.tokopedia.id"

# Creator: amadea
# Purpose: get wallet balance, use at desktop
# Description: for header need "Authorization" key from  token type bearer and access token)
# Session: after login
# Required parameters: host
# Optional parameters: method, name, headers
# Edited: erlangga (20170723: change bearer)
def api_wallet_balance_v1(self, host, **kwargs):
    path     = "/api/v1/wallet/balance"
    response = ht.call(self, host, path, **kwargs)
    return response

# Creator: amadea
# Purpose: get cashback balance, use at desktop
# Description: for header need user id, phone, environment (production or staging) to generate hmac. For query need msisdn (phone number)
# Session: after login
# Required parameters: host, user id, phone, env
# Optional parameters: method, name, headers, query
def api_me_cashback_balance_v1(self, host, user_id, phone, env, **kwargs):
    path     = '/api/v1/me/cashback/balance'
    default = {
        "query":"msisdn="+phone,
        "method":"GET"
    }
    kwargs['headers'] = tkpdhmac.generate_cashback(kwargs.get('method',default['method']), path, user_id, phone, env, kwargs.get('headers'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Creator: teukuzulfikar
# Purpose: get me balance, use at desktop
# Description: for header need "Authorization" key from otp (token type and access token)
# Session: after login
# Required parameters: host
def api_me_balance_v1(self, host, **kwargs):
    path     = "/api/v1/me/balance"
    response = ht.call(self, host, path, **kwargs)
    return response

# Creator: teukuzulfikar
# Purpose: get info of user, use frequently on tokocash.com
# Description: for header need "Authorization" key from otp (token type and access token)
# Session: after login
# Required parameters: host
def api_me_wallet_v1(self, host, **kwargs):
    path     = "/api/v1/me/wallet"
    response = ht.call(self, host, path, **kwargs)
    return response

# Creator: teukuzulfikar
# Purpose: get info of user, use frequently on tokocash.com
# Description: for header need "Authorization" key from otp (token type and access token)
# Session: after login
# Optional parameters: page, no_limit, type
# Required parameters: host
def api_me_history_v1(self, host, **kwargs):
    path     = "/api/v1/me/history"
    response = ht.call(self, host, path, **kwargs)
    return response

# Creator: teukuzulfikar
# Purpose: get access token of user
# Description: for header need "Authorization" key from Basic
# Session: after login
# Required parameters: grant_type, refresh_token
def oauth_token(self, host, **kwargs):
    path     = "/oauth/token"
    response = ht.call(self, host, path, **kwargs)
    return response