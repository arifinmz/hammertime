from libs import tkpdhmac, ht

host_production = "https://inbox.tokopedia.com"
host_staging    = "https://inbox-staging.tokopedia.com"

# Purpose : to read comments of the products
# Session : session is not needed
# Required Parameters : self, host, product_id, device_id, shop_domain, user_id,
# Optional Parameters : method, query, name, bodies
def talk_read_v2(self, host,  device_id, user_id, **kwargs):
    path = "/talk/v2/read"
    default = {
        "query":"product_id=177749132&device_id=b&per_page=10&os_type=1&shop_domain=74500&page=1&user_id=",
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : to read talk comments of the products V2
# Session : session is needed
# Required Parameters : self, host, shop_id, device_id, talk_id, user_id
# Optional Parameters : method, query, name, bodies
def talk_comment_v2(self, host, device_id, user_id, **kwargs):
    path = "/talk/v2/comment"
    default = {
        "query":"shop_id=74500&device_id=b&os_type=1&talk_id=119727565&page=1&user_id=",
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : to read talk comments of the products V1
# Session : session is needed
# Required Parameters : self, host, talk_id
# Optional Parameters : method, query, name
def talk_comment_v1(self, host, talk_list, **kwargs):
    path = "/talk/v1/comment/" + talk_list
    default = {
        "query":"type=multi"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : fernanda panca prima
#session        : No Session
#purpose        : function to get the talks of the shop
#required param : host
#optional param : method, query, headers, name
def talk_response_P_v1(self, host, shop_id, **kwargs):
    path = '/talk/v1/response/' + shop_id
    response = ht.call(self, host, path, **kwargs)
    return response

#creator        : rizal fauzi rahman
#session        : session
#purpose        : function to create talks of the shop
#required param : host
#optional param : method, query, headers, name
def talk_create_v1(self, host, **kwargs):
    path = '/talk/v1/create'
    default = {
        'method':'POST'
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : rizal fauzi rahman
#session        : session
#purpose        : function to create talks of the shop in android
#required param : host
#optional param : method, query, headers, name
def talk_create_v2(self, host, user_id, device_id, **kwargs):
    path = '/talk/v2/create'
    default = {
        'method':'POST'
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#creator        : fernanda panca prima
#session        : No Session
#purpose        : function to get the review and talk counts of a product
#required param : host
#optional param : method, query, headers, name
def review_productcount_P_v1(self, host, product_id, **kwargs):
    path = '/review/v1/productcount/'+product_id
    response = ht.call(self, host, path, **kwargs)
    return response

#session        : No Session
#purpose        : function to generate token to send talk
#required param : host
#optional param : method, query, headers, name
def token_generate_v1(self, host, **kwargs):
    path = "/token/v1/generate"
    response = ht.call(self, host, path, **kwargs)
    return response

#session        : No Session
#purpose        : function to get talk data
#required param : host, product_id
#optional param : method, query, headers, name
def talk_read_P_v1(self, host, product_id, **kwargs):
    path = "/talk/v1/read/" + product_id
    default = {
        "query":"master=0&page=1&sort=&talkId=&type=p"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : talk counter
# Session : no session
# Required Parameters : self, host, product_id
def talk_talkcount_P_v1(self, host, product_id, **kwargs):
    path        = '/talk/v1/talkcount/' + product_id
    response    = ht.call(self, host, path, **kwargs)
    return response

# Purpose : shop badge
# Session : no session
# Required Parameters : self, host, shop_id
def reputation_badge_shop_P_v1(self, host, shop_id, **kwargs):
    path        = '/reputation/v1/badge/shop/'+shop_id
    response    = ht.call(self, host, path, **kwargs)
    return response

#session        : No Session
#purpose        : function to get inbox data of a user in desktop
#required param : user_id, loadtest, talktype
#optional param : filter, start, platform, master
def talk_inbox_v1(self, host, user_id, device_id, **kwargs):
    path     = "/talk/v1/inbox"
    default = {
        "method" : "GET",
        "query" : "master=0&filter=all&talktype=inbox&start=0&platform=desktop&user_id=2684597&loadtest=2684597-0"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

#session        : No Session
#purpose        : function to get inbox data of a user in apps
#required param : user_id, loadtest, talktype, nav, device_id, os_type
#optional param : filter, page
def talk_inbox_v2(self, host, user_id, device_id, **kwargs):
    path = "/talk/v2/inbox"
    default = {
        "method" : "POST"
    }
    kwargs['headers'], kwargs['bodies'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('bodies'))
    response = ht.call(self, host, path, **kwargs)
    return response

#session        : No Session
#purpose        : function to get talk data in PDP apps
#required param : user_id, loadtest, talktype, nav, device_id, os_type
#optional param : filter, page
def talk_read_P_v2(self, host, **kwargs):
    path = "/talk/v2/read"
    query   = kwargs.get('query')
    default = {
        "method" : "GET",
        "query" : query
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Author: haries.efrika
# Purpose : list message topchat
# Session : session cookie
def message_inbox_v1(self, host, **kwargs):
    path        = '/message/v1/inbox'
    resp    = ht.call(self, host, path, **kwargs)
    return resp

