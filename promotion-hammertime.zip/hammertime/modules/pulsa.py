from libs import ht

host_production = "https://pulsa.tokopedia.com"
host_staging    = "https://pulsa-staging.tokopedia.com"

# Purpose : get user data on recharge
# Required Params: host
# Optional Params: headers, query
# Session: cannot be access without login
def login_ajax(self, host, **kwargs):
    path     = "/login/ajax"
    default = {
        "method":'GET'
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : get last order from favorite list
# Required Params: host
# Optional Params: headers
# Session: can be access with/out login
def favorite_lastOrders(self, host, **kwargs):
    path     = '/favorite/last-orders'
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : get order list in pulsa
# Required Params: host
# Optional Params: headers, query(action=get_deposit), name, method
# Session: can be access with/out login
def ajax_orderList(self, host, **kwargs):
    path     = '/ajax/order-list'
    default = {
        "query":"action=get_deposit"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : get last order in pulsa
# Required Params: host
# Optional Params: headers, query
# Session: can be access with/out login
def ajax_getlastorder(self, host, **kwargs):
    path     = "/ajax/getlastorder"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : get recharge widget on desktop
# Session : Not Required
# Required Parameters : self, host
# Optional Parameters : query, headers, name, method
def gtm_rechargeWidgetDesktop_v3(self, host, **kwargs):
    path     = "/gtm/recharge-widget-desktop-v3.js"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : get recharge widget on mobile web
# Description : need cookie if using session
# Session : before, after login
# Required Parameters : self, host
# Optional Parameters : query, headers, name, method
def gtm_rechargeWidgetMobile(self, host, **kwargs):
    path     = "/gtm/recharge-widget-mobile.js"
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : get instant checkout in pulsa
# Required Params: host
# Optional Params: headers, query(action=get_deposit), name, method
# Session: can be access with/out login
def instant_checkout(self, host, path, **kwargs):
    url = ht.make_url(host, path, **kwargs)
    response = ht.page(self, url, **kwargs)
    return response

# Purpose: get last order in pulsa/ home
def favorite_lastOrders(self, host, **kwargs):
    path = "/favorite/last-orders"
    default = {
        "method":"GET"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

    