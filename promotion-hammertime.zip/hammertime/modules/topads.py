from libs import tkpdhmac, ht

host_production = "https://ta.tokopedia.com"
host_staging    = "https://ta-staging.tokopedia.com"

# Purpose : Get user's hmac
# Session : logged in (with cookie)
# Required Parameters : self, host
# Optional Parameters : query, name, headers, method
def dashboard_hmac_v1(self, host, user_id, **kwargs):
    path     = '/v1/dashboard/hmac'
    default  = {
        'method':'GET',
        'query':'device=%27desktop%27&method=GET&url=%2Fv1.1%2Fdashboard%2Fdeposit&content=shop_id%3D962782%26shop_data%3D1'
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_topads(kwargs.get('method', default['method']),path, user_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : Get User TopAds Deposit
# Session : Logged In (with HMAC)
# Required Parameters : self, host, user_id
# Optional Parameters : query, name, headers
def dashboard_deposit_v1_1(self, host, user_id, **kwargs):
    path = '/v1.1/dashboard/deposit'
    default = {
        "method":"GET",
        "query":"shop_id=480044"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_topads(kwargs.get('method', default['method']), path, user_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : Get list of ads, can be product or shop ads
# Description : default ads parameter is for product
# Session : after login
# Required Parameters : self, host
# Accepted Optional Parameters : query, name, headers, method
def promo_display_ads_v1_1(self, host, **kwargs):
    path = '/promo/v1.1/display/ads'
    default = {
        "query":"src=fav_product&ep=product&item=6%2C2&device=desktop&page=1&user_id=9370471&dep_id=36"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : Get list of ads, can be product or shop ads with template id
# Description : default ads parameter is for product
# Session : after login
# Required Parameters : self, host
# Accepted Optional Parameters : query, name, headers, method
def promo_display_ads_v1_2(self, host, **kwargs):
    path = '/promo/v1.2/display/ads'
    default = {
        "query":"template_id=3%2C4&device=android&src=search&q=sorban&ep=cpm&item=1&page=1&user_id=7984268"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def promo_display_ads_v1_3(self, host, **kwargs):
    path = '/promo/v1.3/display/ads'
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : Get list of promoted products
# Description : default ads parameter is for product, need cookie and user id on the query if using session.
# Session : before, after login
# Required Parameters : self, host
# Accepted Optional Parameters : query, name, headers, method
def promo_display_products_v1_1(self, host, **kwargs):
    path = '/promo/v1.1/display/products'
    default = {
        "query":"q=kacamata&src=search&item=4&user_id=0&device=mobile"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : Get list of promoted shops
# Description : need cookie and user id on the query if using session.
# Session : after login
# Required Parameters : self, host
# Accepted Optional Parameters : query, name, headers, method
def promo_display_shops_v1(self, host, **kwargs):
    path = '/promo/v1/display/shops'
    default = {
        "query":"src=search&item=4&user_id=0&device=mobile&q=kacamata"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : Get random list of category(dept id) then return it the first data
# Session : required, need hmac tokopedia to generate headers
# Required Parameters : self, host, user_id, device_id
# Accepted Optional Parameters : query, name, headers, method
def promo_info_user_v1(self, host, user_id, device_id, **kwargs):
    path = "/promo/v1/info/user"
    default = {
        "headers": {
            'Tkpd-UserId' : user_id,
            'X-Device' : 'android',
            'Tkpd-SessionId' : 'aaaaaaa'
        },
        "method":"GET",
        "query":"pub_id=14"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate(kwargs.get('method', default['method']), path, user_id, device_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

# Purpose : Get js
# Description : js loaded in the first load time
# Session : before login
# Required Parameters : self, host
# Accepted Optional Parameters : method, name, headers
def plugin_js_display(self, host, **kwargs):
    path ='/plugin/js/display'
    response = ht.call(self, host, path, **kwargs)
    return response

# Purpose : Get product ads
# Description : need viewport to generate an advertisement
# Session : before, after login
# Required Parameters : self, host, viewport
# Accepted Optional Parameters : query, name, headers, method
def promo_views_P_v1(self, host, viewport, **kwargs):
    path = '/promo/v1/views/' + viewport
    response = ht.call(self, host, path, **kwargs)
    return response


def promo_clicks_P_v1(self, host, clickport, **kwargs):
    path ='/promo/v1/clicks/' + clickport
    response = ht.call(self, host, path, **kwargs)
    return response

def promo_group_v2_1(self, host, user_id, **kwargs):
    path = '/v2.1/promo/group'
    default = {
        "method":"POST"
    }
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_topads(kwargs.get('method', default['method']), path, user_id, kwargs.get('headers'), kwargs.get('json'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def promo_group_bulk_v2(self, host, user_id, **kwargs):
    path = '/v2/promo/group/bulk'
    default = {
        "method":"PATCH"
    }
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_topads(kwargs.get('method', default['method']), path, user_id, kwargs.get('headers'), kwargs.get('json'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def promo_bulk_v2(self, host, user_id, **kwargs):
    path = '/v2/promo/bulk'
    default = {
        "method":"PATCH"
    }
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_topads(kwargs.get('method', default['method']), path, user_id, kwargs.get('headers'), kwargs.get('json'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def promo_v2_1(self, host, user_id, **kwargs):
    path = '/v2.1/promo'
    default = {
        "method":"POST"
    }
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_topads(kwargs.get('method', default['method']), path, user_id, kwargs.get('headers'), kwargs.get('json'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def dashboard_tkpdProducts_v1_1(self, host, user_id, **kwargs):
    path = '/v1.1/dashboard/tkpd_products'
    default = {
        "method":"GET"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_topads(kwargs.get('method', default['method']), path, user_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def manage_cart_verifyVoucher_v2(self, host, user_id, **kwargs):
    path = '/v2/manage/cart/verify_voucher'
    default ={
        "method":"POST"
    }
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_topads(kwargs.get('method', default['method']), path, user_id, kwargs.get('headers'), kwargs.get('json'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def webService_shop_getEtalase_v1(self, host, **kwargs):
    path = '/v1/web-service/shop/get_etalase'
    default = {
        "query":"shop_id=480048"
    }
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def dashboard_searchProducts_v1_1(self, host, user_id, **kwargs):
    path = '/v1.1/dashboard/search_products'
    default = {
        'method':'GET',
        'query':'shop_id=480048&rows=50&is_promoted=1' 
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_topads(kwargs.get('method',default['method']), path, user_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def dashboard_searchGroups_v1_1(self, host, user_id, **kwargs):
    path = '/v1.1/dashboard/search_groups'
    default = {
        'method':'GET',
        'query':'shop_id=2664611&view_all=1&group_type=1'
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_topads(kwargs.get('method',default['method']), path, user_id, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response