from libs import tkpdhmac, ht

host_staging = "https://goldmerchant-staging.tokopedia.com"
host_production = "https://goldmerchant.tokopedia.com"


# ========= shops statistic druid =========
def shopStats_shopScoreSum_P_v1(self, host, shop_id, **kwargs):
    path = "/v1/shopstats/shopscore/sum/" + shop_id
    default = {
        "method":'GET'
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_goldmerchant(kwargs.get('method', default['method']), path, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def shopStats_getBuyerGraph_P_v2(self, host, shop_id, **kwargs):
    path = "/v2/shop_stats/get_buyer_graph/" + shop_id
    default = {
        "method":'GET',
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_goldmerchant(kwargs.get('method', default['method']), path, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def shopStats_getBuyerTable_P_v2(self, host, shop_id, **kwargs):
    path = "/v2/shop_stats/get_buyer_table/" + shop_id
    default = {
        "method":'GET'
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_goldmerchant(kwargs.get('method', default['method']), path, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def shopStats_getBuyerLocation_P_v2(self, host, shop_id, **kwargs):
    path = "/v2/shop_stats/get_buyer_location/" + shop_id
    default = {
        "method":'GET'
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_goldmerchant(kwargs.get('method', default['method']), path, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def shopStats_getTransactionGraph_P_v2(self, host, shop_id, **kwargs):
    path = "/v2/shop_stats/get_transaction_graph/" + shop_id
    default = {
        "method":'GET'
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_goldmerchant(kwargs.get('method', default['method']), path, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def shopStats_getTransactionStat_P_v2(self, host, shop_id, **kwargs):
    path = "/v2/shop_stats/get_transaction_stat/" + shop_id
    default = {
        "method":'GET'
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_goldmerchant(kwargs.get('method', default['method']), path, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def shopStats_getTransactionTable_P_v2(self, host, shop_id, **kwargs):
    path = "/v2/shop_stats/get_transaction_table/" + shop_id
    default = {
        "method":'GET'
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_goldmerchant(kwargs.get('method', default['method']), path, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def shopStats_getProductGraph_P_v2(self, host, shop_id, **kwargs):
    path = "/v2/shop_stats/get_product_graph/" + shop_id
    default = {
        "method":'GET'
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_goldmerchant(kwargs.get('method', default['method']), path, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def shopStats_getPopularProduct_P_v2(self, host, shop_id, **kwargs):
    path = "/v2/shop_stats/get_popular_product/" + shop_id
    default = {
        "method":'GET'
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_goldmerchant(kwargs.get('method', default['method']), path, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def shopStats_getProductTable_P_v2(self, host, shop_id, **kwargs):
    path = "/v2/shop_stats/get_product_table/" + shop_id
    default = {
        "method":'GET'
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_goldmerchant(kwargs.get('method', default['method']), path, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def product_video_v1(self, host, product_id, **kwargs):
    path = "/v1/product/video/" + product_id
    default = {
        "method":'GET'
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_goldmerchant(kwargs.get('method', default['method']), path, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def mobile_featuredProduct_P_v1(self, host, featured_product, **kwargs):
    path = "/v1/mobile/featured_product/"+featured_product
    default = {
        "method":"GET",
        "query" : "json=1"
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_goldmerchant(kwargs.get('method', default['method']), path, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response


def user_shop_P_v1(self, host, user_id, **kwargs):
    path = "/v1/user/"+ user_id +"/shop"
    default = {
        "method":"GET"    
    }
    kwargs['headers'], kwargs['query'] = tkpdhmac.generate_goldmerchant(kwargs.get('method', default['method']), path, kwargs.get('headers'), kwargs.get('query'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response

def tx_cashback_v1(self, host, **kwargs):
    path = "/v1/tx/cashback"
    default = {
        "method":"POST"    
    }
    kwargs['headers'], kwargs['json'] = tkpdhmac.generate_goldmerchant(kwargs.get('method', default['method']), path, kwargs.get('headers'), kwargs.get('json'))
    response = ht.call(self, host, path, default=default, **kwargs)
    return response
