import requests
import json

phone_number = raw_input('Enter phone number : ')
email = raw_input('email address: ')

while True:
    env = raw_input('choose environment (production/staging):')
    if env.upper() == 'PRODUCTION' :
        host = 'https://accounts.tokopedia.id'
        break;
    elif env.upper() == 'STAGING' :
        host = 'https://accounts-staging.tokopedia.id'
        break;
    else :
        print('choose between production/staging')

url = host+'/oauth/otp/request'
bodies = {
    'phone_number': phone_number
}
# Adding empty header as parameters are being sent in payload
headers = {'Authorization': 'Basic RzZUNkNWVFM4Yk1ZOnBKU1NYNDNjNHY4ZnRZODZSZmVMVVhkVGhYWDJCUVB0'}
r = requests.post(url, data=bodies, headers=headers)

print('Sending OTP to your phone. please check your phone.')
activation = raw_input('Enter activation code : ')
url = host+'/oauth/token'
headers = {'Authorization': 'Basic RzZUNkNWVFM4Yk1ZOnBKU1NYNDNjNHY4ZnRZODZSZmVMVVhkVGhYWDJCUVB0'}
bodies = {'grant_type':'password',
    'username':phone_number,
    'password': activation, #input this one, unfortunately no json for this
    'scope':'topcash:read,topcash:update,topcash:create',
    'identifier':email
    }
r = requests.post(url, data=bodies, headers=headers)
bearer = r.json()
returnString = bearer['token_type']+' '+bearer['access_token']
print(returnString)
