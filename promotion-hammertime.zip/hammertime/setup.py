# encoding: utf-8

from setuptools import setup, find_packages, Command
import sys, os, re, ast

setup(
    name='hammertime',
    version='0.1.0',
    description="Load Testing Framework by Dexter",
    long_description="""Hammertime is a project by Dexter Tokopedia to maintain performance test's test cases. Hammertime is using forked locust project with some powerful options to make your performance test experience better""",
    classifiers=[
        "Programming Language :: Python :: 2.7",
    ],
    keywords='',
    author='Fernanda Panca Prima, Lauren Vicky Calista, Rizal Fauzi Rahman, Amadea Kristina Budiman, Erlangga Krisnamukti',
    author_email='dexter@tokopedia.com',
    url='',
    license='',
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
    install_requires=["locustio==0.8.1", "beautifulsoup4==4.6.0", "avro==1.8.2"],
    dependency_links=["https://github.com/erlanggakrisnamukti/locust/archive/develop.zip#egg=locustio-0.8.1"]
)
