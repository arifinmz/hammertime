import random
import string

vowels = list('aeiou')

def generate_word(min, max):
  word = ''
  syllables = min + int(random.random() * (max - min))
  for i in range(0, syllables):
    word += _gen_syllable(i)
  return word.capitalize()

def _gen_syllable(num):
  if num % 2 == 0 :
    return _word_part('v')
  return _word_part('c')

def _word_part(type):
  if type is 'c':
    return random.sample([ch for ch in list(string.lowercase) if ch not in vowels], 1)[0]
  if type is 'v':
    return random.sample(vowels, 1)[0]