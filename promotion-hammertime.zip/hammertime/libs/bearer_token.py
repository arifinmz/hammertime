host_production = 'https://accounts.tokopedia.com'
host_staging    = 'https://accounts-staging.tokopedia.com'
host_staging_oauth = 'https://accounts-staging.tokopedia.id'

# Purpose: generate bearer token
# Session: before login
# Required parameters: host
# Optional parameters: bodies
def generate(self, host, **kwargs):
    method  = 'POST'
    path     = '/token'

    global host_staging, host_production
    bearer_host = ''
    if(host.find('staging') != -1):
        bearer_host = host_staging
    else:
        bearer_host = host_production

    url     = bearer_host+path
    headers = {
        'authorization':'Basic MTAwMTo3YzcxNDFjMTk3Zjg5Nzg3MWViM2I1YWY3MWU1YWVjNzAwMzYzMzU1YTc5OThhNGUxMmMzNjAwYzdkMzE='
    }
    user_data = kwargs.get('bodies', {})
    response  = self.client.request(method, url, data=user_data, headers=headers, name=url, catch_response=True)

    if response.status_code == 200:
        try:
            bearer = response.json()
            if "access_token" in bearer :
                response.success()
                return bearer['token_type']+' '+bearer['access_token']
            # else:
            #     raise AssertionError("failed to get token, probably reached get token limit")
        except Exception, e:
            print(response.content)
            # response.failure(response.content)
    # else:
    #     try :
    #         response.raise_for_status()
    #     except Exception, e:
    #         response.failure(e)
    return ''

