import logging
import ht
from datetime import datetime, timedelta

STATE_OPEN = 'open'
STATE_CLOSED = 'closed'
STATE_HALF_OPEN = 'half-open'

cb_time_window = 15
cb_cooldown = 120
cb_threshold = 0

# Circuit Breaker Implementation for locust
# Inspired by danielfm https://github.com/danielfm/pybreaker
def is_allowed(self, url, cb_api_list, **kwargs):
    if not kwargs.get('cb_threshold') : return True
    method_url = kwargs.get('method', "GET") + ht._generate_name(url, **kwargs)
    
    if not method_url in cb_api_list :
        cb_api_list[method_url] = DexterCircuitBreaker(cooldown=kwargs.get('cb_cooldown',cb_cooldown), reset_timeout=kwargs.get('cb_time_window',cb_time_window), error_ratio=kwargs.get('cb_threshold', cb_threshold), method_url=method_url)
    cb_api = cb_api_list[method_url]

    # Codeblock for half open and change status
    if cb_api.is_cooldown_time_passed():
        response = ht.hit(self, url, **kwargs)
        if ht._is_failure_status_code(response, **kwargs) :
            cb_api.state = STATE_OPEN
            cb_api.opened_at = datetime.now()
            return False
        else :
            cb_api.state = STATE_HALF_OPEN
            cb_api.reset_time_window(cb_api._half_open_time_window)
            cb_api.opened_at = None
            return True
    elif (cb_api.state == STATE_CLOSED) or (cb_api.state == STATE_HALF_OPEN):
        return True
    return False

class DexterCircuitBreaker(object):
    
    logger = logging.getLogger(__name__)
    
    def __init__(self, cooldown=cb_cooldown, reset_timeout=cb_time_window, error_ratio=cb_threshold, method_url=""):
        self._reset_timeout = reset_timeout
        self._cooldown = cooldown
        self._fail_counter = 0
        self._hit_counter = 0
        self._initial_time_window = reset_timeout
        self._state = STATE_CLOSED 
        self._opened_at = None
        self._method_url = method_url
        self._error_ratio = error_ratio
        self._created_time = datetime.now()
        self._time_window_end = self._created_time + timedelta(seconds = self._reset_timeout)
        self._half_open_time_window = 3

    @property
    def error_ratio(self):
        """
        error_ratio property.
        """
        return self._error_ratio

    @error_ratio.setter
    def error_ratio(self, value):
        self._error_ratio = value

    @property
    def initial_time_window(self):
        """
        initial_time_window property.
        """
        return self._initial_time_window

    @initial_time_window.setter
    def initial_time_window(self, value):
        self._initial_time_window = value

    @property
    def method_url(self):
        """
        method_url property.
        """
        return self._method_url

    @method_url.setter
    def method_url(self, value):
        self._method_url = value

    @property
    def reset_timeout(self):
        """
        reset timeout property.
        """
        return self._reset_timeout

    @reset_timeout.setter
    def reset_timeout(self, value):
        self._reset_timeout = value

    @property
    def fail_counter(self):
        """
        fail counter property.
        """
        return self._fail_counter

    @fail_counter.setter
    def fail_counter(self, value):
        self._fail_counter = value

    @property
    def hit_counter(self):
        """
        hit counter property.
        """
        return self._hit_counter

    @hit_counter.setter
    def hit_counter(self, value):
        self._hit_counter = value

    @property
    def state(self):
        """
        state property.
        """
        return self._state

    @state.setter
    def state(self, value):
        self._state = value

    @property
    def cooldown(self):
        """
        Returns cooldown time for checking half open.
        """
        return self._cooldown

    @cooldown.setter
    def cooldown(self, datetime):
        """
        Sets cooldown time.
        """
        self._cooldown = datetime

    @property
    def opened_at(self):
        """
        Returns the most recent value of when the circuit was opened.
        """
        return self._opened_at

    @opened_at.setter
    def opened_at(self, datetime):
        """
        Sets the most recent value of opened_at.
        """
        self._opened_at = datetime

    @property
    def time_window_end(self):
        """
        Returns the most recent value when time_window ends.
        """
        return self._time_window_end

    @time_window_end.setter
    def time_window_end(self, datetime):
        """
        Sets the most recent value of time_window_end.
        """
        self._time_window_end = datetime

    def increment_fail_counter(self):
        """
        Increases the failure counter by one.
        """
        self._fail_counter += 1

    def reset_fail_counter(self):
        """
        Reset fail counter when response is ok
        """
        self._fail_counter = 0

    def increment_hit_counter(self):
        """
        Increases the hit counter by one.
        """
        self._hit_counter += 1

    def reset_hit_counter(self):
        """
        Reset hit counter when response is ok
        """
        self._hit_counter = 0

    def is_time_window_passed(self, **kwargs):
        """
        check wether this current time is already passed window time or not
        """
        if kwargs.get('now',datetime.now()) > self._time_window_end:
            return True
        return False

    def is_cooldown_time_passed(self):
        """
        check wether this object time is already passed or not
        """

        # checking if the cb is in open state
        if self.opened_at is None : 
            return False

        # checking if cooldown time has passed
        time = self._opened_at
        if datetime.now() > (time + timedelta(seconds = self._cooldown)):
            return True
        return False

    def reset_time_window(self, value):
        self._reset_timeout = value
        self._time_window_end = datetime.now() + timedelta(seconds=int(self._reset_timeout))

class CBException():

    def __init__(self):
        self.status_code = -1

    def raise_for_status(self):
        raise Exception("Hammertime circuit breaker turned on")

    def success(self):
        pass
    
    def failure(self, *args):
        pass
