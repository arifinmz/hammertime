from functools import wraps

class UserConversion:
  '''
  Class to use convertion rate of your function
  How to use:
    1. import this module. i.e: from libs import user_conversion
    2. create instance of it. i.e: uc = user_conversion.UserConversion(0.2)
    3. add decorator @attempt(total_user) to your function definition. i.e:
        @uc.attempt(1000)
        def your_function():
          pass
        your_function()  
  '''
  
  def __init__(self, threshold=1):
    '''
    threshold will become 1 if threshold not specified
    '''
    self._threshold = threshold
    self._converted_user = 0
  
  def attempt(self, total_user):
    '''
    function decorator to execute decorated function if converted user is still under threshold.
    i.e: 
      uc = UserConvertion(0.2)

      @uc.attempt(1000)
      def your_function():
        pass
      your_function()  
    '''
    def func_wrapper(func):
      @wraps(func)
      def wrapper(*args, **kwargs):
        if total_user <= 0 : return
        current_rate = float(self._converted_user)/float(total_user)
        if current_rate <= self._threshold and self._threshold > 0 : 
          self.converted_user_increase()
          func(*args, **kwargs)
          self.converted_user_decrease()
      return wrapper
    return func_wrapper

  def possible_to_convert(self, total_user):
    '''
    function to see if convertion is still possible
    '''
    if total_user <= 0 : return False
    current_rate = float(self._converted_user)/float(total_user)
    if current_rate <= self._threshold and self._threshold > 0 : 
      return True
    return False

  @property
  def converted_user(self):
    '''
    get current amount of current converted user
    '''
    return self._converted_user

  @converted_user.setter
  def converted_user(self, value):
    '''
    set current amount of current converted user
    '''
    self._converted_user = value
  
  def converted_user_increase(self):
    '''
    add user to current converted user (+1)
    '''
    self._converted_user += 1

  def converted_user_decrease(self):
    '''
    release user from converted user (-1)
    '''
    self._converted_user -= 1

  def converted_user_reset(self):
    '''
    reset current converted user to 0
    '''
    self._converted_user = 0

  @property
  def max_threshold(self):
    '''
    get maximum threshold of converted user
    '''
    return self._threshold

  @max_threshold.setter
  def max_threshold(self, value):
    '''
    set maximum threshold of converted user
    '''
    self._threshold = value

  def max_threshold_reset(self):
    '''
    reset maximum threshold of converted user
    '''
    self._threshold = 0
