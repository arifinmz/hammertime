import hashlib
import hmac
import base64
import time
import datetime, json, random, string
try:
    from urllib.parse import urlencode
except Exception as e:
    from urllib import urlencode


key = 'web_service_v4'

def generate(method,path,user_id,device_id,headers,bodies):
    '''
    Set Headers and Bodies with WSAuth signature
    '''
    hash_string = '%s~%s' % (user_id,device_id)
    hash_string = hashlib.md5(hash_string.encode()).hexdigest()
    device_time = int(round(time.time()))
    additional_hash_param = '&hash=%s&device_time=%s'% (hash_string,device_time)
    if method.upper() == 'POST' :
        bodies = bodies if bodies is not None else {}
        bodies_query_string = urlencode(bodies)
        content_type = 'application/x-www-form-urlencoded'
    else :
        bodies = bodies if bodies is not None else ''
        bodies_query_string = bodies
        content_type = ''
    hash_header = '%s%s' % (bodies_query_string,additional_hash_param)
    content_md5 = hashlib.md5(hash_header.encode()).hexdigest()
    date = time.strftime('%a, %d %b %Y %H:%M:%S %z')
    hmac_message = '%s\n%s\n%s\n%s\n%s' % (method,content_md5,content_type,date,path)
    global key
    digest_result = _make_digest(hmac_message,key)
    signature = 'TKPD Tokopedia:'+digest_result
    headers = headers if headers is not None else {}
    headers['Authorization'] = signature
    headers['X-Method'] = method
    headers['Content-MD5'] = content_md5
    headers['Date'] = date

    if method.upper() == 'POST' :
        bodies['hash'] = hash_string
        bodies['device_time'] = device_time
    else :
        bodies = hash_header
    return headers, bodies

def generate_goldmerchant(method,path,headers,query):
    '''
    Set Headers and Bodies with WSAuth signature
    '''
    if method.upper() == 'POST' :
       query = query if query is not None else {}
       query_string = urlencode(query)
       content_type = 'application/x-www-form-urlencoded'
    else :
       query = query if query is not None else ''
       query_string = query
       content_type = ''


    hash_header = '%s' % (query_string)
    content_md5 = hashlib.md5(hash_header.encode()).hexdigest()
    date = time.strftime('%a, %d %b %Y %H:%M:%S %z')
    hmac_message = '%s\n%s\n%s\n%s\n%s' % (method,content_md5,content_type,date,path)
    global key
    digest_result = _make_digest(hmac_message,key)
    signature = 'TKPD Tokopedia:'+digest_result
    headers = headers if headers is not None else {}

    headers['X-TKPD-Authorization'] = signature
    headers['X-Method'] = method
    headers['Content-MD5'] = content_md5
    headers['X-Date'] = date

    return headers, query

def generate_topads(method,path,user_id,headers,bodies):
    '''
    Set Headers and Bodies with WSAuth signature for TopAds services
    '''
    if method.upper() == 'POST' :
        bodies = bodies if bodies is not None else {}
        bodies_query_string = urlencode(bodies)
        content_type = 'application/json'
    elif method.upper() == 'PATCH':
        bodies = bodies if bodies is not None else {}
        bodies_query_string = urlencode(bodies)
        content_type = ''
    else :
        bodies = bodies if bodies is not None else ''
        bodies_query_string = bodies
        content_type = ''
    content_md5 = hashlib.md5(bodies_query_string.encode()).hexdigest()
    date = time.strftime('%d %b %y %H:%M %z')
    hmac_message = '%s\n%s\n%s\n%s\nx-tkpd-userid:%s\n%s' % (method,content_md5,content_type,date,user_id,path)
    global key
    digest_result = _make_digest(hmac_message,key)
    signature = 'TKPD Tokopedia:'+digest_result
    headers = headers if headers is not None else {}
    headers['Authorization'] = signature
    headers['X-Method'] = method
    headers['Content-MD5'] = content_md5
    headers['X-Date'] = date
    headers['X-Tkpd-UserId'] = user_id

    return headers, bodies

def generate_pulsa(method, path, user_id, headers, bodies):
    '''
    Set Headers and Bodies with WSAuth signature for Pulsa services
    '''
    device_time = int(round(time.time() * 1000)) # return in miliseconds
    if method.upper() == 'POST' :
        bodies = bodies if bodies is not None else {}
        bodies_query_string = json.dumps(bodies)
        content_type = 'application/json'
    else :
        bodies = bodies if bodies is not None else ''
        bodies_query_string = bodies
        content_type = ''
        hash_string = hashlib.md5(user_id.encode()).hexdigest()
        bodies_query_string = '%s&hash=%s&device_time=%s'% (bodies_query_string,hash_string,device_time)
    content_md5 = hashlib.md5(bodies_query_string.encode()).hexdigest()
    date = time.strftime('%a, %d %b %Y %H:%M:%S %z')
    hmac_message = '%s\n%s\n%s\n%s\nx-tkpd-userid:%s\n%s' % (method,content_md5,content_type,date,user_id,path)
    global key
    digest_result = _make_digest(hmac_message,key)
    signature = 'TKPD Tokopedia:'+digest_result
    headers = headers if headers is not None else {}
    headers['Authorization'] = signature
    headers['Content-MD5'] = content_md5
    headers['Date'] = date
    headers['X-Method'] = method
    headers['X-Tkpd-UserId'] = user_id

    if method.upper() == 'POST' :
        pass
    else :
        bodies = bodies_query_string
    return headers, bodies

def generate_mojito(method,path,user_id,device_id,headers,bodies):
    '''
    Set Headers and Bodies with WSAuth signature for Mojito services
    '''
    hash_string = '%s~%s' % (user_id,device_id)
    hash_string = hashlib.md5(hash_string.encode()).hexdigest()
    device_time = int(round(time.time() * 1000))
    additional_hash_param = '&hash=%s&device_time=%s'% (hash_string,device_time)
    if method.upper() == 'POST' or method.upper() == 'DELETE':
        bodies = bodies if bodies is not None else {}
        bodies_query_string = urlencode(bodies)
        content_type = 'application/x-www-form-urlencoded'
    else :
        bodies = bodies if bodies is not None else ''
        bodies_query_string = bodies
        content_type = 'application/json'
    hash_header = '%s%s' % (bodies_query_string,additional_hash_param)
    content_md5 = hashlib.md5(hash_header.encode()).hexdigest()
    date = time.strftime('%a, %d %b %Y %H:%M:%S %z')
    hmac_message = '%s\n%s\n%s\n%s\n%s' % (method,content_md5,content_type,date,path)
    digest_result = _make_digest(hmac_message,"mojito_api_v1")
    signature = 'TKPD Tokopedia:'+digest_result
    headers = headers if headers is not None else {}
    headers['Authorization'] = signature
    headers['X-Method'] = method
    headers['Content-MD5'] = content_md5
    headers['X-Date'] = date
    headers['X-User-ID'] = user_id
    headers['Content-Type'] = content_type

    if method.upper() == 'POST' or method.upper() == 'DELETE':
        bodies['hash'] = hash_string
        bodies['device_time'] = device_time
    else :
        bodies = '%s%s' % (bodies,additional_hash_param)
    return headers, bodies

def generate_cashback(method,path,user_id,msisdn,env,headers):
    '''
    Set Headers and Bodies with WSAuth signature for Cashback services
    '''
    if method.upper() == 'POST' :
        content_type = 'application/x-www-form-urlencoded'
    else :
        content_type = ''

    if env.lower() == 'production' :
        key = 'CPAnAGpC3NIg7ZSj'
    else :
        key = 'cSPkELXf2GVk4pnT'

    content_md5 = ''
    date = time.strftime('%a, %d %b %Y %H:%M:%S %z')
    hmac_message = '%s\n%s\n%s\n%s\nx-tkpd-userid:%s\nx-msisdn:%s\n%s' % (method,content_md5,content_type,date,str(user_id),str(msisdn),path)

    digest_result = _make_digest(hmac_message,key)
    signature = 'TKPD Tokopedia:'+digest_result
    headers = headers if headers is not None else {}
    headers['Authorization'] = signature
    headers['Date'] = date
    headers['X-Tkpd-UserId'] = str(user_id)
    headers['X-Msisdn'] = str(msisdn)

    return headers

def generate_flight(method, path, user_id, device_id, headers, bodies):
    '''
    Set Headers and Bodies with WSAuth signature for Flight services
    '''
    if method.upper() == 'POST' :
        bodies = bodies if bodies is not None else {}
        bodies_query_string = json.dumps(bodies)
        content_type = 'application/json'
    else :
        bodies = bodies if bodies is not None else ''
        bodies_query_string = bodies
        content_type = ''
        bodies_query_string = '%s'% (bodies_query_string)
    content_md5 = hashlib.md5(bodies_query_string.encode()).hexdigest()
    date = time.strftime('%a, %d %b %Y %H:%M:%S %z')
    hmac_message = '%s\n%s\n%s\n%s\nx-tkpd-userid:%s\n%s' % (method,content_md5,content_type,date,user_id,path)
    global key
    digest_result = _make_digest(hmac_message,key)
    signature = 'TKPD Tokopedia:'+digest_result
    headers = headers if headers is not None else {}
    if method.upper() == 'POST' :
        headers['content-type'] = content_type
    headers['Authorization'] = signature
    headers['Content-MD5'] = content_md5
    headers['Date'] = date
    headers['X-Method'] = method
    headers['X-Tkpd-UserId'] = user_id
    headers['Tkpd-SessionId'] = device_id
    headers['os-type'] = '1'

    if method.upper() == 'POST' :
        pass
    else :
        bodies = bodies_query_string

    return headers, bodies

def generate_spike(method,path,user_id,device_id,platform, headers,bodies):
    '''
    Set Headers and Bodies with WSAuth signature
    '''
    hash_string = '%s~%s' % (user_id,device_id)
    hash_string = hashlib.md5(hash_string.encode()).hexdigest()
    device_time = int(round(time.time()))
    additional_hash_param = '&hash=%s&device_time=%s'% (hash_string,device_time)
    if method.upper() == 'POST' :
        bodies = bodies if bodies is not None else {}
        bodies_query_string = urlencode(bodies)
        content_type = 'application/x-www-form-urlencoded'
    else :
        bodies = bodies if bodies is not None else ''
        bodies_query_string = bodies
        content_type = ''
    hash_header = '%s%s' % (bodies_query_string,additional_hash_param)
    content_md5 = hashlib.md5(hash_header.encode()).hexdigest()
    date = time.strftime('%a, %d %b %Y %H:%M:%S %z')
    hmac_message = '%s\n%s\n%s\n%s\n%s' % (method,content_md5,content_type,date,path)
    global key
    digest_result = _make_digest(hmac_message,key)
    signature = 'TKPD Tokopedia:'+digest_result
    headers = headers if headers is not None else {}
    headers['Authorization'] = signature
    headers['X-Method'] = method
    headers['Content-MD5'] = content_md5
    headers['Date'] = date
    return headers, bodies

def generate_sauron_token(method, path, user_id, headers, bodies):
    '''
    Note: user_id should be empty
    '''
    secret = "ProjectSauron"
    device_time = int(time.time())
    if method.upper() == 'POST' :
        bodies = bodies if bodies is not None else {}
        bodies_query_string = json.dumps(bodies)
        content_md5 = hashlib.md5(bodies_query_string.encode()).hexdigest()
        content_type = 'application/json'
    else :
        bodies = bodies if bodies is not None else ''
        bodies_query_string = bodies
        content_type = ''
        content_md5 = ''
    hmac_message = '%s\n%s\n%s\n%s\n%s%s' % (method,content_md5,content_type,device_time,user_id,path)
    digest_result = _make_digest(hmac_message,secret)
    signature = 'Tokopedia Watchtower:'+digest_result
    if method.upper() == 'POST' :
        headers['Authorization'] = signature
        headers['Content-Type'] = content_type
        headers['Content-MD5'] = content_md5
        headers['Date'] = str(device_time)
    else :
        bodies = "token=%s&ut=%s&%s" % (signature,device_time,bodies_query_string)
    return headers, bodies


def _make_digest(message, key):
    '''
    Generate HMAC SHA1 signature
    '''
    key = key
    message = message
    digester = hmac.new(key, msg=message, digestmod=hashlib.sha1)
    signature = base64.b64encode(digester.digest())
    return signature
    
def generate_kero(method,path,user_id,device_id,headers,bodies):
    '''
    Set Headers and Bodies with WSAuth signature
    '''
    hash_string = '%s~%s' % (user_id,device_id)
    hash_string = hashlib.md5(hash_string.encode()).hexdigest()
    device_time = int(round(time.time()))
    additional_hash_param = '&hash=%s&device_time=%s'% (hash_string,device_time)
    if method.upper() == 'POST' :
        bodies = bodies if bodies is not None else {}
        bodies_query_string = urlencode(bodies)
        content_type = 'application/x-www-form-urlencoded'
    else :
        bodies = bodies if bodies is not None else ''
        bodies_query_string = bodies
        content_type = ''
    hash_header = '%s%s' % (bodies_query_string,additional_hash_param)
    content_md5 = hashlib.md5(hash_header.encode()).hexdigest()
    date = time.strftime('%a, %d %b %Y %H:%M:%S %z')
    hmac_message = '%s\n%s\n%s\n%s\n%s' % (method,content_md5,content_type,date,path)
    global key
    digest_result = _make_digest(hmac_message,key)
    signature = 'TKPD Tokopedia:'+digest_result
    headers = headers if headers is not None else {}
    headers['Authorization'] = signature
    headers['X-Method'] = method
    headers['Content-MD5'] = content_md5
    headers['Date'] = date

    if method.upper() == 'POST' :
        bodies['hash'] = hash_string
        bodies['device_time'] = device_time
    else :
        bodies = hash_header
    return headers, bodies

def generate_kero_token(method, path):
    key = 'Keroppi'
    device_time = int(round(time.time()))
    custom_header = ''
    content_md5 = ''

    if method.upper() == 'POST' :
        content_type = 'application/x-www-form-urlencoded'
    else :
        content_type = ''
    hmac_message = '%s\n%s\n%s\n%d\n%s%s' % (method,content_md5,content_type,device_time,custom_header,path)
    digest_result = _make_digest(hmac_message,key)
    signature = 'Tokopedia+Kero:'+digest_result
    return signature, device_time

def random_generator(size=6, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))

def generate_event(method, path, user_id, bearer_token, headers, bodies):

    if method.upper() == 'POST' :
        bodies = bodies if bodies is not None else {}
        bodies_query_string = json.dumps(bodies)
        content_type = 'application/json'
    else :
        bodies = bodies if bodies is not None else ''
        bodies_query_string = bodies
        content_type = ''
    signature = bearer_token
    headers = headers if headers is not None else {}
    if method.upper() == 'POST' :
        headers['content-type'] = content_type
    headers['Authorization'] = signature
    headers['Tkpd-UserId'] = user_id

    if method.upper() == 'POST' :
        pass
    else :
        bodies = bodies_query_string

    return headers, bodies

def generate_chat(method, path, user_id, device_id, headers, bodies):
    '''
    Copied from flight, works for Chat
    '''
    if method.upper() == 'POST' :
        bodies = bodies if bodies is not None else {}
        bodies_query_string = json.dumps(bodies)
        content_type = 'application/json'
    else :
        bodies = bodies if bodies is not None else ''
        bodies_query_string = bodies
        content_type = ''
        bodies_query_string = '%s'% (bodies_query_string)
    content_md5 = hashlib.md5(bodies_query_string.encode()).hexdigest()
    date = time.strftime('%a, %d %b %Y %H:%M:%S %z')
    hmac_message = '%s\n%s\n%s\n%s\nx-tkpd-userid:%s\n%s' % (method,content_md5,content_type,date,user_id,path)
    global key
    digest_result = _make_digest(hmac_message,key)
    signature = 'TKPD Tokopedia:'+digest_result
    headers = headers if headers is not None else {}
    if method.upper() == 'POST' :
        headers['content-type'] = content_type
    headers['Authorization'] = signature
    headers['Content-MD5'] = content_md5
    headers['Date'] = date
    headers['X-Method'] = method
    headers['X-Tkpd-UserId'] = user_id
    headers['Tkpd-SessionId'] = device_id
    headers['os-type'] = '1'

    if method.upper() == 'POST' :
        pass
    else :
        bodies = bodies_query_string

    return headers, bodies
