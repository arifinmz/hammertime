import re
import htcircuit
from bs4 import BeautifulSoup
from datetime import datetime, timedelta

cb_api_list = {}

def call(self, host, path, **kwargs):
    '''
    Function to simply make a locust request
      - auto check the `default` kwarg
      - auto make url
      - auto call your request
      - auto check circuit breaker
    '''
    if (kwargs.get('default')) : kwargs = _check_values(kwargs.get('default'), **kwargs)
    url = make_url(host, path, **kwargs)
    if htcircuit.is_allowed(self, url, cb_api_list, **kwargs) :
        response = hit(self, url, **kwargs)
    else :
        response = htcircuit.CBException()
    return response

def make_url(host, path, **kwargs):
    '''
    function to generate url from given host, path, and query if exist
    '''
    protocol  = kwargs.get('protocol', "https")
    query     = kwargs.get('query', None)

    protocolRegex = re.compile('^http.*')
    if protocolRegex.search(host) is False : host = protocol + "://" + host
    url  = host + path + "?" + query if query else host + path
    return url

def hit(self, url, **kwargs):
    '''
    Basic Function for each locust request
    '''
    request_kwargs = _prepare_request_kwargs(url, **kwargs)
    if kwargs.get('method') : method = kwargs.get('method')
    elif kwargs.get('json') : method = 'POST'
    else : method = 'GET' if request_kwargs.get('data') is None else 'POST'
    response = self.client.request(method, url, **request_kwargs)
   
    # check circuit breaker
    _htcircuit_check(method, url, response, **request_kwargs)
    
    # print failed request
    if _is_failure_status_code(response, **request_kwargs) :
        print("[%s] %s" % (response.status_code, request_kwargs.get('name')), response.content)

    return response

def page(self, url, **kwargs):
    '''
    Function to call page
    Page has static assets, with this call you can pass kwargs 'assets' as True if you want to also load the static assets
    '''
    response = hit(self, url, **kwargs)
    assets = kwargs.get('assets', False)
    if assets:
        #Load all src
        soup = BeautifulSoup(response.text, "html.parser")
        res_assets = list()
        for y in soup.find_all(src=re.compile('^http.*')):
            url = y['src']
            res_assets.append(hit(self, url))

        # Load Header Sources
        head = soup.head
        for x in head.find_all(href=re.compile('^http.*')):
            url = x['href']
            res_assets.append(hit(self, url))
        return response, res_assets
    else : return response

def _prepare_request_kwargs(url, **kwargs):
    '''
    function to prepare all kwargs passed for locust request
    '''
    request_kwargs = {}
    locust_acceptable_keys = ['data','headers','cookies','params','catch_response','files','auth','timeout','allow_redirects','proxies','stream','verify','cert','json']
    for locust_acceptable_key in locust_acceptable_keys:
        if kwargs.get(locust_acceptable_key) : request_kwargs[locust_acceptable_key] = kwargs.get(locust_acceptable_key)
    if kwargs.get('bodies') : request_kwargs['data'] = kwargs.get('bodies')
    request_kwargs['name'] = _generate_name(url, **kwargs)
    request_kwargs = _check_user_agent(request_kwargs)
    return request_kwargs

def _check_values(defaultValues, **kwargs):
    '''
    Check the default value of each module.
    if user doesn't fill the value that should be filled, system fills the value with the value inside defaultValues
    Support two dimensional dictionary
    '''
    options = kwargs
    for key in defaultValues :
        options[key] = kwargs.get(key,defaultValues[key])
        if (type(defaultValues[key]) == type(dict())):
            for subkey in defaultValues[key]:
                if not options[key].has_key(subkey) : options[key][subkey] = defaultValues[key][subkey]
    return options

def _generate_name(url, **kwargs):
    '''
    Generate display name of the API
    '''
    return kwargs.get('name', url.replace("?"+kwargs.get('query'), "") if kwargs.get('hide_query') is True else url)

def _is_failure_status_code(response, **kwargs):
    '''
    Check if status code from response is success or not
    '''
    if response.status_code >= 400 or response.status_code == 0 :
        return True
    return False

def _htcircuit_check(method, url, response, **kwargs):
    '''
    check and handle the circuit breaker state of the called API
    '''
    method_url = method + _generate_name(url, **kwargs)
    now = datetime.now()

    #check if this endpoint has circuit breaker
    if method_url in cb_api_list :
        cb_api = cb_api_list[method_url]
        cb_api.increment_hit_counter()
        if _is_failure_status_code(response, **kwargs) :
            cb_api.increment_fail_counter()
        if cb_api.is_time_window_passed(now=now) :
            too_many_errors = (float(cb_api.fail_counter)/float(cb_api.hit_counter) > float(cb_api.error_ratio))
            cb_api.reset_hit_counter()
            cb_api.reset_fail_counter()
            if cb_api.state == htcircuit.STATE_HALF_OPEN:
                if too_many_errors :
                    cb_api.state = htcircuit.STATE_OPEN
                    cb_api.opened_at = now
                else :
                    cb_api.state = htcircuit.STATE_CLOSED
                    cb_api.reset_time_window(cb_api.initial_time_window)
            elif cb_api.state == htcircuit.STATE_CLOSED:
                if too_many_errors :
                    cb_api.state = htcircuit.STATE_OPEN
                    cb_api.opened_at = now
                else :
                    cb_api.reset_time_window(cb_api.initial_time_window)
 
def _check_user_agent(request):
    user_agent_key = 'User-Agent'
    user_agent_root = 'headers'
    default_user_agent = 'dexter/hammertime'
    if not user_agent_root in request :
        request[user_agent_root] = {}
    if not user_agent_key in request[user_agent_root] :
        request[user_agent_root][user_agent_key] = default_user_agent
    return request
